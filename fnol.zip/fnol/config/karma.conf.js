/// <reference path="../src/common/Confirmation-Question/ConfirmationQuestionController.js" />
/// <reference path="../src/common/shell/shellController.js" />
/// <reference path="../tests/jasmine/jasmine-html.js" />
/// <reference path="../tests/jasmine/jasmine-html.js" />
/// <reference path="../tests/jasmine/jasmine.js" />
// Karma configuration
// Generated on Wed april 27 2016 (Pacific Daylight Time)

module.exports = function (config) {
    config.set({

        // base path that will be used to resolve all patterns (eg. files, exclude)

        basePath: '',


        // frameworks to use
        // available frameworks: https://npmjs.org/browse/keyword/karma-adapter
        frameworks: ['jasmine'],


        // list of files / patterns to load in the browser
        files: [
			// Libraries
            '../tests/jasmine/jasmine.js',
            '../Scripts/jquery-2.2.1.min.js',
            '../Scripts/modernizr-2.8.3.js',
            '../Scripts/angular.js',
             '../Scripts/angular-mocks.js',
            '../Scripts/angular-sanitize.js',
            '../Scripts/angular-route.js',
            '../Scripts/angular-animate.js',
            '../Scripts/angular-ui-router.js',
            '../Scripts/angular-cookies.js',
             '../Scripts/angular-resource.js',
            '../Scripts/angular-touch.js',
            '../Scripts/angular-translate.min.js',
            '../src/config/angular-idle.js',
           
            '../src/common/auth/auth.js',
            '../src/common/auth/auth-userSession.js',
            '../src/common/auth/auth-service.js',
            '../src/common/auth/auth-factory.js',
             '../src/config/infinite-scroll.js',
            '../src/app/loading-bar.js',
             '../src/config/miEnvironment.js',

            '../src/app/*.js',
            '../src/config/*.js',
            '../src/miComponents/*.js',
			'../src/common/**/*.js',
             '../src/common/**/!(*.Spec).js'
			//'app/index.js',
			//'src/modules/**/*.js',
			//'!src/common/**/*spec.js'
        ],


        // list of files to exclude
        exclude: [

        ],


        // preprocess matching files before serving them to the browser
        // available preprocessors: https://npmjs.org/browse/keyword/karma-preprocessor
        preprocessors: {
            // source files, that you wanna generate coverage for
            // do not include tests or libraries
            // (these files will be instrumented by Istanbul)
            //'../src/common/**/*.js': ['coverage'],
            //'../src/common/Confirmation-Question/ConfirmationQuestionController.js': ['coverage'],
            '../src/common/**/!(*.Spec).js': ['coverage']
        },

        // coverage reporter generates the coverage
        // possible values: 'dots', 'progress', 'junit', 'growl', 'coverage'
        reporters: ['progress', 'coverage'],

        coverageReporter: {
            dir: '../coverage/',
            reporters: [
				{ type: 'html', subdir: 'report-html' },
				{ type: 'lcov', subdir: 'lcov' },
				{ type: 'cobertura', subdir: 'cobertura' }
            ],
            watermarks: {
                statements: [50, 75], // [below-this%-red, below-this%-yellow]
                functions: [50, 75],
                branches: [50, 75],
                lines: [50, 75]
            },
            includeAllSources: true
        },

        //junitReporter: {
        //	outputFile: '../coverage/cobertura/cobertura-coverage.xml'
        //},

        // web server port
        port: 9876,


        // enable / disable colors in the output (reporters and logs)
        colors: true,


        // level of logging
        // possible values: config.LOG_DISABLE || config.LOG_ERROR || config.LOG_WARN || config.LOG_INFO || config.LOG_DEBUG
        logLevel: config.LOG_INFO,


        // enable / disable watching file and executing tests whenever any file changes
        autoWatch: true,


        // start these browsers
        // available browser launchers: https://npmjs.org/browse/keyword/karma-launcher
        browsers: ['phantomJS'],

        // If browser does not capture in given timeout [ms], kill it
        captureTimeout: 60000,


        // Continuous Integration mode
        // if true, Karma captures browsers, runs the tests and exits
        singleRun: false
    });
};