﻿Version 2.0.25 9/16/2015
- MODAL - added border radius to modal footer
- APP MENU - rearranged layout so each item can have hovers

Version 2.0.24 9/15/2015
- BUTTON - tweaked padding

Version 2.0.23 9/14/2015
- LAYOUT - if chevron is in mi-header, it will be the base font size instead of the header font size to match visually

Version 2.0.22 9/14/2015
- UTILITIES - THEME - fixed mi-spacer variables

Version 2.0.21 9/14/2015
- UAM BLOCK - fixed margin em bug

Version 2.0.20 9/14/2015
- LIST MANAGER - removed mi-list-manager class and will apply styles directly to kendo grid

Version 2.0.19 9/14/2015
- UAM BLOCK - changed padding to rem instead of em

Version 2.0.16 9/9/2015
- BUTTONS - added transparent button 

Version 2.0.15 9/9/2015
- LIST MANAGER - styled header above scrollbar to match background
- added !important to spacer utility classes

Version 2.0.14 9/3/2015
- LIST MANAGER - fixed some more properties

Version 2.0.13 9/3/2015
- LIST MANAGER - fixed some properties

Version 2.0.12 9/3/2015
- LIST MANAGER - added style overrides to the kendo data grid as long as markup adds the mi-list-manager class
- adjusted padding for .mi-header to 1.1rem 1.1rem;

Version 2.0.11 9/2/2015
- CARD - phantom card container has height of 16rem to make up for removing height form mi-card
- VALIDATION - changed error validation text color to white;

Version 2.0.10 9/1/2015
- UAM BLOCK - added mi-large and mi-medium classes that center the header to the icon
- UAM BLOCK - UAM BANNER - added mi-uam-icon as a default icon
- added app-test.scss to test the compilation of all the scss files

Version 2.0.9 9/1/2015
- merge by Dennis Tsai with some existing styles in RCC2

Version 2.0.8 8/31/2015
- removed height from card

Version 2.0.7 8/31/2015
- added README.txt to components
- UAM BLOCK - corrected margin-left: $mi-uam-block-content-margin - .214em;


Version 2.0.6 8/27/2015
- added _SHAME--miux-forms.scss
- added margin-bottom override for <label> 
- BUTTON - mi-font-button: capitalize
- BUTTON - padding-bottom: 7px increased to 8px
- BUTTON - font-weight: semi-bold 600
- BUTTON - set button border radius from 3px to $mi-base-border-radius
- THEME - new variable - $mi-font-weight-semibold: 600
- THEME - new variable - $mi-modal-padding: 1.43rem (20px if base font size is 14px)
- MODAL - modal elements now use $mi-modal-padding instead of $mi-base-padding
- MODAL - changed modal header and footer background to match visual spec
- MODAL - tweaked modal header to have border radius to match modal container
- MODAL - changed modal content area background to mocha01
- MODAL - adjusted action primary button margin left to match modal padding
- LAYOUT - moved mi-action from MODAL to LAYOUT
- UAM BLOCK - matched icon margin with block padding
- UAM BLOCK - added slight top margin to content
- UAM BLOCK - bg color mocha01 for instruct and confirm 
- UAM BLOCK - footer has margin top to separate it from content
- UAM BLOCK - removed .mi-uam-footer-left and .mi-uam-footer-right for mi-actions because they were doing the same thing.
- UAM BLOCK - added margin left to match padding for button when it is not the only child







