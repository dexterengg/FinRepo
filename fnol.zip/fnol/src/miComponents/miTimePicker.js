﻿angular.module('miComponents')
.directive('miTimePicker', function () {
    return {
        restrict: "EA",
        required: 'ngModel',
        replace: true,
        template: '<input class={{timeClass}}  type="time"/>',
        scope: {
            timeClass: '@'
        }
    }
});