﻿angular.module('miComponents')
.directive('miRadiobutton', function () {
    return {
        restrict: 'EA',
       required: 'ngModel',
        replace: true,
        scope: {
             radioClass: '@',
            radioValue: '@',
            radioClick: '&'       
        },
        template: '<input type="radio" value={{radioValue}} class={{radioClass}} ng-click="radioClick()" >'
       
    }
});
