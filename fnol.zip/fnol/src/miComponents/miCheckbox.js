﻿angular.module('miComponents')
.directive('miCheckbox', function () {
    return {
      restrict: 'EA',
      require: 'ngModel',
      replace: true,
       scope: {
            chkboxClass: '@',
            chkboxValue: '@',
            chkboxClick: '&'
           },
      template: '<input type="checkbox" value={{chkboxValue}} class={{chkboxClass}} ng-click="chkboxClick()"/>'
      }
});




