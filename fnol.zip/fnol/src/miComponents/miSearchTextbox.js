﻿angular.module('miComponents')
.directive('miSearchtextbox', function () {
    return {
        restrict: 'EA',
        required: 'ngModel',
        replace: true,
        scope: {
            txtClass: '@',
            txtPlaceholder: '@',
            src: '@',
            imageClass: '@',
            onClick: '&',
            onBlur: '&',
            searchCriteria: '='
        },
        template: '<div class="mi-search-box">'
                   + '<div  class="mi-search-form">'
                   + '<input type="text"  class={{txtClass}} placeholder={{txtPlaceholder}} ng-model="searchCriteria" ng-blur="onBlur()" />'
                   + '<button class="search-button" type="submit" ng-click="onClick()">'
                   + '<span class="mi-icon-search mi-icon-search-big"></span>'
                   + '</button></div></div>'
    }
});












