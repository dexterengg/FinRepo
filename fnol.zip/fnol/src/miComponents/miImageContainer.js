﻿angular.module("miComponents")
.directive('miImageContainer', function () {

    return {
        restrict: 'EA',
        template: '<img ng-src="{{imageUrl}}" class={{imageClass}} ng-click="imageClick()" title={{imageTitle}}/>',
        scope: {
            imageTitle: '@',
            imageUrl: '@',
            imageClass: '@',
            imageClick: '&'
        }
    };
});