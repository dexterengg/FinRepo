﻿angular.module('miComponents')
.directive('miAccordion', function () {
    return {
        restrict: 'E',
        scope: {
            section: '=',
            func: '='
        },
        templateUrl: '/src/miComponents/miAccordion/AccordionTemplate.html'
    }
});