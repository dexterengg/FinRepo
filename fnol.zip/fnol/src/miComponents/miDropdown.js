﻿angular.module('miComponents')
.directive('miDropdown', function () {
    return {
        replace: true,
        restrict: 'E',
        scope: false,
        template: function (element, attrs) {
            if (!angular.isDefined(attrs.defaultLabel))
                attrs.defaultLabel = "";

            return '<span>'+
                         
                        '<select name="' + attrs.ddlName + '" ng-model="' + attrs.ngModel + '" ng-change="' + attrs.ddlChange + '"  class="'+ attrs.ddlClass +'" ng-options="' + attrs.ddlOptions + '"' + ((attrs.required) ? ' required' : '') + '></select>'+
                   '</span>';z
        },
        link: function (scope, el, attrs) {
            scope.$watch(attrs.ngModel, function () {
                var model = scope.$eval(attrs.ngModel);
              
            });
        }
       
    }
});

