﻿angular.module('miComponents', ['vAccordion', 'ngAnimate'])
    .directive('miButton', function () {
        return {
            restrict: 'EA',
            replace: true,
            scope: {
                btnText: '@',
                btnClass: '@',
                btnClick: '&'
            },
            template: '<button class={{btnClass}} ng-click="btnClick()">{{btnText}}</button>'
        };
    });