﻿angular.module('miComponents')
.directive('miDateTime', function () {
    return {
        restrict: "EA",
        required: 'ngModel',
        replace: true,
        template: '<input class={{datetimeClass}}  type="datetime-local"/>',
        scope: {
            datetimeClass: '@'
        }
    }
});
