﻿angular.module('miComponents')
.directive('miNotification', function ($timeout) {
    return {
        restrict: 'EA',
        replace: true,
        scope: {
            notifyTimeout: '@',
            notifyText: '@',
            notifyClass: '@',
            notifyClick: '&'
        },
        template: '<div class={{notifyClass}} ng-click="notifyClick()">{{notifyText}}</div>',
        link: function (scope, element, attrs) {
            $timeout(function () {
                element.hide();
            }, scope.notifyTimeout);
        }
    }
});
