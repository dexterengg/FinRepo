﻿angular.module('miComponents')
.directive('miTextbox', function () {
    return {
        restrict: 'EA',
       required: 'ngModel',
        replace: true,
        scope: {
            txtClass: '@',
            txtPlaceholder: '@'
        },
        template: '<input type="text"  class={{txtClass}} placeholder={{txtPlaceholder}} />',
       
    }
});
