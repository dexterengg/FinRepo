﻿(function (ng) {
    'use strict';

    ng.module("mi.mfnol.web", [
    'miComponents',
    'ui.router',
    'ngAnimate',
    'ngCookies',
    'miFileUploader',
    'mi.mfnol.environment',
    'ngResource',
    'ngTouch',
    'mi.ProcessingBar',
    'ngSanitize',
    'pascalprecht.translate',
    'tmh.dynamicLocale',
    'ngIdle',
    'miOauth',
    'infiniteScroll',
    'angularUUID2'
    
    ]);
}(angular));