(function () {
    'use strict';
    angular.module('mi.ProcessingBar', [])
  .provider('cfpLoadingBar', function () {
      this.$get = ['$rootScope', function ($rootScope) {

          function _start() {
              $rootScope.Processing = true;
          }
          function _complete() {
              $rootScope.Processing = false;

          }


          function _startCallPopup() {

              $rootScope.callPopOn = true;
          }
          function _completeCallPopup() {

              $rootScope.callPopOn = false;

          }

          function _openAdvancedSearch() {

              $rootScope.advancedSearchPopup = true;
          }
          function _closeAdvancedSearch() {

              $rootScope.advancedSearchPopup = false;

          }

          function _openPopupWindow() {

              $rootScope.showPopup = true;
          }
          function _closePopupWindow() {

              $rootScope.showPopup = false;

          }

          return {
              start: _start,
              complete: _complete,
              startCallPopup: _startCallPopup,
              completeCallPopup: _completeCallPopup,
              openAdvancedSearch: _openAdvancedSearch,
              closeAdvancedSearch: _closeAdvancedSearch,
              openPopupWindow: _openPopupWindow,
              closePopupWindow: _closePopupWindow,
          };
      }];
  });
})();
