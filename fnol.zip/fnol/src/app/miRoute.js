﻿(function (ng) {
    'use strict';

    ng.module("mi.mfnol.web")

        .run(function ($rootScope, $location, $state, $window, $http, ENV, miComponentRoute, miAppProperties) {
            try {
                $http({
                    method: "GET",
                    url: "/test.sample",
                    headers: {
                        'Content-Type': 'application/JSON'
                    }
                }).success(function (result) {
                    $rootScope.miEnvironment = JSON.parse(result);
                    $window.ga('create', $rootScope.miEnvironment.FNOL_GOOGLE_ANALYTICS_TRACKING_ID, 'auto');
                    $rootScope.$on('$locationChangeSuccess', function () {
                        $rootScope.actualLocation = $location.path();
                    });
                    $rootScope.$watch(function () { return $location.path() }, function (newLocation, oldLocation) {
                        if ($rootScope.actualLocation === newLocation) {
                            miAppProperties.resetAllVarivables();
                            miAppProperties.ClearUserIdentificationLoginKeyDetails();
                            $state.go(miComponentRoute.getComponentroute(ENV.SECURELOGIN_CONSTANT));
                        }
                    });
                    $rootScope.$on('$locationChangeSuccess', function (event) {
                        $window.ga('send', 'pageview', $location.path());
                    });
                }).error(function (result) {
                    alert('Failed to load MiEnvironment configuration settings !');
                });
            }
            catch (e) {
                // Do nothing
            }
        })

          .constant('DEBUG_MODE', /*DEBUG_MODE*/true/*DEBUG_MODE*/)
      .constant('VERSION_TAG', /*VERSION_TAG_START*/new Date().getTime()/*VERSION_TAG_END*/)
      .constant('LOCALES', (function () {
          // Define your variable

          var currLocale;

          if (window.location.href.split("#/")[1]) {
              currLocale = window.location.href.split("#/")[1].split("/")[2];
              currLocale = currLocale.split("?")[0];
          }
          // Use the variable in your constants
          var locals = {
              'fr-FR': 'fr-FR',
              'en-US': 'en-US',
              'fr-CA': 'fr-CA',
              'en-GB': 'en-GB',
              'de-DE': 'de-DE',
              'it-IT': 'it-IT',
              'es-ES': 'es-ES'
          }

          if (!(currLocale in locals))
          { currLocale = ""; }

          return {
              'locales': locals,
              'preferredLocale': currLocale
          }

      })())
    .config(function ($stateProvider, $urlRouterProvider, cfpLoadingBarProvider, IdleProvider, KeepaliveProvider) {

        IdleProvider.idle(150); // 5 minutes idle
        IdleProvider.timeout(150);// 5 minutes timeout
        KeepaliveProvider.interval(6 * 60); // 5 minute keep-alive ping

        cfpLoadingBarProvider.includeSpinner = true;

        $urlRouterProvider.otherwise("/shell")

        $stateProvider
            .state('shell', {
                url: "/shell/:org/:lan",
                views:
                           {
                               'shellView': {
                                   templateUrl: '/src/common/shell/shell.html',
                                   controller: 'ShellCtrl'
                               }
                           }

            })

             .state('shell.securelogin', {
                 url: "/securelogin",
                 views:
                            {
                                'shellcontainerView': {
                                    templateUrl: '/src/common/shell/authsecurelogin.html',
                                    controller: 'AuthSecureLoginCtrl'
                                }
                            }

             })

          .state('shell.intro1', {
              url: "/intro1",
              views:
                         {
                             'shellHeaderView': {
                                 templateUrl: '/src/common/header/info1header.html',
                                 controller: 'Info1HeaderCtrl'
                             },
                             'shellcontainerView': {
                                 templateUrl: '/src/common/landingPage1/landingPage1.html',
                                 controller: 'Intro1Ctrl'
                             }
                         }

          })
       .state('shell.intro2', {
           url: "/intro2",
           views:
                         {
                             'shellHeaderView': {
                                 templateUrl: '/src/common/header/info2header.html',
                                 controller: 'Info2HeaderCtrl'
                             },
                             'shellcontainerView': {
                                 templateUrl: '/src/common/landingPage2/landingPage2.html',
                                 controller: 'Intro2Ctrl'
                             }
                         }
       })
        .state('shell.intro3', {
            url: "/intro3",
            views:
                         {
                             'shellHeaderView': {
                                 templateUrl: '/src/common/header/info3header.html',
                                 controller: 'Info3HeaderCtrl'
                             },
                             'shellcontainerView': {
                                 templateUrl: '/src/common/landingPage3/landingPage3.html',
                                 controller: 'Intro3Ctrl'
                             }
                         }
        })

             .state('shell.existingClaim-Check', {
                 url: "/existingClaim-Check",
                 views:
                              {
                                  'shellHeaderView': {
                                      templateUrl: '/src/common/header/ExistingClaimheader.html'

                                  },
                                  'shellcontainerView': {
                                      templateUrl: '/src/common/ExistingClaimPage/ExistingClaimPage.html',
                                      controller: 'ExistingClaimPageCtrl'
                                  }
                              }
             })




            .state('shell.landing-Question', {
                url: "/landing-Question",
                views:
                              {
                                  'shellHeaderView': {
                                      templateUrl: '/src/common/header/RemoveClaimHeader.html',
                                      controller: 'LandingQuestionCtrl'
                                  },
                                  'shellcontainerView': {
                                      templateUrl: '/src/common/landing-Question/landing-Question.html',
                                  }
                              }
            })

        .state('shell.identification-Question', {
            url: "/identification-Question",
            views:
                         {
                             'shellHeaderView': {
                                 templateUrl: '/src/common/header/shellheader.html'
                             },
                             'shellcontainerView': {
                                 templateUrl: '/src/common/identification/identification-Question.html',
                                 controller: 'IdentificationCtrl'
                             }
                         }
        })
         .state('shell.landing-Question.date-Question', {
             url: "/date-Question",
             views:
                          {
                              'shellinnercontainerView': {
                                  templateUrl: '/src/common/date-Question/date-Question.html',
                                  controller: 'DateQuestionCtrl'
                              }
                          }
         })

          .state('shell.landing-Question.datetime-Question', {
              url: "/datetime-Question",
              views:
                           {
                               'shellinnercontainerView': {
                                   templateUrl: '/src/common/datetime-Question/datetime-Question.html',
                                   controller: 'DateTimeQuestionCtrl'
                               }
                           }
          })
       .state('shell.landing-Question.time-Question', {
           url: "/time-Question",
           views:
                        {
                            'shellinnercontainerView': {
                                templateUrl: '/src/common/time-Question/time-Question.html',
                                controller: 'TimeQuestionCtrl'
                            }
                        }
       })

        .state('shell.landing-Question.script-Question', {
            url: "/script-Question",
            views:
                         {
                             'shellinnercontainerView': {
                                 templateUrl: '/src/common/script-Question/script-Question.html',
                                 controller: 'ScriptQuestionCtrl'
                             }
                         }
        })
        .state('shell.landing-Question.choiceselection-Question', {
            url: "/choiceselection-Question",
            views:
                         {
                             'shellinnercontainerView': {
                                 templateUrl: '/src/common/choiceselection-Question/choiceselection-Question.html',
                                 controller: 'ChoiceSelectionQuestionCtrl'
                             }
                         }
        })
       .state('shell.landing-Question.range-Question', {
           url: "/range-Question",
           views:
                        {
                            'shellinnercontainerView': {
                                templateUrl: '/src/common/range-Question/range-Question.html',
                                controller: 'RangeQuestionCtrl'
                            }
                        }
       })
       .state('shell.landing-Question.yesno-Question', {
           url: "/yesno-Question",
           views:
                        {
                            'shellinnercontainerView': {
                                templateUrl: '/src/common/yesno-Question/yesno-Question.html',
                                controller: 'YesNoQuestionCtrl'
                            }
                        }
       })
       .state('shell.landing-Question.open-Question', {
           url: "/open-Question",
           views:
                        {
                            'shellinnercontainerView': {
                                templateUrl: '/src/common/open-Question/open-Question.html',
                                controller: 'OpenQuestionCtrl'
                            }
                        }
       })


            .state('shell.landing-Question.LocationType-Question', {
                url: "/Location-Type",
                views: {
                    'shellinnercontainerView': {
                        templateUrl: '/src/common/Complex-Question/Complex-Question.html',
                        controller: 'ComplexQuestionCtrl'
                    }
                }
            })

            .state('shell.landing-Question.PartyType-Question', {
                url: "/Party-Type",
                views: {
                    'shellinnercontainerView': {
                        templateUrl: '/src/common/Complex-Question/Complex-Question.html',
                        controller: 'ComplexQuestionCtrl'
                    }
                }
            })
             .state('shell.landing-Question.liability-Check', {
                 url: "/liability-Check",
                 views:
                                {

                                    'shellinnercontainerView': {
                                        templateUrl: '/src/common/liability-Check/liability-Check.html',
                                        controller: 'LiabilityCheckCtrl'
                                    }
                                }
             })

            .state('shell.landing-Question.outcome-Detail', {
                url: "/outcome-Check",
                views:

                     {

                         'shellinnercontainerView': {
                             templateUrl: '/src/common/outcome-Detail/outcome-Detail.html',
                             controller: 'OutcomeDetailCtrl'
                         }
                     }

            })

        .state('shell.landing-Question.confirmation-Check', {
            url: "/confirmation-Check",
            views:
                         {
                             'shellinnercontainerView': {
                                 templateUrl: '/src/common/FileUpload/file-Upload.html',//Confirmation-Question/Confirmation-Question.html',
                                 controller: 'FileUploadCtrl'//'ConfirmationQuestionCtrl'
                             }
                         }
        })
            .state('shell.landing-Question.summary-Check', {
                url: "/summary-Check",
                views:
                             {
                                 'shellinnercontainerView': {
                                     templateUrl: '/src/common/summary-Page/summary-Page.html',
                                     controller: 'SummaryPageCtrl'
                                 }
                             }
            })
            .state('shell.landing-Question.Moi', {
                url: "/Moi",
                views:
                             {
                                 'shellinnercontainerView': {
                                     templateUrl: '/src/common/Moi/Moi.html',
                                     controller: 'MoiSelectionCtrl'
                                 }
                             }
            })


	 .state('shell.landing-Question.ResourceLookUp', {
	     url: "/ResourceLookUp",
	     views:
                             {

                                 'shellinnercontainerView': {
                                     templateUrl: '/src/common/ResourceLookUp/ResourceLookUpPage.html',
                                     controller: 'resourceCtrl'
                                 }
                             }

	 })
             .state('shell.landing-Question.ScheduleAppointment', {
                 url: "/ScheduleAppointment",
                 views:
                                     {

                                         'shellinnercontainerView': {
                                             templateUrl: '/src/common/ScheduleAppointment/ScheduleAppointmentPage.html',
                                             controller: 'AppointmentCtrl'
                                         }
                                     }

             })

    .state('shell.Error', {
        url: "/Error",
        views:
                   {
                       'shellHeaderView': {
                           templateUrl: '/src/common/header/shellheader.html'
                       },
                       'shellcontainerView': {
                           templateUrl: '/src/common/error-pages/Error.html',
                           controller: 'ErrorCtrl'
                       }
                   }

    })

            .state('shell.landing-Question.AppointmentSummary', {
                url: "/AppointmentSummary",
                views:
                             {
                                 'shellinnercontainerView': {
                                     templateUrl: '/src/common/AppointmentConfirmationPage/AppointmentConfirmation.html',
                                     controller: 'AppointmentSummaryCtrl'
                                 }
                             }
            })

        .state('shell.ClaimSummary', {
            url: "/ClaimSummary",
            views:
                         {
                             'shellHeaderView': {
                                 templateUrl: '/src/common/header/shellheader.html'
                             },
                             'shellcontainerView': {
                                 templateUrl: '/src/common/ClaimSummaryPage/ClaimSummary.html',
                                 controller: 'ClaimSummaryCtrl'
                             }
                         }
        })
        .state('shell.landing-Question.AdjusterAppointmentInfo', {
            url: "/AdjusterAppointmentInfo",
            views:
                         {
                             'shellinnercontainerView': {
                                 templateUrl: '/src/common/AdjusterAppointmentInfoPage/AdjusterAppointmentInfo.html',
                                 controller: 'AdjusterAppointmentInfoCtrl'
                             }
                         }
        });

    })

     // Angular debug info
      .config(function ($compileProvider, DEBUG_MODE) {
          if (!DEBUG_MODE) {
              $compileProvider.debugInfoEnabled(false);// disables AngularJS debug info
          }
      })
      // Angular Translate
      .config(function ($translateProvider, DEBUG_MODE, ENV, LOCALES) {
          if (DEBUG_MODE) {
              $translateProvider.useMissingTranslationHandlerLog();// warns about missing translates
          }

          $translateProvider.useStaticFilesLoader({
              prefix: '/src/miI18n/miresources-locale_',
              suffix: '.js'
          });

          $translateProvider.preferredLanguage(LOCALES.preferredLocale === "" ? ENV.DEFAULT_LOCALE : LOCALES.preferredLocale);
          //  $translateProvider.useLocalStorage();
      })


      // Angular Dynamic Locale
      .config(function (tmhDynamicLocaleProvider) {
          tmhDynamicLocaleProvider.localeLocationPattern('Scripts/i18n/angular-locale_{{locale}}.js');
      })
    .run(function ($rootScope, $window, Idle, $stateParams, $state, ENV, miAppProperties, miComponentRoute, cfpLoadingBar) {
        Idle.watch();
        $rootScope.$on('IdleTimeout', function () {
            miAppProperties.setsessionexpired(true);
            miAppProperties.resetAllVarivables();
            miAppProperties.ClearUserIdentificationLoginKeyDetails();
            $state.go(miComponentRoute.getComponentroute(ENV.SECURELOGIN_CONSTANT));
            cfpLoadingBar.closeAdvancedSearch();
            cfpLoadingBar.closePopupWindow();
        });

    });
}(angular));