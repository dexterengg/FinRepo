﻿[
    {
        "key": "_ExistingUser_Greetmsg_",
        "value": "Nous avons trouvé une créance existante avec les informations saisies. Une seule demande peut être en cours à la fois. S'il vous plaît sélectionnez «Continuer avec une créance existante» si vous souhaitez continuer avec la revendication précédente ou sélectionnez «Jeter et commencer une nouvelle demande» pour supprimer la revendication précédente et recommencer."

    },
       {
           "key": "_Continue_",
           "value": "Continuer une créance existante"

       },
    {
        "key": "_Discard_",
        "value": "Jeter et commencer une nouvelle demande"

    },
    {
        "key": "_GetStart_",
        "value": "Commençons"

    },
    {
        "key": "_Landingpage_Greetmsg_",
        "value": "Il ne devrait prendre environ 10-15 minutes."
       
    },
    {
        "key":"_LandingpageTitle_",
        "value": "Prêt à signaler votre demande?"
       
    },
    {
        "key": "_LandingpageNewClaim_",
        "value": "Signaler une nouvelle demande"
       
    },
    {
        "key": "_LandingpageExistingClaim_",
        "value": "Continuer une revendication"
       
    },

    {
        "key": "_Infopage1Title_",
        "value": "Nous allons garder trace de vos progrès lors de votre demande"
      
    },

    {
        "key": "_Infopage2Title_",
        "value": " Vous pouvez appeler MPI à tout moment pendant le processus."

    },

    {
        "key": "_Infopage2Button_",
        "value": "  Anem a començar >"

    },

     {
         "key": "_Skip_",
         "value": "sauter >"

     },

    {
        "key": "_Back_",
        "value": "< arrière"

    },

    {
        "key": "_Next_",
        "value": "Suivant"

    },
     {
         "key": "_ShellTitle_",
         "value": "Un nouveau rapport de la revendication"

     },

    {
        "key": "_Confirm_",
        "value": "Confirmer"

    },

    {
        "key": "_Yes_",
        "value": "Oui"

    },

    {
        "key": "_No_",
        "value": "non"

    }

    
]
