﻿angular.module('mi.mfnol.web')
    .factory('milocalize', ['$http', '$rootScope', '$window', '$filter', '$stateParams', function ($http, $rootScope, $window, $filter, $stateParams) {
        var localize = {
            language: '',
            dictionary: [],
            url: undefined,
            resourceFileLoaded: false,
            successCallback: function (data) {
                localize.dictionary = data;
                localize.resourceFileLoaded = true;
                $rootScope.$broadcast('localizeResourcesUpdated');
            },
            setLanguage: function (value) {
                localize.language = value;
                localize.initLocalizedResources();
            },
            setUrl: function (value) {
                localize.url = value;
                localize.initLocalizedResources();
            },
            buildUrl: function () {
                if (!localize.language) {
                    var lang, androidLang;
                    //alert($stateParams.lan);
                    if ($window.navigator && $window.navigator.userAgent && (androidLang = $window.navigator.userAgent.match(/android.*\W(\w\w)-(\w\w)\W/i))) {
                        //lang = androidLang[1];
                        
                        lang = $stateParams.lan;
                        
                    } else {
                        //lang = $window.navigator.userLanguage || $window.navigator.language;
                       
                        lang = $stateParams.lan;
                       
                    }
                    localize.language = lang;
                  
                }
                return '/src/miI18n/miresources-locale_' + localize.language + '.js';
            },
            initLocalizedResources: function () {
                var url = localize.url || localize.buildUrl();
                $http({ method: "GET", url: url, cache: false }).success(localize.successCallback).error(function () {
                    var url = '/src/miI18n/miresources-locale_default.js';
                    $http({ method: "GET", url: url, cache: false }).success(localize.successCallback);
                });
            },
            getLocalizedString: function (value) {
                var result = '';
                if ((localize.dictionary !== []) && (localize.dictionary.length > 0)) {
                    var entry = $filter('filter')(localize.dictionary, function (element) {
                        return element.key === value;
                    }
                    )[0];
                    result = entry.value;
                }
                return result;
            }
        };
        localize.initLocalizedResources();
        return localize;
    }])

    // simple translation filter
    // usage {{ TOKEN | i18n }}
    .filter('i18n', ['milocalize', function (localize) {
        return function (input) {
            return localize.getLocalizedString(input);
        };
    }])

    .directive('i18n', ['milocalize', function (localize) {
        var i18nDirective = {
            restrict: "EAC",
            updateText: function (elm, token) {
                var values = token.split('|');
                if (values.length >= 1) {

                    var tag = localize.getLocalizedString(values[0]);

                    if ((tag !== null) && (tag !== undefined) && (tag !== '')) {
                        if (values.length > 1) {
                            for (var index = 1; index < values.length; index++) {
                                var target = '{' + (index - 1) + '}';
                                tag = tag.replace(target, values[index]);
                            }
                        }
                        elm.text(tag);
                    };
                }
            },
            link: function (scope, elm, attrs) {
                scope.$on('localizeResourcesUpdated', function () {
                    i18nDirective.updateText(elm, attrs.i18n);
                });
                attrs.$observe('i18n', function (value) {
                    i18nDirective.updateText(elm, attrs.i18n);
                });
            }
        };
        return i18nDirective;
    }]);






