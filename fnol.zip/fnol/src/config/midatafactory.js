﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')

.factory('miAppProperties', ['$rootScope', '$filter', 'miMoiProperties', 'miResourceProperties', 'ENV',
    function (
        $rootScope,
        $filter,
        miMoiProperties,
        miResourceProperties,
          ENV) {
        //Define Constant Variables
        var constant = {};


        ////data
        constant.data = false;
        constant.sendData = function (data) {
            this.data = data;
        };
        constant.getData = function () {
            return this.data;
        };


        ////data
        constant.displayQuestionFlag = false;
        constant.setdisplayQuestionFlag = function (data) {
            this.displayQuestionFlag = data;
        };
        constant.getdisplayQuestionFlag = function () {
            return this.displayQuestionFlag;
        };


        constant.questionnairesDetails = [];
        constant.insertQuestionnairesQuestionDetails = function (Id, Question, Answer, Type) {
            var QuesAnsDetail = { "Id": Id, "Question": Question, "Answer": Answer, "Type": Type };
            this.questionnairesDetails.push(QuesAnsDetail);
        };

        constant.getQuestionnairesQuestionDetails = function () {
            return this.questionnairesDetails;
        };
        constant.ClearQuestionnairesQuestionDetails = function () {
            this.questionnairesDetails.length = 0;
        };

        constant.SetIdentificationDataIntoQuestionnaireQuestionDetails = function () {
            for (var count = 0; count < this.UserIdentificationdata.length; count++) {
                this.questionnairesDetails.push(this.UserIdentificationdata[count]);
            }
            //            this.questionnairesDetails = this.UserIdentificationdata;
        };

        ////UserIdentificationdata
        constant.UserIdentificationdata = [];
        constant.insertUserIdentificationdata = function (Id, Question, Answer, Type) {
            var QuesAnsDetail = { "Id": Id, "Question": Question, "Answer": Answer, "Type": Type };
            this.UserIdentificationdata.push(QuesAnsDetail);
        };



        //Function to set complex type answer data as string to show it on summary page
        constant.setComplexAnswerDataForSummary = function (additionalAnswerInfo) {
            var complexAnswerDataForSummary = []
            var objAdditionalAnswerInfo = JSON.parse(additionalAnswerInfo);
            var strAdditonalAnswerInfo = "";
            var isFirstObject = true;
            if (objAdditionalAnswerInfo.length > 0) {
                $.each(objAdditionalAnswerInfo, function (index, object) {
                    if (object.Value) {
                        //Condition to check that the current object is not first object
                        //and it does not have label value,  then no need to put break here
                        if ((!isFirstObject) && (!object.Label))
                            complexAnswerDataForSummary.push(",  ");
                        else if (!isFirstObject)
                            complexAnswerDataForSummary.push(" <br/>");

                        //If label is present then show the label with colon before values
                        if (object.Label) {
                            complexAnswerDataForSummary.push(object.Label + " : ");
                        }

                        //Code to replace "<" with &lt and ">" with &gt so that it will 
                        //render data on questionnaire summary without running script under script tag
                        var objValue = object.Value.replace(/</gi, "&lt;");
                        objValue = objValue.replace(/>/gi, "&gt;");
                        complexAnswerDataForSummary.push(objValue);

                        isFirstObject = false;
                    }
                })
            }
            return complexAnswerDataForSummary.join("");
        };

        constant.setAllQuestionDetails = function (questionnaireDetailsData) {
            constant.setdisplayQuestionFlag(false);
            for (var index = 0; index < questionnaireDetailsData.length; index++) {
                if (questionnaireDetailsData[index].questionnrVersionList.length > 0) {
                    //Getting questions list and passing into variable
                    var questionsList = questionnaireDetailsData[index].questionnrVersionList[0].resQuestnList;

                    var questionId, questionText, answerType, answerText;
                    //Checking if question list having any question
                    if (questionsList.length > 0) {
                        //Getting total no of questions and passing into variable to use it in for loop
                        var totalQuestions = questionsList.length;
                        for (var questionCount = 0; questionCount < totalQuestions; questionCount++) {
                            //Checking whether currenty questionis Display Question/Answer Text                            
                            if (questionsList[questionCount].customTextFlag === ENV.ANSWERSTATEMENT_QUESTIONANSWER) {
                                constant.setdisplayQuestionFlag(true);
                                questionId = questionsList[questionCount].qustnnreQustnId;
                                questionText = questionsList[questionCount].qustnText;
                                answerType = questionsList[questionCount].answrControlType;

                                //Getting total no of answers and passing into variable to use it in for loop
                                var totalAnswers = questionsList[questionCount].answerList.length;

                                //For loop to iterate all answers option and to get the answered one
                                for (var answerCount = 0; answerCount < totalAnswers; answerCount++) {
                                    //Checking property "answered".  If it is true - means user has selected that answer
                                    if (questionsList[questionCount].answerList[answerCount].answered === true) {
                                        //Switch case to handle the different answer types.  It will use to set correct answer text
                                        switch (answerType) {
                                            case ENV.DATETIME_CONSTANT:
                                                //Converting UTC datetime format to system locale datetime format
                                                answerText = new Date(questionsList[questionCount].answerList[answerCount].answerDisplayText).toLocaleString();
                                                break;
                                            case ENV.DATE_CONSTANT:
                                                //Converting UTC datetime format to system locale date format
                                                answerText = new Date(questionsList[questionCount].answerList[answerCount].answerDisplayText).toLocaleDateString();
                                                break;
                                            case ENV.TIME_CONSTANT:
                                                //Converting UTC datetime format to system locale time format
                                                answerText = new Date(questionsList[questionCount].answerList[answerCount].answerDisplayText).toLocaleTimeString();
                                                break;
                                            case ENV.PARTY_CONSTANT:
                                            case ENV.LOCATION_CONSTANT:
                                                answerText = this.setComplexAnswerDataForSummary(questionsList[questionCount].answerList[answerCount].additionalAnswerInfo);
                                                break;
                                            default:
                                                answerText = questionsList[questionCount].answerList[answerCount].answerDisplayText;
                                                break;
                                        }   //End of switch condition                                        
                                    }   //End of if condition to check whether answered is true
                                }   //End of for loop of total answers

                                //Calling function to insert question details.
                                //Later we are using it to show the details on page
                                this.insertQuestionnairesQuestionDetails(questionId, questionText, answerText, answerType);
                            }   //End of if conditin to check answer control type                            

                                //Checking whether currenty question is Display Statement Text 
                            else if (questionsList[questionCount].customTextFlag === ENV.ANSWERSTATEMENT_STATEMENTTEXT) {
                                questionId = questionsList[questionCount].qustnnreQustnId;
                                questionText = "";
                                answerType = questionsList[questionCount].answrControlType;

                                //Getting total no of answers and passing into variable to use it in for loop
                                var totalAnswers = questionsList[questionCount].answerList.length;

                                //For loop to iterate all answers option and to get the answered one
                                for (var answerCount = 0; answerCount < totalAnswers; answerCount++) {
                                    //Checking property "answered".  If it is true - means user has selected that answer
                                    if (questionsList[questionCount].answerList[answerCount].answered === true) {
                                        answerText = questionsList[questionCount].answerList[answerCount].customText;
                                        if (answerText) {
                                            constant.setdisplayQuestionFlag(true);
                                        }
                                    }   //End of if condition to check whether answered is true
                                }   //End of for loop of total answers

                                //Calling function to insert question details
                                //Later we are using it to show the details on page                                
                                this.insertQuestionnairesQuestionDetails(questionId, questionText, answerText, answerType);
                            }

                                //Checking whether currenty question is  Do not display                           
                            else {
                                questionId = questionsList[questionCount].qustnnreQustnId;
                                questionText = "";
                                answerType = questionsList[questionCount].answrControlType;
                                answerText = "";
                                //Calling function to insert question details.
                                //Later we are using it to show the details on page                                
                                this.insertQuestionnairesQuestionDetails(questionId, questionText, answerText, answerType);
                            }

                        }   //End of totalQuestion for loop
                    }   //End of if condition to check questions list
                }   //End of questionnaire version for loop
            }
        };





        constant.getUserIdentificationdata = function () {
            return this.UserIdentificationdata;
        };
        constant.ClearUserIdentificationdata = function () {
            this.UserIdentificationdata.length = 0;
        };

        constant.UserIdentificationLoginDetails = {
        };

        constant.setUserIdentificationLoginKeyDetails = function (key, value) {
            this.UserIdentificationLoginDetails[key] = value;
        };

        constant.getUserIdentificationLoginKeyDetails = function (key) {
            return this.UserIdentificationLoginDetails[key];
        };

        constant.ClearUserIdentificationLoginKeyDetails = function () {
            this.UserIdentificationLoginDetails = {};
        };

        ////PolicyVerificationdata
        constant.PolicyVerificationdata = false;
        constant.setPolicyVerificationRequestData = function (identificationDetails, companyCode, evaluationID) {
            this.PolicyVerificationdata = "{" + identificationDetails + '"companyCd": "' + companyCode + '" , "idntfctnQntnrreEvalDocId": "' + evaluationID + '" }';

        };
        constant.getPolicyVerificationRequestData = function () {
            return this.PolicyVerificationdata;
        };
        ////

        ////QuestionData
        constant.QuestionData = false;
        constant.setCurrentQuestion = function (QuestionData) {
            this.QuestionData = QuestionData;
        };
        constant.getCurrentQuestion = function () {
            return this.QuestionData;
        };

        ////ResourceData
        constant.ResourceData = false;
        constant.setResourceData = function (ResourceData) {
            this.ResourceData = ResourceData;
        };
        constant.getResourceData = function () {
            return this.ResourceData;
        };


        constant.ResourceDataList = false;
        constant.setResourceDataList = function (ResourceDataList) {
            this.ResourceDataList = ResourceDataList;
        };
        constant.getResourceDataList = function () {
            return this.ResourceDataList;
        };

        ////

        ////OutcomeDetail
        constant.OutcomeDetail = false;
        constant.setOutcomeDetail = function (OutcomeDetail) {
            this.OutcomeDetail = OutcomeDetail;
        };
        constant.getOutcomeDetail = function () {
            return this.OutcomeDetail;
        };

        /////
        constant.OutComeAnswers = [];
        //set display outcomes
        constant.setDisplayOutCome = function (OutcomeDetail) {
            for (var iIndex = 0; iIndex < OutcomeDetail.fnolOutComesList.length; iIndex++) {
                // only outcome should display which have set to display 'Y' or outcomeName is null (i.e. generic message)
                if (OutcomeDetail.fnolOutComesList[iIndex].displayOutcome === "Y" || !OutcomeDetail.fnolOutComesList[iIndex].evltnOutcome) {
                    this.OutComeAnswers.push(OutcomeDetail.fnolOutComesList[iIndex]);
                }
            };
        };
        //get display outcomes
        constant.getDisplayOutCome = function () {
            return this.OutComeAnswers;
        };

        ////Docidlist
        constant.Docidlist = [];
        constant.setDocidlist = function (Docidlist) {
            this.Docidlist.push(Docidlist);
        };
        constant.getDocidlist = function () {
            return this.Docidlist.toString();
        };
        ////

        ////ConfigIdList
        constant.evltnConfigId = [];
        constant.setConfigIdlist = function (evltnConfigId) {
            this.evltnConfigId.push(evltnConfigId);
        };
        constant.getConfigIdlist = function () {
            return this.evltnConfigId.toString();
        };
        ///

        ////VehicalDetails
        constant.vehicalDetails = false;
        constant.vehicalDetailsStatus = false;
        constant.setVehicalDetails = function (vehicalDetails) {
            this.vehicalDetails = vehicalDetails;
        };
        constant.setvehicalDetailsStatus = function (vehicalDetailsStatus) {
            this.vehicalDetailsStatus = vehicalDetailsStatus;
        };
        constant.getVehicalDetails = function () {
            return this.vehicalDetails;
        };
        constant.getvehicalDetailsStatus = function () {
            return this.vehicalDetailsStatus;
        };


        ////AppointmentDetails
        constant.appointmentDetailsStatus = false;
        constant.appointmentDetails = false;

        constant.setappointmentDetailsStatus = function (appointmentDetailsStatus) {
            this.appointmentDetailsStatus = appointmentDetailsStatus;
        };
        constant.setappointmentDetails = function (appointmentDetails) {
            this.appointmentDetails = appointmentDetails;
        };

        constant.getappointmentDetails = function () {
            return this.appointmentDetails;
        };

        constant.getappointmentDetailsStatus = function () {
            return this.appointmentDetailsStatus;
        };
        ////


        ///Question Details Data Handling List  insertQuestionDetails
        constant.currentquestionnaireQuestionId = 0;
        constant.questionDetailsList = [];
        constant.insertQuestionDetails = function (questionnaireQuestionId, answerText, complexAnswerList) {
            this.clearQuestionDetails();
            this.currentquestionnaireQuestionId = questionnaireQuestionId;
            var questionDetails = {
                "qustnnrQustnId": questionnaireQuestionId,
                "answer": answerText,
                "complexAnswerList": complexAnswerList
            };
            this.questionDetailsList.push(questionDetails);
        };
        constant.getQuestionDetails = function () {
            return this.questionDetailsList;
        };
        constant.clearQuestionDetails = function () {
            this.questionDetailsList.length = 0;
            this.currentquestionnaireQuestionId = 0;
        };
        constant.getcurrentquestionnaireQuestionId = function () {
            return this.currentquestionnaireQuestionId;
        };
        ///End of Question Details Data Handling List
        ////theme
        constant.theme = false;
        constant.settheme = function (theme) {
            this.theme = theme;
        };
        constant.gettheme = function () {
            return this.theme;
        };
        ////

        ////orgcode
        constant.orgcode = false;
        constant.setorgcode = function (orgcode) {
            this.orgcode = orgcode;
        };
        constant.getorgcode = function () {
            return this.orgcode;
        };
        ////

        ////animationclass
        constant.animationclass = false;
        constant.setanimationclass = function (animationclass) {
            this.animationclass = animationclass;
        };
        constant.getanimationclass = function () {
            return this.animationclass;
        };
        ////

        ////language
        constant.language = false;
        constant.setlanguage = function (language) {
            this.language = language;
        };
        constant.getlanguage = function () {
            return this.language;
        };
        ////

        ////sessionid
        constant.sessionID = false;
        constant.setSessionID = function (sessionID) {
            this.sessionID = sessionID;
        };
        constant.getSessionID = function () {
            return this.sessionID;
        };

        ////redirectionToken
        constant.redirectionToken = false;
        constant.setredirectionToken = function (redirectionToken) {
            this.redirectionToken = redirectionToken;
        };
        constant.getredirectionToken = function () {
            return this.redirectionToken;
        };
        ////

        ////sessionexpired
        constant.sessionexpired = false;
        constant.setsessionexpired = function (sessionexpired) {
            this.sessionexpired = sessionexpired;
        };
        constant.getsessionexpired = function () {
            return this.sessionexpired;
        };
        ////

        ////Identificationfields
        constant.Identificationfields = false;
        constant.setIdentificationfields = function (Identificationfields) {
            this.Identificationfields = Identificationfields;
        };
        constant.getIdentificationfields = function () {
            return this.Identificationfields;
        };
        ////

        ////contextid
        constant.contextid = false;
        constant.setcontextid = function (contextid) {
            this.contextid = contextid;
        };
        constant.getcontextid = function () {
            if (!this.contextid) {
                this.contextid = 0;
            }
            return this.contextid;
        };
        ////

        ////languagelist
        constant.languagelist = false;
        constant.setlanguagelist = function (languagelist) {
            this.languagelist = languagelist;
        };
        constant.getlanguagelist = function () {
            return this.languagelist;
        };
        ////

        ////statuscode
        constant.statuscode = false;
        constant.setstatuscode = function (statuscode) {
            this.statuscode = statuscode;
        };
        constant.getstatuscode = function () {
            return this.statuscode;
        };
        ////

        ////islandingpage
        constant.islandingpage = false;
        constant.setislandingpage = function (islandingpage) {
            this.islandingpage = islandingpage;
        };
        constant.getislandingpage = function () {
            return this.islandingpage;
        };
        ////

        ////
        ////custom error
        constant.customerror = false;
        constant.setCustomError = function (customerror) {
            this.customerror = customerror;
        };
        constant.getCustomError = function () {
            return this.customerror;
        };
        //set and get appointmentList
        constant.appointmentListSlots = {};
        constant.appointmentListSlots.hasData = false;
        constant.setAppointmentList = function (appointmentList, hasData) {
            this.appointmentListSlots.appointmentList = appointmentList;
            this.appointmentListSlots.hasData = hasData;
        };
        constant.getAppointmentList = function () {
            return this.appointmentListSlots;
        };
        ////

        ///PreviousQuestion QuestionnaireQuestionId 
        constant.previoustquestionnaireQuestionId = 0;
        constant.getPrevioustquestionnaireQuestionId = function () {
            return this.previoustquestionnaireQuestionId;
        };
        ///

        ////Stage Constants
        constant.flagStage = true;
        constant.stageName = true
        constant.questionnaireID = false;
        constant.DocID = false;
        constant.IdentificationEvalDocID = false;
        constant.stageUiOrder = false;
        constant.StageOrder = false;
        constant.pageName = false;
        constant.stageType = false;
        constant.coStageId = false;
        constant.stageDesc = false;
        constant.totalNumOfStages = false;
        constant.systemDocId = false;
        constant.isConfirmed = false;
        constant.integrationStage = false;
        constant.previousQuestionFlag = false;
        constant.backbutton = true;
        constant.questionstate = "";
        constant.stageStatus = null;
        constant.isAnswering = false;
        constant.userSystemMap = false;
        constant.carrierSystemMap = false;
        constant.appointmenttype = false;
        ////Set Stage Constant Values

        constant.setappointmentType = function (appointmenttype) {
            this.appointmenttype = appointmenttype;
        };

        constant.setflagStage = function (flagStage) {
            this.flagStage = flagStage;
        };
        constant.setstageName = function (stageName) {
            this.stageName = stageName;
        };
        constant.setquestionnaireID = function (questionnaireID) {
            this.questionnaireID = questionnaireID;
        };
        constant.setDocID = function (DocID) {
            this.DocID = DocID;
        };
        constant.setIdentificationEvalDocID = function (EvalDocID) {
            this.IdentificationEvalDocID = EvalDocID;
        };
        constant.setstageUiOrder = function (stageUiOrder) {
            this.stageUiOrder = stageUiOrder;
        };
        constant.setStageOrder = function (StageOrder) {
            this.StageOrder = StageOrder;
        };
        constant.setpageName = function (pageName) {
            this.pageName = pageName;
        };
        constant.setstageType = function (stageType) {
            this.stageType = stageType;
        };
        constant.setcoStageId = function (coStageId) {
            this.coStageId = coStageId;
        };
        constant.setstageDesc = function (stageDesc) {
            this.stageDesc = stageDesc;
        };
        constant.settotalNumOfStages = function (totalNumOfStages) {
            this.totalNumOfStages = totalNumOfStages;
        };
        constant.setsystemDocId = function (systemDocId) {
            this.systemDocId = systemDocId;
        };
        constant.setisConfirmed = function (flag) {
            this.isConfirmed = flag;
        };
        //back handling flag
        constant.setIntegrationStage = function (integrationStage) {
            this.integrationStage = integrationStage;
        };
        constant.setpreviousQuestionFlag = function (previousQuestionFlag) {
            this.previousQuestionFlag = previousQuestionFlag;
        };
        constant.setQuestionstate = function (questionstate) {
            this.questionstate = questionstate;
        };
        constant.setStageStatus = function (stageStatus) {
            this.stageStatus = stageStatus;
        };
        constant.setIsAnswering = function (isAnswering) {
            this.isAnswering = isAnswering;
        }

        constant.setUserSystemMap = function (userSystemMap) {
            this.userSystemMap = userSystemMap;
        };
        constant.setCarrierSystemMap = function (carrierSystemMap) {
            this.carrierSystemMap = carrierSystemMap;
        };
        //back handling flag
        ////

        ////Get Stage Constant Values
        constant.getappointmentType = function () {
            return this.appointmenttype;
        };

        constant.getflagStage = function () {
            return this.flagStage;
        };
        constant.getstageName = function () {
            return this.stageName;
        };
        constant.getquestionnaireID = function () {
            return this.questionnaireID;
        };
        constant.getDocID = function () {
            if (this.DocID)
                return this.DocID;
            else
                return 0;
        };
        constant.getIdentificationEvalDocID = function () {
            return this.IdentificationEvalDocID;
        };
        constant.getstageUiOrder = function () {
            return this.stageUiOrder;
        };
        constant.getStageOrder = function () {
            return this.StageOrder;
        };
        constant.getpageName = function () {
            return this.pageName;
        };
        constant.getstageType = function () {
            return this.stageType;
        };
        constant.getcoStageId = function () {
            return this.coStageId;
        };
        constant.getstageDesc = function () {
            if (!this.stageDesc) {
                this.stageDesc = "";
            }
            return this.stageDesc;
        };
        constant.gettotalNumOfStages = function () {
            return this.totalNumOfStages;
        };
        constant.getisConfirmed = function () {
            return this.isConfirmed;
        };

        constant.getintegrationStage = function () {
            return this.integrationStage;
        };
        constant.getpreviousQuestionFlag = function () {
            return this.previousQuestionFlag;
        };
        constant.getQuestionstate = function () {
            return this.questionstate;
        };
        constant.getStageStatus = function () {
            return this.stageStatus;
        };
        constant.getIsAnswering = function () {
            return this.isAnswering;
        };

        constant.getUserSystemMap = function () {
            return this.userSystemMap;
        };
        constant.getCarrierSystemMap = function () {
            return this.carrierSystemMap;
        };
        ////

        ////Assignment Data
        constant.AssignmentData = false;
        constant.setAssignmentData = function (AssignmentData) {
            this.AssignmentData = AssignmentData;
        };
        constant.getAssignmentData = function () {
            return this.AssignmentData;
        };

        ///// Clear all variables before hitting 0 stage after sessionOut\refresh
        constant.resetAllVarivables = function () {
            this.UserIdentificationdata.length = 0;
            this.redirectionToken = false;
            this.contextid = false;
            this.StageOrder = 0;
            this.systemDocId = 0;
            this.isConfirmed = false;
        }
        ////

        ///Partial Stage Properties
        constant.partialStage = false;
        constant.setpartialStage = function (partialStage) {
            this.partialStage = partialStage;
        };
        constant.getpartialStage = function () {
            return this.partialStage;
        };
        ///

        /// Update assignment service payload
        constant.assignmentDTO = {};

        constant.assignmentDTO.methodOfInspection = null;
        constant.assignmentDTO.moiOrgID = null;
        constant.assignmentDTO.setMethodOfInspection = function (methodOfInspection) {
            this.methodOfInspection = methodOfInspection;
        };
        constant.assignmentDTO.setMoiOrgID = function (moiOrgID) {
            this.moiOrgID = moiOrgID;
        };
        constant.assignmentDTO.getMethodOfInspection = function () {
            return this.methodOfInspection;
        };
        constant.assignmentDTO.getMoiOrgID = function () {
            return this.moiOrgID;
        };
        ////

        ///Carrier Contact Properties
        constant.carrierTelePhone = false;
        constant.setCarrierTelePhone = function (carrierTelePhone) {
            this.carrierTelePhone = carrierTelePhone;
        };
        constant.getCarrierTelePhone = function () {
            return this.carrierTelePhone;
        };
        constant.callCenterHourTitle = "";
        //set call center Hour Title
        constant.setCallCenterHourTitle = function (callCenterHourTitle) {
            this.callCenterHourTitle = callCenterHourTitle;
        };
        //get call center Hour Title
        constant.getCallCenterHourTitle = function () {
            return this.callCenterHourTitle;
        };

        constant.callCenterHours = [];
        //set call Center Hours
        constant.setCallCenterHours = function (callCenterHours) {
            this.callCenterHours = callCenterHours;
        };
        //get call Center Hours
        constant.getCallCenterHours = function () {
            return this.callCenterHours;
        };

        constant.callCenterHoursDTO = "";
        //set language specific call Center Hours received from carrier
        constant.setCallCenterHoursDTO = function (callCenterHoursDTO) {
            localStorage.setItem('callCenterHoursDTO', callCenterHoursDTO);
        };
        //get language specific call Center Hours received from carrier
        constant.getCallCenterHoursDTO = function () {
            this.callCenterHoursDTO = localStorage.getItem('callCenterHoursDTO');
            return this.callCenterHoursDTO;
        };

        constant.displayCallCenterHours = false;
        constant.setDisplayCallCenterHours = function (displayCallCenterHours) {
            this.displayCallCenterHours = displayCallCenterHours;
        };
        //get call Center Hours
        constant.getDisplayCallCenterHours = function () {
            return this.displayCallCenterHours;
        };

        constant.utcOffset = false;
        constant.setUtcOffset = function (utcOffset) {
            this.utcOffset = utcOffset;
        };
        //get call UTC offset
        constant.getUtcOffset = function () {
            return this.utcOffset;
        };

        //Start of code section to handle the first question of questionnaire for partial case
        //Constant flag variable to handle the first question of questionnaire for partial case
        constant.flagNextStageFirstQuestion = false;
        constant.setflagNextStageFirstQuestion = function (flagNextStageFirstQuestion) {
            this.flagNextStageFirstQuestion = flagNextStageFirstQuestion;
        };
        constant.getflagNextStageFirstQuestion = function () {
            return this.flagNextStageFirstQuestion;
        }
        //End of code section to handle the first question of questionnaire for partial case


        ///// back button visible true/false according to return flag
        constant.backFlag = true;
        constant.setBackButtonDisableFromNoPreQuestion = function (backFlag) {
            this.backFlag = backFlag;
        };
        constant.getBackButtonDisableFromNoPreQuestion = function () {
            return this.backFlag;
        };


        constant.getBackButtonFlag = function () {
            if (constant.StageOrder == 1) { this.backbutton = false; }
            else if (constant.stageType === ENV.INTEGRATION_CONSTANT && constant.pageName == ENV.SUMMARY_CONSTANT) {
                this.backbutton = false;
            }
            else if (constant.stageType === ENV.PREDEFINED_PAGE_CONSTANT && constant.integrationStage === true) {
                this.backbutton = false;
            }
            else if (constant.stageType === ENV.QUESTIONNAIRE_CONSTANT && constant.integrationStage === true && constant.previousQuestionFlag === true) {
                // else if (constant.stageType === ENV.QUESTIONNAIRE_CONSTANT && constant.integrationStage === true) {
                this.backbutton = false;
            }
            else if (constant.stageType === ENV.INTEGRATION_CONSTANT && constant.integrationStage === true) {
                this.backbutton = false;
            }
            else {
                this.backbutton = true;
            }
            return this.backbutton;
        };
        constant.getBackButtonCss = function () {
            var backButtonCss = ENV.CLICKABLE_CSS;
            if (constant.getBackButtonFlag() != true) {
                backButtonCss = ENV.NONCLICKABLE_CSS;
            }
            else if (constant.getBackButtonDisableFromNoPreQuestion() != true) {
                backButtonCss = ENV.NONCLICKABLE_CSS;
            }
            else {
                backButtonCss = ENV.CLICKABLE_CSS;
            }
            return backButtonCss;

        }

        //Code to set and get version mismatch status
        constant.versionMismatchStatus = false;
        constant.setVersionMismatchStatus = function (status) {
            this.versionMismatchStatus = status;
        };
        constant.getVersionMismatchStatus = function () {
            return this.versionMismatchStatus;
        };
        //End of Code to set and get version mismatch status

        ////back button functionality block end

        constant.IsStageStatusChanged = function (currentQuestionDetails, answerDetails, tempAdditionalAnswerInfo, additionalAnswerInfo) {
            //Condition to check whether claim status is complete or not
            //If yes then only we need to proceed to match current answer with existing one
            if (this.getStageStatus() === ENV.CLAIMSTATUS_COMPLETE) {
                //Switch condition to check controller.
                //Because For Choice, Range and Yes_No we will get answer DTO
                //For rest controllers we will get particular answer
                switch (currentQuestionDetails.answrControlType) {
                    case ENV.CHOICE_CONSTANT:
                    case ENV.RANGE_CONSTANT:
                    case ENV.YES_NO_CONSTANT:
                        //Fetching the object with the matched criteria
                        //IF found means user has given different answer 
                        var answerObject = $filter('filter')(currentQuestionDetails.answerList, { answerItemID: answerDetails.answerItemID, answered: false })[0];
                        if (answerObject) {
                            return true;
                        }
                        break;

                    case ENV.PARTY_CONSTANT:
                    case ENV.LOCATION_CONSTANT:
                        var answerObject = false;
                        //Fetching the object with the matched criteria
                        //IF found means user has given different answer 
                        if (answerDetails) {
                            answerObject = $filter('filter')(currentQuestionDetails.answerList, { answerItemID: answerDetails.answerItemID, answered: false })[0];
                        }
                        if (answerObject) {
                            return true;
                        }
                        else {
                            //Checking whether existing additional answer information is equal to previously answerd additional answer information or not
                            //Existing adtional answer info will be in tempAdditionalAnswerInfo
                            //And currently given additional answer info will be in additionalAnswerInfo
                            if (tempAdditionalAnswerInfo.length > 0) {
                                if (JSON.stringify(tempAdditionalAnswerInfo) != JSON.stringify(additionalAnswerInfo)) {
                                    return true;
                                }
                            }
                        }
                        break;

                    case ENV.DATETIME_CONSTANT:
                    case ENV.DATE_CONSTANT:
                    case ENV.TIME_CONSTANT:
                    case ENV.OPEN_CONSTANT:
                        if (currentQuestionDetails.answerList[0] != null && currentQuestionDetails.answerList[0] != undefined) {
                            if (currentQuestionDetails.answerList[0].answerDisplayText) {
                                if (currentQuestionDetails.answerList[0].answerDisplayText.toUpperCase() != answerDetails.toUpperCase()) {
                                    return true;
                                }
                            }
                            else {
                                return true;
                            }
                        }
                        break;
                }
                //Return false if stage status is complete and current answer is same 
                return false;
            }
            else {
                //If status is not complete then simply return false.
                return false;
            }
        }

        /// Create the appointment dto for book the appointment
        constant.appointmentDTO = {};
        constant.appointmentDTO.locationId = null;
        constant.appointmentDTO.appointmentType = null;
        constant.appointmentDTO.startDateTime = null;
        constant.appointmentDTO.resourceCode = null;
        //set the properties of dto
        constant.appointmentDTO.setResourceCode = function (resourceCode) {
            this.resourceCode = resourceCode;
        };

        constant.appointmentDTO.setLocationId = function (locationId) {
            this.locationId = locationId;
        };
        constant.appointmentDTO.setAppointmentType = function (appointmentType) {
            this.appointmentType = appointmentType;
        };
        constant.appointmentDTO.setStartDateTime = function (startDateTime) {
            this.startDateTime = startDateTime;
        };
        ///end of set the properties of dto

        ////get properties of dto
        constant.appointmentDTO.getResourceCode = function () {
            return this.resourceCode;
        };

        constant.appointmentDTO.getLocationId = function () {
            return this.locationId;
        };
        constant.appointmentDTO.getAppointmentType = function () {
            return this.appointmentType;
        };
        constant.appointmentDTO.getStartDateTime = function () {
            return this.startDateTime;
        };
        //end of get properties of dto
        ////

        //Function to set all postal code related entries to default
        //So that it will not effect the searching of resource list
        constant.setPostalCodeToDefault = function () {
            if (miMoiProperties.getresourcePostalCode()) {
                miMoiProperties.setresourcePostalCode(null);
                var assignmentresult = constant.getAssignmentData();
                /*
                        When moiDetailsFilterDTO is not null then zipCode=assignmentresult.data.moiDetailsFilterDTO.zipCode else null
                        If zipCode is null then Territory=null and Radius=null
                        If zipCode is not null then Territory=ENV.RADIUS_DESC and Radius=ENV.RADIUS
                    */
                var zipCode = assignmentresult.data.moiDetailsFilterDTO ? assignmentresult.data.moiDetailsFilterDTO.zipCode : ENV.NULL_VALUE
                miResourceProperties.setPostalCode(zipCode);
                miResourceProperties.setTerritoryType(zipCode ? ENV.RADIUS_DESC : ENV.NULL_VALUE);
                miResourceProperties.setRadius(zipCode ? ENV.RADIUS : ENV.NULL_VALUE);
            }
        }
        ////
        ///set the questionniareSummary Page Status to check this exists or not in edit functionnality of ConfirmationQuestionController
        //If one/more than one questionnaire stages skip and get integration stage by click on back button from questionnaireSummaryPage then back button should be disabled
        //Now click on edit button then user should be on some page i.e. Questionnaire Summary page.
        constant.questionnireSummaryStatus = null;
        constant.setQuestionnaireSummaryPage = function (questionnireSummaryStatus) {
            this.questionnireSummaryStatus = questionnireSummaryStatus;
        };
        constant.getQuestionnaireSummaryPage = function () {
            return this.questionnireSummaryStatus;
        };
        ///START OF PHOTO UPLOADED BLOCK
        constant.ImageUploadDataArrary = [];
        constant.setImageData = function () {
            for (var iIndex = 0; iIndex < ENV.IMAGE_BOXES; iIndex++) {
                var cssClassIndex = iIndex === 0 ? 1 : iIndex + 1;
                var objImage = { "Id": iIndex, "ImageId": 'UploadImage' + iIndex.toString(), "CssClass": 'pic-' + cssClassIndex, "ShowBlankImage": true, "ImageSrc": '', "ShowUploadedImage": false, };
                this.ImageUploadDataArrary.push(objImage);
            }
            return this.ImageUploadDataArrary;
        };
        constant.getImageData = function () {
            return this.ImageUploadDataArrary;
        };

        ///END OF PHOTO UPLOADED BLOCK

        return constant;
    }])




  .factory('miResourceProperties', ['miMoiProperties', '$rootScope', 'ENV',
    function (miMoiProperties,
        $rootScope,
        ENV) {

        var resourceSearchCriteria = {};

        resourceSearchCriteria.CoCode = null;
        resourceSearchCriteria.ResourceType = null;
        resourceSearchCriteria.ResourceSubType = null;
        resourceSearchCriteria.GroupType = null;
        resourceSearchCriteria.ClaimID = null;
        resourceSearchCriteria.ApplCode = null;
        resourceSearchCriteria.Name = null;
        resourceSearchCriteria.DispatchCenterID = null;
        resourceSearchCriteria.Network = null;
        resourceSearchCriteria.CNum = null;
        resourceSearchCriteria.ExpertiseCondition = null;
        resourceSearchCriteria.Expertise = null;
        resourceSearchCriteria.HideShop = null;
        resourceSearchCriteria.Radius = null;
        resourceSearchCriteria.Address = null;
        resourceSearchCriteria.City = null;
        resourceSearchCriteria.State = null;
        resourceSearchCriteria.Country = null;
        resourceSearchCriteria.PostalCode = null;
        resourceSearchCriteria.ResourceId = null;
        resourceSearchCriteria.RadiusSearch = null;
        resourceSearchCriteria.Capacity = null;
        resourceSearchCriteria.SimpleSearch = null;
        resourceSearchCriteria.ActiveFlag = null;
        resourceSearchCriteria.TerritoryType = null;
        resourceSearchCriteria.OfficeID = null;
        resourceSearchCriteria.SortField = null;
        resourceSearchCriteria.SortDirection = null;
        resourceSearchCriteria.StaticContentPrefix = null;
        resourceSearchCriteria.LoggedInUser = null;
        resourceSearchCriteria.IsResourcesSearch = null;
        resourceSearchCriteria.SuffixID = null;
        resourceSearchCriteria.ResourceLimit = null;

        resourceSearchCriteria.setApplCode = function (ApplCode) {
            this.ApplCode = ApplCode;
        };
        resourceSearchCriteria.getApplCode = function () {
            return this.ApplCode;
        };

        resourceSearchCriteria.setResourceSubType = function (ResourceSubType) {
            this.ResourceSubType = ResourceSubType;
        };
        resourceSearchCriteria.getResourceSubType = function () {
            return this.ResourceSubType;
        };

        resourceSearchCriteria.setSortField = function (SortField) {
            this.SortField = SortField;
        };
        resourceSearchCriteria.getSortField = function () {
            return this.SortField;
        };


        resourceSearchCriteria.setPostalCode = function (PostalCode) {
            this.PostalCode = PostalCode;
        };
        resourceSearchCriteria.getPostalCode = function () {
            return this.PostalCode;
        };


        resourceSearchCriteria.setTerritoryType = function (TerritoryType) {
            this.TerritoryType = TerritoryType;
        };
        resourceSearchCriteria.getTerritoryType = function () {
            return this.TerritoryType;
        };


        resourceSearchCriteria.setRadius = function (Radius) {
            this.Radius = Radius;
        };
        resourceSearchCriteria.getRadius = function () {
            return this.Radius;
        };

        resourceSearchCriteria.setGroupType = function (GroupType) {
            this.GroupType = GroupType;
        };
        resourceSearchCriteria.getGroupType = function () {
            return this.GroupType;
        };

        resourceSearchCriteria.setResourceType = function (ResourceType) {
            this.ResourceType = ResourceType;
        };
        resourceSearchCriteria.getResourceType = function () {
            return this.ResourceType;
        };

        resourceSearchCriteria.setResourceId = function (ResourceId) {
            this.ResourceId = ResourceId;
        };
        resourceSearchCriteria.getResourceId = function () {
            return this.ResourceId;
        };

        resourceSearchCriteria.setDefaultCriteriaForMoi = function (MoiType) {
            this.setResourceId("");
            if (MoiType === ENV.MOITYPE_NSDO) {
                this.setResourceType('non-staff');
                this.setResourceSubType('BS');
                miMoiProperties.setResourceGroup('Resource');
            }
            else if (MoiType === ENV.MOITYPE_SC) {
                this.setGroupType('SER_CEN');
                miMoiProperties.setResourceGroup('Group');
            }
            else if (MoiType === ENV.MOITYPE_DI) {
                this.setGroupType('DRVIN');
                miMoiProperties.setResourceGroup('Group');
            }
            else if (MoiType === ENV.MOITYPE_FI) {
                this.setResourceType('staff');
                this.setApplCode('CMAPES');
                miMoiProperties.setResourceGroup('Resource');
            }

            this.setSortField(ENV.RESOURCESORT);
        };

        resourceSearchCriteria.setDefaultCriteriaForResource = function (MoiType, ResourceId) {
            this.setResourceId("");
            this.setResourceType("");
            this.setResourceSubType("");
            this.setGroupType("");
            this.setApplCode("");
            if (MoiType === ENV.MOITYPE_NSDO) {
                this.setResourceId(ResourceId);
                this.setResourceType('non-staff');
                this.setResourceSubType('BS');
                miMoiProperties.setResourceGroup('Resource');
            }
            else if (MoiType === ENV.MOITYPE_DI) {
                this.setResourceId(ResourceId);
                this.setGroupType('DRVIN');
                miMoiProperties.setResourceGroup('Group');
            }
            else if (MoiType === ENV.MOITYPE_SC) {
                this.setResourceId(ResourceId);
                this.setGroupType('SER_CEN');
                miMoiProperties.setResourceGroup('Group');
            }
            else if (MoiType === ENV.MOITYPE_FI) {
                this.setResourceId(ResourceId);
                this.setResourceType('staff');
                this.setApplCode('CMAPES');
                miMoiProperties.setResourceGroup('Resource');
            }
            else if (MoiType === ENV.MOITYPE_STG_YRD) {
                this.setResourceId(ResourceId);
                this.setGroupType('STG_YRD');
                miMoiProperties.setResourceGroup('Group');
            }

            this.setSortField(ENV.RESOURCESORT);
        };

        resourceSearchCriteria.getResourceSearchCriteria = function () {
            return {

                CoCode: resourceSearchCriteria.CoCode,
                ResourceType: resourceSearchCriteria.ResourceType,
                ResourceSubType: resourceSearchCriteria.ResourceSubType,
                GroupType: resourceSearchCriteria.GroupType,
                ClaimID: resourceSearchCriteria.ClaimID,
                ApplCode: resourceSearchCriteria.ApplCode,
                Name: resourceSearchCriteria.Name,
                DispatchCenterID: resourceSearchCriteria.DispatchCenterID,
                Network: resourceSearchCriteria.Network,
                CNum: resourceSearchCriteria.CNum,
                ExpertiseCondition: resourceSearchCriteria.ExpertiseCondition,
                Expertise: resourceSearchCriteria.Expertise,
                HideShop: resourceSearchCriteria.HideShop,
                Radius: resourceSearchCriteria.Radius,
                Address: resourceSearchCriteria.Address,
                City: resourceSearchCriteria.City,
                State: resourceSearchCriteria.State,
                Country: resourceSearchCriteria.Country,
                PostalCode: resourceSearchCriteria.PostalCode,
                ResourceId: resourceSearchCriteria.ResourceId,
                RadiusSearch: resourceSearchCriteria.RadiusSearch,
                Capacity: resourceSearchCriteria.Capacity,
                SimpleSearch: resourceSearchCriteria.SimpleSearch,
                ActiveFlag: resourceSearchCriteria.ActiveFlag,
                TerritoryType: resourceSearchCriteria.TerritoryType,
                OfficeID: resourceSearchCriteria.OfficeID,
                SortField: resourceSearchCriteria.SortField,
                SortDirection: resourceSearchCriteria.SortDirection,
                StaticContentPrefix: resourceSearchCriteria.StaticContentPrefix,
                LoggedInUser: resourceSearchCriteria.LoggedInUser,
                IsResourcesSearch: resourceSearchCriteria.IsResourcesSearch,
                SuffixID: resourceSearchCriteria.SuffixID,
                ResourceLimit: resourceSearchCriteria.ResourceLimit,
            };
        };


        ////
        return resourceSearchCriteria;
    }])


.factory('miComponentRoute',
    function (
        $rootScope,
        ENV,
        miAppProperties) {

        var constant = {};
        constant.Component = false;
        constant.getComponentroute = function (Component) {
            if (Component == ENV.SECURELOGIN_CONSTANT)
                return 'shell.securelogin';
            if (Component == ENV.INTRO1_CONSTANT)
                return 'shell.intro1';
            if (Component == ENV.INTRO2_CONSTANT)
                return 'shell.intro2';
            if (Component == ENV.INTRO3_CONSTANT)
                return 'shell.intro3';
            if (Component == ENV.LANDING_CONSTANT)
                return 'shell.landing-Question';
            if (Component == ENV.IDENTIFICATION_CONSTANT)
                return 'shell.identification-Question';
            if (Component == ENV.SCRIPT_CONSTANT)
                return 'shell.landing-Question.script-Question';
            if (Component == ENV.DATETIME_CONSTANT)
                return 'shell.landing-Question.datetime-Question';
            if (Component == ENV.DATE_CONSTANT)
                return 'shell.landing-Question.date-Question';
            if (Component == ENV.TIME_CONSTANT)
                return 'shell.landing-Question.time-Question';
            if (Component == ENV.YES_NO_CONSTANT)
                return 'shell.landing-Question.yesno-Question';
            if (Component == ENV.CHOICE_CONSTANT)
                return 'shell.landing-Question.choiceselection-Question';
            if (Component == ENV.RANGE_CONSTANT)
                return 'shell.landing-Question.range-Question';
            if (Component == ENV.OPEN_CONSTANT)
                return 'shell.landing-Question.open-Question';
            if (Component == ENV.LIABILITY_CONSTANT)
                return 'shell.landing-Question.liability-Check';
            if (Component == ENV.EXISTINGCLAIM_CONSTANT)
                return 'shell.existingClaim-Check';
            if (Component == ENV.CONFIRMATION_CONSTANT)
                return 'shell.landing-Question.confirmation-Check';
            if (Component == ENV.SUMMARY_CONSTANT)
                return 'shell.landing-Question.summary-Check';
            if (Component == ENV.OUTCOMES_CONSTANT)
                return 'shell.landing-Question.outcome-Detail';
            if (Component == ENV.MOI_PAGE_CONSTANT)
                return 'shell.landing-Question.Moi';
            if (Component == ENV.RESOURCE_CONSTANT)
                return 'shell.landing-Question.ResourceLookUp';
            if (Component == ENV.APPOINTMENT_CONSTANT)
                return 'shell.landing-Question.ScheduleAppointment';
            if (Component == ENV.CLAIMSUMMARY_PAGE_CONSTANT)
                return 'shell.ClaimSummary';
            if (Component == ENV.APPOINTMENTSUMMARY_PAGE_CONSTANT)
                return 'shell.landing-Question.AppointmentSummary';
            if (Component == ENV.ADJUSTER_APPOINTMENT_INFO_CONSTANT)
                return 'shell.landing-Question.AdjusterAppointmentInfo';
            if (Component == ENV.PARTY_CONSTANT)
                return 'shell.landing-Question.PartyType-Question';
            if (Component == ENV.LOCATION_CONSTANT)
                return 'shell.landing-Question.LocationType-Question';
            if (Component === 401) {
                miAppProperties.setstatuscode(401);
                return 'shell.Error';
            }
            else {
                miAppProperties.setstatuscode(400);
                return 'shell.Error';
            }
        };
        return constant;
    })

.factory('miQues',
    function (
        $rootScope) {
        var constant = {};
        constant.plainQues = "";
        constant.formatedQues = "";
        constant.getQues = function (formatedQues, plainQues) {
            if (formatedQues != "false") {
                var que = atob(formatedQues).replace(/<ul>/g, "<ul style='list-style-type:inherit;margin:none;padding:none;'>");
                que = que.replace(/<ol>/g, "<ol style='list-style-type:auto;margin:none;padding:none;'>");
                return que;
            }
            else {
                return plainQues;
            }
        };
        return constant;
    })

.factory('miUiStagesProgressbar', [
            '$rootScope',
        '$interval',
    'miAnimation',
    function (
        $rootScope,
        $interval,
        miAnimation) {

        var uiStagesProgressbarFactory = {};
        uiStagesProgressbarFactory.changeUiStage = function (noOfUiStages, currentUiStage) {
            //for stage UI implementation
            noOfUiStages -= 1;
            currentUiStage -= 1;
            var iindex = 0, howManyTimes = noOfUiStages;
            function animateProgressBar() {
                if (iindex >= 1) {
                    var uistages = [];
                    for (var i = 1; i <= noOfUiStages; i++) {
                        uistages.push('Hidden');
                    }

                    for (var i = 1; i <= iindex; i++) {
                        if (i < currentUiStage) {
                            uistages[i - 1] = 'Complete';
                        }
                        else if (i == currentUiStage) {
                            uistages[i - 1] = 'Active';
                        }
                        else {
                            uistages[i - 1] = 'Pending';
                        }
                    }

                    $rootScope.stages = uistages;
                }
                iindex++;
                if (iindex <= howManyTimes) {
                    var intervalCanceller = $interval(function () {
                        //hide notification
                        animateProgressBar();
                        $interval.cancel(intervalCanceller);
                    }, 200);

                    //$timeout(animateProgressBar, 500);
                }
                else {
                    $rootScope.initailizeProgressBar = false;
                    miAnimation.setAnimation(noOfUiStages);
                }
            }

            miAnimation.resetAnimation();

            if ($rootScope.initailizeProgressBar) {
                animateProgressBar();
            }
            else {
                if (noOfUiStages >= 1) {
                    var uistages = [];
                    for (var i = 1; i <= noOfUiStages; i++) {
                        if (i < currentUiStage) {
                            uistages.push('Complete');
                        }
                        else if (i == currentUiStage) {
                            uistages.push('Active');
                        }
                        else {
                            uistages.push('Pending');
                        }
                    }
                    $rootScope.stages = uistages;
                }

                miAnimation.setAnimation(noOfUiStages);
            }
        };

        return uiStagesProgressbarFactory;
    }])


        .factory('miAnimation',
    function (
        $rootScope,
        $interval) {

        var miAnimationFactory = {};
        miAnimationFactory.setAnimation = function (noOfVisibleStages) {
            function animatePageLogo() {
                $rootScope.logo = "Y";

                var intervalCanceller = $interval(function () {
                    animatePageBody();
                    $interval.cancel(intervalCanceller);
                }, 200);

                //$timeout(animatePageBody, noOfVisibleStages * 300);
            }
            function animatePageBody() {
                $rootScope.body = "Y";
                $rootScope.bodyarrow = "Y";
            }

            var intervalCanceller = $interval(function () {
                animatePageLogo();
                $interval.cancel(intervalCanceller);
            }, noOfVisibleStages * 200);

            //$timeout(animatePageLogo, noOfVisibleStages * 500);
        };
        miAnimationFactory.resetAnimation = function () {
            $rootScope.logo = "N";
            $rootScope.body = "N";
            $rootScope.bodyarrow = "N";
        };
        return miAnimationFactory;
    })

.factory('miQuestionaireFactory', [
    '$rootScope',
    '$filter',
    '$q',
    'ENV',
    'miAppProperties',
    'miLocale',
    'miGetOutcomeService',
    'miGetNextStageService',
    'miGetQuestionService',
    'miGetPreviousQuestionService',
    'miGetQuestionEvaluationService',
    'miGetEvaluationDocIdService',
    'miCopyQuestionnaireSystemCodeService',
    'miSaveQuestionService',
    'miCreateStageService',
    function (
        $rootScope,
        $filter,
        $q,
        ENV,
        miAppProperties,
        miLocale,
        miGetOutcomeService,
        miGetNextStageService,
        miGetQuestionService,
        miGetPreviousQuestionService,
        miGetQuestionEvaluationService,
        miGetEvaluationDocIdService,
        miCopyQuestionnaireSystemCodeService,
        miSaveQuestionService,
        miCreateStageService) {

        var factory = {};

        factory.getOutcome = function (companycode, contextid) {
            var deferred = $q.defer();
            var outcomeResult = { data: '', status: '', route: '' };
            miGetOutcomeService.getOutcome(companycode, contextid)
            .then(function (result) {
                outcomeResult.data = result.data;
                outcomeResult.status = result.status;
                if (outcomeResult.status != 200 && outcomeResult.status != 204) {
                    outcomeResult.route = result.status;
                }
                else {
                    miAppProperties.setOutcomeDetail(outcomeResult.data);
                    miAppProperties.setDisplayOutCome(outcomeResult.data);

                    outcomeResult.route = ENV.OUTCOMES_CONSTANT;
                }
                deferred.resolve(outcomeResult);
            });
            return deferred.promise;
        };

        factory.postOutcome = function (companycode, contextid, outcomeDetails) {
            var deferred = $q.defer();
            var outcomeResult = {
                data: '', status: '', route: ''
            };
            miGetOutcomeService.postOutcome(companycode, contextid, outcomeDetails)
            .then(function (result) {
                outcomeResult.data = result.data;
                outcomeResult.status = result.status;
                if (outcomeResult.status != 200 && outcomeResult.status != 204) {
                    outcomeResult.route = result.status;
                }
                deferred.resolve(outcomeResult);
            });
            return deferred.promise;
        };
        factory.getQuestion = function (companycode, qustnnrevaldocid, questionnaireid, lan, isLimitFirst) {
            var deferred = $q.defer();
            var questionResult = { data: '', status: '', route: '' };

            //for getting quesionnaier first question on next 
            if (isLimitFirst || (!miAppProperties.getcurrentquestionnaireQuestionId() && miAppProperties.getpartialStage() === false)) {
                miAppProperties.setQuestionstate("?limit=first");
            }
            else {
                if ((miAppProperties.getStageStatus() === ENV.CLAIMSTATUS_INPROGRESS && miAppProperties.getpartialStage() === true && miAppProperties.getflagNextStageFirstQuestion() === true) ||
                    (miAppProperties.getStageStatus() === ENV.CLAIMSTATUS_COMPLETE && miAppProperties.getflagNextStageFirstQuestion() === true)) {
                    miAppProperties.setQuestionstate("?limit=first");

                    //setting the variable to false so that next time for same stage we will get next question instead of first question
                    //Otherwise it will go in loop and everytime it will show the first question of current stage
                    miAppProperties.setflagNextStageFirstQuestion(false);
                }
                else {
                    miAppProperties.setQuestionstate("");
                }
            }
            miGetQuestionService.getQuestion(companycode, qustnnrevaldocid, questionnaireid, lan, miAppProperties.getcurrentquestionnaireQuestionId())
            .then(function (result) {
                questionResult.data = result.data;
                questionResult.status = result.status;
                if (questionResult.status != 200 && questionResult.status != 204) {
                    questionResult.route = result.status;
                    deferred.resolve(questionResult);
                }
                else if (questionResult.status === 204) {
                    miAppProperties.clearQuestionDetails();
                    //Condition to check for partial stage (in case of current stage status is "REOPEN" and current stage type is questionnaire)
                    //and all questions are answered for current questionnaire
                    //In this case we need to show the first question of current questionnaire
                    if (!miAppProperties.getcurrentquestionnaireQuestionId() && miAppProperties.getpartialStage() === true && miAppProperties.getStageStatus() === ENV.CLAIMSTATUS_REOPEN && miAppProperties.getIsAnswering() === true) {
                        //if (!miAppProperties.getcurrentquestionnaireQuestionId() && miAppProperties.getpartialStage() === true && miAppProperties.getStageStatus() === ENV.CLAIMSTATUS_REOPEN) {
                        factory.getQuestion(companycode, qustnnrevaldocid, questionnaireid, lan, true).then(function (result) {
                            //Setting the variable "setIsAnswering" to false.  
                            //So that if next time we will get 204 in case of completion of all question
                            //In that case it should not call first question of current questionnaire
                            miAppProperties.setIsAnswering(false);
                            deferred.resolve(result);
                        });
                    }
                    else {
                        miAppProperties.setIsAnswering(false);
                        // service call to update system question document
                        factory.CopyQuestionnaireSystemCode(companycode, miAppProperties.getcontextid(), miAppProperties.getcoStageId(), lan).then(function (result) {
                            if (result.status != 200) { // service respone is not 200 then return/resolve actual status otherwise return getquestion service response.
                                deferred.resolve(result);
                            }
                            else {
                                deferred.resolve(questionResult);
                            }
                        });

                    }
                }
                    // handling version mismatch scenario it will re-intialize questionnaire and ask for first question
                else if (questionResult.data.qustnnrVrsnChng === true) {
                    miAppProperties.clearQuestionDetails();
                    // re-intialize document                    
                    miGetEvaluationDocIdService.getEvaluationDocId(companycode, questionnaireid, qustnnrevaldocid, lan, miAppProperties.getCarrierSystemMap(), miAppProperties.getUserSystemMap())
                       .then(function (result) {
                           questionResult.data = result.data;
                           questionResult.status = result.status;
                           if (questionResult.status != 200 && questionResult.status != 204) {
                               questionResult.route = result.status;
                           }
                           else {
                               questionResult.route = "";
                               miAppProperties.setQuestionstate("?limit=first");
                               miGetQuestionService.getQuestion(companycode, qustnnrevaldocid, questionnaireid, lan, miAppProperties.getcurrentquestionnaireQuestionId())
                                .then(function (result) {
                                    questionResult.data = result.data;
                                    questionResult.status = result.status;
                                    if (questionResult.status != 200 && questionResult.status != 204) {
                                        questionResult.route = result.status;
                                    }
                                    else if (questionResult.status === 204) {
                                        miAppProperties.clearQuestionDetails();
                                    }
                                    else {
                                        questionResult.route = result.data.answrControlType;
                                        miAppProperties.setCurrentQuestion(result.data);
                                        miAppProperties.setpreviousQuestionFlag(result.data.firstQuestion);
                                        // set version mismatch flag
                                        miAppProperties.setVersionMismatchStatus(true);
                                    }
                                    deferred.resolve(questionResult);
                                });
                           }
                       });
                }
                else {
                    questionResult.route = questionResult.data.answrControlType;
                    miAppProperties.setIsAnswering(false);
                    //setting all the question data
                    miAppProperties.setCurrentQuestion(questionResult.data);
                    miAppProperties.setpreviousQuestionFlag(questionResult.data.firstQuestion);
                    deferred.resolve(questionResult);
                }

            });
            return deferred.promise;
        };


        factory.getPreviousQuestion = function (companycode, docid, questionnaireID, lan, qustnnrequstnid) {
            var deferred = $q.defer();
            var previousQuestionResult = { data: '', status: '', route: '' };
            miGetPreviousQuestionService.getPreviousQuestion(companycode, docid, questionnaireID, lan, qustnnrequstnid)
                .then(function (result) {
                    previousQuestionResult.data = result.data;
                    previousQuestionResult.status = result.status;
                    if (previousQuestionResult.status != 200 && previousQuestionResult.status != 204) {
                        previousQuestionResult.route = result.status;
                        deferred.resolve(previousQuestionResult);
                    }
                    else if (previousQuestionResult.status === 204) {
                        // previousQuestionResult.route = result.status;
                        previousQuestionResult.route = "";
                        deferred.resolve(previousQuestionResult);
                    }
                        // handling version mismatch scenario it will re-intialize questionnaire and ask for first question
                    else if (previousQuestionResult.data.qustnnrVrsnChng === true) {
                        miAppProperties.clearQuestionDetails();
                        // re-intialize document                    
                        miGetEvaluationDocIdService.getEvaluationDocId(companycode, questionnaireID, docid, lan, miAppProperties.getCarrierSystemMap(), miAppProperties.getUserSystemMap())
                           .then(function (result) {
                               previousQuestionResult.data = result.data;
                               previousQuestionResult.status = result.status;
                               if (previousQuestionResult.status != 200 && previousQuestionResult.status != 204) {
                                   previousQuestionResult.route = result.status;
                                   deferred.resolve(previousQuestionResult);
                               }
                               else {
                                   previousQuestionResult.route = "";
                                   miAppProperties.setQuestionstate("?limit=first");
                                   miGetQuestionService.getQuestion(companycode, docid, questionnaireID, lan, miAppProperties.getcurrentquestionnaireQuestionId())
                                    .then(function (result) {
                                        previousQuestionResult.data = result.data;
                                        previousQuestionResult.status = result.status;
                                        if (previousQuestionResult.status != 200 && previousQuestionResult.status != 204) {
                                            previousQuestionResult.route = result.status;
                                        }
                                        else if (previousQuestionResult.status === 204) {
                                            miAppProperties.clearQuestionDetails();
                                        }
                                        else {
                                            previousQuestionResult.route = result.data.answrControlType;
                                            miAppProperties.setCurrentQuestion(result.data);
                                            miAppProperties.setpreviousQuestionFlag(result.data.firstQuestion);
                                            // set version mismatch flag
                                            miAppProperties.setVersionMismatchStatus(true);
                                        }
                                        deferred.resolve(previousQuestionResult);
                                    });
                               }
                           });
                    }

                    else {
                        previousQuestionResult.route = previousQuestionResult.data.answrControlType;
                        deferred.resolve(previousQuestionResult);
                    }


                });
            return deferred.promise;

        }

        factory.getQuestionEvaluation = function (companycode, qustnnrevaldocid) {
            var deferred = $q.defer();
            var questionEvaluationResult = { data: '', status: '', route: '' };
            miGetQuestionEvaluationService.getQuestionEvaluation(companycode, qustnnrevaldocid)
            .then(function (result) {
                questionEvaluationResult.data = result.data;
                questionEvaluationResult.status = result.status;
                if (questionEvaluationResult.status != 200 && questionEvaluationResult.status != 204) {
                    questionEvaluationResult.route = result.status;
                }
                else {
                    questionEvaluationResult.route = "";
                }
                deferred.resolve(questionEvaluationResult);
            });
            return deferred.promise;
        };

        factory.getQuestionnaireDetails = function (companycode, contextid, lan) {
            var deferred = $q.defer();
            var questionnaireDetailsResult = { data: '', status: '', route: '' };
            miGetQuestionEvaluationService.getQuestionnaireDetails(companycode, contextid, lan)
            .then(function (result) {
                questionnaireDetailsResult.data = result.data;
                questionnaireDetailsResult.status = result.status;
                if (questionnaireDetailsResult.status != 200 && questionnaireDetailsResult.status != 204) {
                    questionnaireDetailsResult.route = result.status;
                }
                else {
                    //Calling function to set all question answers details into UserIdentificationData
                    questionnaireDetailsResult.route = "";
                }
                deferred.resolve(questionnaireDetailsResult);
            });
            return deferred.promise;
        };
        // changes in initialization process for system and user map
        factory.getEvaluationDocId = function (companycode, questionnaireid, systemdocid, lan, sysMap, userMap) {
            var deferred = $q.defer();
            var evaluationDocResult = { data: '', status: '', route: '' };
            miGetEvaluationDocIdService.getEvaluationDocId(companycode, questionnaireid, systemdocid, lan, sysMap, userMap)
            .then(function (result) {
                evaluationDocResult.data = result.data;
                evaluationDocResult.status = result.status;
                if (evaluationDocResult.status != 200 && evaluationDocResult.status != 204) {
                    evaluationDocResult.route = result.status;
                }
                else {
                    evaluationDocResult.route = "";
                }
                deferred.resolve(evaluationDocResult);
            });
            return deferred.promise;
        };

        factory.saveQuestion = function (companycode, qustnnrevaldocId, questionnaireid, lan, questionDetails) {
            var deferred = $q.defer();
            var questionResult = { data: '', status: '', route: '' };
            miSaveQuestionService.saveQuestion(companycode, qustnnrevaldocId, questionnaireid, lan, questionDetails)
            .then(function (result) {
                questionResult.data = result.data;
                questionResult.status = result.status;
                if (questionResult.status != 200 && questionResult.status != 204) {
                    questionResult.route = result.status;
                }
                else {
                    questionResult.route = "";
                }
                deferred.resolve(questionResult);
            });
            return deferred.promise;
        };

        factory.questionnaireRouteDecision = function (orgcode, docid, questionnaireid, language) {
            var deferred = $q.defer();
            var questionnaireRouteResult = { data: '', status: '', route: '' };
            if (docid) {

                if (miAppProperties.getStageStatus() === ENV.CLAIMSTATUS_INPROGRESS) {
                    factory.getQuestion(orgcode, docid, questionnaireid, language)
                         .then(function (questionData) {
                             if (questionData.status != 200 && questionData.status != 204) {
                                 questionnaireRouteResult.route = questionData.status;
                             }
                             else {
                                 questionnaireRouteResult.data = questionData.data;
                                 questionnaireRouteResult.route = questionData.route;
                                 questionnaireRouteResult.status = questionData.status;
                                 //deferred.resolve(questionnaireRouteResult);
                             }
                             deferred.resolve(questionnaireRouteResult);
                         });

                }
                else {
                    //Always re-initialize questionnaire to update sys doc data and evaluation doc so it will contain update system codes
                    factory.getEvaluationDocId(orgcode, questionnaireid, docid, language, miAppProperties.getCarrierSystemMap(), miAppProperties.getUserSystemMap())
                        .then(function (evaluationDocId) {
                            if (evaluationDocId.route) {
                                questionnaireRouteResult.data = evaluationDocId.data;
                                questionnaireRouteResult.route = evaluationDocId.route;
                                questionnaireRouteResult.status = evaluationDocId.status;
                                deferred.resolve(questionnaireRouteResult);
                            }
                            else {
                                factory.getQuestion(orgcode, docid, questionnaireid, language)
                                .then(function (questionData) {
                                    if (questionData.status != 200 && questionData.status != 204) {
                                        questionnaireRouteResult.route = questionData.status;
                                    }
                                    else {
                                        questionnaireRouteResult.data = questionData.data;
                                        questionnaireRouteResult.route = questionData.route;
                                        questionnaireRouteResult.status = questionData.status;
                                        //deferred.resolve(questionnaireRouteResult);
                                    }
                                    deferred.resolve(questionnaireRouteResult);
                                });
                            }
                        });
                }
            }
            else {
                factory.getEvaluationDocId(orgcode, questionnaireid, docid, language, miAppProperties.getCarrierSystemMap(), miAppProperties.getUserSystemMap())
                .then(function (evaluationDocId) {
                    if (evaluationDocId.route) {
                        questionnaireRouteResult.data = evaluationDocId.data;
                        questionnaireRouteResult.route = evaluationDocId.route;
                        questionnaireRouteResult.status = evaluationDocId.status;
                        deferred.resolve(questionnaireRouteResult);
                    }
                    else {
                        miAppProperties.setDocID(evaluationDocId.data);
                        if (miAppProperties.getcontextid() && miAppProperties.getflagStage()) {
                            if (miAppProperties.getStageStatus() != null) {
                                miAppProperties.setflagStage(false);
                            }
                            else {
                                miCreateStageService.createStage(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                                   .then(function (createstageresponse) {
                                       if (createstageresponse.status != 200 && createstageresponse.status != 204) {
                                           questionnaireRouteResult.data = createstageresponse.data;
                                           questionnaireRouteResult.route = createstageresponse.status;
                                           questionnaireRouteResult.status = createstageresponse.status;
                                           deferred.resolve(questionnaireRouteResult);
                                       }
                                       else {
                                           miAppProperties.setflagStage(false);
                                           factory.getQuestion(orgcode, miAppProperties.getDocID(), questionnaireid, language)
                                              .then(function (questionData) {
                                                  if (questionData.status != 200 && questionData.status != 204) {
                                                      questionnaireRouteResult.route = questionData.status;
                                                  }
                                                  else {
                                                      questionnaireRouteResult.data = questionData.data;
                                                      questionnaireRouteResult.route = questionData.route;
                                                      questionnaireRouteResult.status = questionData.status;
                                                  }
                                                  deferred.resolve(questionnaireRouteResult);
                                              });
                                       }
                                   });
                            }
                        }
                        else {
                            factory.getQuestion(orgcode, miAppProperties.getDocID(), questionnaireid, language)
                            .then(function (questionData) {
                                if (questionData.status != 200 && questionData.status != 204) {
                                    questionnaireRouteResult.route = questionData.status;
                                }
                                else {
                                    questionnaireRouteResult.data = questionData.data;
                                    questionnaireRouteResult.route = questionData.route;
                                    questionnaireRouteResult.status = questionData.status;
                                }
                                deferred.resolve(questionnaireRouteResult);
                            });
                        }
                    }
                })
            }
            return deferred.promise;
        };

        //Factory to copy questionnarie system code
        factory.CopyQuestionnaireSystemCode = function (companycode, contextid, evaldocid, lan) {
            var deferred = $q.defer();
            var CopyQuestionnaireSystemCodeResult = { data: '', status: '', route: '' };
            miCopyQuestionnaireSystemCodeService.CopyQuestionnaireSystemCode(companycode, contextid, evaldocid, lan)
            .then(function (result) {
                CopyQuestionnaireSystemCodeResult.data = result.data;
                CopyQuestionnaireSystemCodeResult.status = result.status;
                if (CopyQuestionnaireSystemCodeResult.status != 200) {
                    CopyQuestionnaireSystemCodeResult.route = result.status;
                }
                else {
                    CopyQuestionnaireSystemCodeResult.route = "";
                }
                deferred.resolve(CopyQuestionnaireSystemCodeResult);
            });
            return deferred.promise;
        };

        return factory;
    }])


.factory('miStageFactory', [
    '$rootScope',
    '$filter',
    '$q',
    'ENV',
    'miAppProperties',
    'miLocale',
    'miGetNextStageService',
    'miCreateStageService',
    'miUpdateStageService',
    'miGetStageFromUriService',
    'miGetPartialStageService',
    'miQuestionaireFactory',
    'miMoiFactory',
    'miCMSIntegrationService',
    'miGetPreviousStageService',
    'miCMSFactory',
    'miEditQuestionnaireSummaryService',
    function (
        $rootScope,
        $filter,
        $q,
        ENV,
        miAppProperties,
        miLocale,
        miGetNextStageService,
        miCreateStageService,
        miUpdateStageService,
        miGetStageFromUriService,
        miGetPartialStageService,
        miQuestionaireFactory,
        miMoiFactory,
        miCMSIntegrationService,
        miGetPreviousStageService,
        miCMSFactory,
        miEditQuestionnaireSummaryService) {

        var factory = {};

        factory.cmsIntegration = function (contextid, lan) {
            var deferred = $q.defer();
            var cmsintegrationResult = { data: '', status: '', route: '' };
            miCMSIntegrationService.CmsIntegration(contextid, lan)
            .then(function (result) {
                cmsintegrationResult.data = result.data;
                cmsintegrationResult.status = result.status;
                if (cmsintegrationResult.status != 200 && cmsintegrationResult.status != 204) {
                    $rootScope.ShellTitle = "";
                    cmsintegrationResult.route = result.status;
                    deferred.resolve(cmsintegrationResult);
                }
                else {
                    cmsintegrationResult.route = "";
                    deferred.resolve(cmsintegrationResult);
                }
            });
            return deferred.promise;
        };

        factory.cmsIntegrationRouteDecision = function (contextid, docid, costageid, lan) {
            var deferred = $q.defer();
            var cmsintegrationRoute = { data: '', status: '', route: '' };
            // Condition to check if integration stage is already IN_PROGRESS then do not need to create stage again
            if (ENV.CLAIMSTATUS_INPROGRESS === miAppProperties.getStageStatus()) {
                factory.cmsIntegration(contextid, lan)
                .then(function (cmsresponse) {
                    if (cmsresponse.route) {
                        cmsintegrationRoute.route = cmsresponse.route;
                        deferred.resolve(cmsintegrationRoute);
                    }
                    else {
                        miUpdateStageService.updateStage(contextid, costageid, lan, ENV.CLAIMSTATUS_COMPLETE)
                            .then(function (updatestageresponse) {
                                if (updatestageresponse.status != 200 && updatestageresponse.status != 204) {
                                    cmsintegrationRoute.data = updatestageresponse.data;
                                    cmsintegrationRoute.route = updatestageresponse.status;
                                    cmsintegrationRoute.status = updatestageresponse.status;
                                    deferred.resolve(cmsintegrationRoute);
                                }
                                else {
                                    if (cmsresponse.data.resStatus === ENV.SUCCESS) {
                                        factory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                      .then(function (nextstagedata) {
                                          cmsintegrationRoute.route = nextstagedata.route;
                                          deferred.resolve(cmsintegrationRoute);
                                      })
                                    }
                                    else {
                                        //handle custom error here
                                        cmsintegrationRoute.route = 400;
                                        miAppProperties.setCustomError(cmsresponse.data.errInfo.errDesc);
                                        deferred.resolve(cmsintegrationRoute);
                                    }
                                }

                            });
                    }
                });
            }
                // else in case of stage in not IN_PROGRESS so create first
            else {
                miCreateStageService.createStage(contextid, docid, costageid, lan)
                          .then(function (createstageresponse) {
                              if (createstageresponse.status != 200 && createstageresponse.status != 204) {
                                  cmsintegrationRoute.data = createstageresponse.data;
                                  cmsintegrationRoute.route = createstageresponse.status;
                                  cmsintegrationRoute.status = createstageresponse.status;
                                  deferred.resolve(cmsintegrationRoute);
                              }
                              else {
                                  factory.cmsIntegration(contextid, lan)
                                  .then(function (cmsresponse) {
                                      if (cmsresponse.route) {
                                          cmsintegrationRoute.route = cmsresponse.route;
                                          deferred.resolve(cmsintegrationRoute);
                                      }
                                      else {
                                          miUpdateStageService.updateStage(contextid, costageid, lan, ENV.CLAIMSTATUS_COMPLETE)
                                              .then(function (updatestageresponse) {
                                                  if (updatestageresponse.status != 200 && updatestageresponse.status != 204) {
                                                      cmsintegrationRoute.data = updatestageresponse.data;
                                                      cmsintegrationRoute.route = updatestageresponse.status;
                                                      cmsintegrationRoute.status = updatestageresponse.status;
                                                      deferred.resolve(cmsintegrationRoute);
                                                  }
                                                  else {
                                                      if (cmsresponse.data.resStatus === ENV.SUCCESS) {
                                                          factory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                        .then(function (nextstagedata) {
                                                            cmsintegrationRoute.route = nextstagedata.route;
                                                            deferred.resolve(cmsintegrationRoute);
                                                        })
                                                      }
                                                      else {
                                                          //handle custom error here
                                                          cmsintegrationRoute.route = 400;
                                                          miAppProperties.setCustomError(cmsresponse.data.errInfo.errDesc);
                                                          deferred.resolve(cmsintegrationRoute);
                                                      }
                                                  }

                                              });
                                      }
                                  });
                              }
                          });
            }
            return deferred.promise;
        };

        factory.getNextStage = function (companycode, appversion, stageorder, lan) {
            var deferred = $q.defer();
            var nextStageResult = { data: '', status: '', route: '' };
            miGetNextStageService.getNextStage(companycode, appversion, stageorder, lan, miAppProperties.getcontextid())
            .then(function (result) {
                nextStageResult.data = result.data;
                nextStageResult.status = result.status;
                if (nextStageResult.status != 200 && nextStageResult.status != 204) {
                    $rootScope.ShellTitle = "";
                    nextStageResult.route = nextStageResult.status;
                    deferred.resolve(nextStageResult);
                }
                else if (nextStageResult.status === 204 || !nextStageResult.data) {
                    $rootScope.ShellTitle = "";
                    nextStageResult.route = ENV.CLAIMSUMMARY_PAGE_CONSTANT;//"";//HARDCORDED LAST STAGE CLAIM SUMMARY IF NOT ADDED IN STAGE TABLE
                    deferred.resolve(nextStageResult);
                }
                else {
                    miAppProperties.setstageName(nextStageResult.data.stageName);
                    miAppProperties.setstageUiOrder(nextStageResult.data.stageUiOrder);
                    miAppProperties.setStageOrder(nextStageResult.data.stageOrder);
                    miAppProperties.setpageName(nextStageResult.data.pageName);
                    miAppProperties.setstageType(nextStageResult.data.stageType);
                    miAppProperties.setstageDesc(nextStageResult.data.stageDescription);
                    miAppProperties.settotalNumOfStages(nextStageResult.data.totalNumOfStages);
                    miAppProperties.setIdentificationEvalDocID(miAppProperties.getDocID());
                    miAppProperties.setcoStageId(nextStageResult.data.coStageId);
                    miAppProperties.setIntegrationStage(nextStageResult.data.prevStageIntgrtnTyp);
                    miAppProperties.setStageStatus(nextStageResult.data.stageStatus);
                    // set system question map to initialize questionnaire
                    miAppProperties.setUserSystemMap(nextStageResult.data.userSystemMap);
                    miAppProperties.setCarrierSystemMap(nextStageResult.data.carrierSystemMap);

                    ///$rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');

                    if (miAppProperties.getredirectionToken() === miAppProperties.getstageName()) {

                        if (miAppProperties.getstageType() === ENV.QUESTIONNAIRE_CONSTANT) {
                            //checking the partial stage condition
                            //If yes then we need to set the "is answering" flag to ture.
                            //It will later use in getquestion function to get the first question in case of 204
                            if (miAppProperties.getpartialStage() === true) {
                                miAppProperties.setIsAnswering(true);
                            }
                            //Condition to check whether it is partial stage case and the next stage is in "IN Progress" mode
                            //So we need to shwo the first question of questionnaire 
                            // added the condition to check stageStatus is complete and get first question of questionnaire and this condition comes from edit functionnality of questionnaireSummary page
                            if (miAppProperties.getpartialStage() === true && (miAppProperties.getStageStatus() === ENV.CLAIMSTATUS_INPROGRESS || miAppProperties.getStageStatus() === ENV.CLAIMSTATUS_COMPLETE)) {
                                miAppProperties.setflagNextStageFirstQuestion(true);
                            }

                            miAppProperties.setquestionnaireID(nextStageResult.data.questionnaireId);
                            miAppProperties.setDocID(nextStageResult.data.documentId);
                            // miAppProperties.setsystemDocId(nextStageResult.data.sysDocumentId);// already commented code
                            if (miAppProperties.getislandingpage()) {
                                miQuestionaireFactory.questionnaireRouteDecision(miAppProperties.getorgcode(), miAppProperties.getDocID(), miAppProperties.getquestionnaireID(), miLocale.getLocaleCode())
                                    .then(function (questionnaireRoute) {
                                        if (questionnaireRoute.status == 204)//condition to check when questionnaire does not have any question
                                        {
                                            if (questionnaireRoute.data === "") {
                                                if (miAppProperties.getcontextid()) {
                                                    factory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                                                    .then(function (updatestageresponse) {
                                                        if (updatestageresponse.route) {
                                                            nextStageResult.route = updatestageresponse.route;
                                                            deferred.resolve(nextStageResult);
                                                        }
                                                        else {
                                                            miAppProperties.setflagStage(true);
                                                            //miAppProperties.setDocidlist(miAppProperties.getDocID());
                                                            factory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                                       .then(function (nextstagedata) {
                                                                           nextStageResult.route = nextstagedata.route;
                                                                           deferred.resolve(nextStageResult);
                                                                       });


                                                        }
                                                    })
                                                }
                                                else {
                                                    factory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                    .then(function (nextstagedata) {
                                                        nextStageResult.route = nextstagedata.route;
                                                        deferred.resolve(nextStageResult);
                                                    })
                                                }
                                            }
                                            ////
                                        }
                                        else {
                                            $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                            nextStageResult.route = questionnaireRoute.route;
                                            deferred.resolve(nextStageResult);
                                        }
                                    })
                            }
                            else {
                                $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                nextStageResult.route = ENV.LANDING_CONSTANT;
                                deferred.resolve(nextStageResult);
                            }
                        }
                        else if (miAppProperties.getstageType() === ENV.INTEGRATION_CONSTANT) {
                            //integration type
                            $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                            //Integration having page "Vehicle Summary Page"
                            if (miAppProperties.getpageName() == ENV.SUMMARY_CONSTANT) {

                                miAppProperties.setPolicyVerificationRequestData($rootScope.identificationkeyvaluepairs, miAppProperties.getorgcode(), miAppProperties.getDocID(), miAppProperties.getIdentificationEvalDocID());
                                miCMSFactory.policyVerification(miAppProperties.getPolicyVerificationRequestData(), miLocale.getLocaleCode())
                                .then(function (policyVerificationdata) {
                                    if (miAppProperties.getvehicalDetailsStatus() === 406) {
                                        //cfpLoadingBar.complete();
                                        nextStageResult.route = policyVerificationdata.route;
                                        deferred.resolve(nextStageResult);
                                    }
                                        // create stage only when policy verification successfull
                                    else if (policyVerificationdata.data) {
                                        miAppProperties.setDocID(false);
                                        factory.createStage(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                                          .then(function (response) {
                                              //cfpLoadingBar.complete();
                                              if (response.route) {
                                                  nextStageResult.route = response.route;
                                                  deferred.resolve(nextStageResult);

                                              }
                                              else {
                                                  nextStageResult.route = policyVerificationdata.route;
                                                  deferred.resolve(nextStageResult);

                                              }
                                          });
                                    }
                                    else {
                                        nextStageResult.route = policyVerificationdata.route;
                                        deferred.resolve(nextStageResult);
                                    }
                                });
                            }
                            else {
                                miAppProperties.setDocID(false);
                                factory.cmsIntegrationRouteDecision(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                                       .then(function (cmsintegrationrouteresponse) {
                                           nextStageResult.route = cmsintegrationrouteresponse.route;
                                           deferred.resolve(nextStageResult);
                                       });
                            }
                        }
                        else {
                            //predefined page
                            if (miAppProperties.getredirectionToken() === ENV.IDENTIFICATION_STATE) {
                                $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                //Condition to check the page name is Identification Confirmation Page
                                //If yes then we need to get all quenstion answers details and show them on page
                                if (miAppProperties.getpageName() == ENV.CONFIRMATION_CONSTANT) {
                                    miQuestionaireFactory.getQuestionnaireDetails(companycode, miAppProperties.getcontextid(), lan)
                                    .then(function (questionnaireDetailsResult) {
                                        if (questionnaireDetailsResult.route) {
                                            nextStageResult.route = questionnaireDetailsResult.route;
                                            deferred.resolve(nextStageResult);
                                        }
                                        else {
                                            //Clear questionnaire question details to reset all values
                                            miAppProperties.ClearQuestionnairesQuestionDetails();

                                            //Set Identification data into questionnaire details
                                            miAppProperties.SetIdentificationDataIntoQuestionnaireQuestionDetails();

                                            //Calling function to set all question answers details into UserIdentificationData
                                            miAppProperties.setAllQuestionDetails(questionnaireDetailsResult.data);

                                            nextStageResult.route = miAppProperties.getpageName();

                                            deferred.resolve(nextStageResult);

                                        }
                                    })
                                }

                            }
                            else {
                                miAppProperties.setDocID(false);
                                if (miAppProperties.getpageName() === ENV.MOI_PAGE_CONSTANT) {
                                    $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                    //CREATE POST FNOL STAGE
                                    factory.createStage(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                                    .then(function (result) {
                                        if (result.route) {
                                            nextStageResult.route = result.route;
                                            deferred.resolve(nextStageResult);
                                        }
                                        else {
                                            miAppProperties.setflagStage(false);
                                            miMoiFactory.moiPageDecision(ENV.MOI_PAGE_CONSTANT)
                                             .then(function (moipageresponse) {
                                                 nextStageResult.route = moipageresponse.route;
                                                 deferred.resolve(nextStageResult);
                                             });
                                        }
                                    })
                                }

                                else {
                                    //Condition to check the page name is Questionnaire Summary Page
                                    //If yes then we need to check stagestatus for making stage inprogress and route the confirmationPage1 based on condition
                                    if (miAppProperties.getpageName() === ENV.QUESTIONNAIRE_SUMMARY_CONSTANT) {
                                        miAppProperties.setQuestionnaireSummaryPage(ENV.QUESTIONNAIRE_SUMMARY_CONSTANT);
                                        $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                        miQuestionaireFactory.getQuestionnaireDetails(companycode, miAppProperties.getcontextid(), lan)
                                        .then(function (questionnaireDetailsResult) {
                                            if (questionnaireDetailsResult.route) {
                                                nextStageResult.route = questionnaireDetailsResult.route;
                                                deferred.resolve(nextStageResult);
                                            }
                                            else {
                                                //Clear questionnaire question details to reset all values
                                                miAppProperties.ClearQuestionnairesQuestionDetails();
                                                //Calling function to set all question answers details into UserIdentificationData
                                                miAppProperties.setAllQuestionDetails(questionnaireDetailsResult.data);
                                                if (miAppProperties.getStageStatus() != null) {
                                                    miAppProperties.setflagStage(false);
                                                    nextStageResult.route = ENV.CONFIRMATION_CONSTANT;
                                                    deferred.resolve(nextStageResult);
                                                }
                                                else {
                                                    //Create stage for the questionnaire summary page
                                                    factory.createStage(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                                                     .then(function (result) {
                                                         if (result.route) {
                                                             nextStageResult.route = result.route;
                                                             miAppProperties.setflagStage(false);
                                                             deferred.resolve(nextStageResult);
                                                         }
                                                         else {
                                                             nextStageResult.route = ENV.CONFIRMATION_CONSTANT;
                                                             deferred.resolve(nextStageResult);

                                                         }

                                                     });
                                                }
                                            }
                                        })

                                    }
                                    else {
                                        $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                        nextStageResult.route = miAppProperties.getpageName();
                                        deferred.resolve(nextStageResult);
                                    }
                                }
                            }
                        }
                    }
                    else {

                        if (miAppProperties.getstageName() != ENV.REPORTCLAIM_STATE) {

                            if (miAppProperties.getstageType() === ENV.QUESTIONNAIRE_CONSTANT) {
                                //checking the partial stage condition
                                //If yes then we need to set the "is answering" flag to ture.
                                //It will later use in getquestion function to get the first question in case of 204
                                if (miAppProperties.getpartialStage() === true) {
                                    miAppProperties.setIsAnswering(true);
                                }
                                //Condition to check whether it is partial stage case and the next stage is in "IN Progress" mode
                                //So we need to shwo the first question of questionnaire
                                // added the condition to check stageStatus is complete and get first question of questionnaire and this condition comes from edit functionnality of questionnaireSummary page
                                if (miAppProperties.getpartialStage() === true && (miAppProperties.getStageStatus() === ENV.CLAIMSTATUS_INPROGRESS || miAppProperties.getStageStatus() === ENV.CLAIMSTATUS_COMPLETE)) {
                                    miAppProperties.setflagNextStageFirstQuestion(true);
                                }
                                miAppProperties.setquestionnaireID(nextStageResult.data.questionnaireId);
                                miAppProperties.setDocID(nextStageResult.data.documentId);

                                //miAppProperties.setsystemDocId(nextStageResult.data.sysDocumentId);  //already commented code

                                miAppProperties.setredirectionToken(miAppProperties.getstageName());

                                if (miAppProperties.getislandingpage()) {
                                    miQuestionaireFactory.questionnaireRouteDecision(miAppProperties.getorgcode(), miAppProperties.getDocID(), miAppProperties.getquestionnaireID(), miLocale.getLocaleCode())
                                        .then(function (questionnaireRoute) {
                                            if (questionnaireRoute.status == 204)//condition to check when questionnaire does not have any question
                                            {
                                                if (questionnaireRoute.data === "") {
                                                    if (miAppProperties.getcontextid()) {
                                                        factory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                                                        .then(function (updatestageresponse) {
                                                            if (updatestageresponse.route) {
                                                                nextStageResult.route = updatestageresponse.route;
                                                                deferred.resolve(nextStageResult);
                                                            }
                                                            else {
                                                                miAppProperties.setflagStage(true);
                                                                //miAppProperties.setDocidlist(miAppProperties.getDocID());
                                                                factory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                                           .then(function (nextstagedata) {
                                                                               nextStageResult.data = nextstagedata.data;
                                                                               nextStageResult.route = nextstagedata.route;
                                                                               deferred.resolve(nextStageResult);
                                                                           });


                                                            }
                                                        })
                                                    }
                                                    else {
                                                        factory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                        .then(function (nextstagedata) {
                                                            nextStageResult.data = nextstagedata.data;
                                                            nextStageResult.route = nextstagedata.route;
                                                            deferred.resolve(nextStageResult);
                                                        })
                                                    }
                                                }
                                                ////
                                            }
                                            else {
                                                $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                                nextStageResult.route = questionnaireRoute.route;
                                                deferred.resolve(nextStageResult);
                                            }
                                        })
                                }
                                else {
                                    $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                    nextStageResult.route = ENV.LANDING_CONSTANT;
                                    deferred.resolve(nextStageResult);
                                }
                            }
                            else if (miAppProperties.getstageType() === ENV.INTEGRATION_CONSTANT) {
                                //integration type
                                $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                //Integration having page "Vehicle Summary Page"
                                if (miAppProperties.getpageName() == ENV.SUMMARY_CONSTANT) {
                                    miAppProperties.setPolicyVerificationRequestData($rootScope.identificationkeyvaluepairs, miAppProperties.getorgcode(), miAppProperties.getDocID(), miAppProperties.getIdentificationEvalDocID());
                                    miCMSFactory.policyVerification(miAppProperties.getPolicyVerificationRequestData(), miLocale.getLocaleCode())
                                    .then(function (policyVerificationdata) {
                                        if (miAppProperties.getvehicalDetailsStatus() === 406) {
                                            //cfpLoadingBar.complete();
                                            nextStageResult.route = policyVerificationdata.route;
                                            deferred.resolve(nextStageResult);

                                        }
                                            // create stage only when policy verification successfull
                                        else if (policyVerificationdata.data) {
                                            miAppProperties.setDocID(false);
                                            factory.createStage(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                                              .then(function (response) {
                                                  //cfpLoadingBar.complete();
                                                  if (response.route) {
                                                      nextStageResult.route = response.route;
                                                      deferred.resolve(nextStageResult);
                                                  }
                                                  else {
                                                      nextStageResult.route = policyVerificationdata.route;
                                                      deferred.resolve(nextStageResult);

                                                  }
                                              });
                                        }
                                        else {
                                            nextStageResult.route = policyVerificationdata.route;
                                            deferred.resolve(nextStageResult);
                                        }
                                    });
                                }
                                else {
                                    miAppProperties.setDocID(false);
                                    factory.cmsIntegrationRouteDecision(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                                           .then(function (cmsintegrationrouteresponse) {
                                               nextStageResult.route = cmsintegrationrouteresponse.route;
                                               deferred.resolve(nextStageResult);
                                           });
                                }
                            }
                            else {
                                //predefined page
                                if (miAppProperties.getredirectionToken() === ENV.IDENTIFICATION_STATE) {
                                    //nextStageResult.route = ENV.CONFIRMATION_CONSTANT;
                                    $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                    nextStageResult.route = miAppProperties.getpageName();
                                    deferred.resolve(nextStageResult);
                                }
                                else {
                                    miAppProperties.setDocID(false);
                                    if (miAppProperties.getpageName() === ENV.MOI_PAGE_CONSTANT) {
                                        $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                        //CREATE POST FNOL STAGE
                                        factory.createStage(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                                        .then(function (result) {
                                            if (result.route) {
                                                nextStageResult.route = result.route;
                                                deferred.resolve(nextStageResult);
                                            }
                                            else {
                                                miAppProperties.setflagStage(false);
                                                miMoiFactory.moiPageDecision(ENV.MOI_PAGE_CONSTANT)
                                                 .then(function (moipageresponse) {
                                                     nextStageResult.route = moipageresponse.route;
                                                     deferred.resolve(nextStageResult);
                                                 });
                                            }
                                        })
                                    }
                                    else {
                                        //Condition to check the page name is Questionnaire Summary Page
                                        //If yes then we need to check stagestatus for making stage inprogress and route the confirmationPage1 based on condition
                                        if (miAppProperties.getpageName() === ENV.QUESTIONNAIRE_SUMMARY_CONSTANT) {
                                            miAppProperties.setQuestionnaireSummaryPage(ENV.QUESTIONNAIRE_SUMMARY_CONSTANT);
                                            $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                            miQuestionaireFactory.getQuestionnaireDetails(companycode, miAppProperties.getcontextid(), lan)
                                                   .then(function (questionnaireDetailsResult) {
                                                       if (questionnaireDetailsResult.route) {
                                                           nextStageResult.route = questionnaireDetailsResult.route;
                                                           deferred.resolve(nextStageResult);
                                                       }
                                                       else {
                                                           //Clear questionnaire question details to reset all values
                                                           miAppProperties.ClearQuestionnairesQuestionDetails();
                                                           //Calling function to set all question answers details into UserIdentificationData
                                                           miAppProperties.setAllQuestionDetails(questionnaireDetailsResult.data);
                                                           if (miAppProperties.getStageStatus() != null) {
                                                               miAppProperties.setflagStage(false);
                                                               nextStageResult.route = ENV.CONFIRMATION_CONSTANT;
                                                               deferred.resolve(nextStageResult);
                                                           }
                                                           else {
                                                               //Create stage for the questionnaire summary page
                                                               factory.createStage(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                                                                .then(function (result) {
                                                                    if (result.route) {
                                                                        nextStageResult.route = result.route;
                                                                        miAppProperties.setflagStage(false);
                                                                        deferred.resolve(nextStageResult);
                                                                    }
                                                                    else {

                                                                        nextStageResult.route = ENV.CONFIRMATION_CONSTANT;
                                                                        deferred.resolve(nextStageResult);

                                                                    }

                                                                });
                                                           }
                                                       }
                                                   })

                                        }
                                        else {
                                            $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                            nextStageResult.route = miAppProperties.getpageName();
                                            deferred.resolve(nextStageResult);
                                        }
                                    }
                                }
                            }
                        }   //End of if condition to check stagename is ReportClaim or not
                        else {
                            $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                            nextStageResult.route = miAppProperties.getpageName();
                            deferred.resolve(nextStageResult);
                        }
                    }
                }
            });
            return deferred.promise;
        };

        factory.createStage = function (contextid, documentid, costageid, lan) {
            var deferred = $q.defer();
            var createStageResult = {
                data: '', status: '', route: ''
            };
            miCreateStageService.createStage(contextid, documentid, costageid, lan)
            .then(function (result) {
                createStageResult.data = result.data;
                createStageResult.status = result.status;
                if (createStageResult.status != 200 && createStageResult.status != 204) {
                    createStageResult.route = result.status;
                }
                else {
                    createStageResult.route = "";
                }
                deferred.resolve(createStageResult);
            });
            return deferred.promise;
        };

        factory.updateStage = function (contextid, coStageid, lan, claimStatus) {
            var deferred = $q.defer();
            var updateStageResult = {
                data: '', status: '', route: ''
            };
            miUpdateStageService.updateStage(contextid, coStageid, lan, claimStatus)
            .then(function (result) {
                updateStageResult.data = result.data;
                updateStageResult.status = result.status;
                if (updateStageResult.status != 200 && updateStageResult.status != 204) {
                    updateStageResult.route = result.status;
                }
                else {
                    updateStageResult.route = "";
                }
                deferred.resolve(updateStageResult);
            });
            return deferred.promise;
        };

        factory.getNextStagefromUri = function (Uri, appversion, lan) {
            var deferred = $q.defer();
            var stageUriResult = {
                data: '', status: '', route: ''
            };
            miGetStageFromUriService.getNextStagefromUri(Uri, appversion, lan)
            .then(function (result) {
                stageUriResult.data = result.data;
                stageUriResult.status = result.status;
                if (stageUriResult.status != 200 && stageUriResult.status != 204) {
                    $rootScope.ShellTitle = "";
                    stageUriResult.route = result.status;
                    deferred.resolve(stageUriResult);
                }
                else if (stageUriResult.status === 204 || !stageUriResult.data) {
                    $rootScope.ShellTitle = "";
                    stageUriResult.route = "";
                    deferred.resolve(stageUriResult);
                }
                else {
                    miAppProperties.setstageName(stageUriResult.data.stageName);
                    miAppProperties.setquestionnaireID(stageUriResult.data.questionnaireId);
                    miAppProperties.setDocID(stageUriResult.data.documentId);
                    miAppProperties.setstageUiOrder(stageUriResult.data.stageUiOrder);
                    miAppProperties.setStageOrder(stageUriResult.data.stageOrder);
                    miAppProperties.setpageName(stageUriResult.data.pageName);
                    miAppProperties.setstageType(stageUriResult.data.stageType);
                    miAppProperties.setcoStageId(stageUriResult.data.coStageId);
                    miAppProperties.setstageDesc(stageUriResult.data.stageDescription);
                    miAppProperties.settotalNumOfStages(stageUriResult.data.totalNumOfStages);
                    miAppProperties.setredirectionToken(miAppProperties.getstageName());
                    miAppProperties.setIntegrationStage(stageUriResult.data.prevStageIntgrtnTyp);
                    miAppProperties.setStageStatus(stageUriResult.data.stageStatus);
                    // set system question map to initialize questionnaire
                    miAppProperties.setUserSystemMap(stageUriResult.data.userSystemMap);
                    miAppProperties.setCarrierSystemMap(stageUriResult.data.carrierSystemMap);

                    // $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                    if (miAppProperties.getstageType() === ENV.QUESTIONNAIRE_CONSTANT) {
                        //Questionnaire
                        $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                        stageUriResult.route = ENV.LANDING_CONSTANT;
                        deferred.resolve(stageUriResult);
                    }
                    else if (miAppProperties.getstageType() === ENV.INTEGRATION_CONSTANT) {
                        //integration type
                        miAppProperties.setDocID(false);
                        $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                        factory.cmsIntegrationRouteDecision(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                                     .then(function (cmsintegrationrouteresponse) {
                                         stageUriResult.route = cmsintegrationrouteresponse.route;
                                         deferred.resolve(stageUriResult);
                                     });

                    }
                    else {
                        //predefined page
                        miAppProperties.setDocID(false);
                        if (miAppProperties.getpageName() === ENV.MOI_PAGE_CONSTANT) {
                            $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                            miMoiFactory.moiPageDecision(ENV.MOI_PAGE_CONSTANT)
                            .then(function (moipageresponse) {
                                stageUriResult.route = moipageresponse.route;
                                deferred.resolve(stageUriResult);
                            });
                        }
                        else {
                            //condition to check the page name is questionnaire summary page
                            if (miAppProperties.getpageName() === ENV.QUESTIONNAIRE_SUMMARY_CONSTANT) {
                                miAppProperties.setQuestionnaireSummaryPage(ENV.QUESTIONNAIRE_SUMMARY_CONSTANT);
                                $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                miQuestionaireFactory.getQuestionnaireDetails(miAppProperties.getorgcode(), miAppProperties.getcontextid(), lan)
                            .then(function (questionnaireDetailsResult) {
                                if (questionnaireDetailsResult.route) {
                                    stageUriResult.route = questionnaireDetailsResult.route;
                                    deferred.resolve(stageUriResult);
                                }
                                else {
                                    //Clear questionnaire question details to reset all values
                                    miAppProperties.ClearQuestionnairesQuestionDetails();
                                    //Calling function to set all question answers details into UserIdentificationData
                                    miAppProperties.setAllQuestionDetails(questionnaireDetailsResult.data);
                                    stageUriResult.route = ENV.CONFIRMATION_CONSTANT;
                                    deferred.resolve(stageUriResult);

                                }
                            })

                            }
                            else {
                                $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                stageUriResult.route = miAppProperties.getpageName();
                                deferred.resolve(stageUriResult);
                            }
                        }
                    }
                }
            });
            return deferred.promise;
        };

        factory.getNextPartialStage = function (companycode, appversion, contextid, lan) {
            var deferred = $q.defer();
            var partialStageResult = {
                data: '', status: '', route: ''
            };
            miGetPartialStageService.getNextPartialStage(companycode, appversion, contextid, lan)
            .then(function (result) {
                partialStageResult.data = result.data;
                partialStageResult.status = result.status;

                if (partialStageResult.status != 200 && partialStageResult.status != 204) {
                    $rootScope.ShellTitle = "";
                    partialStageResult.route = result.status;
                    deferred.resolve(partialStageResult);
                }
                else if (partialStageResult.status === 204) {
                    if (result.headers()["next-stage-uri"]) {
                        factory.getNextStagefromUri(result.headers()["next-stage-uri"], appversion, lan)
                        .then(function (nextstagedata) {
                            partialStageResult.route = nextstagedata.route;
                            partialStageResult.data = nextstagedata.data;
                            deferred.resolve(partialStageResult);
                        });
                    }
                    else {
                        $rootScope.ShellTitle = "";
                        partialStageResult.route = ENV.CLAIMSUMMARY_PAGE_CONSTANT;//"";//HARDCORDED LAST STAGE CLAIM SUMMARY IF NOT ADDED IN STAGE TABLE
                        deferred.resolve(partialStageResult);
                    }
                }
                else if (partialStageResult.data === "") {
                    $rootScope.ShellTitle = "";
                    partialStageResult.route = "";
                    deferred.resolve(partialStageResult);
                }
                else {
                    miAppProperties.setstageName(partialStageResult.data.stageName);
                    miAppProperties.setquestionnaireID(partialStageResult.data.questionnaireId);
                    miAppProperties.setDocID(partialStageResult.data.documentId);
                    miAppProperties.setstageUiOrder(partialStageResult.data.stageUiOrder);
                    miAppProperties.setStageOrder(partialStageResult.data.stageOrder);
                    miAppProperties.setpageName(partialStageResult.data.pageName);
                    miAppProperties.setstageType(partialStageResult.data.stageType);
                    miAppProperties.setcoStageId(partialStageResult.data.coStageId);
                    miAppProperties.setstageDesc(partialStageResult.data.stageDescription);
                    miAppProperties.settotalNumOfStages(partialStageResult.data.totalNumOfStages);
                    miAppProperties.setredirectionToken(miAppProperties.getstageName());
                    miAppProperties.setIntegrationStage(partialStageResult.data.prevStageIntgrtnTyp);
                    miAppProperties.setStageStatus(partialStageResult.data.stageStatus);
                    // set system question map to initialize questionnaire
                    miAppProperties.setUserSystemMap(partialStageResult.data.userSystemMap);
                    miAppProperties.setCarrierSystemMap(partialStageResult.data.carrierSystemMap);
                    //   $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                    if (miAppProperties.getstageType() === ENV.QUESTIONNAIRE_CONSTANT) {
                        //Questionnaire
                        $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                        partialStageResult.route = ENV.LANDING_CONSTANT;
                        deferred.resolve(partialStageResult);
                    }
                    else if (miAppProperties.getstageType() === ENV.INTEGRATION_CONSTANT) {
                        //integration type
                        $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                        if (miAppProperties.getpageName() == ENV.SUMMARY_CONSTANT) {  //route the vehicle summary page in partial case when user left the application at this statge
                            partialStageResult.route = miAppProperties.getpageName();
                            deferred.resolve(partialStageResult);
                        }
                        else {
                            miAppProperties.setDocID(false);
                            factory.cmsIntegrationRouteDecision(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                                        .then(function (cmsintegrationrouteresponse) {
                                            partialStageResult.route = cmsintegrationrouteresponse.route;
                                            deferred.resolve(partialStageResult);
                                        });
                        }
                    }
                    else {
                        //predefined page
                        miAppProperties.setDocID(false);
                        if (miAppProperties.getpageName() === ENV.MOI_PAGE_CONSTANT) {
                            $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                            miMoiFactory.moiPageDecision(ENV.MOI_PAGE_CONSTANT)
                            .then(function (moipageresponse) {
                                partialStageResult.route = moipageresponse.route;
                                deferred.resolve(partialStageResult);
                            });
                        }
                        else {
                            //condition to check the page name is questionnaire summary page
                            if (miAppProperties.getpageName() === ENV.QUESTIONNAIRE_SUMMARY_CONSTANT) {
                                miAppProperties.setQuestionnaireSummaryPage(ENV.QUESTIONNAIRE_SUMMARY_CONSTANT);
                                $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                miQuestionaireFactory.getQuestionnaireDetails(companycode, miAppProperties.getcontextid(), lan)
                            .then(function (questionnaireDetailsResult) {
                                if (questionnaireDetailsResult.route) {
                                    partialStageResult.route = questionnaireDetailsResult.route;
                                    deferred.resolve(partialStageResult);
                                }
                                else {
                                    //Clear questionnaire question details to reset all values
                                    miAppProperties.ClearQuestionnairesQuestionDetails();
                                    //Calling function to set all question answers details into UserIdentificationData
                                    miAppProperties.setAllQuestionDetails(questionnaireDetailsResult.data);
                                    partialStageResult.route = ENV.CONFIRMATION_CONSTANT;
                                    deferred.resolve(partialStageResult);

                                }
                            })

                            }
                            else {
                                $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                partialStageResult.route = miAppProperties.getpageName();
                                deferred.resolve(partialStageResult);
                            }
                        }
                    }
                }
            });
            return deferred.promise;
        };

        factory.getPreviousStage = function (contextid, companycode, appversion, stageorder, lan) {     //Function for getting previous stage
            var deferred = $q.defer();
            var previousStageResult = {
                data: '', status: '', route: ''
            };
            miGetPreviousStageService.getPreviousStage(contextid, companycode, appversion, stageorder, lan)
           .then(function (result) {
               previousStageResult.data = result.data;
               previousStageResult.status = result.status;
               if (previousStageResult.status != 200 && previousStageResult.status != 204) {
                   $rootScope.ShellTitle = "";
                   previousStageResult.route = previousStageResult.status;
                   deferred.resolve(previousStageResult);
               }
               else if (previousStageResult.status === 204 || !previousStageResult.data) {
                   $rootScope.ShellTitle = "";
                   previousStageResult.route = "";
                   deferred.resolve(previousStageResult);
               }
               else {
                   miAppProperties.setstageName(previousStageResult.data.stageName);
                   miAppProperties.setstageUiOrder(previousStageResult.data.stageUiOrder);
                   miAppProperties.setStageOrder(previousStageResult.data.stageOrder);
                   miAppProperties.setpageName(previousStageResult.data.pageName);
                   miAppProperties.setstageType(previousStageResult.data.stageType);
                   miAppProperties.setstageDesc(previousStageResult.data.stageDescription);
                   miAppProperties.settotalNumOfStages(previousStageResult.data.totalNumOfStages);
                   //miAppProperties.setIdentificationEvalDocID(miAppProperties.getDocID());
                   miAppProperties.setcoStageId(previousStageResult.data.coStageId);
                   miAppProperties.setIntegrationStage(previousStageResult.data.prevStageIntgrtnTyp);
                   miAppProperties.setStageStatus(previousStageResult.data.stageStatus);
                   // set system question map to initialize questionnaire
                   miAppProperties.setUserSystemMap(previousStageResult.data.userSystemMap);
                   miAppProperties.setCarrierSystemMap(previousStageResult.data.carrierSystemMap);

                   ///   $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                   //This condition is for Questionnair state
                   if (miAppProperties.getstageType() == ENV.QUESTIONNAIRE_CONSTANT) {
                       miAppProperties.setquestionnaireID(previousStageResult.data.questionnaireId);
                       miAppProperties.setDocID(previousStageResult.data.documentId);
                       // miAppProperties.setredirectionToken(miAppProperties.getstageName());
                       miQuestionaireFactory.getPreviousQuestion(miAppProperties.getorgcode(), miAppProperties.getDocID(), miAppProperties.getquestionnaireID(), miLocale.getLocaleCode(), miAppProperties.getPrevioustquestionnaireQuestionId())
                       .then(function (questiondata) {
                           //condition to check when previous stage is questionnaire and next previous stage is integration stage then back should be disabled
                           if (miAppProperties.getintegrationStage() === true && questiondata.data === "" && questiondata.status === 204) {
                               miAppProperties.setBackButtonDisableFromNoPreQuestion(false);
                               miAppProperties.setCurrentQuestion(questiondata.data);
                               previousStageResult.route = questiondata.route;
                               deferred.resolve(previousStageResult);
                           }
                               //condition to check when previous stage is questionnaire and next previous stage is not integration stage then again get previous stage by recursive
                           else if (miAppProperties.getintegrationStage() != true && questiondata.data === "" && questiondata.status === 204) {
                               miAppProperties.currentquestionnaireQuestionId = 0;
                               miAppProperties.setquestionnaireID(0);
                               miAppProperties.setpartialStage(false);
                               factory.getPreviousStage(miAppProperties.getcontextid(), miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                              .then(function (previousresult) {
                                  if (previousresult.status === 204) {
                                      previousStageResult.route = "";
                                      deferred.resolve(previousStageResult);
                                  }
                                  else {
                                      //condition to check when previous stage is questionnaire and next previous stage is integration stage then get next stage upto present stage for update the present stage value and user 
                                      //should go next but back is disabled here.
                                      if (miAppProperties.getintegrationStage() === true) {
                                          miAppProperties.setBackButtonDisableFromNoPreQuestion(false);
                                          factory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                                                                                 .then(function (nextstagedata) {
                                                                                                                     previousStageResult.data = nextstagedata.data;
                                                                                                                     previousStageResult.route = "";
                                                                                                                     deferred.resolve(previousStageResult);
                                                                                                                 })
                                      }
                                      else {
                                          previousStageResult.data = previousresult.data;
                                          previousStageResult.route = previousresult.route;
                                          deferred.resolve(previousStageResult);
                                      }
                                  }
                              })

                           }
                           else {
                               $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                               miAppProperties.setCurrentQuestion(questiondata.data);
                               miAppProperties.setpreviousQuestionFlag(questiondata.data.firstQuestion);  //set the question flag which is not comes from previousQustion Service of questionnire when user go to back 
                               previousStageResult.route = questiondata.route;
                               deferred.resolve(previousStageResult);
                           }

                       });
                   }
                   else {
                       $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                       if (previousStageResult.data.pageName === ENV.INTRO2_CONSTANT) {  // TO Check Informational Predefined PageName to rendor the previous information page
                           previousStageResult.route = ENV.INTRO3_CONSTANT;
                       }
                       else {
                           previousStageResult.route = miAppProperties.getpageName();
                       }
                       deferred.resolve(previousStageResult);
                   }
               }
           });
            return deferred.promise;
        };

        //call the gefirstquestionnaire service from confirmation page1 to get first questionnaire using 
        //edit functionality from questionnaire summary page
        factory.getFirstQuestionnaire = function (companycode, contextid, appversion, lan) {
            var deferred = $q.defer();
            var firstQuestionnaireResult = {
                data: '', status: '', route: ''
            };
            miEditQuestionnaireSummaryService.getFirstQuestionnaire(companycode, contextid, appversion, lan)
            .then(function (result) {
                firstQuestionnaireResult.data = result.data;
                firstQuestionnaireResult.status = result.status;

                if (firstQuestionnaireResult.status != 200) {
                    $rootScope.ShellTitle = "";
                    firstQuestionnaireResult.route = result.status;
                    deferred.resolve(firstQuestionnaireResult);
                }
                else {
                    miAppProperties.setstageName(firstQuestionnaireResult.data.stageName);
                    miAppProperties.setquestionnaireID(firstQuestionnaireResult.data.questionnaireId);
                    miAppProperties.setDocID(firstQuestionnaireResult.data.documentId);
                    miAppProperties.setstageUiOrder(firstQuestionnaireResult.data.stageUiOrder);
                    miAppProperties.setStageOrder(firstQuestionnaireResult.data.stageOrder);
                    miAppProperties.setpageName(firstQuestionnaireResult.data.pageName);
                    miAppProperties.setstageType(firstQuestionnaireResult.data.stageType);
                    miAppProperties.setcoStageId(firstQuestionnaireResult.data.coStageId);
                    miAppProperties.setstageDesc(firstQuestionnaireResult.data.stageDescription);
                    miAppProperties.settotalNumOfStages(firstQuestionnaireResult.data.totalNumOfStages);
                    miAppProperties.setredirectionToken(miAppProperties.getstageName());
                    miAppProperties.setIntegrationStage(firstQuestionnaireResult.data.prevStageIntgrtnTyp);
                    miAppProperties.setStageStatus(firstQuestionnaireResult.data.stageStatus);
                    // set system question map to initialize questionnaire
                    miAppProperties.setUserSystemMap(firstQuestionnaireResult.data.userSystemMap);
                    miAppProperties.setCarrierSystemMap(firstQuestionnaireResult.data.carrierSystemMap);
                    // $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                    if (miAppProperties.getstageType() === ENV.QUESTIONNAIRE_CONSTANT) {
                        //call the getQuestion for getting first questionnaire and argument pass as true for getting 
                        //the first question of first questionnaire
                        miQuestionaireFactory.getQuestion(miAppProperties.getorgcode(), miAppProperties.getDocID(), miAppProperties.getquestionnaireID(), miLocale.getLocaleCode(), true)
                                .then(function (questionData) {
                                    if (questionData.status != 200 && questionData.status != 204) {
                                        firstQuestionnaireResult.route = questionData.status;
                                        deferred.resolve(firstQuestionnaireResult);
                                    }
                                    else if (questionData.status === 204 && questionData.data === "") {
                                        factory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                                              .then(function (nextstagedata) {
                                                                                  firstQuestionnaireResult.route = nextstagedata.route;
                                                                                  deferred.resolve(firstQuestionnaireResult);
                                                                              });

                                    }
                                    else {
                                        $rootScope.ShellTitle = $filter('translate')('_' + miAppProperties.getstageName() + '_');
                                        firstQuestionnaireResult.data = questionData.data;
                                        firstQuestionnaireResult.route = questionData.route;
                                        firstQuestionnaireResult.status = questionData.status;
                                        deferred.resolve(firstQuestionnaireResult);
                                    }

                                });
                    }

                }
            });
            return deferred.promise;
        };

        return factory;
    }])


.factory('miCMSFactory', [
    '$rootScope',
    '$filter',
    '$q',
    'ENV',
    'miAppProperties',
    'miPolicyVerificationService',
    'miGetVehicalDetailsService',
    'miQuestionaireFactory',
    'miDeletePolicyService',
    'miMoiFactory',
    //'miStageFactory',
    'miLocale',
    function (
        $rootScope,
        $filter,
        $q,
        ENV,
        miAppProperties,
        miPolicyVerificationService,
        miGetVehicalDetailsService,
        miQuestionaireFactory,
        miDeletePolicyService,
        miMoiFactory,
        //miStageFactory,
        miLocale) {

        var factory = {};

        factory.policyVerification = function (policyverificationrequestdata, lan) {
            var deferred = $q.defer();
            var policyVerificationResult = {
                data: '', status: '', route: ''
            };
            miPolicyVerificationService.verifyPolicy(policyverificationrequestdata, lan, miAppProperties.getcontextid())
            .then(function (result) {
                policyVerificationResult.data = result.data;
                policyVerificationResult.status = result.status;
                miAppProperties.setvehicalDetailsStatus(result.status);
                if (policyVerificationResult.status != 200 && policyVerificationResult.status != 204 && policyVerificationResult.status != 406) {
                    $rootScope.ShellTitle = "";
                    policyVerificationResult.route = result.status;
                    deferred.resolve(policyVerificationResult);
                }
                else if (policyVerificationResult.status === 204 || !policyVerificationResult.data) {
                    $rootScope.ShellTitle = "";
                    policyVerificationResult.route = "";
                    deferred.resolve(policyVerificationResult);
                }
                else {
                    miAppProperties.setcontextid(policyVerificationResult.data.contextId);
                    miAppProperties.setVehicalDetails(policyVerificationResult.data);
                    policyVerificationResult.route = miAppProperties.getpageName();
                    deferred.resolve(policyVerificationResult);
                }
            });
            return deferred.promise;
        };

        factory.getVehicalDetails = function (contextid, lan) {
            var deferred = $q.defer();
            var vehicalDetailsResult = {
                data: '', status: '', route: ''
            };
            miGetVehicalDetailsService.getVehicalDetails(contextid, lan)
            .then(function (result) {
                vehicalDetailsResult.data = result.data;
                vehicalDetailsResult.status = result.status;
                if (vehicalDetailsResult.status != 200 && vehicalDetailsResult.status != 204) {
                    $rootScope.ShellTitle = "";
                    vehicalDetailsResult.route = result.status;
                    deferred.resolve(vehicalDetailsResult);
                }
                else {
                    miAppProperties.setVehicalDetails(vehicalDetailsResult.data);
                    vehicalDetailsResult.route = "";
                    deferred.resolve(vehicalDetailsResult);
                }
            });
            return deferred.promise;
        };

        factory.deletePolicy = function (contextid, contextstatus, lan) {
            var deferred = $q.defer();
            var deletePolicyResult = {
                data: '', status: '', route: ''
            };
            miDeletePolicyService.deletePolicy(contextid, contextstatus, lan)
            .then(function (result) {
                deletePolicyResult.data = result.data;
                deletePolicyResult.status = result.status;
                if (deletePolicyResult.status != 200 && deletePolicyResult.status != 204) {
                    $rootScope.ShellTitle = "";
                    deletePolicyResult.route = result.status;
                    deferred.resolve(deletePolicyResult);
                }
                else {
                    deletePolicyResult.route = "";
                    deferred.resolve(deletePolicyResult);
                }
            });
            return deferred.promise;
        };

        return factory;
    }])

.factory('miAppFactory', [
    '$rootScope',
    '$q',
    'miAppProperties',
    'miLocale',
    'ENV',
    'miGetLanguageListService',
    'miGetComplexDataService',
    'miGetIdentificationFieldsService',
    'miIdentificationService',
    'miStageFactory',
    'miQuestionaireFactory',
    function (
        $rootScope,
        $q,
        miAppProperties,
        miLocale,
        ENV,
        miGetLanguageListService,
        miGetComplexDataService,
        miGetIdentificationFieldsService,
        miIdentificationService,
        miStageFactory,
        miQuestionaireFactory
        ) {

        var factory = {};

        factory.getLanguageList = function () {
            var deferred = $q.defer();
            var languageListResult = {
                data: '', status: '', route: ''
            };
            miGetLanguageListService.getLanguageList()
            .then(function (result) {
                languageListResult.data = result.data;
                languageListResult.status = result.status;
                if (languageListResult.status != 200 && languageListResult.status != 204) {
                    $rootScope.ShellTitle = "";
                    languageListResult.route = result.status;
                    deferred.resolve(languageListResult);
                }
                else {
                    var ar = [];
                    for (var i = 0; i < languageListResult.data.languagesList.length; i++) {
                        ar.push({
                            'text': languageListResult.data.languagesList[i].nativeName, 'value': languageListResult.data.languagesList[i].cultureCd
                        });
                    }
                    miAppProperties.setlanguagelist(ar);
                    languageListResult.route = "";
                    deferred.resolve(languageListResult);
                }
            });
            return deferred.promise;
        };

        factory.getIdentificationFields = function (companycode, lan) {
            var deferred = $q.defer();
            var identificationResult = {
                data: '', status: '', route: ''
            };
            miGetIdentificationFieldsService.getIdentificationFields(companycode, lan)
            .then(function (result) {
                identificationResult.data = result.data;
                identificationResult.status = result.status;
                if (identificationResult.status != 200 && identificationResult.status != 204) {
                    $rootScope.ShellTitle = "";
                    identificationResult.route = result.status;
                    deferred.resolve(identificationResult);
                }
                else {
                    miAppProperties.setIdentificationfields(identificationResult.data);
                    identificationResult.route = "";
                    deferred.resolve(identificationResult);
                }
            });
            return deferred.promise;
        };

        factory.identify = function (queryparam, lan) {
            var deferred = $q.defer();
            var identificationResult = {
                data: '', status: '', route: ''
            };
            miIdentificationService.identify(queryparam, lan)
            .then(function (result) {
                identificationResult.data = result.data;
                identificationResult.status = result.status;
                if (identificationResult.status != 200 && identificationResult.status != 204) {
                    $rootScope.ShellTitle = "";
                    identificationResult.route = result.status;
                    deferred.resolve(identificationResult);
                }
                else {
                    identificationResult.route = "";
                    deferred.resolve(identificationResult);
                }
            });
            return deferred.promise;
        };

        factory.getRoute = function () {
            var deferred = $q.defer();
            var Result = {
                data: '', status: '', route: ''
            };
            miQuestionaireFactory.saveQuestion(miAppProperties.getorgcode(), miAppProperties.getDocID(), miAppProperties.getquestionnaireID(), miLocale.getLocaleCode(), miAppProperties.getQuestionDetails())
            .then(function (savequestionresponse) {
                if (savequestionresponse.route) {
                    Result.route = savequestionresponse.route;
                    deferred.resolve(Result);
                }
                else {
                    miQuestionaireFactory.getQuestion(miAppProperties.getorgcode(), miAppProperties.getDocID(), miAppProperties.getquestionnaireID(), miLocale.getLocaleCode())
                                        .then(function (questiondata) {
                                            if (questiondata.data === "") {
                                                if (miAppProperties.getcontextid()) {
                                                    miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                                                    .then(function (updatestageresponse) {
                                                        if (updatestageresponse.route) {
                                                            Result.route = updatestageresponse.route;
                                                            deferred.resolve(Result);
                                                        }
                                                        else {
                                                            miAppProperties.setflagStage(true);
                                                            miQuestionaireFactory.getQuestionEvaluation(miAppProperties.getorgcode(), miAppProperties.getDocID())
                                                            .then(function (questionevaluationresponse) {
                                                                if (questionevaluationresponse.route) {
                                                                    Result.route = questionevaluationresponse.route;
                                                                    deferred.resolve(Result);
                                                                }
                                                                else {
                                                                    //miAppProperties.setDocidlist(miAppProperties.getDocID());
                                                                    miAppProperties.setBackButtonDisableFromNoPreQuestion(true);
                                                                    miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                                        .then(function (nextstagedata) {
                                                                            Result.route = nextstagedata.route;
                                                                            deferred.resolve(Result);
                                                                        })
                                                                }
                                                            })
                                                        }
                                                    })
                                                }
                                                else {
                                                    miAppProperties.setBackButtonDisableFromNoPreQuestion(true);
                                                    miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                    .then(function (nextstagedata) {
                                                        Result.route = nextstagedata.route;
                                                        deferred.resolve(Result);
                                                    })
                                                }
                                            }
                                            else {
                                                miAppProperties.setBackButtonDisableFromNoPreQuestion(true);
                                                Result.route = questiondata.route;
                                                deferred.resolve(Result);
                                            }
                                        })
                }
            })
            return deferred.promise;
        }

        factory.getPreviousRoute = function (qustnnrequstnid) {
            var deferred = $q.defer();
            var Result = {
                data: '', status: '', route: ''
            };

            miQuestionaireFactory.getPreviousQuestion(miAppProperties.getorgcode(), miAppProperties.getDocID(), miAppProperties.getquestionnaireID(), miLocale.getLocaleCode(), qustnnrequstnid)
                 .then(function (questiondata) {
                     if (questiondata.status === 204) {
                         miAppProperties.currentquestionnaireQuestionId = 0;
                         miAppProperties.setquestionnaireID(0);
                         miAppProperties.setpartialStage(false);
                         miStageFactory.getPreviousStage(miAppProperties.getcontextid(), miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                        .then(function (previousresult) {
                            if (miAppProperties.getintegrationStage() === true && miAppProperties.getpreviousQuestionFlag()) {
                                //If there is version change in previous stage, but user is in current stage(means stage 2)
                                //Then user will back on 1st question of previous stage questionnaire  in case of version change
                                //that's why we are using the following code : miAppProperties.getVersionMismatchStatus() === true
                                if (miAppProperties.getVersionMismatchStatus() === true) {
                                    Result.route = previousresult.route;
                                    deferred.resolve(Result);
                                }
                                    //condition to check when user go back from first question of questionnaire and previous stage is also questionnire with no question and next previous stage is integration 
                                    //then user should not go back from present stage and back should be disable but user can go next from here.
                                else {
                                    miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                    .then(function (nextstagedata) {
                                        Result.route = "";
                                        deferred.resolve(Result);
                                    });
                                }
                            }
                            else {
                                Result.route = previousresult.route;
                                deferred.resolve(Result);
                            }
                        })
                     }
                     else {
                         miAppProperties.setCurrentQuestion(questiondata.data);
                         miAppProperties.setpreviousQuestionFlag(questiondata.data.firstQuestion);
                         Result.route = questiondata.route;
                         deferred.resolve(Result);
                     }

                 })

            return deferred.promise;
        }
        //
        factory.getComplexFieldData = function (url) {
            var deferred = $q.defer();
            var fieldListResult = {
                data: '', status: '', route: ''
            };
            miGetComplexDataService.getComplexFieldData(url)
            .then(function (result) {
                fieldListResult.data = result.data;
                fieldListResult.status = result.status;
                if (fieldListResult.status != 200) {
                    $rootScope.ShellTitle = "";
                    fieldListResult.route = result.status;
                    deferred.resolve(fieldListResult);
                }
                else {
                    fieldListResult.route = "";
                    deferred.resolve(fieldListResult);
                }
            });
            return deferred.promise;
        }

        return factory;
    }])




.factory('miValidation',
    function (
        $rootScope,
        $filter,
        ENV) {

        var validationFactory = {};
        var output = "";
        validationFactory.validate = function (inputValue) {
            output = "Valid";
            var val = inputValue.trim();
            if (val) {
            }
            else { val = "" }
            return ((val != "") ? output : $filter('translate')('_Required_'));
        }

        validationFactory.validatePostal = function (inputValue) {
            var val = inputValue.toString().toUpperCase();
            var regExCA = /[ABCEGHJKLMNPRSTVXY]\d[ABCEGHJ-NPRSTV-Z][ ]?\d[ABCEGHJ-NPRSTV-Z]\d/; // for canada
            var regExUS = /(^\d{5}$)|(^\d{5}-\d{4}$)/; // for GMR (US)
            return (regExCA.test(val) || regExUS.test(val) ? output : $filter('translate')('_VALIDPOSTALCODE_'));
        }

        validationFactory.validateDateandTime = function (inputValue, type, isCustom, format) {
            var isValid = false;
            if (!isCustom && angular.equals(type, ENV.TIME_CONSTANT)) {
                var datetimestamp = Date.parse(inputValue);
                isValid = !isNaN(datetimestamp);
            }
            else if (!isCustom && angular.equals(type, ENV.DATE_CONSTANT)) {
                var datetimestamp = Date.parse(inputValue);
                isValid = !isNaN(datetimestamp);
            }
            else {
                isValid = validateCustomDateTime(inputValue, type, format);
            }

            if (isValid) {
                output = "Valid";
            }
            else {
                if (type === ENV.DATE_CONSTANT || type === ENV.DATEOFLOSS_CONSTANT) {
                    output = $filter('translate')('_InValidDate_');
                }
                else if (type === ENV.DATETIME_CONSTANT) {
                    output = $filter('translate')('_InValidDateTime_');
                }
                else {
                    output = $filter('translate')('_InValidTime_');
                }
            }

            return output;
        }
        // validate date and time with custom validator for other than chrome
        function validateCustomDateTime(datetimeValue, type, format) {

            if (type === ENV.DATE_CONSTANT || type === ENV.DATEOFLOSS_CONSTANT) {
                return validateCustomDate(datetimeValue.toString().trim(), format);
            }
            else if (angular.equals(type, ENV.DATETIME_CONSTANT)) {
                if (angular.equals(datetimeValue.toString(), ENV.INVALID_DATE)) {
                    return false;
                }
                else {
                    var parts = datetimeValue.split(" ");
                    var datePart = parts[0].toString().trim();
                    var timePart = parts[parts.length - 1].toString().trim();
                    return (validateCustomDate(datePart, format.split(" ")[0]) && validateCustomTime(timePart));
                }
            }
            else {
                return validateCustomTime(datetimeValue.toString().trim());
            }
        }

        function validateCustomDateTimeAllowEmpty(datetimeValue, type, format) {

            if (type === ENV.DATE_CONSTANT || type === ENV.DATEOFLOSS_CONSTANT) {
                return validateCustomDate(datetimeValue.toString().trim(), format);
            }
            else if (type === ENV.DATETIME_CONSTANT) {
                var parts = datetimeValue.split(" ");
                var datePart = parts[0].toString().trim();
                var timePart = parts[parts.length - 1].toString().trim();

                return (validateCustomDate(datePart, format) && validateCustomTime(timePart));
            }
            else {
                return validateCustomTimeAllowEmpty(datetimeValue.toString().trim());
            }
        }
        // validate date with 
        function validateCustomDate(dateValue, format) {
            var date_regex1 = /^(0?[1-9]|1[0-2])\/(0?[1-9]|1[0-9]|2[0-9]|3[01])\/(16|17|18|19|20|21)\d{2}$/;
            var date_regex2 = /^(0?[1-9]|1[0-9]|2[0-9]|3[01])\/(0?[1-9]|1[0-2])\/(16|17|18|19|20|21)\d{2}$/;
            var toBeContinue = false;
            if (dateValue == "")
                return false;
            if (dateValue && format == ENV.DATE_FORMAT)
                toBeContinue = date_regex1.test(dateValue);
            if (dateValue && format == ENV.DATE_FORMAT2) {
                toBeContinue = date_regex2.test(dateValue);
                dateValue = dateValue.replace(/(\d{2})\/(\d{2})\/(\d{4})/, "$2/$1/$3");
            }

            if (toBeContinue) {
                // Parse the date parts to integers
                var day, month, year, parts, monthLength;
                parts = dateValue.split("/");

                day = parseInt(parts[1].length == 1 ? "0" + parts[1] : parts[1], 10);
                month = parseInt(parts[0].length == 1 ? "0" + parts[0] : parts[0], 10);
                year = parseInt(parts[2].length == 1 ? "0" + parts[2] : parts[2], 10);

                // Check the ranges of month and year
                if (year < 1000 || year > 3000 || month == 0 || month > 12)
                    return false;

                monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

                // Adjust for leap years
                if (year % 400 == 0 || (year % 100 != 0 && year % 4 == 0))
                    monthLength[1] = 29;

                // Check the range of the day
                return day > 0 && day <= monthLength[month - 1];
            }
            else
                return false;
        }

        function validateCustomTime(timeValue) {

            //var time_regex = /^\d{2}:\d{2}$/;// hh:mm
            //var time_regex = /^(0?[0-9]|\d{2})\/(0?[0-9]|\d{2})$/;
            var time_regex = /^([0-2]?[0-9]):[0-5]?[0-9]$/;
            if (!(time_regex.test(timeValue))) {
                return false;
            }
            else {
                // Parse the time parts to integers
                var parts = timeValue.split(":");
                var hour = parseInt(parts[0], 10);
                var minute = parseInt(parts[1], 10);

                // Check the ranges of hour and minute
                if (hour > 23 || minute > 59)
                    return false;
                else
                    return true;
            }
        }

        function validateCustomTimeAllowEmpty(timeValue) {

            //var time_regex = /^\d{2}:\d{2}$/;// hh:mm
            //var time_regex = /^(0?[0-9]|\d{2})\/(0?[0-9]|\d{2})$/;
            if (timeValue.length === 0)
                return true;
            var time_regex = /^([0-2]?[0-9]):[0-5]?[0-9]$/;
            if (!(time_regex.test(timeValue))) {
                return false;
            }
            else {
                // Parse the time parts to integers
                var parts = timeValue.split(":");
                var hour = parseInt(parts[0], 10);
                var minute = parseInt(parts[1], 10);

                // Check the ranges of hour and minute
                if (hour > 23 || minute > 59)
                    return false;
                else
                    return true;
            }
        }

        validationFactory.validateDateandTimeAllowEmpty = function (inputValue, type, isCustom) {

            var isValid = false;
            if (isCustom) {
                isValid = validateCustomDateTimeAllowEmpty(inputValue, type);
            }
            else {
                var datetimestamp = Date.parse(inputValue);
                isValid = !isNaN(datetimestamp);
            }

            if (isValid) {
                output = "Valid";
            }
            else {
                if (type === ENV.DATE_CONSTANT || type === ENV.DATEOFLOSS_CONSTANT) {
                    output = $filter('translate')('_InValidDate_');
                }
                else if (type === ENV.DATETIME_CONSTANT) {
                    output = $filter('translate')('_InValidDateTime_');
                }
                else {
                    output = $filter('translate')('_InValidTime_');
                }
            }

            return output;
        }

        validationFactory.getCustomDateTime = function (inputValue, type, format) {

            var month = (inputValue.getMonth() + 1).toString().length == 1 ? "0" + (inputValue.getMonth() + 1).toString() : (inputValue.getMonth() + 1).toString();
            var days = inputValue.getDate().toString().length == 1 ? "0" + inputValue.getDate().toString() : inputValue.getDate().toString();
            var year = (inputValue.getYear() + 1900);
            var hours = inputValue.getHours().toString().length == 1 ? "0" + inputValue.getHours().toString() : inputValue.getHours().toString();
            var minutes = inputValue.getMinutes().toString().length == 1 ? "0" + inputValue.getMinutes().toString() : inputValue.getMinutes().toString();

            if ((type === ENV.DATE_CONSTANT || type === ENV.DATEOFLOSS_CONSTANT) && format == ENV.DATE_FORMAT) {
                return (month + '/' + days + '/' + year);
            }
            else if ((type === ENV.DATE_CONSTANT || type === ENV.DATEOFLOSS_CONSTANT) && format == ENV.DATE_FORMAT2) {
                return (days + '/' + month + '/' + year);
            }
            else if (type === ENV.DATETIME_CONSTANT && format == ENV.DATETIME_FORMAT) {
                return (month + '/' + days + '/' + year + ' ' + hours + ':' + minutes);
            }
            else if (type === ENV.DATETIME_CONSTANT && format == ENV.DATETIME_FORMAT2) {
                return (days + '/' + month + '/' + year + ' ' + hours + ':' + minutes);
            }
            else {
                return (hours + ':' + minutes);
            }

        }
        validationFactory.isToday = function (date) {
            return $filter('date')(new Date(date).toISOString(), "MM/dd/yyyy") == $filter('date')(new Date().toISOString(), "MM/dd/yyyy");

        }
        function getYearsFromFutureDate(inputValue) {
            var today = new Date();
            var inputDate = new Date(inputValue);
            var years = inputDate.getFullYear() - today.getFullYear();
            var m = inputDate.getMonth() - today.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < inputDate.getDate())) {
                years++;
            }
            return years;
        }
        validationFactory.isNotPastDate = function (date, offset) {
            var currentResourceDate, filterDate, tempDate;
            //Converting current date to resource time zone
            tempDate = $filter('date')(new Date(), ENV.FILTER_DATE_FORMAT2, offset).replace($filter('translate')('_AM_'), "AM").replace($filter('translate')('_PM_'), "PM");
            currentResourceDate = new Date(tempDate).setHours(0, 0, 0, 0);
            filterDate = new Date(date + " " + ENV.DEFAULT_TIME).setHours(0, 0, 0, 0);
            return filterDate >= currentResourceDate ? output : $filter('translate')("_InvalidDateMessage_");
        }
        validationFactory.isNotPastDatetime = function (datetime, offset) {
            var currentResourceDatetime, filterDatetime;
            //Converting current datetime to resource time zone 
            currentResourceDatetime = new Date($filter('date')(new Date(), ENV.FILTER_DATE_FORMAT4, offset)).setSeconds(0, 0);
            filterDatetime = new Date(datetime).setSeconds(0, 0);
            return filterDatetime >= currentResourceDatetime ? output : $filter('translate')("_InvalidTimeMessage_");
        }
        validationFactory.setMaxSearchYear = function (selectedDate, tenure) {
            return getYearsFromFutureDate(selectedDate) <= tenure ? output : $filter('translate')("_RecentDateMessage_");
        }
        validationFactory.compareDatetime = function (date1, date2) {
            return date2 >= date1 ? output : $filter('translate')("_InvalidTimeMessage_");
        }
        validationFactory.isInISOFormat = function (dateString) {
            var ISO_8601_regex = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{3}))?([\+-]\d{2}(?::\d{2})?)$/;
            return dateString.match(ISO_8601_regex);
        }
        validationFactory.isRequiredValidation = function (value, message) {
            return value.trim() != "" ? "Valid" : message;
        }
        validationFactory.regexValidation = function (value, regex, message) {
            return new RegExp(regex).test(value) ? "Valid" : message;
        }
        return validationFactory;

    })

.factory('miLocale',
    function (
            $rootScope,
            ENV,
            $stateParams) {

        var CurrLocaleCode = {};
        CurrLocaleCode.data = $stateParams.lan === "" ? ENV.DEFAULT_LOCALE : $stateParams.lan;
        CurrLocaleCode.setLocaleCode = function (code) {
            this.data = code;
        };
        CurrLocaleCode.getLocaleCode = function () {
            return this.data;
        };
        return CurrLocaleCode;
    })

    .factory('miResourceDataFactory', [
         '$rootScope',
        'miServiceCenterResourceLookUpService',
        'miShopResourceLookUpService',
        '$q',
        'miAppProperties',
        'ENV',
        function (
            $rootScope,
            miServiceCenterResourceLookUpService,
            miShopResourceLookUpService,
            $q,
            miAppProperties,
            ENV) {

            var factory = {
            };

            factory.GetResourcesOrGroup = function (searchCriteria, moiGroupResource) {
                var deferred = $q.defer();
                var resourcesResult = {
                    data: '', status: '', route: ''
                };
                var ResourceLookupService;
                if (moiGroupResource == ENV.MOIGROUPTYPE)
                    ResourceLookupService = miServiceCenterResourceLookUpService;
                else
                    ResourceLookupService = miShopResourceLookUpService;
                ResourceLookupService.GetResources(searchCriteria, miAppProperties.getorgcode())
                .then(function (result) {
                    resourcesResult.data = result.data;
                    resourcesResult.status = result.status;
                    if (resourcesResult.status != 200 && resourcesResult.status != 204) {
                        $rootScope.ShellTitle = "";
                        resourcesResult.route = result.status;
                        deferred.resolve(resourcesResult);
                    }
                    else {
                        resourcesResult.route = "";
                        deferred.resolve(resourcesResult);
                    }
                });
                return deferred.promise;
            };
            return factory;
        }])

        .factory('miCarrierContactFactory', [
         '$rootScope',
         '$q',
         'ENV',
         'miCarrierContactService',
        function (
            $rootScope,
            $q,
            ENV,
            miCarrierContactService) {

            var factory = {
            };

            factory.getCarrierTelephoneNumber = function (companycode, lan) {
                var deferred = $q.defer();
                var carrierContactResult = {
                    data: '', status: '', route: ''
                };
                miCarrierContactService.getCarrierContact(companycode, lan)
                .then(function (result) {
                    carrierContactResult.data = result.data;
                    carrierContactResult.status = result.status;
                    if (carrierContactResult.status != 200 && carrierContactResult.status != 204) {
                        $rootScope.ShellTitle = "";
                        carrierContactResult.route = result.status;
                        deferred.resolve(carrierContactResult);
                    }
                    else {
                        carrierContactResult.route = "";
                        deferred.resolve(carrierContactResult);
                    }
                });
                return deferred.promise;
            };
            return factory;
        }])
        .factory('miAdvanceSearchFactory', [
       '$http',
       '$q',
       '$rootScope',
       'ENV',
       'miuserSession',
       'miAppProperties',
       '$filter',
       function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties, $filter) {
           var factory = {
           };
           factory.advancedSearchByDatetime = function () {
               $rootScope.searchTypeLabel = $filter('translate')('_AdvanceSearchTypeLabel_');
               $rootScope.searchFormFields = {
                   "field": [{
                       "id": "datestart",
                       "placeholder": $filter('translate')('_DateFormat_'),
                       "name": $filter('translate')("_StartingOn_"),
                       "type": "date",
                       "isSupportable": ENV.Modernizr.inputtypes.date,
                       "val": "dateStart"
                   }, {
                       "id": "timeafter",
                       "placeholder": ENV.TIME_FORMAT,
                       "name": $filter('translate')("_AnytimeAfter_"),
                       "type": "time",
                       "isSupportable": ENV.Modernizr.inputtypes.time,
                       "val": "timeAfter"

                   }, {
                       "id": "timebefore",
                       "placeholder": ENV.TIME_FORMAT,
                       "name": $filter('translate')("_AnytimeBefore_"),
                       "type": "time",
                       "isSupportable": ENV.Modernizr.inputtypes.time,
                       "val": "timeBefore"
                   }]
               }
           }
           return factory;
       }])
    .factory("miConversion", ["miValidation", "miAppProperties", "$filter", "ENV", function (miValidation, miAppProperties, $filter, ENV) {
        var factory = {};
        factory.utcWithOutTimeZone = function (utcDateTime, timeZone) {
            //ISO_8601 format validation
            if (miValidation.isInISOFormat(utcDateTime)) {

                var utcDateTimeTemp = $filter('date')(utcDateTime, ENV.ISO_DATETIME_FORMAT, timeZone);
                var dateString = utcDateTime.split("T");
                var dateTimeOffset = dateString[1].split("+");
                if (dateTimeOffset.length > 1) {
                    miAppProperties.setUtcOffset("+" + dateTimeOffset[1]);
                }
                else {
                    dateTimeOffset = dateString[1].split("-");
                    miAppProperties.setUtcOffset("-" + dateTimeOffset[1]);
                }
                return utcDateTimeTemp;
            }
            else if (utcDateTime.split("Z").length > 0) {
                return utcDateTime.split("Z")[0];
            }
            else {
                return utcDateTime;
            }
        }
        return factory;
    }])
    .factory('miLocalStorageCollection', [
    'miuserSession',
    '$rootScope',
    'ENV',
    '$timeout',
    '$q',
     function (
     miuserSession,
     $rootScope,
     ENV,
     $timeout,
     $q) {
         var service = {};
         service.setPhotoCollection = function (PhotoCollection) {
             var allDataCollection = null;
             if (localStorage.getItem('container')) {
                 allDataCollection = JSON.parse(localStorage.getItem('container'));
             }
             else {
                 allDataCollection = localStorage.getItem('container');
             }
             if (allDataCollection) {
                 var index = this.getArrayIndex(allDataCollection, PhotoCollection[0].id);
                 if (index > -1) {
                     for (var count = 0; count < allDataCollection.length; count++) {
                         if (allDataCollection[index][0].id == PhotoCollection[0].id) {
                             var GarbajCollection = JSON.parse(localStorage.getItem('Garbag')) || [];
                             GarbajCollection.push(allDataCollection[index][0].fileId);
                             GarbajCollection.push(allDataCollection[index][0].thumbFileId);
                             localStorage.setItem('Garbag', JSON.stringify(GarbajCollection));
                             allDataCollection.splice(index, 1);
                             break;
                         }
                     }
                 }
             }
             var pushAllData = allDataCollection || [];
             pushAllData.push(PhotoCollection);
             localStorage.setItem('container', JSON.stringify(pushAllData));
         };
         service.getPhotoCollection = function () {
             var dataCollection = localStorage.getItem('container');
             return dataCollection;
         };
         service.getArrayIndex = function (array, id) {
             for (var arrIndex = 0; arrIndex < array.length; arrIndex++) {
                 if (array[arrIndex][0].id == id) {
                     return arrIndex;
                 }
             }
             return -1;
         };
         //Photo info collection
         service.setPhotodata = function ($scope, Id, ScreenName, thumburl, fullimgurl, ImageName, fileId, thumbFileId, fileDescription) {
             $scope.dataCollection = [
                          {
                              id: Id,
                              screenName: ScreenName,
                              thumbUrl: thumburl,
                              fullImgUrl: fullimgurl,
                              fileId: fileId,
                              imageName: ImageName,
                              thumbFileId: thumbFileId,
                              fileDescription: fileDescription
                          }
             ];
             service.setPhotoCollection($scope.dataCollection);
         };
         return service;
     }]);



}(angular));