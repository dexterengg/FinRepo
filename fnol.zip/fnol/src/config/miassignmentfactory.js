﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')



.factory('miMoiProperties',
    function (
         $rootScope) {

        var moi = {};

        ///moi selection data
        moi.moiSelectionData = false;
        moi.setmoiSelectionData = function (moiSelectionData) {
            this.moiSelectionData = moiSelectionData;
        };
        moi.getmoiSelectionData = function () {
            return this.moiSelectionData;
        };
        ///
        ///moi Type
        moi.moiType = false;
        moi.setmoiType = function (moiType) {
            this.moiType = moiType;
        };
        moi.getmoiType = function () {
            return this.moiType;
        };

        moi.resouceGroup;

        moi.setResourceGroup = function (resourceGroup) {
            this.resourceGroup = resourceGroup;
        }

        moi.getResourceGroup = function () {
            return this.resourceGroup;
        }

        ///moi user id
        moi.userId = null;
        moi.setuserId = function (userId) {
            this.userId = userId;
        };
        moi.getuserId = function () {
            return this.userId;
        };
        ////

        ///moi companyCode
        moi.companyCode = null;
        moi.setcompanyCode = function (companyCode) {
            this.companyCode = companyCode;
        };
        moi.getcompanyCode = function () {
            return this.companyCode;
        };
        ////

        ///moi OrgId
        moi.moiOrgId = false;
        moi.setmoiOrgId = function (moiOrgId) {
            this.moiOrgId = moiOrgId;
        };
        moi.getmoiOrgId = function () {
            return this.moiOrgId;
        };

        ///moi Assignment DocId
        moi.moiAssignmentDocId = false;
        moi.setmoiAssignmentDocId = function (moiAssignmentDocId) {
            this.moiAssignmentDocId = moiAssignmentDocId;
        };
        moi.getmoiAssignmentDocId = function () {
            return this.moiAssignmentDocId;
        };

        ///Moi Filters
        moi.catFlag = null;
        moi.evltrConfigID = null;
        moi.stateCode = null;
        moi.drivability = null;
        moi.vehicleType = null;
        moi.typeOfLoss = null;
        moi.propertyType = null;
        moi.zipCode = null;
        moi.latitude = null;
        moi.longitude = null;
        moi.expertise = null;
        moi.countryCode = null;
        moi.assignmentSaveStep = null;
        moi.cmsSelectedResourceFlag = false;

        moi.setcatFlag = function (catFlag) {
            this.catFlag = catFlag;
        };
        moi.setevltrConfigID = function (evltrConfigID) {
            if (evltrConfigID) {
                this.evltrConfigID = evltrConfigID.toString();
            }
            else {
                this.evltrConfigID = evltrConfigID;
            }
        };
        moi.setstateCode = function (stateCode) {
            this.stateCode = stateCode;
        };
        moi.setdrivability = function (drivability) {
            this.drivability = drivability;
        };
        moi.setvehicleType = function (vehicleType) {
            this.vehicleType = vehicleType;
        };
        moi.settypeOfLoss = function (typeOfLoss) {
            this.typeOfLoss = typeOfLoss;
        };
        moi.setpropertyType = function (propertyType) {
            this.propertyType = propertyType;
        };
        moi.setzipCode = function (zipCode) {
            this.zipCode = zipCode;
        };
        moi.setlatitude = function (latitude) {
            this.latitude = latitude;
        };
        moi.setlongitude = function (longitude) {
            this.longitude = longitude;
        };
        moi.setexpertise = function (expertise) {
            if (expertise) {
                this.expertise = expertise.toString();
            }
            else {
                this.expertise = expertise;
            }

        };
        moi.setcountryCode = function (countryCode) {
            this.countryCode = countryCode;
        };

        moi.setCMSSelectedResourceFlag = function (cmsSelectedResourceFlag) {
            this.cmsSelectedResourceFlag = cmsSelectedResourceFlag;
        };

        moi.getCMSSelectedResourceFlag = function () {
            return this.cmsSelectedResourceFlag;
        };

        moi.getmoifilters = function () {
            return {
                catFlag: moi.catFlag,
                evltrConfigID: moi.evltrConfigID,
                stateCode: moi.stateCode,
                drivability: moi.drivability,
                vehicleType: moi.vehicleType,
                typeOfLoss: moi.typeOfLoss,
                propertyType: moi.propertyType,
                zipCode: moi.zipCode,
                latitude: moi.latitude,
                longitude: moi.longitude,
                expertise: moi.expertise,
                countryCode: moi.countryCode

            };
        };
        ////


        ////MoiModelArray
        moi.modelArray = [];
        moi.setMoiModelArray = function (preferedMoiData, selectedMoiData, assignmentresult, moidetail) {
            if (preferedMoiData) {
                for (var assignmentIndex = 0; assignmentIndex < assignmentresult.data.preferedMOIList.length; assignmentIndex++) {
                    for (var iIndex = 0; iIndex < moidetail.data.length; iIndex++) {

                        if (assignmentresult.data.preferedMOIList[assignmentIndex].moiType === moidetail.data[iIndex].MoiType) {
                            var model = {
                                MoiType: moidetail.data[iIndex].MoiType,
                                PriorityOrder: assignmentresult.data.preferedMOIList[assignmentIndex].priorityOrder,
                                RecommendedMOI: assignmentresult.data.preferedMOIList[assignmentIndex].recommendedMOI,
                                MoiID: moidetail.data[iIndex].MoiID,
                                MoiDisplayText: moidetail.data[iIndex].MoiDisplayText,
                                MoiAliasName: moidetail.data[iIndex].MoiAliasName,
                                SearchRadius: moidetail.data[iIndex].SearchRadius,
                                StateScripting: moidetail.data[iIndex].StateScripting,
                                PreStateScriptingText: moidetail.data[iIndex].PreStateScriptingText,
                                PostStateScriptingText: moidetail.data[iIndex].PostStateScriptingText,
                                CarrierEnabled: true,
                                UserEnabled: true,
                                MeetConditions: true,
                                ScriptState: moidetail.data[iIndex].ScriptState,
                                DispatchCntrID: moidetail.data[iIndex].DispatchCntrID,
                                TerritorySearchFlag: moidetail.data[iIndex].TerritorySearchFlag,
                                RadiusSearchFlag: moidetail.data[iIndex].RadiusSearchFlag,
                                SearchType: moidetail.data[iIndex].SearchType,
                                SelfServedEnable: true
                            }
                            this.modelArray.push(model);
                            break;
                        }
                        else
                            continue;
                    }
                }
            }
            else {
                for (var iIndex = 0; iIndex < moidetail.data.length; iIndex++) {

                    if (assignmentresult.data.moiType === moidetail.data[iIndex].MoiType) {
                        var model = {
                            MoiType: moidetail.data[iIndex].MoiType,
                            PriorityOrder: moidetail.data[iIndex].PriorityOrder,
                            RecommendedMOI: moidetail.data[iIndex].RecommendedMOI,
                            MoiID: moidetail.data[iIndex].MoiID,
                            MoiDisplayText: moidetail.data[iIndex].MoiDisplayText,
                            MoiAliasName: moidetail.data[iIndex].MoiAliasName,
                            SearchRadius: moidetail.data[iIndex].SearchRadius,
                            StateScripting: moidetail.data[iIndex].StateScripting,
                            PreStateScriptingText: moidetail.data[iIndex].PreStateScriptingText,
                            PostStateScriptingText: moidetail.data[iIndex].PostStateScriptingText,
                            CarrierEnabled: true,
                            UserEnabled: true,
                            MeetConditions: true,
                            ScriptState: moidetail.data[iIndex].ScriptState,
                            DispatchCntrID: moidetail.data[iIndex].DispatchCntrID,
                            TerritorySearchFlag: moidetail.data[iIndex].TerritorySearchFlag,
                            RadiusSearchFlag: moidetail.data[iIndex].RadiusSearchFlag,
                            SearchType: moidetail.data[iIndex].SearchType,
                            SelfServedEnable: true
                        }
                        this.modelArray.push(model);
                        break;
                    }
                    else
                        continue;
                }
            }
        };

        moi.saveModelsArray = function (models) {
            this.modelArray = models;
        };

        moi.getMoiModelArray = function () {
            return this.modelArray;
        };


        ////MoiList
        moi.moilist = [];
        moi.setmoilist = function (moilist) {
            this.moilist.push(moilist);
        };
        moi.getmoilist = function () {
            return this.moilist.toString();
        };

        moi.resourceSkipped = false;
        moi.setResourceSkipped = function (resourceSkipped) {
            this.resourceSkipped = resourceSkipped;
        }

        moi.getResourceSkipped = function () {
            return this.resourceSkipped;
        }
        /////
        ///moi selection data
        moi.resourcePostalCode = null;
        moi.setresourcePostalCode = function (resourcePostalCode) {
            this.resourcePostalCode = resourcePostalCode;
        };
        moi.getresourcePostalCode = function () {
            return this.resourcePostalCode;
        };

        //Property to set and get the user define postal code for searching in resource
        //It will help if assignment having postal code and user is searching resource with different postal code
        //Then in case of back it will retain the postal code entered by user
        moi.userDefinedResourcePostalCode = null;
        moi.setUserDefinedResourcePostalCode = function (userDefinedResourcePostalCode) {
            this.userDefinedResourcePostalCode = userDefinedResourcePostalCode;
        };
        moi.getUserDefinedResourcePostalCode = function () {
            return this.userDefinedResourcePostalCode;
        };

        return moi;
    })


.factory('miMoiFactory', [
    '$rootScope',
    '$q',
    'miAppProperties',
    'miLocale',
    'ENV',
    'miMoiService',
    'miMoiProperties',
    'miWorkAssignmentFactory',
    'miMOiTypeDetailFactory',
    'miResourceDataFactory',
    'miResourceProperties',
    function (
        $rootScope,
        $q,
        miAppProperties,
        miLocale,
        ENV,
        miMoiService,
        miMoiProperties,
        miWorkAssignmentFactory,
        miMOiTypeDetailFactory,
        miResourceDataFactory,
        miResourceProperties) {

        var factory = {};

        factory.moiPageDecision = function (moipagename) {
            var deferred = $q.defer();
            var moiResult = { data: '', status: '', route: '' };
            miWorkAssignmentFactory.getWorkAssignmentDetails(miAppProperties.getorgcode(), miAppProperties.getcontextid(), miLocale.getLocaleCode())
              .then(function (assignmentresult) {
                  if (assignmentresult.route) {
                      moiResult.route = assignmentresult.route;
                      deferred.resolve(moiResult);
                  }
                      // In case of claim save only (No assignment) should update the stage and redirect to claim summary page
                  else if (assignmentresult.status === 204) {
                      moiResult.route = "";
                      deferred.resolve(moiResult);
                  }
                  else {
                      miAppProperties.setAssignmentData(assignmentresult);
                      if (assignmentresult.data.moiDetailsFilterDTO) {

                          miMoiProperties.setuserId(assignmentresult.data.moiDetailsFilterDTO.userID);
                          miMoiProperties.setcompanyCode(assignmentresult.data.moiDetailsFilterDTO.companyCode);
                          if (assignmentresult.data.moiDetailsFilterDTO.catFlag)
                              miMoiProperties.setcatFlag("yes");
                          else
                              miMoiProperties.setcatFlag("no");
                          miMoiProperties.setevltrConfigID(assignmentresult.data.moiDetailsFilterDTO.evltrConfigID);
                          miMoiProperties.setstateCode(assignmentresult.data.moiDetailsFilterDTO.stateCode);
                          miMoiProperties.setdrivability(assignmentresult.data.moiDetailsFilterDTO.drivability);
                          miMoiProperties.setvehicleType(assignmentresult.data.moiDetailsFilterDTO.vehicleType);
                          miMoiProperties.settypeOfLoss(assignmentresult.data.moiDetailsFilterDTO.typeOfLoss);
                          miMoiProperties.setpropertyType(assignmentresult.data.moiDetailsFilterDTO.propertyType);
                          miMoiProperties.setzipCode(assignmentresult.data.moiDetailsFilterDTO.zipCode);
                          miMoiProperties.setlatitude(assignmentresult.data.moiDetailsFilterDTO.latitude);
                          miMoiProperties.setlongitude(assignmentresult.data.moiDetailsFilterDTO.longitude);
                          miMoiProperties.setexpertise(assignmentresult.data.moiDetailsFilterDTO.expertiseList);
                          miMoiProperties.setcountryCode(assignmentresult.data.moiDetailsFilterDTO.countryCode);
                          miMoiProperties.setCMSSelectedResourceFlag(assignmentresult.data.cmsSelectedResource);

                          // set resource postal code 
                          /*
                          When assignmentresult.data.moiDetailsFilterDTO.zipCode is not null then zipCode=assignmentresult.data.moiDetailsFilterDTO.zipCode else null
                          If zipCode is null then Territory=null and Radius=null
                          If zipCode is not null then Territory=ENV.RADIUS_DESC and Radius=ENV.RADIUS
                          */
                          var zipCode = assignmentresult.data.moiDetailsFilterDTO.zipCode ? assignmentresult.data.moiDetailsFilterDTO.zipCode : ENV.NULL_VALUE
                          miResourceProperties.setPostalCode(zipCode);
                          miResourceProperties.setTerritoryType(zipCode ? ENV.RADIUS_DESC : ENV.NULL_VALUE);
                          miResourceProperties.setRadius(zipCode ? ENV.RADIUS : ENV.NULL_VALUE);
                          //End

                          // set resource properties in case of appraiser and adjuster
                          miResourceProperties.setResourceType(null);
                          miResourceProperties.setResourceSubType(null);
                          miMoiProperties.setResourceGroup(null);
                          miResourceProperties.setGroupType(null);

                          miWorkAssignmentFactory.AssignmentDecision(assignmentresult)
                          .then(function (assignmentDecisionresult) {
                              moiResult.route = assignmentDecisionresult.route;
                              deferred.resolve(moiResult);
                          })
                      }
                          //check adjuster flow in case of claim save(No assigment)
                      else if (assignmentresult.data.adjusterApptReqFlag) {
                          moiResult.route = ENV.ADJUSTER_APPOINTMENT_INFO_CONSTANT;
                          deferred.resolve(moiResult);
                      }
                      else {
                          moiResult.route = "";
                          deferred.resolve(moiResult);
                      }
                  }
              })



            return deferred.promise;
        };

        return factory;
    }])

.factory('miWorkAssignmentFactory', [
         '$rootScope',
        'miWorkAssignmentService',
        '$q',
        'miAppProperties',
        'ENV',
        'miMoiProperties',
        'miMOiTypeDetailFactory',
        'miLocale',
        'miResourceProperties',
        'miResourceDataFactory',
        'miMoiService',
        'miAppointmentService',
        'miAppointmentsSlotFactory',
        '$filter',

        function (
            $rootScope,
            miWorkAssignmentService,
            $q,
            miAppProperties,
            ENV,
            miMoiProperties,
            miMOiTypeDetailFactory,
            miLocale,
            miResourceProperties,
            miResourceDataFactory,
            miMoiService,
            miAppointmentService,
            miAppointmentsSlotFactory,
            $filter
            ) {

            var factory = {};

            factory.getMoiDetails = function (moifilters, companycode, userid, lan) {
                var deferred = $q.defer();
                var moiResult = { data: '', status: '', route: '' };
                miMoiService.getMoiDetails(moifilters, companycode, userid, lan)
                .then(function (result) {
                    moiResult.data = result.data;
                    moiResult.status = result.status;
                    if (moiResult.status != 200 && moiResult.status != 204) {
                        $rootScope.ShellTitle = "";
                        moiResult.route = result.status;
                        deferred.resolve(moiResult);
                    }
                    else {
                        moiResult.route = "";
                        deferred.resolve(moiResult);
                    }
                });
                return deferred.promise;
            };

            factory.getWorkAssignmentDetails = function (companycode, contextid, lan) {
                var deferred = $q.defer();
                var assignmentResult = {
                    data: '', status: '', route: ''
                };
                miWorkAssignmentService.getWorkAssignmentDetails(companycode, contextid, lan)
                   .then(function (result) {
                       assignmentResult.data = result.data;
                       assignmentResult.status = result.status;
                       //if (assignmentResult.status === 400 || assignmentResult.status === 401 || assignmentResult.status === 404 || assignmentResult.status === 415 || assignmentResult.status === 500 || assignmentResult.status === 503) {
                       if (assignmentResult.status != 200 && assignmentResult.status != 204) {
                           $rootScope.ShellTitle = "";
                           assignmentResult.route = result.status;
                           deferred.resolve(assignmentResult);
                       }
                       else {
                           assignmentResult.route = "";
                           deferred.resolve(assignmentResult);
                       }
                   });
                return deferred.promise;
            };

            factory.AssignmentDecision = function (assignmentresult) {

                var deferred = $q.defer();
                var assignmentDecisionResult = {
                    data: '', status: '', route: ''
                };

                if (!assignmentresult.data.moiDetailsFilterDTO.assignmentSaveStep) {
                    //UPDATE STAGE AND GET NEXT STAGE
                    assignmentDecisionResult.route = "";
                    deferred.resolve(assignmentDecisionResult);
                }
                else if (assignmentresult.data.moiDetailsFilterDTO.assignmentSaveStep === ENV.ASSGN_STEP_MOI) {
                    if (assignmentresult.data.moiOrgId) {
                        //set the moiType and Resource Type
                        miMoiProperties.setmoiType(assignmentresult.data.moiType);
                        miAppProperties.assignmentDTO.setMoiOrgID(assignmentresult.data.moiOrgId);

                        if (miMoiProperties.getCMSSelectedResourceFlag()) {
                            miMoiProperties.setResourceSkipped(true);
                        }
                        //UPDATE STAGE AND GET NEXT STAGE IF APOINTMENT NOT REQUIRED
                        if (!assignmentresult.data.estApptReqFlag) {
                            if (assignmentresult.data.adjusterApptReqFlag) {
                                assignmentDecisionResult.route = ENV.ADJUSTER_APPOINTMENT_INFO_CONSTANT;
                                deferred.resolve(assignmentDecisionResult);
                            }
                            else {
                                assignmentDecisionResult.route = "";
                                deferred.resolve(assignmentDecisionResult);
                            }
                        }
                        else {
                            miAppProperties.setappointmentType(ENV.APPOINTMENTTYPE_ESTIMATOR);
                            //Get resource related information
                            factory.getResourceDetails(assignmentresult)
                            .then(function (result) {
                                if (result.route) {
                                    assignmentDecisionResult.route = result.route;
                                    deferred.resolve(assignmentDecisionResult);
                                }
                                else {
                                    var startDate = $filter('date')($filter('date')(new Date(), ENV.ISO_DATETIME_FORMAT), ENV.ISO_DATETIME_FORMAT, miAppProperties.getResourceData().UtcOffset.replace(':', '')) +miAppProperties.getResourceData().UtcOffset;
                                    //call appointment service
                                    miAppointmentsSlotFactory.getAppointments(miAppProperties.getorgcode(), miLocale.getLocaleCode(), assignmentresult.data.resourceCode, startDate, miAppProperties.getappointmentType(), miAppProperties.getcontextid())
                                    .then(function (result) {
                                        if (result.route) {
                                            assignmentDecisionResult.route = result.route;
                                            deferred.resolve(assignmentDecisionResult);
                                        }
                                        else {
                                            //Route to schedule Appointment page 
                                            assignmentDecisionResult.route = ENV.APPOINTMENT_CONSTANT;
                                            deferred.resolve(assignmentDecisionResult);
                                        }
                                    });

                                }
                            });

                        }
                    }

                    else {

                        if (assignmentresult.data.moiType) {
                            ////SKIP MOI WHEN RECEIVED FROM CMS
                            factory.skipCMSMOI(assignmentresult)
                             .then(function (result) {
                                 assignmentDecisionResult.route = result.route;
                                 deferred.resolve(assignmentDecisionResult);
                             })
                        }
                        else {
                            $rootScope.ShellTitle = "";
                            assignmentDecisionResult.route = 400;
                            deferred.resolve(assignmentDecisionResult);
                        }

                    }///METHOD OF INSPECTION
                }
                else if (assignmentresult.data.moiDetailsFilterDTO.assignmentSaveStep === ENV.ASSGN_STEP_ADMIN || assignmentresult.data.moiDetailsFilterDTO.assignmentSaveStep === ENV.ASSGN_STEP_RS || assignmentresult.data.moiDetailsFilterDTO.assignmentSaveStep === ENV.ASSGN_STEP_LE) {
                    if (assignmentresult.data.preferedMOIList) {

                        if (assignmentresult.data.preferedMOIList.length === 1) {
                            ////SKIP PREFERED MOI WHEN WE GET SINGLE PREFERED MOI
                            factory.skipSinglePreferedMOI(assignmentresult)
                             .then(function (result) {
                                 assignmentDecisionResult.route = result.route;
                                 deferred.resolve(assignmentDecisionResult);
                             })
                        }
                        else {
                            ////CONTINUE PREFERED MOI WHEN MORE THEN ONE PREFERED MOI
                            factory.continuePreferedMOI(assignmentresult)
                             .then(function (result) {
                                 assignmentDecisionResult.route = result.route;
                                 deferred.resolve(assignmentDecisionResult);
                             })

                        }
                    }
                    else {
                        ///DISPLAY MOI WHEN  RECEIVED FROM RESTWSMOI
                        factory.getMoiFromRestWSMOI()
                       .then(function (result) {
                           if(result.route === "") { //condition to check when moi does not exists and adjuster appointment is required
                               if (assignmentresult.data.adjusterApptReqFlag) {
                                   assignmentDecisionResult.route = ENV.ADJUSTER_APPOINTMENT_INFO_CONSTANT;
                                   deferred.resolve(assignmentDecisionResult);
                               }
                               else {
                                   //UPDATE STAGE AND GET NEXT STAGE
                                   assignmentDecisionResult.route = "";
                                   deferred.resolve(assignmentDecisionResult);
                               }

                           }
                           else {
                               //UPDATE STAGE AND GET NEXT STAGE
                               assignmentDecisionResult.route = result.route;
                               deferred.resolve(assignmentDecisionResult);
                           }
                       });
                    }
                }
                else if (assignmentresult.data.moiDetailsFilterDTO.assignmentSaveStep === ENV.ASSGN_STEP_AD) {
                    if (assignmentresult.data.adjusterApptReqFlag) {
                        miAppProperties.assignmentDTO.setMoiOrgID(assignmentresult.data.moiOrgId);
                        assignmentDecisionResult.route = ENV.ADJUSTER_APPOINTMENT_INFO_CONSTANT;
                        deferred.resolve(assignmentDecisionResult);
                    }
                    else {
                        assignmentDecisionResult.route = "";
                        deferred.resolve(assignmentDecisionResult);
                    }
                }
                else {

                    //UPDATE STAGE AND GET NEXT STAGE
                    assignmentDecisionResult.route = "";
                    deferred.resolve(assignmentDecisionResult);
                }
                return deferred.promise;
            }

            factory.skipCMSMOI = function (assignmentresult) {
                var deferred = $q.defer();
                var moiTypeDecisionResult = {
                    data: '', status: '', route: ''
                };

                if (assignmentresult.data.moiType === ENV.MOITYPE_NSDO || assignmentresult.data.moiType === ENV.MOITYPE_DI || assignmentresult.data.moiType === ENV.MOITYPE_SC) {
                    miMoiProperties.setmoilist(assignmentresult.data.moiType);
                    miMoiProperties.setmoiType(assignmentresult.data.moiType);
                    miMOiTypeDetailFactory.getMoiTypeDetails(miMoiProperties.getcompanyCode(), miMoiProperties.getuserId(), miMoiProperties.getmoilist(), miLocale.getLocaleCode())
                    .then(function (moidetail) {
                        if(moidetail.route) {
                            moiTypeDecisionResult.route = moidetail.route;
                            deferred.resolve(moiTypeDecisionResult);
                        }

                        else {
                            if (moidetail.data.length <= 0 || moidetail.data == "") {
                                $rootScope.ShellTitle = "";
                                moiTypeDecisionResult.route = 400;
                                deferred.resolve(moiTypeDecisionResult);
                            }
                            else {
                                miMoiProperties.setMoiModelArray(false, true, assignmentresult, moidetail);
                                miResourceProperties.setDefaultCriteriaForMoi(miMoiProperties.getmoiType());
                                var groupResource = '';
                                if (miResourceProperties.getGroupType())
                                    groupResource = ENV.MOIGROUPTYPE;
                                else
                                    groupResource = ENV.MOIRESOURCETYPE;
                                miResourceDataFactory.GetResourcesOrGroup(miResourceProperties.getResourceSearchCriteria(), groupResource)
                                   .then(function (resourcesresponse) {
                                       if(resourcesresponse.route) {
                                           moiTypeDecisionResult.route = resourcesresponse.route;
                                           deferred.resolve(moiTypeDecisionResult);
                                       } else {
                                           moiTypeDecisionResult.route = ENV.RESOURCE_CONSTANT;
                                           miAppProperties.setResourceDataList(resourcesresponse.data);
                                           deferred.resolve(moiTypeDecisionResult);
                                       }
                                   });
                            }

                        }
                    })

                }
                else {
                    $rootScope.ShellTitle = "";
                    moiTypeDecisionResult.route = 400;
                    deferred.resolve(moiTypeDecisionResult);
                }
                $rootScope.moiSkipped = true;
                if (assignmentresult.data.moiType === ENV.MOITYPE_NSDO) {
                    $rootScope.isShop = true;
                }
                else {
                    $rootScope.isShop = false;
                }
                return deferred.promise;
            }

            factory.skipSinglePreferedMOI = function (assignmentresult) {

                var deferred = $q.defer();
                var skipPreferedMoiResult = {
                    data: '', status: '', route: ''
                };//remove ENV.MOITYPE_FI for disable the FI MOI because FI moi already disabled from moi.html page
                if (assignmentresult.data.preferedMOIList[0].moiType === ENV.MOITYPE_NSDO || assignmentresult.data.preferedMOIList[0].moiType === ENV.MOITYPE_DI || assignmentresult.data.preferedMOIList[0].moiType === ENV.MOITYPE_PBE || assignmentresult.data.preferedMOIList[0].moiType === ENV.MOITYPE_SC) {
                    miMoiProperties.setmoilist(assignmentresult.data.preferedMOIList[0].moiType);
                    miMoiProperties.setmoiType(assignmentresult.data.preferedMOIList[0].moiType);
                    miMOiTypeDetailFactory.getMoiTypeDetails(miMoiProperties.getcompanyCode(), miMoiProperties.getuserId(), miMoiProperties.getmoilist(), miLocale.getLocaleCode())
                    .then(function (moidetail) {
                        if(moidetail.route) {
                            skipPreferedMoiResult.route = moidetail.route;
                            deferred.resolve(skipPreferedMoiResult);
                        }
                        else {
                            if (moidetail.data.length <= 0 || moidetail.data == "") {
                                $rootScope.ShellTitle = "";
                                skipPreferedMoiResult.route = 400;
                                deferred.resolve(skipPreferedMoiResult);
                            }
                            else {
                                miMoiProperties.setMoiModelArray(true, false, assignmentresult, moidetail);
                                miResourceProperties.setDefaultCriteriaForMoi(miMoiProperties.getmoiType());
                                var groupResource = '';
                                if (miResourceProperties.getGroupType())
                                    groupResource = ENV.MOIGROUPTYPE;
                                else
                                    groupResource = ENV.MOIRESOURCETYPE;
                                miResourceDataFactory.GetResourcesOrGroup(miResourceProperties.getResourceSearchCriteria(), groupResource)
                                   .then(function (resourcesresponse) {
                                       if(resourcesresponse.route) {
                                           skipPreferedMoiResult.route = resourcesresponse.route;
                                           deferred.resolve(skipPreferedMoiResult);
                                       } else {
                                           skipPreferedMoiResult.route = ENV.RESOURCE_CONSTANT;
                                           miAppProperties.setResourceDataList(resourcesresponse.data);
                                           deferred.resolve(skipPreferedMoiResult);
                                       }
                                   });
                            }
                        }
                    })
                }
                else {
                    $rootScope.ShellTitle = "";
                    skipPreferedMoiResult.route = 400;
                    deferred.resolve(skipPreferedMoiResult);
                }
                $rootScope.moiSkipped = true;
                if (assignmentresult.data.preferedMOIList[0].moiType === ENV.MOITYPE_NSDO) {
                    $rootScope.isShop = true;
                }
                else {
                    $rootScope.isShop = false;
                }
                return deferred.promise;
            }

            factory.continuePreferedMOI = function (assignmentresult) {
                var deferred = $q.defer();
                var continuePreferedMoiResult = {
                    data: '', status: '', route: ''
                };

                for (var iIndexMoi = 0; iIndexMoi < assignmentresult.data.preferedMOIList.length; iIndexMoi++) {
                    miMoiProperties.setmoilist(assignmentresult.data.preferedMOIList[iIndexMoi].moiType);
                }

                miMOiTypeDetailFactory.getMoiTypeDetails(miMoiProperties.getcompanyCode(), miMoiProperties.getuserId(), miMoiProperties.getmoilist(), miLocale.getLocaleCode())
                .then(function (moidetail) {
                    if(moidetail.route) {
                        continuePreferedMoiResult.route = moidetail.route;
                        deferred.resolve(continuePreferedMoiResult);
                    }
                    else {
                        if (moidetail.data.length <= 0 || moidetail.data == "") {
                            $rootScope.ShellTitle = "";
                            continuePreferedMoiResult.route = 400;
                            deferred.resolve(continuePreferedMoiResult);
                        }
                        else {
                            miMoiProperties.setMoiModelArray(true, false, assignmentresult, moidetail);
                            continuePreferedMoiResult.route = ENV.MOI_PAGE_CONSTANT;
                            deferred.resolve(continuePreferedMoiResult);
                        }
                    }
                })


                return deferred.promise;
            }

            factory.getMoiFromRestWSMOI = function () {
                var deferred = $q.defer();
                var getMoiFromRestWSResult = {
                    data: '', status: '', route: ''
                };
                factory.getMoiDetails(miMoiProperties.getmoifilters(), miMoiProperties.getcompanyCode(), miMoiProperties.getuserId(), miLocale.getLocaleCode())
                      .then(function (result) {
                          getMoiFromRestWSResult.data = result.data;
                          getMoiFromRestWSResult.status = result.status;
                          if (getMoiFromRestWSResult.status != 200 && getMoiFromRestWSResult.status != 204) {
                              $rootScope.ShellTitle = "";
                              getMoiFromRestWSResult.route = result.status;
                              deferred.resolve(getMoiFromRestWSResult);
                          }
                          else if (getMoiFromRestWSResult.data === "") {
                              $rootScope.ShellTitle = "";
                              getMoiFromRestWSResult.route = 400;
                              deferred.resolve(getMoiFromRestWSResult);
                          }
                          else {
                              var ismoiexist = false;
                              for (var i = 0; i < getMoiFromRestWSResult.data.length -1; i++) {
                                  if (!getMoiFromRestWSResult.data[i].CarrierEnabled || !getMoiFromRestWSResult.data[i].UserEnabled || !getMoiFromRestWSResult.data[i].MeetConditions || !getMoiFromRestWSResult.data[i].SelfServedEnable) {
                                      ismoiexist = false;
                                  }//remove ENV.MOITYPE_FI for disable the FI MOI because FI moi already disabled from moi.html page
                                  else if (getMoiFromRestWSResult.data[i].MoiType === ENV.MOITYPE_NSDO || getMoiFromRestWSResult.data[i].MoiType === ENV.MOITYPE_DI || getMoiFromRestWSResult.data[i].MoiType === ENV.MOITYPE_PBE || getMoiFromRestWSResult.data[i].MoiType === ENV.MOITYPE_SC) {
                                      ismoiexist = true;
                                      break;
                                  }
                              }
                              if (!ismoiexist) {
                                  //$rootScope.ShellTitle = "";
                                  getMoiFromRestWSResult.route = "";
                                  deferred.resolve(getMoiFromRestWSResult);
                              }
                              else {

                                  miMoiProperties.saveModelsArray(getMoiFromRestWSResult.data);
                                  getMoiFromRestWSResult.route = ENV.MOI_PAGE_CONSTANT;
                                  deferred.resolve(getMoiFromRestWSResult);
                              }
                          }
                      })
                return deferred.promise;

            }

            factory.getResourceDetails = function (assignmentresult) {
                var deferred = $q.defer();
                var resourceDetailsResult = {
                    data: '', status: '', route: ''
                };
                miResourceProperties.setDefaultCriteriaForResource(assignmentresult.data.moiType, assignmentresult.data.resourceCode);
                var groupResource = '';
                    miResourceProperties.setPostalCode(null);
                    miResourceProperties.setTerritoryType(null);
                    miResourceProperties.setRadius(null);
                if (miResourceProperties.getGroupType())
                    groupResource = ENV.MOIGROUPTYPE;
                else
                    groupResource = ENV.MOIRESOURCETYPE;
                miResourceDataFactory.GetResourcesOrGroup(miResourceProperties.getResourceSearchCriteria(), groupResource)
                   .then(function (resourcesresponse) {
                       if(resourcesresponse.route) {
                           resourceDetailsResult.route = resourcesresponse.route;
                           deferred.resolve(resourceDetailsResult);
                       } else {
                           resourceDetailsResult.route = "";
                           miAppProperties.setResourceData(resourcesresponse.data[0]);
                           deferred.resolve(resourceDetailsResult);
                       }
                   });
                return deferred.promise;
            }

            return factory;
        }])


.factory('miAppointmentsSlotFactory', [
         'ENV',
         '$rootScope',
         'miAppointmentService',
        '$q',
        'miAppProperties',
        function (
            ENV,
            $rootScope,
            miAppointmentService,
            $q,
            miAppProperties) {

            var factory = { };

            factory.getAppointments = function (companycode, lan, resourcecode, startdate, appointmenttype, contextid, endTime) {
                var deferred = $q.defer();
                var appointmentSlotsResult = {
                    data: '', status: '', route: ''
                };              
                miAppointmentService.getAppointment(companycode, lan, resourcecode, startdate, appointmenttype, contextid, endTime)
                   .then(function (result) {
                       appointmentSlotsResult.data = result.data;
                       appointmentSlotsResult.status = result.status;
                       miAppProperties.setappointmentDetailsStatus(result.status);
                       if (appointmentSlotsResult.status != 200 && appointmentSlotsResult.status != 406) {
                           $rootScope.ShellTitle = "";
                           appointmentSlotsResult.route = result.status;
                           deferred.resolve(appointmentSlotsResult);
                       }
                       else {
                           if (appointmentSlotsResult.data.resStatus === ENV.SUCCESS) {
                               miAppProperties.setappointmentDetails(appointmentSlotsResult.data);
                               appointmentSlotsResult.route = "";
                               deferred.resolve(appointmentSlotsResult);
                           }
                           else {
                               if (appointmentSlotsResult.data.errInfo.errCode === 11) {
                                   miAppProperties.setCustomError(appointmentSlotsResult.data.errInfo.errDesc);
                                   appointmentSlotsResult.route = "";
                                   deferred.resolve(appointmentSlotsResult);
                               }
                               if (appointmentSlotsResult.data.errInfo.errCode === 10) {
                                   appointmentSlotsResult.route = 400;
                                   deferred.resolve(appointmentSlotsResult);
                               }

                           }
                       }
                   });
                return deferred.promise;
            };
            factory.getOffsetForTimeZone = function (timeZoneName) {
                var offset = '';
                switch (timeZoneName) {
                    case "Pacific Standard Time":
                        offset = "-08:00";
                        break;
                    case "Central Standard Time":
                        offset = "-06:00";
                        break;
                    case "Eastern Standard Time":
                        offset = "-05:00";
                        break;
                    case "Hawaiian Standard Time":
                        offset = "-10:00";
                        break;
                    default:
                        offset = "-08:00";
                        break;
                }
                return offset;
            };
            return factory;
        }])

.factory('miMOiTypeDetailFactory', [
         '$rootScope',
        'miMoiTypeDetailService',
        '$q',
        'miAppProperties',
        function (
            $rootScope,
            miMoiTypeDetailService,
            $q,
            miAppProperties) {

            var factory = { };

            factory.getMoiTypeDetails = function (companycode, userid, moi, lan) {
                var deferred = $q.defer();
                var moiTypeResult = {
                    data: '', status: '', route: ''
                };
                miMoiTypeDetailService.getMoiTypeDetails(companycode, userid, moi, lan)
                   .then(function (result) {
                       moiTypeResult.data = result.data;
                       moiTypeResult.status = result.status;
                       if (moiTypeResult.status != 200 && moiTypeResult.status != 204) {
                           $rootScope.ShellTitle = "";
                           moiTypeResult.route = result.status;
                           deferred.resolve(moiTypeResult);
                       }
                       else {
                           moiTypeResult.route = "";
                           deferred.resolve(moiTypeResult);
                       }
                   });
                return deferred.promise;
            };
            return factory;
        }])

.factory('miAssignmentUpdateFactory', [
        '$rootScope',
        'miUpdateAppraisalAssignmentService',
        '$q',
        function ($rootScope, miUpdateAppraisalAssignmentService, $q) {
            var factory = { };
            factory.UpdateAssignment = function (assignmentDTO, contextId, companyCode, assignmentDocId, lan) {
                var deferred = $q.defer();
                var updateAssignmentResult = {
                    data: '', status: '', route: ''
                };
                miUpdateAppraisalAssignmentService.UpdateAssignment(assignmentDTO, contextId, companyCode, assignmentDocId, lan)
               .then(function (result) {

                   updateAssignmentResult.data = result.data;
                   updateAssignmentResult.status = result.status;
                   if (updateAssignmentResult.status != 200 && updateAssignmentResult.status != 204) {
                       $rootScope.ShellTitle = "";
                       updateAssignmentResult.route = result.status;
                       deferred.resolve(updateAssignmentResult);
                   }
                   else {
                       updateAssignmentResult.route = "";
                       deferred.resolve(updateAssignmentResult);
                   }


               });
                return deferred.promise;
            };
            return factory;
        }])
        //Book Appointment Factory
    .factory('miBookAppointmentFactory', [
        '$rootScope',
        '$q',
        'ENV',
        'miBookAppointmentService',
        'miAppProperties',
         function (
            $rootScope,
            $q,
            ENV,
            miBookAppointmentService,
            miAppProperties) {
             var factory = { };
             factory.BookAppointment = function (appointmentDTO, contextId, companyCode, assignmentDocId, lan) {
                 var deferred = $q.defer();
                 var bookAppointmentResult = {
                     data: '', status: '', route: ''
                 };
                 miBookAppointmentService.BookAppointment(appointmentDTO, contextId, companyCode, assignmentDocId, lan)
                .then(function (result) {

                    bookAppointmentResult.data = result.data;
                    bookAppointmentResult.status = result.status;
                    if (bookAppointmentResult.status != 200 && bookAppointmentResult.status != 406) {
                        $rootScope.ShellTitle = "";
                        bookAppointmentResult.route = result.status;
                        deferred.resolve(bookAppointmentResult);
                    }
                    else {
                        if (bookAppointmentResult.data.resStatus === ENV.SUCCESS) {
                            bookAppointmentResult.route = "";
                            deferred.resolve(bookAppointmentResult);
                        }
                        else {
                            if (bookAppointmentResult.data.errInfo.errCode === 10) {
                                bookAppointmentResult.route = 400;
                                deferred.resolve(bookAppointmentResult);
                            }
                            if (bookAppointmentResult.data.errInfo.errCode == 11) {
                                miAppProperties.setCustomError(bookAppointmentResult.data.errInfo.errDesc);
                                bookAppointmentResult.route = "";
                                deferred.resolve(bookAppointmentResult);
                            }
                        }
                    }
                });
                 return deferred.promise;
             };
             return factory;
         }])
        //Get MOI List Factory on back button 
    .factory('miGetMoiListFactory', [
        '$rootScope',
        '$q',
        'ENV',
        'miAppProperties',
        'miWorkAssignmentFactory',
         function (
            $rootScope,
            $q,
            ENV,
            miAppProperties,
            miWorkAssignmentFactory) {
             var factory = { };
             factory.GetMoiList = function () {
                 var deferred = $q.defer();
                 var getMoiListResult = {
                     data: '', status: '', route: ''
                 };
                 var assignmentData = miAppProperties.getAssignmentData();
                 if (assignmentData.data.preferedMOIList) {

                     if (assignmentData.data.preferedMOIList.length > 1) {
                         ////CONTINUE PREFERED MOI WHEN MORE THEN ONE PREFERED MOI on back 
                         miWorkAssignmentFactory.continuePreferedMOI(assignmentData)
                          .then(function (result) {
                              getMoiListResult.route = result.route;
                              deferred.resolve(getMoiListResult);
                          });
                     }
                 }
                 else {
                     miWorkAssignmentFactory.getMoiFromRestWSMOI()
                     .then(function (result) {
                         getMoiListResult.route = result.route;
                         deferred.resolve(getMoiListResult);
                     });
                 }
                 return deferred.promise;
             };
             return factory;
         }]);


    //ss


}(angular));