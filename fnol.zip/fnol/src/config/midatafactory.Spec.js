﻿describe('MFNOL AngularJS Factory (MFnol factory)', function () {
    var sut, rootScope;
    var mockFormatText, mockplainText, mockconstant;
    var expectedDetail = {
        data: "fake-data",
        questionnairesDetails: [{ "Id": 1, "Question": 'fake-question', "Answer": 'fake-answer', "Type": 'fake-type' }],
        Docidlist: "{1},{2}",
        evltnConfigId: "{101},{102}",
        questionDetails: [{ "qustnnrQustnId": "fake-questinnireId", "answer": "fake-answertext" }],
        appointmentDTO: {},
        EditSummaryData: {
            
                "stageName": "fake-stageName",
                "questionnaireId": "fake-questionnireId",
                "documentId": "fake-documentId",
                "stageUiOrder": "fake-stageUiOrder",
                "stageOrder": "fake-stageOrder",
                "pageName": "fake-pageName",
                "stageType": "Questionnaire",
                "coStageId": "fake-coStageId",
                "stageDescription": "fake-StageDesc",
                "totalNumOfStages": "fake-totalNumOfStages",
                "prevStageIntgrtnTyp": "false",
                "stageStatus": "fake-status",
                "userSystemMap": "false",
                "carrierSystemMap":"false",
            
        }
    }
    beforeEach(module('mi.mfnol.web')); // load the module
    describe('miAppProperties factory Unit Test Cases', function () {
        beforeEach(inject(function () {
            inject(function ($injector) {
                rootScope = $injector.get('$rootScope').$new();
                sut = $injector.get('miAppProperties');
            });
        }));
        it('ensure getData() funtion should be called', function () {
            sut.sendData(expectedDetail.data);
            expect(sut.getData()).toBe('fake-data')
        });
        it('ensure data should be null when called with null value', function () {
            sut.sendData(null);
            expect(sut.getData()).toBe(null);
        });
        it('ensure getQuestionnairesQuestionDetails should be called', function () {
            sut.insertQuestionnairesQuestionDetails(1, "fake-question", "fake-answer", "fake-type");
            sut.ClearQuestionnairesQuestionDetails();
            expect(sut.getQuestionnairesQuestionDetails()).not.toBe(null);
        });
        it('ensure SetIdentificationDataIntoQuestionnaireQuestionDetails should be called', function () {
            sut.insertUserIdentificationdata(1, "fake-question", "fake-answer", "fake-type");
            sut.SetIdentificationDataIntoQuestionnaireQuestionDetails();
            expect(sut.UserIdentificationdata).not.toBe(null);
        });
        it('ensure getUserIdentificationdata should be called', function () {
            sut.getUserIdentificationdata();
            sut.ClearUserIdentificationdata();
            expect(sut.UserIdentificationdata.length).toBe(0);
        }); 
        it('ensure getUserIdentificationLoginKeyDetails should be called', function () {
            sut.setUserIdentificationLoginKeyDetails("Key","fake-value");
            expect(sut.getUserIdentificationLoginKeyDetails("Key")).toBe("fake-value");
        });
        it('ensure getPolicyVerificationRequestData should be called', function () {
            sut.setPolicyVerificationRequestData("fake-details", "M2", 1010);
            expect(sut.getPolicyVerificationRequestData()).not.toBe(null);
        });
        it('ensure getCurrentQuestion should be called', function () {
            sut.setCurrentQuestion("fake-Questiondata");
            expect(sut.getCurrentQuestion()).toBe("fake-Questiondata");
        });
        it('ensure getResourceData should be called', function () {
            sut.setResourceData("fake-resourceData");
            expect(sut.getResourceData()).toBe("fake-resourceData");
        });
        it('ensure getOutcomeDetail should be called', function () {
            sut.setOutcomeDetail("fake-outputdetails");
            expect(sut.getOutcomeDetail()).toBe("fake-outputdetails");
        });
        it('ensure getDocidlist should be called', function () {
            sut.setDocidlist(expectedDetail.Docidlist);
            expect(sut.getDocidlist()).toBe(expectedDetail.Docidlist);
        });
        it('ensure getConfigIdlist should be called', function () {
            sut.setConfigIdlist(expectedDetail.evltnConfigId);
            expect(sut.getConfigIdlist()).toBe(expectedDetail.evltnConfigId);
        });
        it('ensure getVehicalDetails and getvehicalDetailsStatus should be called', function () {
            sut.setVehicalDetails(false);
            expect(sut.getVehicalDetails()).toBe(false);
            sut.setvehicalDetailsStatus(false);
            expect(sut.getvehicalDetailsStatus()).toBe(false);

        });
        it('ensure getappointmentDetails and getappointmentDetailsStatus should be called', function () {
            sut.setappointmentDetails("fake-appointmentDetails");
            expect(sut.getappointmentDetails()).toBe("fake-appointmentDetails");
            sut.setappointmentDetailsStatus("fake-appointmentStatus");
            expect(sut.getappointmentDetailsStatus()).toBe("fake-appointmentStatus");
        });
        it('ensure insertQuestionDetails and getQuestionDetails should be called', function () {
            sut.insertQuestionDetails("fake-questinnireId","fake-answertext");
            expect(sut.getQuestionDetails()[0]["qustnnrQustnId"]).toBe(expectedDetail.questionDetails[0]["qustnnrQustnId"]);
            expect(sut.getcurrentquestionnaireQuestionId()).toBe("fake-questinnireId");
        });
        it('ensure gettheme,getorgcode,animationclass,language,sessionID functions should be called', function () {
            sut.settheme("fake-theme");
            sut.setorgcode("fake-orgcode");
            sut.setanimationclass("fake-animationclass");
            sut.setlanguage("fake-language");
            sut.setSessionID("fake-sessionId");
            expect(sut.gettheme()).toBe("fake-theme");
            expect(sut.getorgcode()).toBe("fake-orgcode");
            expect(sut.getanimationclass()).toBe("fake-animationclass");
            expect(sut.getlanguage()).toBe("fake-language");
            expect(sut.getSessionID()).toBe("fake-sessionId");
        });
        it('ensure getredirectionToken,getcontextid,getIdentificationfields,getlanguagelist,getstatuscode functions should be called', function () {
            sut.setredirectionToken("fake-redirectiontoken");
            sut.setsessionexpired("fake-sessionExpired");
            sut.setIdentificationfields("fake-identificationData");
            sut.setcontextid("fake-contextId"); 
            sut.setlanguagelist("fake-languageList");
            sut.setstatuscode("fake-statusCode");
            expect(sut.getredirectionToken()).toBe("fake-redirectiontoken");
            expect(sut.getsessionexpired()).toBe("fake-sessionExpired");
            expect(sut.getIdentificationfields()).toBe("fake-identificationData");
            expect(sut.getcontextid()).toBe("fake-contextId");
            expect(sut.getlanguagelist()).toBe("fake-languageList");
            expect(sut.getstatuscode()).toBe("fake-statusCode");
        });
        it('ensure getBackButtonFlag function should be called', function () {
            sut.StageOrder=1;
            expect(sut.getBackButtonFlag()).toBe(false);
            sut.StageOrder = 0;
            sut.stageType = "Integration";
            sut.pageName = "Vehicle Summary Page"
            expect(sut.getBackButtonFlag()).toBe(false);
            sut.StageOrder = 0;
            sut.stageType = "Pre-defined Page";
            sut.pageName = "Pre-defined Page"
            sut.integrationStage = true;
            expect(sut.getBackButtonFlag()).toBe(false);
            sut.StageOrder = 0;
            sut.stageType = "Questionnaire";
            sut.pageName = "Pre-defined Page"
            sut.integrationStage = true;
            sut.previousQuestionFlag = true;
            expect(sut.getBackButtonFlag()).toBe(false);
            sut.StageOrder = 0;
            sut.stageType = "Integration";
            sut.pageName = "fake-Page"
            sut.integrationStage = true;
            expect(sut.getBackButtonFlag()).toBe(false);
            sut.StageOrder = 0;
            sut.stageType = "Integration1";
            sut.pageName = "fake-Page"
            sut.integrationStage = false;
            expect(sut.getBackButtonFlag()).toBe(true);
        });
        it('ensure getBackButtonCss function should be called with nonclickable button class', function () {
            sut.StageOrder = 1;
            expect(sut.getBackButtonCss()).toBe("nonclickable_Back_Btn");
        });
        it('ensure getBackButtonCss function should be called with nonclickable button class', function () {
            sut.StageOrder = 0;
            expect(sut.getBackButtonCss()).toBe("clickable_Back_Btn");
        });
        it('ensure getLocationId,getAppointmentType,getStartDateTime functions should be called', function () {
            sut.appointmentDTO.setLocationId("fake-locationId");
            sut.appointmentDTO.setAppointmentType("fake-appointmenttype");
            sut.appointmentDTO.setStartDateTime("fake-startTime");
            expect(sut.appointmentDTO.getLocationId()).toBe("fake-locationId");
            expect(sut.appointmentDTO.getAppointmentType()).toBe("fake-appointmenttype");
            expect(sut.appointmentDTO.getStartDateTime()).toBe("fake-startTime");
        });
    });
    describe('miComponentRoute', function () {
        var SECURELOGIN_CONS = "SECURELOGIN";
        var INTRO1_CONS = "Splash Page";
        var INTRO2_CONS = "Informational Page";
        var INTRO3_CONS = "INTRO3";
        var LANDING_CONS = "LANDING_QUESTION";
        var IDENTIFICATION_CONS = "Identification Page";
        var SCRIPT_CONS = "SCRIPT_QUESTION";
        var DATETIME_CONS = "DATETIME_QUESTION";
        var DATE_CONS = "DATE_QUESTION";
        var YES_NO_CONS = "YES_NO_VALUE";
        var CHOICE_CONS = "CHOICE_SELECTION";
        var TIME_CONS = "TIME_QUESTION";
        var RANGE_CONS = "RANGE_VALUE";
        var OPEN_CONS = "OPEN_QUESTION";
        var LIABILITY_CONS = "Outcomes";
        var EXISTINGCLAIM_CONS = "EXISTING_CLAIM";
        var CONFIRMATION_CONS = "Identification Confirmation Page";
        var SUMMARY_CONSTANT = "Vehicle Summary Page";
        var OUTCOMES_CONSTANT = "OUTCOMES_CHECK";
        var RESOURCE_CONSTANT = "ResourceLookup Page";
        var APPOINTMENT_CONSTANT = "ScheduleAppointment Page";
        var CLAIMSUMMARY_PAGE_CONSTANT = "ClaimSummary";
        var APPOINTMENTSUMMARY_PAGE_CONSTANT = "AppointmentSummary";
        var ADJUSTER_APPOINTMENT_INFO_CONSTANT = "ADJUSTER_APPOINTMENT_INFO"
        var MOI_PAGE_CONSTANT = "Post FNOL";
        var BAD_REQUEST = "400";
        var UNAUTHORIZE = "401";
        beforeEach(inject(function () {
            inject(function ($injector) {
                rootScope = $injector.get('$rootScope').$new();
                sut = $injector.get('miComponentRoute');
            });
        }));
        it('should return securelogin', function () {
            var introOutput1 = sut.getComponentroute(SECURELOGIN_CONS);
            expect(introOutput1).toBe('shell.securelogin');
        });
        it('should return intro1', function () {
            var introOutput1 = sut.getComponentroute(INTRO1_CONS);
            expect(introOutput1).toBe('shell.intro1');
        });
        it('should return intro2', function () {
            var introOutput2 = sut.getComponentroute(INTRO2_CONS);
            expect(introOutput2).toBe('shell.intro2');
        });
        it('should return intro3', function () {
            var introOutput3 = sut.getComponentroute(INTRO3_CONS);
            expect(introOutput3).toBe('shell.intro3');
        });
        it('should return LANDING_QUESTION', function () {
            var landingQuestion = sut.getComponentroute(LANDING_CONS);
            expect(landingQuestion).toBe('shell.landing-Question');
        });
        it('should return IDENTIFICATION_QUESTION', function () {
            var identificationQuestion = sut.getComponentroute(IDENTIFICATION_CONS);
            expect(identificationQuestion).toBe('shell.identification-Question');
        });
        it('should return SCRIPT_QUESTION', function () {
            var scriptQuestion = sut.getComponentroute(SCRIPT_CONS);
            expect(scriptQuestion).toBe('shell.landing-Question.script-Question');
        });
        it('should return DATETIME_CONS', function () {
            var dateTime = sut.getComponentroute(DATETIME_CONS);
            expect(dateTime).toBe('shell.landing-Question.datetime-Question');
        });
        it('should return DATE_CONS', function () {
            var date = sut.getComponentroute(DATE_CONS);
            expect(date).toBe('shell.landing-Question.date-Question');
        });
        it('should return YES_NO_CONS', function () {
            var yesNo = sut.getComponentroute(YES_NO_CONS);
            expect(yesNo).toBe('shell.landing-Question.yesno-Question');
        });
        it('should return CHOICE_CONS', function () {
            var yesNo = sut.getComponentroute(CHOICE_CONS);
            expect(yesNo).toBe('shell.landing-Question.choiceselection-Question');
        });
        it('should return TIME_CONS', function () {
            var time = sut.getComponentroute(TIME_CONS);
            expect(time).toBe('shell.landing-Question.time-Question');
        });
        it('should return RANGE_CONS', function () {
            var range = sut.getComponentroute(RANGE_CONS);
            expect(range).toBe('shell.landing-Question.range-Question');
        });
        it('should return OPEN_CONS', function () {
            var open = sut.getComponentroute(OPEN_CONS);
            expect(open).toBe('shell.landing-Question.open-Question');
        });
        it('should return LIABILITY_CONS', function () {
            var liability = sut.getComponentroute(LIABILITY_CONS);
            expect(liability).toBe('shell.landing-Question.liability-Check');
        });
        it('should return EXISTINGCLAIM_CONS', function () {
            var existingClaim = sut.getComponentroute(EXISTINGCLAIM_CONS);
            expect(existingClaim).toBe('shell.existingClaim-Check');
        });
        it('should return CONFIRMATION_CONS', function () {
            var confirmation = sut.getComponentroute(CONFIRMATION_CONS);
            expect(confirmation).toBe('shell.landing-Question.confirmation-Check');
        });
        it('should return summary-Check', function () {
            var summarypage = sut.getComponentroute(SUMMARY_CONSTANT);
            expect(summarypage).toBe('shell.landing-Question.summary-Check');
        });
        it('should return outcome detail', function () {
            var outcome = sut.getComponentroute(OUTCOMES_CONSTANT);
            expect(outcome).toBe('shell.landing-Question.outcome-Detail');
        });
        it('should return moi detail', function () {
            var moi = sut.getComponentroute(MOI_PAGE_CONSTANT);
            expect(moi).toBe('shell.landing-Question.Moi');
        });
        it('should return resource detail', function () {
            var resoure = sut.getComponentroute(RESOURCE_CONSTANT);
            expect(resoure).toBe('shell.landing-Question.ResourceLookUp');
        });
        it('should return appointment page', function () {
            var appointment = sut.getComponentroute(APPOINTMENT_CONSTANT);
            expect(appointment).toBe('shell.landing-Question.ScheduleAppointment');
        });
        it('should return claim summary page', function () {
            var claimsummary = sut.getComponentroute(CLAIMSUMMARY_PAGE_CONSTANT);
            expect(claimsummary).toBe('shell.ClaimSummary');
        });
        it('should return appointment summary page', function () {
            var appointmentsummary = sut.getComponentroute(APPOINTMENTSUMMARY_PAGE_CONSTANT);
            expect(appointmentsummary).toBe('shell.landing-Question.AppointmentSummary');
        });
        it('should return adjuster appointment page', function () {
            var adjuster = sut.getComponentroute(ADJUSTER_APPOINTMENT_INFO_CONSTANT);
            expect(adjuster).toBe('shell.landing-Question.AdjusterAppointmentInfo');
        });
    }); 
    describe('miQues', function () {
        beforeEach(function () {
            var setupMocks = function () {
                mockmiQues = {
                    getQues: function (value1, value2) {
                        if (value1 != "false") {
                            return mockFormatText;
                        }
                        else {
                            return mockplainText;
                        }
                        return mockconstant;
                    }
                };
            };
            var registerMocks = function () {
                module(function ($provide) {
                    $provide.value("miQues", mockmiQues);
                });
            };
            setupMocks();
            registerMocks();
        });
        beforeEach(inject(function () {
            inject(function ($injector, $controller) {
                scope = $injector.get('$rootScope').$new();
                sut = $injector.get('miQues');
            });
        }));
        it('should get formated question text', function () {
            mockFormatText = "formatedText";
            spyOn(mockmiQues, 'getQues').and.callThrough();
            var result = sut.getQues("formatedQues", "plainQues");
            expect(result).toEqual('formatedText');
        });
        it('should get plain question text', function () {
            mockplainText = "plaintext";
            spyOn(mockmiQues, 'getQues').and.callThrough();
            var result = sut.getQues("false", "plainQues");
            expect(result).toEqual('plaintext');
        });
    });
    describe('miQuestionaireFactory', function () {
        var miQuestionaireFactory, $httpBackend;
        beforeEach(inject(function () {
            inject(function ($injector) {
                scope = $injector.get('$rootScope').$new();
                miQuestionaireFactory = $injector.get('miQuestionaireFactory');
                mistagefactory = $injector.get('miStageFactory');
                $httpBackend = $injector.get('$httpBackend');
                miGetOutcomeService = $injector.get('miGetOutcomeService');
                miGetQuestionEvaluationService = $injector.get('miGetQuestionEvaluationService');
                miGetQuestionEvaluationService = $injector.get('miGetQuestionEvaluationService');
                miGetEvaluationDocIdService = $injector.get('miGetEvaluationDocIdService');
                miSaveQuestionService = $injector.get('miSaveQuestionService');
                miCopyQuestionnaireSystemCodeService = $injector.get('miCopyQuestionnaireSystemCodeService');
                miAppProperties = $injector.get('miAppProperties');
            });
        }));
        it(' service  has been be loaded successfully', function () {
            expect(miQuestionaireFactory).toBeDefined();
        });
        it('ensure getOutcomes should be called with status 400', function () {
            spyOn(miGetOutcomeService, 'getOutcome').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status:400});
            });
            miQuestionaireFactory.getOutcome("m2", "100000007698");
            expect(miGetOutcomeService.getOutcome).toHaveBeenCalled();
        });
        it('ensure getOutcomes should be called with status 200', function () {
            spyOn(miGetOutcomeService, 'getOutcome').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            miQuestionaireFactory.getOutcome("m2", "100000007698");
            expect(miGetOutcomeService.getOutcome).toHaveBeenCalled();
        });
        it('ensure getQuestionEvaluation should be called with status 400', function () {
            spyOn(miGetQuestionEvaluationService, 'getQuestionEvaluation').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status:400});
            });
            miQuestionaireFactory.getQuestionEvaluation("m2", "100000007698");
            expect(miGetQuestionEvaluationService.getQuestionEvaluation).toHaveBeenCalled();
        });
        it('ensure getQuestionEvaluation should be called with status 200', function () {
            spyOn(miGetQuestionEvaluationService, 'getQuestionEvaluation').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            miQuestionaireFactory.getQuestionEvaluation("m2", "100000007698");
            expect(miGetQuestionEvaluationService.getQuestionEvaluation).toHaveBeenCalled();
        });
        it('ensure getQuestionnaireDetails should be called with status 400', function () {
            spyOn(miGetQuestionEvaluationService, 'getQuestionnaireDetails').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status:400});
            });
            miQuestionaireFactory.getQuestionnaireDetails("m2", "100000007698","en-US");
            expect(miGetQuestionEvaluationService.getQuestionnaireDetails).toHaveBeenCalled();
        });
        it('ensure getQuestionnaireDetails should be called with status 200', function () {
            spyOn(miGetQuestionEvaluationService, 'getQuestionnaireDetails').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            miQuestionaireFactory.getQuestionnaireDetails("m2", "100000007698", "en-US");
            expect(miGetQuestionEvaluationService.getQuestionnaireDetails).toHaveBeenCalled();
        });
        it('ensure getEvaluationDocId should be called with status 400', function () {
            spyOn(miGetEvaluationDocIdService, 'getEvaluationDocId').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status:400});
            });
            miQuestionaireFactory.getEvaluationDocId("m2", "100000007698","121", "en-US","fake-sysmap","fake-usermap");
             expect(miGetEvaluationDocIdService.getEvaluationDocId).toHaveBeenCalled();
        });
        it('ensure getEvaluationDocId should be called with status 200', function () {
            spyOn(miGetEvaluationDocIdService, 'getEvaluationDocId').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            miQuestionaireFactory.getEvaluationDocId("m2", "100000007698", "121", "en-US", "fake-sysmap", "fake-usermap");
            expect(miGetEvaluationDocIdService.getEvaluationDocId).toHaveBeenCalled();
        });
        it('ensure saveQuestion should be called with status 400', function () {
            spyOn(miSaveQuestionService, 'saveQuestion').and.callFake(function() {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            miQuestionaireFactory.saveQuestion("m2", "10788", "100000007698", "en-US", "fake-questionDetails");
            expect(miSaveQuestionService.saveQuestion).toHaveBeenCalled();
        });
        it('ensure saveQuestion should be called with status 200', function () {
            spyOn(miSaveQuestionService, 'saveQuestion').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            miQuestionaireFactory.saveQuestion("m2", "10788", "100000007698", "en-US", "fake-questionDetails");
            expect(miSaveQuestionService.saveQuestion).toHaveBeenCalled();
        });
        it('ensure CopyQuestionnaireSystemCode should be called with status 400', function () {
            spyOn(miCopyQuestionnaireSystemCodeService, 'CopyQuestionnaireSystemCode').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            miQuestionaireFactory.CopyQuestionnaireSystemCode("m2", "10788", "100000007698", "en-US");
            expect(miCopyQuestionnaireSystemCodeService.CopyQuestionnaireSystemCode).toHaveBeenCalled();
        });
        it('ensure CopyQuestionnaireSystemCode should be called with status 200', function () {
            spyOn(miCopyQuestionnaireSystemCodeService, 'CopyQuestionnaireSystemCode').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            miQuestionaireFactory.CopyQuestionnaireSystemCode("m2", "10788", "100000007698", "en-US");
            expect(miCopyQuestionnaireSystemCodeService.CopyQuestionnaireSystemCode).toHaveBeenCalled();
        });

        it('ensure questionnaireRouteDecision should be called and getQuestion should be called with error code 400', function () {
            spyOn(miQuestionaireFactory, 'getQuestion').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            miAppProperties.setStageStatus('IN_PROGRESS');
            miQuestionaireFactory.questionnaireRouteDecision("m2", "10788", "100000007698", "en-US");
            expect(miQuestionaireFactory.getQuestion).toHaveBeenCalled();
        });
        it('ensure questionnaireRouteDecision should be called and getQuestion should be called with response code 200', function () {
            spyOn(miQuestionaireFactory, 'getQuestion').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            miAppProperties.setStageStatus('IN_PROGRESS');
            miQuestionaireFactory.questionnaireRouteDecision("m2", "10788", "100000007698", "en-US");
            expect(miQuestionaireFactory.getQuestion).toHaveBeenCalled();
        });
        it('ensure questionnaireRouteDecision and getEvaluationDocId should be called', function () {
            spyOn(miQuestionaireFactory, 'getEvaluationDocId').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", route: 400 });
            });
            miAppProperties.setStageStatus('Complete');
            miQuestionaireFactory.questionnaireRouteDecision("m2", "10788", "100000007698", "en-US");
            expect(miQuestionaireFactory.getEvaluationDocId).toHaveBeenCalled();
        });
        it('ensure questionnaireRouteDecision and getQuestion should be called when getEvaluationDocId service return route blank', function () {
            spyOn(miQuestionaireFactory, 'getEvaluationDocId').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", route: "" });
            });
            spyOn(miQuestionaireFactory, 'getQuestion').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            miAppProperties.setStageStatus('Complete');
            miQuestionaireFactory.questionnaireRouteDecision("m2", "10788", "100000007698", "en-US");
            expect(miQuestionaireFactory.getEvaluationDocId).toHaveBeenCalled();
        });
        it('ensure getQuestion should be called with status code 400 when evaluation docId not null', function () {
            spyOn(miQuestionaireFactory, 'getEvaluationDocId').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", route: "" });
            });
            spyOn(miQuestionaireFactory, 'getQuestion').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            miAppProperties.setStageStatus('Complete');
            miQuestionaireFactory.questionnaireRouteDecision("m2", "10788", "100000007698", "en-US");
            expect(miQuestionaireFactory.getEvaluationDocId).toHaveBeenCalled();
            expect(miQuestionaireFactory.getQuestion).toHaveBeenCalled();
        });
    });
    describe('miStageFactory', function () {
        var miQuestionaireFactory, $httpBackend;
        beforeEach(inject(function () {
            inject(function ($injector) {
                scope = $injector.get('$rootScope').$new();
                miQuestionaireFactory = $injector.get('miQuestionaireFactory');
                mistagefactory = $injector.get('miStageFactory');
                $httpBackend = $injector.get('$httpBackend');
                miCMSIntegrationService = $injector.get('miCMSIntegrationService');
                miCreateStageService = $injector.get('miCreateStageService');
                miUpdateStageService = $injector.get('miUpdateStageService');
                miGetPreviousStageService = $injector.get('miGetPreviousStageService');
                miEditQuestionnaireSummaryService = $injector.get('miEditQuestionnaireSummaryService');
                miGetPartialStageService = $injector.get('miGetPartialStageService');
                miMoiFactory = $injector.get('miMoiFactory');
            });
        }));
        it('ensure CmsIntegration should be called with status 400', function () {
            spyOn(miCMSIntegrationService, 'CmsIntegration').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status:400});
            });
            mistagefactory.cmsIntegration("100000007698");
            expect(miCMSIntegrationService.CmsIntegration).toHaveBeenCalled();
        });
        it('ensure CmsIntegration should be called with status 200', function () {
            spyOn(miCMSIntegrationService, 'CmsIntegration').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            mistagefactory.cmsIntegration("100000007698");
            expect(miCMSIntegrationService.CmsIntegration).toHaveBeenCalled();
        });
        it('ensure createStage should be called with status 400', function () {
            spyOn(miCreateStageService, 'createStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status:400});
            });
            mistagefactory.createStage("100000007698");
            expect(miCreateStageService.createStage).toHaveBeenCalled();
        });
        it('ensure createStage should be called with status 200', function () {
            spyOn(miCreateStageService, 'createStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            mistagefactory.createStage("100000007698");
            expect(miCreateStageService.createStage).toHaveBeenCalled();
        });
        it('ensure updateStage should be called with status 400', function () {
            spyOn(miUpdateStageService, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status:400});
            });
            mistagefactory.updateStage("100000007698");
            expect(miUpdateStageService.updateStage).toHaveBeenCalled();
        });
        it('ensure updateStage should be called with status 200', function () {
            spyOn(miUpdateStageService, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            mistagefactory.updateStage("100000007698");
            expect(miUpdateStageService.updateStage).toHaveBeenCalled();
        });
        it('ensure cmsIntegrationRouteDecision should be called with status 400', function () {
            spyOn(miCreateStageService, 'createStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            mistagefactory.cmsIntegrationRouteDecision("fake-contextid", "fake-docid", "fake-costageid","en-US");
            expect(miCreateStageService.createStage).toHaveBeenCalled();
        });
        it('ensure cmsIntegrationRouteDecision should be called with status 200', function () {
            spyOn(miCreateStageService, 'createStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            spyOn(mistagefactory, 'cmsIntegration').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", route: 400 });
            });
            mistagefactory.cmsIntegrationRouteDecision("fake-contextid", "fake-docid", "fake-costageid", "en-US");
            expect(miCreateStageService.createStage).toHaveBeenCalled();
        });
        it('ensure cmsIntegrationRouteDecision and updateStage should be called', function () {
            spyOn(miCreateStageService, 'createStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            spyOn(mistagefactory, 'cmsIntegration').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", route:200 });
            });
            spyOn(miUpdateStageService, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", route: 400 });
            });
            mistagefactory.cmsIntegrationRouteDecision("fake-contextid", "fake-docid", "fake-costageid", "en-US");
            expect(miCreateStageService.createStage).toHaveBeenCalled();
            //expect(miUpdateStageService.updateStage).toHaveBeenCalled();
        });
        it('ensure getFirstQuestionnaire and EditQuestionnaireSummary should be called with status 400', function () {
            spyOn(miEditQuestionnaireSummaryService, 'getFirstQuestionnaire').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            mistagefactory.getFirstQuestionnaire("M2","fake-contextid","fake-version", "en-US");
            expect(miEditQuestionnaireSummaryService.getFirstQuestionnaire).toHaveBeenCalled();
            //expect(miUpdateStageService.updateStage).toHaveBeenCalled();
        });
        it('ensure EditQuestionnaireSummary and getQuestion should be called with status 400', function () {
            expectedDetail.EditSummaryData.stageType = "Questionnaire";
            spyOn(miEditQuestionnaireSummaryService, 'getFirstQuestionnaire').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(miQuestionaireFactory, 'getQuestion').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            mistagefactory.getFirstQuestionnaire("M2", "fake-contextid", "fake-version", "en-US");
            expect(miEditQuestionnaireSummaryService.getFirstQuestionnaire).toHaveBeenCalled();
            expect(miQuestionaireFactory.getQuestion).toHaveBeenCalled();
        });
        it('ensure EditQuestionnaireSummary and getQuestion should be called with status 200', function () {
            spyOn(miEditQuestionnaireSummaryService, 'getFirstQuestionnaire').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(miQuestionaireFactory, 'getQuestion').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data",route:"fake-route", status: 200 });
            });
            mistagefactory.getFirstQuestionnaire("M2", "fake-contextid", "fake-version", "en-US");
            expect(miEditQuestionnaireSummaryService.getFirstQuestionnaire).toHaveBeenCalled();
            expect(miQuestionaireFactory.getQuestion).toHaveBeenCalled();
        });
        it('ensure getNextStage should be called when called the EditQuestionnaireSummary and stage is questionnaire with getQuestion service status 204 ', function () {
            spyOn(miEditQuestionnaireSummaryService, 'getFirstQuestionnaire').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(miQuestionaireFactory, 'getQuestion').and.callFake(function () {
                return $.Deferred().resolve({ data: "", route: "fake-route", status: 204 });
            });
            spyOn(mistagefactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "", route: "fake-route", status: 200 });
            });
            mistagefactory.getFirstQuestionnaire("M2", "fake-contextid", "fake-version", "en-US");
            expect(miEditQuestionnaireSummaryService.getFirstQuestionnaire).toHaveBeenCalled();
            expect(miQuestionaireFactory.getQuestion).toHaveBeenCalled();
        });
       
    });

    describe('miStageFactory->GetNextStageFromUri', function () {
        var miQuestionaireFactory, $httpBackend;
        beforeEach(inject(function () {
            inject(function ($injector) {
                scope = $injector.get('$rootScope').$new();
                miQuestionaireFactory = $injector.get('miQuestionaireFactory');
                mistagefactory = $injector.get('miStageFactory');
                $httpBackend = $injector.get('$httpBackend');
                miGetPartialStageService = $injector.get('miGetPartialStageService');
                miGetStageFromUriService = $injector.get('miGetStageFromUriService');
                
                miMoiFactory = $injector.get('miMoiFactory');
            });
        }));
        it('ensure miGetPartialStageService should be called with status 400 when called GetNextStageFromUri', function () {
            spyOn(miGetStageFromUriService, 'getNextStagefromUri').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            mistagefactory.getNextStagefromUri('fake-Uri', 'app-version','en-US');
            expect(miGetStageFromUriService.getNextStagefromUri).toHaveBeenCalled();
        });
        it('ensure miGetPartialStageService should be called with status 401 when called GetNextStageFromUri', function () {
            spyOn(miGetStageFromUriService, 'getNextStagefromUri').and.callFake(function () {
                return $.Deferred().resolve({ data: "", status: 401 });
            });
            mistagefactory.getNextStagefromUri('fake-Uri', 'app-version', 'en-US');
            expect(miGetStageFromUriService.getNextStagefromUri).toHaveBeenCalled();
        });
        it('ensure miGetPartialStageService should be called with status 200 when called GetNextStageFromUri and stage type questionnaire', function () {
            expectedDetail.EditSummaryData.stageType = "Questionnaire";
            spyOn(miGetStageFromUriService, 'getNextStagefromUri').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            mistagefactory.getNextStagefromUri('fake-Uri', 'app-version', 'en-US');
            expect(miGetStageFromUriService.getNextStagefromUri).toHaveBeenCalled();
        });
        it('ensure miGetPartialStageService should be called with status 200 when called GetNextStageFromUri and stage type integration', function () {
            expectedDetail.EditSummaryData.stageType = "Integration";
            expectedDetail.EditSummaryData.pageName = "Vehicle Summary Page";
            spyOn(miGetStageFromUriService, 'getNextStagefromUri').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            mistagefactory.getNextStagefromUri('fake-Uri', 'app-version', 'en-US');
            expect(miGetStageFromUriService.getNextStagefromUri).toHaveBeenCalled();
        });
        it('ensure cmsIntegrationRouteDecision service should be called with status 200 when called GetNextStageFromUri and stage type integration', function () {
            expectedDetail.EditSummaryData.stageType = "Integration";
            expectedDetail.EditSummaryData.pageName = "fake-pageName";
            spyOn(miGetStageFromUriService, 'getNextStagefromUri').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(mistagefactory, 'cmsIntegrationRouteDecision').and.callFake(function () {
                return $.Deferred().resolve({ data: "", route: "fake-route", status: 200 });
            });
            mistagefactory.getNextStagefromUri('fake-Uri', 'app-version', 'en-US');
            expect(miGetStageFromUriService.getNextStagefromUri).toHaveBeenCalled();
        });
        it('ensure miMoiFactory should be called with status 200 when called GetNextStageFromUri and stage type predefined page', function () {
            expectedDetail.EditSummaryData.stageType = "fake-stageType";
            expectedDetail.EditSummaryData.pageName = "Post FNOL";
            spyOn(miGetStageFromUriService, 'getNextStagefromUri').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(miMoiFactory, 'moiPageDecision').and.callFake(function () {
                return $.Deferred().resolve({ data: "", route: "fake-route", status: 200 });
            });
            mistagefactory.getNextStagefromUri('fake-Uri', 'app-version', 'en-US');
            expect(miMoiFactory.moiPageDecision).toHaveBeenCalled();
        });
        it('Ensure miQuestionaireFactory should be called with status 200 when called GetNextStageFromUri and stage type predefined page', function () {
            expectedDetail.EditSummaryData.stageType = "fake-stageType";
            expectedDetail.EditSummaryData.pageName = "Questionnaire Confirmation";
            spyOn(miGetStageFromUriService, 'getNextStagefromUri').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(miQuestionaireFactory, 'getQuestionnaireDetails').and.callFake(function () {
                return $.Deferred().resolve({ data: "", route: "fake-route", status: 200 });
            });
            mistagefactory.getNextStagefromUri('fake-Uri', 'app-version', 'en-US');
            expect(miQuestionaireFactory.getQuestionnaireDetails).toHaveBeenCalled();
        });
        it('Ensure miQuestionaireFactory should be called with status 200 when called GetNextStageFromUri and Predefined Page is questionniareConfirmation', function () {
            expectedDetail.EditSummaryData.stageType = "fake-stageType";
            expectedDetail.EditSummaryData.pageName = "Questionnaire Confirmation";
            spyOn(miGetStageFromUriService, 'getNextStagefromUri').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(miQuestionaireFactory, 'getQuestionnaireDetails').and.callFake(function () {
                return $.Deferred().resolve({ data: "", route: "", status: 200 });
            });
            mistagefactory.getNextStagefromUri('fake-Uri', 'app-version', 'en-US');
            expect(miQuestionaireFactory.getQuestionnaireDetails).toHaveBeenCalled();
        });
        it('Ensure user should redirect to predefined page when called GetNextStageFromUri and stage type predefined page', function () {
            expectedDetail.EditSummaryData.stageType = "fake-stageType";
            expectedDetail.EditSummaryData.pageName = "fake-pageName";
            spyOn(miGetStageFromUriService, 'getNextStagefromUri').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            mistagefactory.getNextStagefromUri('fake-Uri', 'app-version', 'en-US');

        });
    });

    describe('miStageFactory->PartialStage', function () {
        var miQuestionaireFactory, $httpBackend;
        beforeEach(inject(function () {
            inject(function ($injector) {
                scope = $injector.get('$rootScope').$new();
                miQuestionaireFactory = $injector.get('miQuestionaireFactory');
                mistagefactory = $injector.get('miStageFactory');
                $httpBackend = $injector.get('$httpBackend');
                miGetPartialStageService = $injector.get('miGetPartialStageService');
                miMoiFactory = $injector.get('miMoiFactory');
            });
        }));
        it('ensure miGetPartialStageService should be called with status 400 when called getNextPartialStage', function () {
            spyOn(miGetPartialStageService, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            mistagefactory.getNextPartialStage('M2', 'app-version', '2', 'en-US');
            expect(miGetPartialStageService.getNextPartialStage).toHaveBeenCalled();
        });
        it('ensure miGetPartialStageService should be called with status 401 when called getNextPartialStage', function () {
            spyOn(miGetPartialStageService, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "", status: 401 });
            });
            mistagefactory.getNextPartialStage('M2', 'app-version', '2', 'en-US');
            expect(miGetPartialStageService.getNextPartialStage).toHaveBeenCalled();
        });
        it('ensure miGetPartialStageService should be called with status 200 when called getNextPartialStage and stage type questionnaire', function () {
            expectedDetail.EditSummaryData.stageType = "Questionnaire";
            spyOn(miGetPartialStageService, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            mistagefactory.getNextPartialStage('M2', 'app-version', '2', 'en-US');
            expect(miGetPartialStageService.getNextPartialStage).toHaveBeenCalled();
        });
        it('ensure miGetPartialStageService should be called with status 200 when called getNextPartialStage and stage type integration', function () {
            expectedDetail.EditSummaryData.stageType = "Integration";
            expectedDetail.EditSummaryData.pageName = "Vehicle Summary Page";
            spyOn(miGetPartialStageService, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            mistagefactory.getNextPartialStage('M2', 'app-version', '2', 'en-US');
            expect(miGetPartialStageService.getNextPartialStage).toHaveBeenCalled();
        });
        it('ensure cmsIntegrationRouteDecision service should be called with status 200 when called getNextPartialStage and stage type integration', function () {
            expectedDetail.EditSummaryData.stageType = "Integration";
            expectedDetail.EditSummaryData.pageName = "fake-pageName";
            spyOn(miGetPartialStageService, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(mistagefactory, 'cmsIntegrationRouteDecision').and.callFake(function () {
                return $.Deferred().resolve({ data: "", route: "fake-route", status: 200 });
            });
            mistagefactory.getNextPartialStage('M2', 'app-version', '2', 'en-US');
            expect(mistagefactory.cmsIntegrationRouteDecision).toHaveBeenCalled();
        });
        it('ensure miMoiFactory should be called with status 200 when called getNextPartialStage and stage type predefined page', function () {
            expectedDetail.EditSummaryData.stageType = "fake-stageType";
            expectedDetail.EditSummaryData.pageName = "Post FNOL";
            spyOn(miGetPartialStageService, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(miMoiFactory, 'moiPageDecision').and.callFake(function () {
                return $.Deferred().resolve({ data: "", route: "fake-route", status: 200 });
            });
            mistagefactory.getNextPartialStage('M2', 'app-version', '2', 'en-US');
            expect(miMoiFactory.moiPageDecision).toHaveBeenCalled();
        });
        it('Ensure miQuestionaireFactory should be called with status 200 when called getNextPartialStage and stage type predefined page', function () {
            expectedDetail.EditSummaryData.stageType = "fake-stageType";
            expectedDetail.EditSummaryData.pageName = "Questionnaire Confirmation";
            spyOn(miGetPartialStageService, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(miQuestionaireFactory, 'getQuestionnaireDetails').and.callFake(function () {
                return $.Deferred().resolve({ data: "", route: "fake-route", status: 200 });
            });
            mistagefactory.getNextPartialStage('M2', 'app-version', '2', 'en-US');
            expect(miQuestionaireFactory.getQuestionnaireDetails).toHaveBeenCalled();
        });
        it('Ensure miQuestionaireFactory should be called with status 200 when called getNextPartialStage and Predefined Page is questionniareConfirmation', function () {
            expectedDetail.EditSummaryData.stageType = "fake-stageType";
            expectedDetail.EditSummaryData.pageName = "Questionnaire Confirmation";
            spyOn(miGetPartialStageService, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(miQuestionaireFactory, 'getQuestionnaireDetails').and.callFake(function () {
                return $.Deferred().resolve({ data: "", route: "", status: 200 });
            });
            mistagefactory.getNextPartialStage('M2', 'app-version', '2', 'en-US');
            expect(miQuestionaireFactory.getQuestionnaireDetails).toHaveBeenCalled();
        });
        it('Ensure user should redirect to predefined page when called getNextPartialStage and stage type predefined page', function () {
            expectedDetail.EditSummaryData.stageType = "fake-stageType";
            expectedDetail.EditSummaryData.pageName = "fake-pageName";
            spyOn(miGetPartialStageService, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            mistagefactory.getNextPartialStage('M2', 'app-version', '2', 'en-US');
            
        });
    });

    describe('miStageFactory->Previous Stage', function () {
        var miQuestionaireFactory, $httpBackend;
        beforeEach(inject(function () {
            inject(function ($injector) {
                scope = $injector.get('$rootScope').$new();
                miQuestionaireFactory = $injector.get('miQuestionaireFactory');
                mistagefactory = $injector.get('miStageFactory');
                $httpBackend = $injector.get('$httpBackend');
                miGetPreviousStageService = $injector.get('miGetPreviousStageService');
            });
        }));
        it('ensure previousStage should be called with status 400', function () {
            spyOn(miGetPreviousStageService, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            mistagefactory.getPreviousStage("100000007698", 'M2', 'app-version', '2', 'en-US');
            expect(miGetPreviousStageService.getPreviousStage).toHaveBeenCalled();
        });
        it('ensure previousStage should be called with status 204', function () {
            spyOn(miGetPreviousStageService, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 204 });
            });
            mistagefactory.getPreviousStage("100000007698", 'M2', 'app-version', '2', 'en-US');
            expect(miGetPreviousStageService.getPreviousStage).toHaveBeenCalled();
        });
        it('ensure getPreviousQuestion should be called with status 204 when called previous stage', function () {
            expectedDetail.EditSummaryData.prevStageIntgrtnTyp = true;
            expectedDetail.EditSummaryData.stageType = "Questionnaire";
            spyOn(miGetPreviousStageService, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(miQuestionaireFactory, 'getPreviousQuestion').and.callFake(function () {
                // return $.Deferred().resolve({ data: { "firstQuestion": "fake-question" },route:"", status: 200 });
                return $.Deferred().resolve({ data: "", route: "", status: 204 });
            });
            mistagefactory.getPreviousStage("100000007698", 'M2', 'app-version', '2', 'en-US');
            expect(miQuestionaireFactory.getPreviousQuestion).toHaveBeenCalled();
        });
        it('ensure getprevious stage should be called when getPreviousQuestion called with status 200 by called previous stage with integration stage false', function () {
            expectedDetail.EditSummaryData.prevStageIntgrtnTyp = false;
            expectedDetail.EditSummaryData.stageType = "Questionnaire";
            spyOn(miGetPreviousStageService, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            spyOn(miQuestionaireFactory, 'getPreviousQuestion').and.callFake(function () {
                return $.Deferred().resolve({ data: { "firstQuestion": "fake-question" }, route: "", status: 200 });
                // return $.Deferred().resolve({ data: "", route: "", status: 200 });
            });

            mistagefactory.getPreviousStage("100000007698", 'M2', 'app-version', '2', 'en-US');
            expect(miQuestionaireFactory.getPreviousQuestion).toHaveBeenCalled();

        })
        it('ensure getPreviousStage should be called when stageType is not questionniare', function () {
            expectedDetail.EditSummaryData.stageType = "fake-stageType";
            spyOn(miGetPreviousStageService, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            mistagefactory.getPreviousStage("100000007698", 'M2', 'app-version', '2', 'en-US');
            expect(miGetPreviousStageService.getPreviousStage).toHaveBeenCalled();
        });
        it('ensure getPreviousStage should be called when stageType is not questionniare and PageName is Informational Page', function () {
            expectedDetail.EditSummaryData.stageType = "fake-stageType";
            expectedDetail.EditSummaryData.pageName = "Informational Page";
            spyOn(miGetPreviousStageService, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ data: expectedDetail.EditSummaryData, status: 200 });
            });
            mistagefactory.getPreviousStage("100000007698", 'M2', 'app-version', '2', 'en-US');
            expect(miGetPreviousStageService.getPreviousStage).toHaveBeenCalled();
        });

    });

    describe('miCMSFactory', function () {
        var miQuestionaireFactory, $httpBackend;
        beforeEach(inject(function () {
            inject(function ($injector) {
                scope = $injector.get('$rootScope').$new();
                miCMSFactory = $injector.get('miCMSFactory');
                $httpBackend = $injector.get('$httpBackend');
                miPolicyVerificationService = $injector.get('miPolicyVerificationService');
                miAppProperties = $injector.get('miAppProperties');
                miGetVehicalDetailsService = $injector.get('miGetVehicalDetailsService');
                 miDeletePolicyService = $injector.get('miDeletePolicyService');
            });
        }));
        it('ensure policyVerification should be called with status 400', function () {
            miAppProperties.setcontextid("125");
            spyOn(miPolicyVerificationService, 'verifyPolicy').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            miCMSFactory.policyVerification("fake-policyVerificationData","en-US");
            expect(miPolicyVerificationService.verifyPolicy).toHaveBeenCalled();
        });
        it('ensure policyVerification should be called with status 200', function () {
            spyOn(miPolicyVerificationService, 'verifyPolicy').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            miCMSFactory.policyVerification("fake-policyVerificationData", "en-US");
            expect(miPolicyVerificationService.verifyPolicy).toHaveBeenCalled();
        });
        it('ensure policyVerification should be called with status 204', function () {
            spyOn(miPolicyVerificationService, 'verifyPolicy').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 204 });
            });
            miCMSFactory.policyVerification("fake-policyVerificationData", "en-US");
            expect(miPolicyVerificationService.verifyPolicy).toHaveBeenCalled();
        });
        it('ensure getVehicalDetails should be called with status 400', function () {
            miAppProperties.setcontextid("125");
            spyOn(miGetVehicalDetailsService, 'getVehicalDetails').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            miCMSFactory.getVehicalDetails("1202","en-US");
            expect(miGetVehicalDetailsService.getVehicalDetails).toHaveBeenCalled();
        });
        it('ensure getVehicalDetails should be called with status 200', function () {
            spyOn(miGetVehicalDetailsService, 'getVehicalDetails').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            miCMSFactory.getVehicalDetails("1202", "en-US");
            expect(miGetVehicalDetailsService.getVehicalDetails).toHaveBeenCalled();
        });
        it('ensure deletePolicy should be called with status 400', function () {
            miAppProperties.setcontextid("125");
            spyOn(miDeletePolicyService, 'deletePolicy').and.callFake(function() {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            miCMSFactory.deletePolicy("1202", "INACTIVE", "en-US");
            expect(miDeletePolicyService.deletePolicy).toHaveBeenCalled();
        });
        it('ensure deletePolicy should be called with status 200', function () {
            spyOn(miDeletePolicyService, 'deletePolicy').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            miCMSFactory.deletePolicy("1202","INACTIVE", "en-US");
            expect(miDeletePolicyService.deletePolicy).toHaveBeenCalled();
        });
    });
    describe('miAppFactory', function () {
        var miQuestionaireFactory, $httpBackend;
        beforeEach(inject(function () {
            inject(function ($injector) {
                scope = $injector.get('$rootScope').$new();
                miAppFactory = $injector.get('miAppFactory');
                $httpBackend = $injector.get('$httpBackend');
                miGetLanguageListService = $injector.get('miGetLanguageListService');
                miAppProperties = $injector.get('miAppProperties');
                miGetIdentificationFieldsService = $injector.get('miGetIdentificationFieldsService');
                miIdentificationService = $injector.get('miIdentificationService');
                miQuestionaireFactory = $injector.get('miQuestionaireFactory');
                miStageFactory = $injector.get('miStageFactory');
                //miCopyQuestionnaireSystemCodeService=$injector.get('miCopyQuestionnaireSystemCodeService');
            });
        }));
        it('ensure getLanguageList should be called with status 400', function () {
            spyOn(miGetLanguageListService, 'getLanguageList').and.callFake(function () {
                return $.Deferred().resolve({ data: { languagesList: "en-GB" }, status: 400 });
            });
            miAppFactory.getLanguageList();
            expect(miGetLanguageListService.getLanguageList).toHaveBeenCalled();
        });
        it('ensure getLanguageList should be called with status 200', function () {
            spyOn(miGetLanguageListService, 'getLanguageList').and.callFake(function () {
                return $.Deferred().resolve({ data:{languagesList:"en-GB"}, status: 200 });
            });
            miAppFactory.getLanguageList();
            expect(miGetLanguageListService.getLanguageList).toHaveBeenCalled();
        });
        it('ensure getIdentificationFields should be called with status 400', function () {
            spyOn(miGetIdentificationFieldsService, 'getIdentificationFields').and.callFake(function () {
                return $.Deferred().resolve({ data: { languagesList: "en-GB" }, status: 400 });
            });
            miAppFactory.getIdentificationFields("M2","en-US");
            expect(miGetIdentificationFieldsService.getIdentificationFields).toHaveBeenCalled();
        });
        it('ensure getIdentificationFields should be called with status 200', function () {
            spyOn(miGetIdentificationFieldsService, 'getIdentificationFields').and.callFake(function () {
                return $.Deferred().resolve({ data: { languagesList: "en-GB" }, status: 200 });
            });
            miAppFactory.getIdentificationFields("M2", "en-US");
            expect(miGetIdentificationFieldsService.getIdentificationFields).toHaveBeenCalled();
        });
        it('ensure identify function should be called with status 400', function () {
            spyOn(miIdentificationService, 'identify').and.callFake(function () {
                return $.Deferred().resolve({ data: { languagesList: "en-GB" }, status: 400 });
            });
            miAppFactory.identify("M2", "en-US");
            expect(miIdentificationService.identify).toHaveBeenCalled();
        });
        it('ensure identify function should be called with status 200', function () {
            spyOn(miIdentificationService, 'identify').and.callFake(function () {
                return $.Deferred().resolve({ data: { languagesList: "en-GB" }, status: 200 });
            });
            miAppFactory.identify("M2", "en-US");
            expect(miIdentificationService.identify).toHaveBeenCalled();
        });
        it('ensure getPreviousRoute function should be called with status 400', function () {
            spyOn(miQuestionaireFactory, 'getPreviousQuestion').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400 });
            });
            miAppFactory.getPreviousRoute("10021");
            expect(miQuestionaireFactory.getPreviousQuestion).toHaveBeenCalled();
        });
        it('ensure getPreviousRoute and getPreviousStage function should be called with status 200', function () {
            spyOn(miQuestionaireFactory, 'getPreviousQuestion').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 204 });
            });
            spyOn(miStageFactory, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", route: 200 });
            });
            miAppFactory.getPreviousRoute("10021");
            expect(miQuestionaireFactory.getPreviousQuestion).toHaveBeenCalled();
            expect(miStageFactory.getPreviousStage).toHaveBeenCalled();
        });
        it('ensure getNextStage should be called when getPreviousRoute and getPreviousStage function should be called with stageType integration', function () {
            miAppProperties.setIntegrationStage(true);
            spyOn(miQuestionaireFactory, 'getPreviousQuestion').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 204 });
            });
            spyOn(miStageFactory, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", route: 200 });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", route: 200 });
            });
            miAppFactory.getPreviousRoute("10021");
            expect(miQuestionaireFactory.getPreviousQuestion).toHaveBeenCalled();
            expect(miStageFactory.getPreviousStage).toHaveBeenCalled();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        });
    });
    describe('miAppFactory->getRoute factory', function () {
        beforeEach(inject(function () {
            inject(function ($injector) {
                scope = $injector.get('$rootScope').$new();
                miAppFactory = $injector.get('miAppFactory');
                miAppProperties = $injector.get('miAppProperties');
                miGetComplexDataService = $injector.get('miGetComplexDataService');
                miQuestionaireFactory = $injector.get('miQuestionaireFactory');
                miStageFactory = $injector.get('miStageFactory');
            });
        }));
        it('ensure saveQuestion service should be called with error when called the getRoute()', function () {
            spyOn(miQuestionaireFactory, 'saveQuestion').and.callFake(function() {
                return $.Deferred().resolve({
                    data: "fake-data", status: 200, route:"fake-route"
                });
            });
            miAppFactory.getRoute();
            expect(miQuestionaireFactory.saveQuestion).toHaveBeenCalled();
        });
        it('ensure getQuestion service should be called with questiondata', function () {
            spyOn(miQuestionaireFactory, 'saveQuestion').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "fake-data", status: 200, route: ""
                });
            });
            spyOn(miQuestionaireFactory, 'getQuestion').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "fake-data", status: 200, route: "fake-route"
                });
            });
            miAppFactory.getRoute();
            expect(miQuestionaireFactory.saveQuestion).toHaveBeenCalled();
            expect(miQuestionaireFactory.getQuestion).toHaveBeenCalled();
        });
        it('ensure updateStage service should be called with error when getQuestion service return no data', function () {
            miAppProperties.setcontextid('123');
            spyOn(miQuestionaireFactory, 'saveQuestion').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "fake-data", status: 200, route: ""
                });
            });
            spyOn(miQuestionaireFactory, 'getQuestion').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "", status: 200, route: "fake-route"
                });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "", status: 200, route: "fake-route"
                });
            });
            miAppFactory.getRoute();
            expect(miQuestionaireFactory.saveQuestion).toHaveBeenCalled();
            expect(miQuestionaireFactory.getQuestion).toHaveBeenCalled();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
        });
        it('ensure getQuestionEvaluation service should be called with error when getQuestion service return no data and updateStage service called successfull', function () {
            miAppProperties.setcontextid('123');
            spyOn(miQuestionaireFactory, 'saveQuestion').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "fake-data", status: 200, route: ""
                });
            });
            spyOn(miQuestionaireFactory, 'getQuestion').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "", status: 200, route: "fake-route"
                });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "", status: 200, route: ""
                });
            });
            spyOn(miQuestionaireFactory, 'getQuestionEvaluation').and.callFake(function () {
                return $.Deferred().resolve({
                data: "", status: 200, route: "fake-route"
            });
            });
            miAppFactory.getRoute();
            expect(miQuestionaireFactory.saveQuestion).toHaveBeenCalled();
            expect(miQuestionaireFactory.getQuestion).toHaveBeenCalled();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
            expect(miQuestionaireFactory.getQuestionEvaluation).toHaveBeenCalled();
        });
        it('ensure getNextStage service should be called when getQuestionEvaluation return success and getQuestion service return no data and updateStage service called successfull', function () {
            miAppProperties.setcontextid('123');
            spyOn(miQuestionaireFactory, 'saveQuestion').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "fake-data", status: 200, route: ""
                });
            });
            spyOn(miQuestionaireFactory, 'getQuestion').and.callFake(function() {
            return $.Deferred().resolve({
                data: "", status: 200, route: "fake-route"
            });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "", status: 200, route: ""
                });
            });
            spyOn(miQuestionaireFactory, 'getQuestionEvaluation').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "", status: 200, route: ""
                });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function() {
                return $.Deferred().resolve({
                    data: "", status: 200, route: "fake-route"
                });
            });
            miAppFactory.getRoute();
            expect(miQuestionaireFactory.saveQuestion).toHaveBeenCalled();
            expect(miQuestionaireFactory.getQuestion).toHaveBeenCalled();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
            expect(miQuestionaireFactory.getQuestionEvaluation).toHaveBeenCalled();
        });
        it('ensure getNextStage service should be called when getQuestion service return no data and contextId does not exists', function () {
            miAppProperties.setcontextid(0);
            spyOn(miQuestionaireFactory, 'saveQuestion').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "fake-data", status: 200, route: ""
                });
            });
            spyOn(miQuestionaireFactory, 'getQuestion').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "", status: 200, route: "fake-route"
                });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function() {
                return $.Deferred().resolve({ data: "", status: 200, route: "fake-route" });
            });
           
            miAppFactory.getRoute();
            expect(miQuestionaireFactory.saveQuestion).toHaveBeenCalled();
            expect(miQuestionaireFactory.getQuestion).toHaveBeenCalled();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
            });
    });


    describe('miAppFactory->getComplexFieldData factory', function () {
        beforeEach(inject(function () {
            inject(function ($injector) {
                scope = $injector.get('$rootScope').$new();
                miAppFactory = $injector.get('miAppFactory');
                miAppProperties = $injector.get('miAppProperties');
                miGetComplexDataService = $injector.get('miGetComplexDataService');
                miStageFactory = $injector.get('miStageFactory');
            });
        }));
        it('ensure getComplexFieldData function should be called with error', function () {
             spyOn(miGetComplexDataService, 'getComplexFieldData').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 400
            });
            });
             miAppFactory.getComplexFieldData("fake-url");
             expect(miGetComplexDataService.getComplexFieldData).toHaveBeenCalled();
        });
         it('ensure getComplexFieldData function should be called with success', function () {
             spyOn(miGetComplexDataService, 'getComplexFieldData').and.callFake(function() {
                return $.Deferred().resolve({ data: "fake-data", status: 200
            });
            });
             miAppFactory.getComplexFieldData("fake-url");
             expect(miGetComplexDataService.getComplexFieldData).toHaveBeenCalled();
             });
    });

    describe('miCarrierContactFactory', function () {
        beforeEach(inject(function () {
            inject(function ($injector) {
                scope = $injector.get('$rootScope').$new();
                miCarrierContactFactory = $injector.get('miCarrierContactFactory');
                miCarrierContactService = $injector.get('miCarrierContactService');
        });
    }));
    it('ensure getCarrierTelephoneNumber should be called with status 400', function () {
            spyOn(miCarrierContactService, 'getCarrierContact').and.callFake(function () {
                return $.Deferred().resolve({ data: { languagesList: "en-GB" }, status: 400 });
    });
            miCarrierContactFactory.getCarrierTelephoneNumber("m2", "en-US");
            expect(miCarrierContactService.getCarrierContact).toHaveBeenCalled();
    });
    it('ensure getCarrierTelephoneNumber should be called with status 200', function () {
            spyOn(miCarrierContactService, 'getCarrierContact').and.callFake(function () {
                return $.Deferred().resolve({ data: { languagesList: "en-GB" }, status: 200 });
    });
            miCarrierContactFactory.getCarrierTelephoneNumber("m2", "en-US");
            expect(miCarrierContactService.getCarrierContact).toHaveBeenCalled();
    });
    });
    describe('miResourceDataFactory', function () {
        var miQuestionaireFactory, $httpBackend;
        beforeEach(inject(function () {
            inject(function ($injector) {
                scope = $injector.get('$rootScope').$new();
                miResourceDataFactory = $injector.get('miResourceDataFactory');
                $httpBackend = $injector.get('$httpBackend');
                ResourceLookupService1 = $injector.get('miServiceCenterResourceLookUpService');
                ResourceLookupService2 = $injector.get('miShopResourceLookUpService');
            });
        }));
        it('ensure GetResourcesOrGroup should be called when moiGroupType is group', function () {
            spyOn(ResourceLookupService1, 'GetResources').and.callFake(function () {
                return $.Deferred().resolve({ data:"fake-data", status: 400 });
            });
            miResourceDataFactory.GetResourcesOrGroup("fake-criteriaData", "Group");
            expect(ResourceLookupService1.GetResources).toHaveBeenCalled();
        });
        it('ensure GetResourcesOrGroup should be called when moiGroupType is Resource', function () {
            spyOn(ResourceLookupService2, 'GetResources').and.callFake(function () {
                return $.Deferred().resolve({ data: "fake-data", status: 200 });
            });
            miResourceDataFactory.GetResourcesOrGroup("fake-criteriaData", "Resource");
            expect(ResourceLookupService2.GetResources).toHaveBeenCalled();
        });

    });

   

});
