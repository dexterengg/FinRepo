﻿(function (ng) {
    'use strict';

    ng.module('mi.mfnol.web')

    ////GetOutcomeService
    .service('miGetOutcomeService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    'miLocale',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties, miLocale) {

        return {
            getOutcome: function (companycode, contextid) {

                var deferred = $q.defer();
                var outcomeResult = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/assignment/companies/" + companycode + "/fnol/" + contextid + "/outcomes",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'Accept-Language': miLocale.getLocaleCode(),
                            'source': ENV.SOURCE
                        }
                    }).success(function (result, status, headers, config) {
                        outcomeResult.data = result;
                        outcomeResult.status = status;
                        deferred.resolve(outcomeResult);
                    }).error(function (result, status, headers, config) {
                        outcomeResult.data = result;
                        outcomeResult.status = status;
                        deferred.resolve(outcomeResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },
            postOutcome: function (companycode, contextid, outcomeDetails) {
                var deferred = $q.defer();
                var outcomeResult = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.POST,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/assignment/companies/" + companycode + "/fnol/" + contextid + "/evaluation/outcome/Acknowledgement",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'Accept-Language': miLocale.getLocaleCode(),
                            'source': ENV.SOURCE
                        },
                        data: outcomeDetails
                    }).success(function (result, status, headers, config) {
                        outcomeResult.data = result;
                        outcomeResult.status = status;
                        deferred.resolve(outcomeResult);
                    }).error(function (result, status, headers, config) {
                        outcomeResult.data = result;
                        outcomeResult.status = status;
                        deferred.resolve(outcomeResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            }

        };
    }])
    ////

    ////GetNextStageService
    .service('miGetNextStageService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            getNextStage: function (companycode, appversion, stageorder, lan, contextId) {

                var deferred = $q.defer();
                var stageResult = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/stage/companies/" + companycode + "/stage/order/" + stageorder + "/" + contextId + "/nextStage",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'appVersion': appversion,
                            'source': ENV.SOURCE
                        }
                    }).success(function (result, status, headers, config) {
                        stageResult.data = result;
                        stageResult.status = status;
                        deferred.resolve(stageResult);
                    }).error(function (result, status, headers, config) {
                        stageResult.data = result;
                        stageResult.status = status;
                        deferred.resolve(stageResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////

    ////GetQuestionService
    .service('miGetQuestionService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            getQuestion: function (companycode, qustnnrevaldocid, questionnaireid, lan, qustnnrequstnid) {

                var deferred = $q.defer();
                var questionResult = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + ENV.GETQUESTION_API_ENDPOINT + companycode + "/questionnaires/" + questionnaireid + "/QustnnrEvalDocId/" + qustnnrevaldocid + "/QuestionnaireQuestionId/" + qustnnrequstnid + "/next-question" + miAppProperties.getQuestionstate(),
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        }
                    }).success(function (result, status, headers, config) {
                        questionResult.data = result;
                        questionResult.status = status;
                        deferred.resolve(questionResult);
                    }).error(function (result, status, headers, config) {
                        questionResult.data = result;
                        questionResult.status = status;
                        deferred.resolve(questionResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])


 .service('miGetPreviousQuestionService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            getPreviousQuestion: function (companycode, qustnnrevaldocid, questionnaireid, lan, qustnnrequstnid) {

                var deferred = $q.defer();
                var questionResult = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + ENV.GETPREVIOUSQUESTION_API_ENDPOINT + companycode + "/questionnaires/" + questionnaireid + "/QuestionnaireEvaluations/" + qustnnrevaldocid + "/QuestionnaireQuestionId/" +qustnnrequstnid + "/previousQuestion",

                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        }
                    }).success(function (result, status, headers, config) {
                        questionResult.data = result;
                        questionResult.status = status;
                        deferred.resolve(questionResult);
                    }).error(function (result, status, headers, config) {
                        questionResult.data = result;
                        questionResult.status = status;
                        deferred.resolve(questionResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////

    ////GetQuestionEvaluationService
    .service('miGetQuestionEvaluationService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    'miLocale',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties, miLocale) {
        return {
            getQuestionEvaluation: function (companycode, qustnnrevaldocId) {

                var deferred = $q.defer();
                var questionEvalutionResult = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.POST,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + ENV.GETQUESTIONEVALUATION_API_ENDPOINT + companycode + "/QuestionnaireEvaluations/" + qustnnrevaldocId + "/evaluate-outcome",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'Accept-Language': miLocale.getLocaleCode(),
                            'source': ENV.SOURCE
                        }
                    }).success(function (result, status, headers, config) {
                        questionEvalutionResult.data = result;
                        questionEvalutionResult.status = status;
                        deferred.resolve(questionEvalutionResult);
                    }).error(function (result, status, headers, config) {
                        questionEvalutionResult.data = result;
                        questionEvalutionResult.status = status;
                        deferred.resolve(questionEvalutionResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

            getQuestionnaireDetails: function (companycode, contextid, lan) {

                var deferred = $q.defer();
                var questionnaireDetails = {
                    data: '', status: ''
                };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + ENV.GETQUESTIONDETAIL_API_ENDPOINT + companycode + "/fnol/" + contextid + "/Summary",

                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        }
                    }).success(function (result, status, headers, config) {
                        questionnaireDetails.data = result;
                        questionnaireDetails.status = status;
                        deferred.resolve(questionnaireDetails);
                    }).error(function (result, status, headers, config) {
                        questionnaireDetails.data = result;
                        questionnaireDetails.status = status;
                        deferred.resolve(questionnaireDetails);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            }


        };
    }])
    ////

    ////GetEvaluationDocIdService
    .service('miGetEvaluationDocIdService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            getEvaluationDocId: function (companycode, questionnaireid, systemdocid, lan, sysMap, userMap) {

                var deferred = $q.defer();
                var evaluationDocResult = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.POST,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + ENV.GETQUESTION_API_ENDPOINT + companycode + "/QuestionnaireEvaluations",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        },
                        data: { "mapSysQustnCdsAndValues": sysMap, "qustnnrId": questionnaireid, "evalDocId": systemdocid, "userAnswrdSystmQustn": userMap }
                    }).success(function (result, status, headers, config) {
                        evaluationDocResult.data = result;
                        evaluationDocResult.status = status;
                        deferred.resolve(evaluationDocResult);
                    }).error(function (result, status, headers, config) {
                        evaluationDocResult.data = result;
                        evaluationDocResult.status = status;
                        deferred.resolve(evaluationDocResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////

    ////SaveQuestionService
    .service('miSaveQuestionService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            saveQuestion: function (companycode, qustnnrevaldocId, questionnaireid, lan, questionDetails) {
                var deferred = $q.defer();
                var output = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.POST,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + ENV.GETQUESTION_API_ENDPOINT + companycode + "/QuestionnaireEvaluations/" + qustnnrevaldocId,
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        },
                        data: questionDetails
                    }).success(function (result, status, headers, config) {
                        output.data = result;
                        output.status = status;
                        deferred.resolve(output);
                    }).error(function (result, status, headers, config) {
                        output.data = result;
                        output.status = status;
                        deferred.resolve(output);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////

    ////CreateStageService
    .service('miCreateStageService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            createStage: function (contextid, documentid, costageid, lan) {

                var deferred = $q.defer();
                var createStageResult = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.POST,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/stage/companies/" + $rootScope.companyCode + "/fnol/" + contextid + "/stage",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        },
                        data: { "contextID": contextid, "status": "IN_PROGRESS", "documentId": documentid, "coStageId": costageid }

                    }).success(function (result, status, headers, config) {
                        createStageResult.data = result;
                        createStageResult.status = status;
                        deferred.resolve(createStageResult);
                    }).error(function (result, status, headers, config) {
                        createStageResult.data = result;
                        createStageResult.status = status;
                        deferred.resolve(createStageResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////

    ////UpdateStageService
    .service('miUpdateStageService', [
    '$http',
    '$q', '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            updateStage: function (contextid, coStageid, lan, claimStatus) {

                var deferred = $q.defer();
                var updateStageResult = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.PUT,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/stage/companies/" + $rootScope.companyCode + "/fnol/" + contextid + "/stage",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        },
                        data: {
                            "contextID": contextid, "status": claimStatus, "coStageId": coStageid
                        }

                    }).success(function (result, status, headers, config) {
                        updateStageResult.data = result;
                        updateStageResult.status = status;
                        deferred.resolve(updateStageResult);
                    }).error(function (result, status, headers, config) {
                        updateStageResult.data = result;
                        updateStageResult.status = status;
                        deferred.resolve(updateStageResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////

    ////GetStageFromUriService
    .service('miGetStageFromUriService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            getNextStagefromUri: function (Uri, appversion, lan) {

                var deferred = $q.defer();
                var stageUriResult = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: Uri,
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'appVersion': appversion,
                            'source': ENV.SOURCE
                        }

                    }).success(function (result, status, headers, config) {
                        stageUriResult.data = result;
                        stageUriResult.status = status;
                        deferred.resolve(stageUriResult);
                    }).error(function (result, status, headers, config) {
                        stageUriResult.data = result;
                        stageUriResult.status = status;
                        deferred.resolve(stageUriResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////

    ////GetPartialStageService
    .service('miGetPartialStageService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            getNextPartialStage: function (companycode, appversion, contextid, lan) {

                var deferred = $q.defer();
                var partialStageResult = { data: '', status: '', headers: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/stage/companies/" + companycode + "/fnol/" + contextid + "/stage",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'appVersion': appversion,
                            'source': ENV.SOURCE
                        }

                    }).success(function (result, status, headers, config) {
                        partialStageResult.data = result;
                        partialStageResult.status = status;
                        partialStageResult.headers = headers;
                        deferred.resolve(partialStageResult);
                    }).error(function (result, status, headers, config) {
                        partialStageResult.data = result;
                        partialStageResult.status = status;
                        partialStageResult.headers = headers;
                        deferred.resolve(partialStageResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////


    ////DeletePolicyService
    .service('miDeletePolicyService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            deletePolicy: function (contextid, policystatus, lan) {

                var deferred = $q.defer();
                var deletePolicyResult = { data: '', status: '', headers: '' };

                try {
                    $http({
                        method: ENV.POST,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/stage/companies/" + $rootScope.companyCode + "/fnol/" + contextid,
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        },
                        data: policystatus

                    }).success(function (result, status, headers, config) {
                        deletePolicyResult.data = result;
                        deletePolicyResult.status = status;
                        deletePolicyResult.headers = headers;
                        deferred.resolve(deletePolicyResult);
                    }).error(function (result, status, headers, config) {
                        deletePolicyResult.data = result;
                        deletePolicyResult.status = status;
                        deletePolicyResult.headers = headers;
                        deferred.resolve(deletePolicyResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////


    ////PolicyVerificationService
    .service('miPolicyVerificationService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            verifyPolicy: function (policyverificationrequestdata, lan, contextId) {

                var deferred = $q.defer();
                var policyVerificationResult = { data: '', status: '', headers: '' };

                try {
                    $http({

                        method: ENV.POST,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/companies/" + $rootScope.companyCode + "/" + contextId + "/fnol",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        },
                        data: policyverificationrequestdata

                    }).success(function (result, status, headers, config) {
                        policyVerificationResult.data = result;
                        policyVerificationResult.status = status;
                        policyVerificationResult.headers = headers;
                        deferred.resolve(policyVerificationResult);
                    }).error(function (result, status, headers, config) {
                        policyVerificationResult.data = result;
                        policyVerificationResult.status = status;
                        policyVerificationResult.headers = headers;
                        deferred.resolve(policyVerificationResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////

    ////GetVehicalDetailsService
    .service('miGetVehicalDetailsService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            getVehicalDetails: function (contextid, lan) {

                var deferred = $q.defer();
                var vehicalDetailsResult = { data: '', status: '', headers: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/companies/" + $rootScope.companyCode + "/fnol/" + contextid + "/vehicle",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        }
                    }).success(function (result, status, headers, config) {
                        vehicalDetailsResult.data = result;
                        vehicalDetailsResult.status = status;
                        vehicalDetailsResult.headers = headers;
                        deferred.resolve(vehicalDetailsResult);
                    }).error(function (result, status, headers, config) {
                        vehicalDetailsResult.data = result;
                        vehicalDetailsResult.status = status;
                        vehicalDetailsResult.headers = headers;
                        deferred.resolve(vehicalDetailsResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////

    ////GetLanguageListService
    .service('miGetLanguageListService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            getLanguageList: function () {

                var deferred = $q.defer();
                var languageListResult = { data: '', status: '', headers: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/companies/" + $rootScope.companyCode + "/fnol/languages",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        }
                    }).success(function (result, status, headers, config) {
                        languageListResult.data = result;
                        languageListResult.status = status;
                        languageListResult.headers = headers;
                        deferred.resolve(languageListResult);
                    }).error(function (result, status, headers, config) {
                        languageListResult.data = result;
                        languageListResult.status = status;
                        languageListResult.headers = headers;
                        deferred.resolve(languageListResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////

    ////GetIdentificationFieldsService
    .service('miGetIdentificationFieldsService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            getIdentificationFields: function (companycode, lan) {

                var deferred = $q.defer();
                var identificationResult = { data: '', status: '', headers: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/companies/" + companycode + "/fnol/loginfields" + "?culture=" + lan,
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE

                        }
                    }).success(function (result, status, headers, config) {
                        identificationResult.data = result;
                        identificationResult.status = status;
                        identificationResult.headers = headers;
                        deferred.resolve(identificationResult);
                    }).error(function (result, status, headers, config) {
                        identificationResult.data = result;
                        identificationResult.status = status;
                        identificationResult.headers = headers;
                        deferred.resolve(identificationResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    ////

    ////IdentificationService
    .service('miIdentificationService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            identify: function (queryparam, lan) {

                var deferred = $q.defer();
                var identificationResult = { data: '', status: '', headers: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/companies/" + $rootScope.companyCode + "/fnol" + "?" + queryparam,

                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        }
                    }).success(function (result, status, headers, config) {
                        identificationResult.data = result;
                        identificationResult.status = status;
                        identificationResult.headers = headers;
                        deferred.resolve(identificationResult);
                    }).error(function (result, status, headers, config) {
                        identificationResult.data = result;
                        identificationResult.status = status;
                        identificationResult.headers = headers;
                        deferred.resolve(identificationResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
        ////

        ////MoiService
    .service('miMoiService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            getMoiDetails: function (moifilters, companycode, userid, lan) {

                var deferred = $q.defer();
                var moiResult = { data: '', status: '', headers: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + ENV.GETMOI_API_ENDPOINT + "CoCode/" + companycode + "/UserID/" + userid,
                        //url: "http://172.18.75.91:3030/api/MOI/" + "CoCode/" + companycode + "/UserID/" + userid,
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'Client': ENV.CLIENT_ID
                            //'Authorization': 'bearer ' + miuserSession.getTokens().accessToken
                        },
                        params: moifilters

                    }).success(function (result, status, headers, config) {
                        moiResult.data = result;
                        moiResult.status = status;
                        moiResult.headers = headers;
                        deferred.resolve(moiResult);
                    }).error(function (result, status, headers, config) {
                        moiResult.data = result;
                        moiResult.status = status;
                        moiResult.headers = headers;
                        deferred.resolve(moiResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
        ////

         //// ResourceLookUpService for service center
      .service('miServiceCenterResourceLookUpService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miAppProperties',
    'miuserSession',
    function (
        $http,
        $q, $rootScope,
        ENV, miAppProperties, miuserSession) {
        return {
            GetResources: function (searchCriteria, companycode) {
                var deferred = $q.defer();
                var resourcesResult = { data: '', status: '', headers: '' };
                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + ENV.RESOURCELOOKUP_SERVICECENTER_API_ENDPOINT + searchCriteria.GroupType + "/CoCode/" + companycode,
                        //url: "http://172.18.75.91:2020/api/search/groups/" + searchCriteria.GroupType + "/CoCode/" + companycode,
                        headers: {
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'Client': ENV.CLIENT_ID,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken
                        },
                        params: searchCriteria

                    }).success(function (result, status, headers, config) {
                        resourcesResult.data = result;
                        resourcesResult.status = status;
                        resourcesResult.headers = headers;
                        deferred.resolve(resourcesResult);
                    }).error(function (result, status, headers, config) {
                        resourcesResult.data = result;
                        resourcesResult.status = status;
                        resourcesResult.headers = headers;
                        deferred.resolve(resourcesResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;
            },
        }
    }])

        //// ResourceLookUpService for shop
    .service('miShopResourceLookUpService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miAppProperties',
    'miuserSession',
    function (
        $http,
        $q, $rootScope,
        ENV, miAppProperties, miuserSession) {
        return {
            GetResources: function (searchCriteria, companycode) {
                var deferred = $q.defer();
                var resourcesResult = { data: '', status: '', headers: '' };
                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + ENV.RESOURCELOOKUP_SHOP_API_ENDPOINT + searchCriteria.ResourceType + "/CoCode/" + companycode,
                        //url: "http://172.18.75.91:2020/api/search/resources/" + searchCriteria.ResourceType + "/CoCode/" + companycode,
                        headers: {
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'Client': ENV.CLIENT_ID,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken
                        },
                        params: searchCriteria

                    }).success(function (result, status, headers, config) {
                        resourcesResult.data = result;
                        resourcesResult.status = status;
                        resourcesResult.headers = headers;
                        deferred.resolve(resourcesResult);
                    }).error(function (result, status, headers, config) {
                        resourcesResult.data = result;
                        resourcesResult.status = status;
                        resourcesResult.headers = headers;
                        deferred.resolve(resourcesResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;
            },
        }
    }])
        //// CMS Integration Call
    .service('miCMSIntegrationService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function (
        $http,
        $q,
        $rootScope,
        ENV,
        miuserSession, miAppProperties) {
        return {
            CmsIntegration: function (contextID, lan) {
                var deferred = $q.defer();
                var cmsIntegrationResult = { data: '', status: '', headers: '' };
                try {
                    $http({
                        method: ENV.POST,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/assignment/companies/" + $rootScope.companyCode + "/fnol/" + contextID + "/assignment",
                        data: '',
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'Accept-Language': lan,
                            'source': ENV.SOURCE
                        }

                    }).success(function (result, status, headers, config) {
                        cmsIntegrationResult.data = result;
                        cmsIntegrationResult.status = status;
                        cmsIntegrationResult.headers = headers;
                        deferred.resolve(cmsIntegrationResult);
                    }).error(function (result, status, headers, config) {
                        cmsIntegrationResult.data = result;
                        cmsIntegrationResult.status = status;
                        cmsIntegrationResult.headers = headers;
                        deferred.resolve(cmsIntegrationResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;
            },
        }
    }])
        ////MoiService
            .service('miWorkAssignmentService', [
            '$http',
            '$q',
            '$rootScope',
            'ENV',
            'miuserSession',
            'miAppProperties',
            function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
                return {
                    getWorkAssignmentDetails: function (companycode, contextid, lan) {

                        var deferred = $q.defer();
                        var workAssignmentResult = { data: '', status: '', headers: '' };

                        try {
                            $http({
                                method: ENV.GET,
                                url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/assignment/companies/" + companycode + "/fnol/" + contextid + "/assignment",
                                headers: {
                                    'Content-Type': ENV.CONTENT_TYPE_JSON,
                                    'Accept-Language': lan,//,
                                    'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                                    'FnolSessionId': miAppProperties.getSessionID(),
                                    'source': ENV.SOURCE
                                }

                            }).success(function (result, status, headers, config) {

                                workAssignmentResult.data = result;
                                workAssignmentResult.status = status;
                                workAssignmentResult.headers = headers;
                                deferred.resolve(workAssignmentResult);
                            }).error(function (result, status, headers, config) {
                                workAssignmentResult.data = result;
                                workAssignmentResult.status = status;
                                workAssignmentResult.headers = headers;
                                deferred.resolve(workAssignmentResult);
                            });

                        } catch (e) {
                            deferred.reject(e);
                        }
                        return deferred.promise;

                    },

                };
            }])
                ////
                ////MoiDetailService
            .service('miMoiTypeDetailService', [
            '$http',
            '$q',
            '$rootScope',
            'ENV',
            'miuserSession',
            'miAppProperties',
            function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
                return {
                    getMoiTypeDetails: function (companycode, userid, moi, lan) {

                        var deferred = $q.defer();
                        var moiTypeResult = { data: '', status: '', headers: '' };

                        try {
                            $http({
                                method: ENV.GET,
                                url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + ENV.GETMOI_API_ENDPOINT + "CoCode/" + companycode + "/UserID/" + userid + "/MOI/" + moi,
                                //url: "http://172.18.75.91:3030/api/MOI/" + "CoCode/" + companycode + "/UserID/" + userid + "/MOI/" + moi,
                                headers: {
                                    'Content-Type': ENV.CONTENT_TYPE_JSON,
                                    'Accept-Language': lan,
                                    'FnolSessionId': miAppProperties.getSessionID(),
                                    'Client': ENV.CLIENT_ID
                                    //'Authorization': 'bearer ' + miuserSession.getTokens().accessToken
                                }
                            }).success(function (result, status, headers, config) {
                                moiTypeResult.data = result;
                                moiTypeResult.status = status;
                                moiTypeResult.headers = headers;
                                deferred.resolve(moiTypeResult);
                            }).error(function (result, status, headers, config) {
                                moiTypeResult.data = result;
                                moiTypeResult.status = status;
                                moiTypeResult.headers = headers;
                                deferred.resolve(moiTypeResult);
                            });

                        } catch (e) {
                            deferred.reject(e);
                        }
                        return deferred.promise;

                    },

                };
            }])
            //// Appraisal assignment update service.
        .service("miUpdateAppraisalAssignmentService", [
        '$http',
        '$q',
        '$rootScope',
        'ENV',
        'miuserSession',
        'miAppProperties',
        function (
            $http,
            $q, $rootScope,
            ENV,
            miuserSession,
            miAppProperties) {
            return {
                UpdateAssignment: function (assignmentDTO, contextId, companycode, assignmentDocId, lan) {
                    var deferred = $q.defer();
                    var updateAssignmentResult = { data: '', status: '', headers: '' };
                    try {
                        $http({
                            // method: ENV.POST,
                            method: ENV.PUT,
                            url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/assignment/companies/" + companycode + "/fnol/" + contextId + "/assignment/" + assignmentDocId + "/resource",
                            headers: {
                                'Content-Type': ENV.CONTENT_TYPE_JSON,
                                'Accept-Language': lan,
                                'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                                'FnolSessionId': miAppProperties.getSessionID(),
                                'source': ENV.SOURCE
                            },
                            data: assignmentDTO
                        }).success(function (result, status, headers, config) {
                            updateAssignmentResult.data = result;
                            updateAssignmentResult.status = status;
                            updateAssignmentResult.headers = headers;
                            deferred.resolve(updateAssignmentResult);
                        }).error(function (result, status, headers, config) {
                            updateAssignmentResult.data = result;
                            updateAssignmentResult.status = status;
                            updateAssignmentResult.headers = headers;
                            deferred.resolve(updateAssignmentResult);
                        });

                    }
                    catch (e) {
                        deferred.reject(e);
                    }
                    return deferred.promise;
                }
            }
        }])
// custom telephone servoce
    .service('miCarrierContactService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {

            getCarrierContact: function (companyCode, lan) {
                var deferred = $q.defer();
                var carrierContactServiceResult = { data: '', status: '', headers: '' };
                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/companies/" + companyCode + "/fnol/contactDetails?culture=" + lan,
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE
                        },

                    }).success(function (result, status, headers, config) {
                        carrierContactServiceResult.data = result;
                        carrierContactServiceResult.status = status;
                        carrierContactServiceResult.headers = headers;
                        deferred.resolve(carrierContactServiceResult);
                    }).error(function (result, status, headers, config) {
                        carrierContactServiceResult.data = result;
                        carrierContactServiceResult.status = status;
                        carrierContactServiceResult.headers = headers;
                        deferred.resolve(carrierContactServiceResult);
                    });
                }
                catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    //// Previous Stage Service.

    .service('miGetPreviousStageService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            getPreviousStage: function (contextid, companycode, appversion, stageorder, lan) {

                var deferred = $q.defer();
                var previousStageResult = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/stage/companies/" + companycode + "/stage/order/" + stageorder + "/" + contextid + "/previousStage",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'appVersion': appversion,
                            'source': ENV.SOURCE
                        }
                    }).success(function (result, status, headers, config) {
                        previousStageResult.data = result;
                        previousStageResult.status = status;
                        deferred.resolve(previousStageResult);
                    }).error(function (result, status, headers, config) {
                        previousStageResult.data = result;
                        previousStageResult.status = status;
                        deferred.resolve(previousStageResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])

    //Get Appoitments slot for Estimator/Adjustor

     .service('miAppointmentService', [
   '$http',
   '$q',
   '$rootScope',
   'ENV',
   'miuserSession',
   'miAppProperties',
   function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
       return {
           getAppointment: function (companyCode, lan, resourceCode, startDate, appointmentType, contextID, params) {
               var deferred = $q.defer();
               var AppointmentServiceResult = {
                   data: '', status: '', headers: ''
               };
               var queryParam = "";
               if (params && params.paramValue) {
                   switch (params.paramName) {
                       case ENV.END_TIME_PARAMS:
                           queryParam = ["?", ENV.END_TIME_PARAMS, "=", encodeURIComponent(params.paramValue)].join("");
                           break;
                       case ENV.SHOW_MORE_PARAMS:
                           queryParam = ["?", ENV.SHOW_MORE_PARAMS, "=", encodeURIComponent(params.paramValue)].join("");
                           break;
                       default:
                           queryParam = ""
                           break;
                   }
               }
               try {
                   $http({
                       method: ENV.GET,
                       //hardcoding the offset for workflow
                       url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + ENV.AppointmentService + companyCode + "/fnol/" + contextID + "/appointmentType/" + appointmentType + "/startDate/" + encodeURIComponent(startDate) + "/locationId/" + resourceCode + "/appointments" + queryParam,
                       headers: {
                           'Content-Type': ENV.CONTENT_TYPE_JSON,
                           'Accept-Language': lan,
                           'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                           'FnolSessionId': miAppProperties.getSessionID(),
                           'source': ENV.SOURCE
                       }

                   }).success(function (result, status, headers, config) {
                       AppointmentServiceResult.data = result;
                       AppointmentServiceResult.status = status;
                       AppointmentServiceResult.headers = headers;
                       deferred.resolve(AppointmentServiceResult);
                   }).error(function (result, status, headers, config) {
                       AppointmentServiceResult.data = result;
                       AppointmentServiceResult.status = status;
                       AppointmentServiceResult.headers = headers;
                       deferred.resolve(AppointmentServiceResult);
                   });
               }
               catch (e) {
                   deferred.reject(e);
               }
               return deferred.promise;

           }
       };
   }])

    // Get mi environment string
    .service('miGetMiEnvironment', [
 '$http',
 '$q',
 '$rootScope',
 function ($http, $q, $rootScope) {
     return {
         getMiEnvironment: function () {
             var deferred = $q.defer();
             try {
                 $http({
                     method: "GET",
                     url: "/test.sample",
                     headers: {
                         'Content-Type': 'application/JSON'
                     }
                 }).success(function (result) {
                     $rootScope.miEnvironment = JSON.parse(result);
                     deferred.resolve();
                 }).error(function (result) {
                     deferred.reject();
                     alert('Failed to load MiEnvironment configuration settings !');
                 });
             }
             catch (e) {
                 deferred.reject(e);
             }

             return deferred.promise;
         }
     };
 }])

    ////CopySystemCodeService
    .service('miCopyQuestionnaireSystemCodeService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            CopyQuestionnaireSystemCode: function (companycode, contextid, costageid, lan) {

                var deferred = $q.defer();
                var copyQuestionnaireSystemCodeResult = { data: '', status: '', headers: '' };

                try {
                    $http({
                        method: ENV.PUT,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/stage/companies/" + companycode + "/fnol/" + contextid + "/stage/" + costageid + "/fnolSystemQuestions",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'source': ENV.SOURCE

                        }

                    }).success(function (result, status, headers, config) {
                        copyQuestionnaireSystemCodeResult.data = result;
                        copyQuestionnaireSystemCodeResult.status = status;
                        copyQuestionnaireSystemCodeResult.headers = headers;
                        deferred.resolve(copyQuestionnaireSystemCodeResult);
                    }).error(function (result, status, headers, config) {
                        copyQuestionnaireSystemCodeResult.data = result;
                        copyQuestionnaireSystemCodeResult.status = status;
                        copyQuestionnaireSystemCodeResult.headers = headers;
                        deferred.resolve(copyQuestionnaireSystemCodeResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])
    //// Book Appointment service.
        .service("miBookAppointmentService", [
        '$http',
        '$q',
        '$rootScope',
        'ENV',
        'miuserSession',
        'miAppProperties',
        function (
            $http,
            $q, $rootScope,
            ENV,
            miuserSession,
            miAppProperties) {
            return {
                BookAppointment: function (appointmentDTO, contextId, companyCode, assignmentDocId, lan) {
                    var deferred = $q.defer();
                    var bookAppointmentResult = { data: '', status: '', headers: '' };
                    try {
                        $http({
                            method: ENV.PUT,
                            url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/assignment/companies/" + companyCode + "/fnol/" + contextId + "/assignment/" + assignmentDocId + "/appointments",
                            headers: {
                                'Content-Type': ENV.CONTENT_TYPE_JSON,
                                'Accept-Language': lan,
                                'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                                'FnolSessionId': miAppProperties.getSessionID(),
                                'source': ENV.SOURCE
                            },
                            data: appointmentDTO
                        }).success(function (result, status, headers, config) {
                            bookAppointmentResult.data = result;
                            bookAppointmentResult.status = status;
                            bookAppointmentResult.headers = headers;
                            deferred.resolve(bookAppointmentResult);
                        }).error(function (result, status, headers, config) {
                            bookAppointmentResult.data = result;
                            bookAppointmentResult.status = status;
                            bookAppointmentResult.headers = headers;
                            deferred.resolve(bookAppointmentResult);
                        });

                    }
                    catch (e) {
                        deferred.reject(e);
                    }
                    return deferred.promise;
                }
            }
        }])
     ////EditQuestionnaireSummaryService
    .service('miEditQuestionnaireSummaryService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    'miuserSession',
    'miAppProperties',
    function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
        return {
            getFirstQuestionnaire: function (companycode, contextid, appversion, lan) {

                var deferred = $q.defer();
                var getFirstQuestionnaireSummaryResult = { data: '', status: '', headers: '' };

                try {
                    $http({
                        method: ENV.GET,
                        url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + "/v1/apd/fnol/stage/companies/" + companycode + "/fnol/" + contextid + "/editSummary/stage",
                        headers: {
                            'Content-Type': ENV.CONTENT_TYPE_JSON,
                            'Accept-Language': lan,
                            'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                            'FnolSessionId': miAppProperties.getSessionID(),
                            'appVersion': appversion,
                            'source': ENV.SOURCE

                        }

                    }).success(function (result, status, headers, config) {
                        getFirstQuestionnaireSummaryResult.data = result;
                        getFirstQuestionnaireSummaryResult.status = status;
                        getFirstQuestionnaireSummaryResult.headers = headers;
                        deferred.resolve(getFirstQuestionnaireSummaryResult);
                    }).error(function (result, status, headers, config) {
                        getFirstQuestionnaireSummaryResult.data = result;
                        getFirstQuestionnaireSummaryResult.status = status;
                        getFirstQuestionnaireSummaryResult.headers = headers;
                        deferred.resolve(getFirstQuestionnaireSummaryResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },

        };
    }])

    /// Get Complex Field Data
    .service('miGetComplexDataService', [
        '$http',
        '$q',
        '$rootScope',
        'ENV',
        'miuserSession',
        'miAppProperties',
        function ($http, $q, $rootScope, ENV, miuserSession, miAppProperties) {
            return {
                getComplexFieldData: function (url) {

                    var deferred = $q.defer();
                    var fieldListResult = { data: '', status: '', headers: '' };

                    try {
                        $http({
                            method: ENV.GET,
                            url: $rootScope.miEnvironment.EXTERNAL_SERVICES_HTTP_URL + url,
                            headers: {
                                'Content-Type': ENV.CONTENT_TYPE_JSON,
                                'Authorization': 'bearer ' + miuserSession.getTokens().accessToken,
                                'FnolSessionId': miAppProperties.getSessionID()
                            }
                        }).success(function (result, status, headers, config) {
                            fieldListResult.data = result;
                            fieldListResult.status = status;
                            fieldListResult.headers = headers;
                            deferred.resolve(fieldListResult);
                        }).error(function (result, status, headers, config) {
                            fieldListResult.data = result;
                            fieldListResult.status = status;
                            fieldListResult.headers = headers;
                            deferred.resolve(fieldListResult);
                        });

                    } catch (e) {
                        deferred.reject(e);
                    }
                    return deferred.promise;

                },

            };
        }]);

}(angular));