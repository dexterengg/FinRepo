﻿describe('MFNOL AngularJS miServices (MFnol Servcies)', function () {
    var $httpBackend, $rootScope, $http, $state, miService, miLocale, miComponentRoute, dataShare, $scope, miStageDecision, miStageQuestionnaireRouteDetails,nextstagedata;
    var constant = {};
    // Set up the module
    beforeEach(module('mainApp'));
    angular.module('mock.servicedata', [])
		.factory('constantShare', function ($q) {
            // set part 
		    constant.settheme = function (theme) {
		    };
		    constant.setorgcode = function (orgcode) {
		    };
		    constant.setanimationclass = function (animationclass) {
		    };
		    constant.setlanguage = function (language) {
		    };
		    constant.setDocID = function (DocID) {
		    };
		    constant.setredirectionToken = function (redirectionToken) {
		    };
		    constant.setsessionexpired = function (sessionexpired) {
		    };
		    constant.setcontextid = function (contextid) {
		    };
		    constant.setlanguagelist = function (languagelist) {
		    };
		    constant.setIdentificationfields = function (Identificationfields) {
		    };
		    constant.setstatuscode = function (statuscode) {
		    };
		    constant.setislandingpage = function (islandingpage) {
		    };
		    constant.setflagStage = function (flagStage) {
		    };
		    constant.setstageName = function (stageName) {
		    };
		    constant.setquestionnaireID = function (questionnaireID) {
		    };
		    constant.setstageUiOrder = function (stageUiOrder) {
		    };
		    constant.setStageOrder = function (StageOrder) {
		    };
		    constant.setpageName = function (pageName) {
		    };
		    constant.setstageType = function (stageType) {
		    };
		    constant.setcoStageId = function (coStageId) {
		    };
		    constant.setstageDesc = function (stageDesc) {
		    };
		    constant.settotalNumOfStages = function (totalNumOfStages) {
		    };
		    constant.setsystemDocId = function (systemDocId) {
		    };
		    
            // get part
		    constant.gettheme = function () {
		        return  expectedDetail.theme;// "M2";
		    };
		    constant.getorgcode = function () {
		        return expectedDetail.orgcode;
		    };
		    constant.getanimationclass = function () {
		        return expectedDetail.animationclass;
		    };
		    constant.getlanguage = function () {
		        return expectedDetail.language;
		    };
		    constant.getDocID = function () {
		        return expectedDetail.DocID;
		    };
		    constant.getcontextid = function () {
		        return expectedDetail.contextid;
		    };
		    constant.getflagStage = function () {
		        return expectedDetail.flagStage;
		    };
		    constant.getstageName = function () {
		        return expectedDetail.stageName;
		    };
		    constant.getquestionnaireID = function () {
		        return expectedDetail.questionnaireID;
		    };
		    constant.getstageUiOrder = function () {
		        return expectedDetail.stageUiOrder;
		    };
		    constant.getStageOrder = function () {
		        return expectedDetail.StageOrder;
		    };
		    constant.getpageName = function () {
		        return expectedDetail.pageName;
		    };
		    constant.getstageType = function () {
		        return expectedDetail.stageType;
		    };
		    constant.getcoStageId = function () {
		        return expectedDetail.coStageId;
		    };
		    constant.getstageDesc = function () {
		        return expectedDetail.stageDesc;
		    };
		    constant.gettotalNumOfStages = function () {
		        return expectedDetail.totalNumOfStages;
		    };
		    constant.getsystemDocId = function () {
		        return expectedDetail.systemDocId;
		    };
		    constant.getislandingpage = function () {
		        return expectedDetail.islandingpage;
		    };
		    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
		    constant.fetch = function () {
		        var mockUser = "M2";
		        return $q.when(mockUser);
		    };

		    // other stubbed methods

		    return constant;
		})
        describe('miStageDecision service', function () {
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $httpBackend = $injector.get('$httpBackend');
                $q = $injector.get('$q');
                miService = $injector.get('miService');
                miLocale = $injector.get('miLocale');
                miStageDecision = $injector.get('miStageDecision');
            });
        });
        
        it('should load miStageDecision services before calling any next function', function () {
            expect(miStageDecision.getroute).toBeDefined();
        });
        it('should call save question from getroute function', function () {
           
            spyOn(miService, 'saveQuestion');
            $httpBackend.expectPOST((miService.saveQuestion("M2", "0", "100000007258", "100000119177", "", "en-US"))).respond(200);
            expect(miService.saveQuestion).toHaveBeenCalled();
            miStageDecision.getroute('100000007759', 'color of car is red');
        });
        it("context ID and get flag Stage should not be blank", function () {
            expect(constant.getcontextid).not.toBeDefined(null);
            expect(constant.getflagStage).not.toBeDefined(null);
        });
        it('should call Create Question from getroute function', function () {
            spyOn(miService, 'createStage');
            $httpBackend.whenGET((miService.createStage("0", "0", "100000007258", "100000119177", "en-US"))).respond(200);
            expect(miService.createStage).toHaveBeenCalled();
            miStageDecision.getroute('100000007759', 'color of car is red');
        });
        it('should call get Question from getroute function', function () {
            spyOn(miService, 'getQuestion');
            $httpBackend.whenGET((miService.getQuestion("M2", "0", "100000007258", "100000119177", "en-US"))).respond(200);
            expect(miService.getQuestion).toHaveBeenCalled();
            miStageDecision.getroute('100000007759', 'color of car is red');
        });
        it('should demonstrate using when and expect (200 status)', inject(function ($http) {
            var $scope = {};
            // fake service url for getQuestion
            $http.get('ENV.GetQuestionApiEndpoint + "companies/" + companies + "/questionnaires/" + questionnaires + "/QustnnrEvalDocId/" + QustnnrEvalDocId + "/next-question"')
              .success(function (data, status, headers, config) {
                  $scope.valid = true;
                  $scope.response = data;
              }).error(function (data, status, headers, config) {
                  $scope.valid = false;
              });
            $httpBackend
              .when('GET', 'ENV.GetQuestionApiEndpoint + "companies/" + companies + "/questionnaires/" + questionnaires + "/QustnnrEvalDocId/" + QustnnrEvalDocId + "/next-question"')
              .respond(200, { newdata: 'data' });
            $httpBackend
              .expect('GET', 'ENV.GetQuestionApiEndpoint + "companies/" + companies + "/questionnaires/" + questionnaires + "/QustnnrEvalDocId/" + QustnnrEvalDocId + "/next-question"');
            expect($httpBackend.flush).not.toThrow();
            expect($scope.valid).toBe(true);
            expect($scope.response).toEqual({ newdata: 'data' });
        }));
        it('update Stage should be called from getroute function', function () {
            spyOn(miService, 'updateStage');
            $httpBackend.expectPOST((miService.updateStage("", 381, "en-US"))).respond(200);
            expect(miService.updateStage).toHaveBeenCalled();
            miStageDecision.getroute('100000007759', 'color of car is red');
        });
        it('should call Get next Stage from getroute function', function () {
            spyOn(miService, 'getNextStage');
            $httpBackend.expectPOST((miService.getNextStage("M2","MFNOL",1,  "en-US"))).respond(200);
            expect(miService.getNextStage).toHaveBeenCalled();
            miStageDecision.getroute('100000007759', 'color of car is red');
        });
        it('verifying nextstagedata value from getroute function', function () {
            expect($scope.nextstagedata).not.toBe(null);
            $scope.$digest();
            miStageDecision.getroute('100000007759', 'color of car is red');
        });
        it('isLandingPage sholud return true from getroute function', function () {
            expect($scope.islandingpage).not.toBe(null);
            $scope.$digest();
            miStageDecision.getroute('100000007759', 'color of car is red');
       });
    });
    describe('miStageQuestionnaireRouteDetails service', function () {
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $httpBackend = $injector.get('$httpBackend');
                $q = $injector.get('$q');
                miStageQuestionnaireRouteDetails = $injector.get('miStageQuestionnaireRouteDetails');
                miLocale = $injector.get('miLocale');
            });
        });
        it('verifying getDocID value from getroute function', function () {
            expect($scope.getDocID).not.toBe(null);
            $scope.$digest();
            miStageDecision.getroute('100000007759', 'color of car is red');
        });
        it('should call getEvaluationDocId method  from getroute function', function () {
            spyOn(miService, 'getEvaluationDocId');
            $httpBackend.expectPOST((miService.getEvaluationDocId("M2", "100000007258", "have policy date expired", "en-US"))).respond(200);
            expect(miService.getEvaluationDocId).toHaveBeenCalled();
            miStageDecision.getroute('100000007759', 'color of car is red');
        });
        it('should call get Question from getroute function', function () {
            spyOn(miService, 'getQuestion');
            $httpBackend.whenGET((miService.getQuestion("M2", "0", "100000007258", "100000119177", "en-US"))).respond(200);
            expect(miService.getQuestion).toHaveBeenCalled();
            miStageDecision.getroute('100000007759', 'color of car is red');
        });
    });
});