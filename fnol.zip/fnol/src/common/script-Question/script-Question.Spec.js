﻿describe('MFNOL AngularJS Controller (Script Question Controller)', function () {

    var $httpBackend, $scope, $controller, stageQuestionaireRouteDetails;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        questionDetailsList: [],
        totalNumOfStages: 6,
        stageUiOrder: 2,
        statuscode: "statuscode",
        currentQuestion: { "qustnnreId": 0, "companyCd": null, "qustnnreQustnId": 100000122487, "editable": true, "qustnPlainText": null, "qustnFormattedText": "", "qustnText": "In this section we will be covering the following", "answrControlType": "SCRIPT_QUESTION", "answerList": [{ "qustnnreQustnId": 0, "answerItemID": 0, "lowRangeValue": 0, "highRangeValue": 0, "answerDisplayText": null, "answerDisplayOrder": 0, "answered": false }] }
        , backbuttoncss: "clickable_Back_Btn",
    };
    // Mocked Service
    angular.module('mock.scriptData', [])
	.factory('miAppProperties', function ($q) {
	    var constant = {};
	    constant.gettheme = function () {
	        return expectedDetail.theme;
	    };
	    constant.getanimationclass = function () {
	        return expectedDetail.animationclass;
	    };
	    constant.gettotalNumOfStages = function () {
	        return expectedDetail.totalNumOfStages;
	    };
	    constant.getstageUiOrder = function () {
	        return expectedDetail.stageUiOrder;
	    };
	    constant.getCurrentQuestion = function () {
	        return expectedDetail.currentQuestion;
	    };
	    constant.setstatuscode = function (statuscode) {
	        expectedDetail.statuscode = statuscode;
	    };
	    constant.getstatuscode = function () {
	        return expectedDetail.statuscode;
	    };
	    constant.insertQuestionDetails = function (questionnaireQuestionId, answerText) {
	        var questionDetails = {
	            "qustnnrQustnId": questionnaireQuestionId,
	            "answer": answerText
	        };
	        expectedDetail.questionDetailsList.push(questionDetails);
	    };
	    constant.getQuestionDetails = function () {
	        return expectedDetail.questionDetailsList;
	    };
	    constant.getBackButtonCss = function () {
	        return expectedDetail.backbuttoncss;
	    };
	    constant.setVersionMismatchStatus = function () { }
	    constant.getVersionMismatchStatus = function () {
	        return false;
	    }
	    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
	    constant.fetch = function () {
	        var mockUser = "M2";
	        return $q.when(mockUser);
	    };
	    // other stubbed methods
	    return constant;
	});
    
    describe('ScriptQuestion_Controller_Test_for_currentTheme', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.scriptData'));

        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('ScriptQuestionCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));
        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });

        it('ensure default page class name', function () {
            expect(scope.pageClass).toBe(expectedDetail.animationclass);
        });
       it('ensure back button css is clickable', function () {
            expect(scope.Back_Btn_Class).toBe(expectedDetail.backbuttoncss);
        });
        it('ensure questionnaire version is false', function () {
            expect(scope.isVersionMismatch).toBe(false);
        });

    });
    describe('Script Question Controller', function () {
        beforeEach(module('mi.mfnol.web'));
        var miAppFactory;
        beforeEach(module('mock.scriptData'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miAppFactory = $injector.get('miAppFactory');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });
        //spec to track that spy created on miUiStagesProgressbar.changeUiStage was called
        it('should call miUiStagesProgressbar changeUiStage', inject(function () {
            $controller('ScriptQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miUiStagesProgressbar: miUiStagesProgressbar });
            expect(miUiStagesProgressbar.changeUiStage).toHaveBeenCalled();
        }));

        it('should call sce trustAsHtml', inject(function () {
            $controller('ScriptQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce });
            spyOn($sce, 'trustAsHtml').and.callThrough();
            $scope.getHtml('<h1>Test</h1>');
            expect($sce.trustAsHtml).toHaveBeenCalled();
        }));

        it('should call miAppFactory getRoute with success', inject(function () {
            $controller('ScriptQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            $state.current.name = "shell.landing-Question.datetime-Question";
            spyOn(miAppFactory, 'getRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "DATETIME_QUESTION" });
            });

            $scope.next();
            expect($scope.questionText).not.toBe(null);

        }));

        it('should call miAppFactory getRoute with error', inject(function () {
            $controller('ScriptQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });

            spyOn(miAppFactory, 'getRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });

            $scope.next();
            expect(miAppFactory.getRoute).toHaveBeenCalled();

        }));

    });

    describe('ScriptType Question Controller_For_Back_Functionality', function () {
        beforeEach(module('mi.mfnol.web'));
        var miAppFactory;
        beforeEach(module('mock.scriptData'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miAppFactory = $injector.get('miAppFactory');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });
        //spec to track that spy created on miUiStagesProgressbar.changeUiStage was called
        it('should call miAppFactory getPreviousRoute with choiceselection questionType', inject(function () {
            $controller('ScriptQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            $state.current.name = "shell.landing-Question.choiceselection-Question";
            spyOn(miAppFactory, 'getPreviousRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "CHOICE_SELECTION" });
            });

            $scope.back();
            expect(miAppFactory.getPreviousRoute).toHaveBeenCalled();


        }));
        it('should call miAppFactory getPreviousRoute with range questionType', inject(function () {
            $controller('ScriptQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            $state.current.name = "shell.landing-Question.choiceselection-Question";
            spyOn(miAppFactory, 'getPreviousRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "RANGE_VALUE" });
            });
            spyOn($state, 'go');
            $scope.back();
            expect(miAppFactory.getPreviousRoute).toHaveBeenCalled();


        }));
        it('should call miAppFactory getPreviousRoute return backbutton CSS', inject(function () {
            $controller('ScriptQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            spyOn(miAppFactory, 'getPreviousRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn($state, 'go');
            $scope.back();
            expect(miAppFactory.getPreviousRoute).toHaveBeenCalled();
        }));
    });

});