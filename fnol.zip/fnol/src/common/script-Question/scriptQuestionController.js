﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('ScriptQuestionCtrl',
    function (
        $scope,
        $state,
        $sce,
        miAppProperties,
        cfpLoadingBar,
        ENV,
        miComponentRoute,
        miQues,
        miUiStagesProgressbar,
        miAppFactory,
        $interval) {
        $scope.Back_Btn_Class = "clickable_Back_Btn";
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        var currentQuestion = miAppProperties.getCurrentQuestion();
        $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();
        $scope.getHtml = function (html) {
            return $sce.trustAsHtml(html);
        };
        $scope.next = function () {
            ga('send', 'event', 'Script question', 'Button click', 'Next');
            cfpLoadingBar.start();

            //set isVersionMismatch to false so that version mismatch message will not show on next question
            miAppProperties.setVersionMismatchStatus(false);

            currentQuestion.answerList[0].answerDisplayText = ENV.SCRIPT_DEFAULT_VALUE;

            //Calling function to insert question details
            miAppProperties.insertQuestionDetails(currentQuestion.qustnnreQustnId, currentQuestion.answerList[0].answerDisplayText);

            miAppFactory.getRoute()
            .then(function (routeresponse) {
                if (routeresponse.route) {
                    if ($state.current.name === miComponentRoute.getComponentroute(routeresponse.route)) {
                        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
                        
                        //Code to check whether version mismatch is true or not
                        //It is the scenario if the script type is first question and user has changed questionnaire from WCAdmin
                        //In this case question will show with error message
                        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();

                        cfpLoadingBar.complete();
                        //$scope.Back_Btn_Class = "clickable_Back_Btn";
                        $scope.samepagecss = "page-inner-slideOutUp";
                        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
                        var intervalCanceller = $interval(function () {
                            $scope.samepagecss = "";
                            currentQuestion = miAppProperties.getCurrentQuestion();
                            $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
                            $interval.cancel(intervalCanceller);
                        }, 1000);
                    }
                    else {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(routeresponse.route));
                    }
                }
            });
        }

        $scope.back = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Back');
            cfpLoadingBar.start();

            //set isVersionMismatch to false so that version mismatch message will not show on next question
            miAppProperties.setVersionMismatchStatus(false);

            miAppFactory.getPreviousRoute(currentQuestion.qustnnreQustnId)
            .then(function (routeresponse) {
                if (routeresponse.route) {
                    if ($state.current.name === miComponentRoute.getComponentroute(routeresponse.route)) {
                        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

                        //Code to check whether version mismatch is true or not
                        //It is the scenario if the script type is first question and user has changed questionnaire from WCAdmin
                        //In this case question will show with error message
                        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();

                        cfpLoadingBar.complete();
                        $scope.samepagecss = "page-inner-slideOutUp";
                        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
                        var intervalCanceller = $interval(function () {
                            $scope.samepagecss = "";
                            currentQuestion = miAppProperties.getCurrentQuestion();
                            $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
                            $interval.cancel(intervalCanceller);
                        }, 1000);
                    }
                    else {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(routeresponse.route));
                    }
                }

                else {
                    cfpLoadingBar.complete();
                    $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
                }
            });

        }
    });
}(angular));

