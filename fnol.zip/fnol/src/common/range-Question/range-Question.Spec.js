﻿describe('MFNOL AngularJS Controller (Range Question Question Controller)', function () {

    var $httpBackend, $scope, $controller, stageQuestionaireRouteDetails;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        UserIdentificationdata: [],
        questionDetailsList: [],
        totalNumOfStages: 6,
        stageUiOrder: 2,
        statuscode: "statuscode",
        stageName: "IDENTIFICATION",
        currentQuestion: { 'qustnnreId': 0, 'companyCd': null, 'qustnnreQustnId': 100000121517, 'editable': true, 'qustnPlainText': null, 'qustnFormattedText': 'PHNwYW4gc3R5bGU9ImZvbnQtc2l6ZTogMTZweDsiPldoYXQgd2FzIHlvdXIgcm9sZSBpbiB0aGUgaW5jaWRlbnQ/PC9zcGFuPg==', 'qustnText': 'What was your role in the incident?', 'answrControlType': 'CHOICE_SELECTION', 'answerList': [{ 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130108, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Registered Owner and Driver', 'answerDisplayOrder': 1, 'answered': false }, { 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130109, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Registered Owner', 'answerDisplayOrder': 2, 'answered': false }, { 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130110, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Driver', 'answerDisplayOrder': 3, 'answered': false }, { 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130111, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Neither', 'answerDisplayOrder': 4, 'answered': false }] },
        backbuttoncss: "clickable_Back_Btn",
        IsStageStatusChanged: true,
        contextid: false,
        coStageId: 123,
        docID: 0
    };
    // Mocked Service
    angular.module('mock.RangeQuestionData', [])
	.factory('miAppProperties', function ($q) {
	    var constant = {};
	    constant.gettheme = function () {
	        return expectedDetail.theme;
	    };
	    constant.getorgcode = function () {
	        return expectedDetail.orgcode;
	    };
	    constant.getanimationclass = function () {
	        return expectedDetail.animationclass;
	    };
	    constant.gettotalNumOfStages = function () {
	        return expectedDetail.totalNumOfStages;
	    };
	    constant.getstageUiOrder = function () {
	        return expectedDetail.stageUiOrder;
	    };
	    constant.getCurrentQuestion = function () {
	        return expectedDetail.currentQuestion;
	    };
	    constant.setstatuscode = function (statuscode) {
	        expectedDetail.statuscode = statuscode;
	    };
	    constant.getstageName = function () {
	        return expectedDetail.stageName;
	    };
	    constant.insertUserIdentificationdata = function (Id, Question, Answer) {
	        var QuesAnsDetail = { "Id": Id, "Question": Question, "Answer": Answer };
	        expectedDetail.UserIdentificationdata.push(QuesAnsDetail);
	    };
	    constant.insertQuestionDetails = function (questionnaireQuestionId, answerText) {
	        var questionDetails = {
	            "qustnnrQustnId": questionnaireQuestionId,
	            "answer": answerText
	        };
	        expectedDetail.questionDetailsList.push(questionDetails);
	    };
	    constant.getBackButtonCss = function () {
	        return expectedDetail.backbuttoncss;
	    };
	    constant.IsStageStatusChanged = function () {
	        return expectedDetail.IsStageStatusChanged
	    };
	    constant.setStageStatus = function (stageStatus) {
	        expectedDetail.stageStatus = stageStatus;
	    }
	    constant.getStageStatus = function () {
	        return expectedDetail.stageStatus;
	    };
	    constant.getcontextid = function () {
	        return expectedDetail.contextid;
	    };
	    constant.getcoStageId = function () {
	        return expectedDetail.coStageId;
	    };
	    constant.getDocID = function () {
	        return expectedDetail.docID;
	    };
	    constant.setVersionMismatchStatus = function () { }
	    constant.getVersionMismatchStatus = function () {
	        return false;
	    }
	    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
	    constant.fetch = function () {
	        var mockUser = "M2";
	        return $q.when(mockUser);
	    };
	    // other stubbed methods
	    return constant;
	});
   
    describe('RangeQuestionData_Controller_Test_for_currentTheme', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.RangeQuestionData'));

        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('RangeQuestionCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));
        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });

        it('ensure default page class name', function () {
            expect(scope.pageClass).toBe(expectedDetail.animationclass);
        });
        it('ensure back button css is clickable', function () {
            expect(scope.Back_Btn_Class).toBe(expectedDetail.backbuttoncss);
        });
        it('ensure questionnaire version is false', function () {
            expect(scope.isVersionMismatch).toBe(false);
        });
    });
    describe('Range Question Controller_Test_For_Next()_function', function () {
        beforeEach(module('mi.mfnol.web'));
        //var miAppFactory;
        beforeEach(module('mock.RangeQuestionData'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miAppFactory = $injector.get('miAppFactory');
                miStageFactory = $injector.get('miStageFactory');
                miAppProperties = $injector.get('miAppProperties');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');

            });
        });
        //spec to track that spy created on $sce.trustAsHtml and miStageFactory.updateStage was called

        it('should call sce trustAsHtml', inject(function () {
            $controller('RangeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce });
            spyOn($sce, 'trustAsHtml').and.callThrough();
            $scope.getHtml('<h1>Test</h1>');
            expect($sce.trustAsHtml).toHaveBeenCalled();
        }));

        it('should call miStageFactory updateStage with error page', inject(function () {
            $controller('RangeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.next(expectedDetail.currentQuestion.answerList[0], true);
            expect(miStageFactory.updateStage).toHaveBeenCalled();

        }));
        it('should call miStageFactory updateStage with success', inject(function () {
            $controller('RangeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miAppFactory, 'getRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.next(expectedDetail.currentQuestion.answerList[0], true);
            expect(miAppProperties.getStageStatus()).toBe("REOPEN");

        }));
        it('should call miStageFactory updateStage and miAppFactory getRoute with success', inject(function () {
            $controller('RangeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            $state.current.name = "shell.landing-Question.datetime-Question";
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            spyOn(miAppFactory, 'getRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "DATETIME_QUESTION" });
            });
            spyOn($state, 'go');
            $scope.next(expectedDetail.currentQuestion.answerList[0], true);
            expect(miUiStagesProgressbar.changeUiStage).toHaveBeenCalled();


        }));
    });
    describe('Range Question Controller_Test_For_Next()_function', function () {
        beforeEach(module('mi.mfnol.web'));
        currentQuestion1 = { 'qustnnreId': 0, 'companyCd': null, 'qustnnreQustnId': 100000121517, 'editable': true, 'qustnPlainText': null, 'qustnFormattedText': 'PHNwYW4gc3R5bGU9ImZvbnQtc2l6ZTogMTZweDsiPldoYXQgd2FzIHlvdXIgcm9sZSBpbiB0aGUgaW5jaWRlbnQ/PC9zcGFuPg==', 'qustnText': 'What was your role in the incident?', 'answrControlType': 'CHOICE_SELECTION', 'answerList': [{ 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130108, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Registered Owner and Driver', 'answerDisplayOrder': 1, 'answered': false }, { 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130109, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Registered Owner', 'answerDisplayOrder': 2, 'answered': false }, { 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130110, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Driver', 'answerDisplayOrder': 3, 'answered': false }, { 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130111, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Neither', 'answerDisplayOrder': 4, 'answered': false }] };
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miAppFactory = $injector.get('miAppFactory');
                miStageFactory = $injector.get('miStageFactory');
                miAppProperties = $injector.get('miAppProperties');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
            });
        });
        //spec to track that spy created on miAppFactory.getRoute was called
        it('should call getRoute function when Stage Status is complete', inject(function (miAppProperties) {
            miAppProperties.setCurrentQuestion(currentQuestion1);
            miAppProperties.IsStageStatusChanged(false);
            $controller('RangeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            spyOn(miAppFactory, 'getRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.next(expectedDetail.currentQuestion.answerList[0], true);
            expect(miAppFactory.getRoute).toHaveBeenCalled();

        }));
    });
    describe('Range Question Controller_For_Back_Functionality', function () {
        beforeEach(module('mi.mfnol.web'));
        var miAppFactory;
        beforeEach(module('mock.RangeQuestionData'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miAppFactory = $injector.get('miAppFactory');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });
        //spec to track that spy created on miUiStagesProgressbar.changeUiStage was called
        it('should call miAppFactory getPreviousRoute with choiceselection questionType', inject(function () {
            $controller('RangeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            $state.current.name = "shell.landing-Question.choiceselection-Question";
            spyOn(miAppFactory, 'getPreviousRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "CHOICE_SELECTION" });
            });
            $scope.back();
            expect(miAppFactory.getPreviousRoute).toHaveBeenCalled();
        }));
        it('should call miAppFactory getPreviousRoute with range questionType', inject(function () {
            $controller('RangeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            $state.current.name = "shell.landing-Question.choiceselection-Question";
            spyOn(miAppFactory, 'getPreviousRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "RANGE_VALUE" });
            });
            spyOn($state, 'go');
            $scope.back();
            expect(miAppFactory.getPreviousRoute).toHaveBeenCalled();
        }));
        it('should call miAppFactory getPreviousRoute return backbutton CSS', inject(function () {
            $controller('RangeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            spyOn(miAppFactory, 'getPreviousRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn($state, 'go');
            $scope.back();
            expect(miAppFactory.getPreviousRoute).toHaveBeenCalled();
        }));
    });
});