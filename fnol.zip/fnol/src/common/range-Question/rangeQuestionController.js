﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('RangeQuestionCtrl',
    function (
        $scope,
        $http,
        $state,
        $sce,
        miAppProperties,
        cfpLoadingBar,
        ENV,
        miComponentRoute,
        miQues,
        miUiStagesProgressbar,
        miAppFactory,
        miLocale,
        miStageFactory,
        $interval) {
        //$scope.Back_Btn_Class = "clickable_Back_Btn";
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        var currentQuestion = miAppProperties.getCurrentQuestion();
        $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
        $scope.isEditable = currentQuestion.editable;
        $scope.answerText = currentQuestion.answerList;
        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();
        $scope.getHtml = function (html) {
            return $sce.trustAsHtml(html);
        };
        $scope.next = function (ans, stat) {
            if (stat) {
                cfpLoadingBar.start();
                
                //set isVersionMismatch to false so that version mismatch message will not show on next question
                miAppProperties.setVersionMismatchStatus(false);

                ga('send', 'event', 'Answer', 'Range question', ans.lowRangeValue + "-" + ans.highRangeValue);

                //Calling function to insert question details
                miAppProperties.insertQuestionDetails(currentQuestion.qustnnreQustnId, "" + ans.lowRangeValue + "-" + ans.highRangeValue + "");

                //Calling function to check whether we user has given same answer or not
                var isStatusChanged = miAppProperties.IsStageStatusChanged(currentQuestion, ans);
                
                //If status changed then we need to first update the stage with state "REOPEN"
                //Otherwise continue with existing call
                if (isStatusChanged) {
                    miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_REOPEN)
                       .then(function (updatestageresponse) {
                           if (updatestageresponse.route) {
                               cfpLoadingBar.complete();
                               $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                            }
                           else {
                                miAppProperties.setStageStatus(ENV.CLAIMSTATUS_REOPEN);
                                $scope.getRoute();
                            }
                        })
                }
                else {
                    $scope.getRoute();
                }

            }
        }

        $scope.getRoute = function () {
            miAppFactory.getRoute()
            .then(function (routeresponse) {
                if (routeresponse.route) {
                    if ($state.current.name === miComponentRoute.getComponentroute(routeresponse.route)) {
                        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

                        //Code to check whether version mismatch is true or not
                        //It is the scenario if the script type is first question and user has changed questionnaire from WCAdmin
                        //In this case question will show with error message
                        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();

                        cfpLoadingBar.complete();
                        $scope.samepagecss = "page-inner-slideOutUp";
                        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
                        var intervalCanceller = $interval(function () {
                            $scope.samepagecss = "";
                            currentQuestion = miAppProperties.getCurrentQuestion();
                            $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
                            $scope.answerText = currentQuestion.answerList;
                            $scope.isEditable = currentQuestion.editable;
                            $interval.cancel(intervalCanceller);
                        }, 1000);
                    }
                    else {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(routeresponse.route));
                    }
                }
            });
        }


        $scope.back = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Back');
            cfpLoadingBar.start();

            //set isVersionMismatch to false so that version mismatch message will not show on next question
            miAppProperties.setVersionMismatchStatus(false);

            miAppFactory.getPreviousRoute(currentQuestion.qustnnreQustnId)
            .then(function (routeresponse) {
                if (routeresponse.route) {
                    if ($state.current.name === miComponentRoute.getComponentroute(routeresponse.route)) {
                        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

                        //Code to check whether version mismatch is true or not
                        //It is the scenario if the script type is first question and user has changed questionnaire from WCAdmin
                        //In this case question will show with error message
                        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();

                        cfpLoadingBar.complete();
                        $scope.samepagecss = "page-inner-slideOutUp";
                        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
                        var intervalCanceller = $interval(function () {
                            $scope.samepagecss = "";
                            currentQuestion = miAppProperties.getCurrentQuestion();
                            $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
                            $scope.answerText = currentQuestion.answerList;
                            $scope.isEditable = currentQuestion.editable;
                            $interval.cancel(intervalCanceller);
                        }, 1000);
                    }
                    else {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(routeresponse.route));
                    }
                }

                else {
                    cfpLoadingBar.complete();
                    $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
                }
            });

        }
    });
}(angular));
