﻿describe('MFNOL AngularJS Controller (info1header Controller)', function () {

    var info1headerexpectedDetail = {
        languageList: [
        {
            text: "Français (Canada)",
            value: "fr-CA"
        },
        {
            text: "English (UK)",
            value: "en-GB"
        },
        {
            text: "English (US)",
            value: "en-US"
        },
        {
            text: "Français (France)",
            value: "fr-FR"
        },
        {
            text: "Deutsch (Deutschland)",
            value: "de-DE"
        },
        {
            text: "Italiano (Italia)",
            value: "it-IT"
        },
        {
            text: "Español (España)",
            value: "es-ES"
        }
        ],
        myValue: "en-US",
        LocaleDisplayName: true,
        
        orgcode: "M2",
    };
    var carrierTelePhone= {"primaryContactNumber":"fake-PrimaryNumber",
            "secondaryContactNumber":"fake-SecondaryNumber"}

    angular.module('mock.info1headerdata', [])
		.factory('miAppProperties', function ($q) {
		    var constant = {};

		    // other stubbed methods
		    constant.setlanguagelist = function (languages) {
		        info1headerexpectedDetail.languageList = languages
		    };
		    constant.getlanguagelist = function () {
		        return info1headerexpectedDetail.languageList;
		    };
		    constant.getCarrierTelePhone = function () {
		        return carrierTelePhone;
		    };
		    constant.setCarrierTelePhone = function (carrierTelePhone) {
		        
		    };
		    constant.setstatuscode = function (statuscode) {
		    };
		    constant.getorgcode = function () {
		        return info1headerexpectedDetail.orgcode;
		    };
		    return constant;
		})
    .service('LocaleService', function ($translate, LOCALES, $rootScope, tmhDynamicLocale) {
        return {
            getLocaleDisplayName: function () {
                return info1headerexpectedDetail.LocaleDisplayName;
            },
            setLocaleByDisplayName: function (localeDisplayName) {

            },
            getLocalesDisplayNames: function () {
                return false;
            }
        };
    });
    describe('info1headerController', function () {
        var ENV, stateparams, miLocale, miCarrierContactFactory;
       // beforeEach(module('mi.mfnol.environment'));
        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.info1headerdata'));

        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                stateparams = $injector.get('$stateParams');
                $state = $injector.get('$state');
                miLocale = $injector.get('miLocale');
                $controller = $injector.get('$controller');
                ENV = $injector.get('ENV');
                miCarrierContactFactory = $injector.get('miCarrierContactFactory');
                $rootScope.CheckHelpDoc = function () {
                    return true;
                }
              });
        });

        it('ensure language list is receiving', inject(function () {
            $controller('Info1HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale });
            expect($scope.myOptions).toBe(info1headerexpectedDetail.languageList);
            info1headerexpectedDetail.LocaleDisplayName = false;
        }));
        it('ensure myvalue has locale display name', inject(function () {
            miLocale.setLocaleCode('fr-FR');
            $controller('Info1HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale, stateparams: stateparams });
            //stateparams.lan = "fr-FR";
            expect($scope.myValue).toBe('fr-FR');
        }));
        it('ensure myvalue has default locale name', inject(function () {
            miLocale.setLocaleCode(null);
            stateparams.lan = "KR-FR";
            $controller('Info1HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale, stateparams: stateparams });
            expect($scope.myValue).toBe('en-US');
        }));
        it('ensure the function  miCarrierContactFactory.getCarrierTelephoneNumber should call with error', inject(function () {
            $controller('Info1HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale });
            spyOn(miCarrierContactFactory, 'getCarrierTelephoneNumber').and.callFake(function () {
                return $.Deferred().resolve({
                    route: 400
                });
            });
            spyOn($state, 'go');
            $scope.changeLanguage("en-US");
            expect($state.go).toHaveBeenCalledWith('shell.Error');
        }));
        it('ensure the function  miCarrierContactFactory.getCarrierTelephoneNumber should call without error', inject(function () {
            $controller('Info1HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale });
            spyOn(miCarrierContactFactory, 'getCarrierTelephoneNumber').and.callFake(function () {
                return $.Deferred().resolve({
                    route: "", data:"fake-data", status:200
                });
            });
            spyOn($state, 'go');
            $scope.changeLanguage("en-US");
            expect($rootScope.identificationHelpDoc).toBe('/src/themes/undefined/helpfiles/index-en-US.html');
        }));
        
        it('ensure the callInsuranceCarrier() should return true', inject(function () {
            $controller('Info1HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale });
            spyOn(miCarrierContactFactory, 'getCarrierTelephoneNumber').and.callFake(function () {
                return $.Deferred().resolve({
                    route: "", data: "fake-data", status: 200
                });
            });
            spyOn($state, 'go');
            $rootScope.callInsuranceCarrier();
            $rootScope.call();
            expect($scope.isVisible).toBe(true);
        }));
        it('ensure the callInsuranceCarrier() should return false', inject(function () {
            
            $controller('Info1HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale });
            $scope.isVisible = true;
            spyOn(miCarrierContactFactory, 'getCarrierTelephoneNumber').and.callFake(function () {
                return $.Deferred().resolve({
                    route: "", data: "fake-data", status: 200
                });
            });
            spyOn($state, 'go');
            $rootScope.callInsuranceCarrier();
            
            expect($scope.isVisible).toBe(false);
        }));
        it('ensure the RefreshTelephoneNumber should call and have no call center numbers', inject(function () {
            $controller('Info1HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale });
            carrierTelePhone = "";
            $scope.RefreshTelephoneNumber();
            expect($rootScope.istelPhoneNumber).toBe(false);
        }));
        it('ensure the RefreshTelephoneNumber should call and return dialTelephone number', inject(function () {
            $controller('Info1HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale });
            carrierTelePhone = {"primaryContactNumber": "fake-PrimaryNumber","secondaryContactNumber": "fake-SecondaryNumber"}
             $scope.RefreshTelephoneNumber();
             expect($rootScope.istelPhoneNumber).toBe(true);
             expect($rootScope.DialPhoneNumber).toBe(carrierTelePhone.primaryContactNumber);
        }));
        it('ensure the RefreshTelephoneNumber should call and return telephone number false', inject(function () {
            $controller('Info1HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale });
            carrierTelePhone = { "primaryContactNumber": "", "secondaryContactNumber": "" };
            $scope.RefreshTelephoneNumber();
            expect($rootScope.istelPhoneNumber).toBe(false);
        }));
        it('ensure the RefreshTelephoneNumber should call and return secondary telephone number', inject(function () {
            $controller('Info1HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale });
            carrierTelePhone = { "primaryContactNumber": "", "secondaryContactNumber": "fake-SecondaryTelephoneNumber" };
            $scope.RefreshTelephoneNumber();
            expect($rootScope.DialPhoneNumber).toBe(carrierTelePhone.secondaryContactNumber);
        }));
    });

    describe('info1headerController Test', function () {
        var ENV, stateparams, miLocale, miCarrierContactFactory;
        beforeEach(module('mi.mfnol.web'));
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                stateparams = $injector.get('$stateParams');
                $state = $injector.get('$state');
                miLocale = $injector.get('miLocale');
                $controller = $injector.get('$controller');
                ENV = $injector.get('ENV');
                miCarrierContactFactory = $injector.get('miCarrierContactFactory');
                miAppProperties = $injector.get('miAppProperties');

            });
        });
        it('ensure the RefreshTelephoneNumbe called with telephoneNumber false', inject(function (miAppProperties) {
            miAppProperties.setCarrierTelePhone("");
            $controller('Info1HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale });
            $scope.RefreshTelephoneNumber();
            expect($rootScope.istelPhoneNumber).toBe(false);
        }));

    });
});