﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('Info2HeaderCtrl',
    function (
        $scope,
        $state,
        miAppProperties,
        ENV,
        cfpLoadingBar,
        miComponentRoute,
        miLocale,
        miStageFactory) {

        $scope.back = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Back');
                cfpLoadingBar.start();
            miStageFactory.getPreviousStage(miAppProperties.getcontextid(), miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                            .then(function (previousresult) {
                                cfpLoadingBar.complete();
                                if (previousresult.route) {
                                    $state.go(miComponentRoute.getComponentroute(previousresult.route));
                                }
                            });
        }
        $scope.skip = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Skip');
            if (miAppProperties.getcontextid()) {
                cfpLoadingBar.start();
                miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                .then(function (updatestageresponse) {
                    if (updatestageresponse.route) {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                    }
                    else {
                        miAppProperties.setflagStage(true);
                        miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                       .then(function (nextstageresponse) {
                           cfpLoadingBar.complete();
                           if (nextstageresponse.route) {
                               $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                           }
                       });
                    }
                });
            }
            else {
                cfpLoadingBar.start();
                miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                          .then(function (nextstageresponse) {
                              cfpLoadingBar.complete();
                              if (nextstageresponse.route) {
                                  $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                              }
                          });
            }
        }
    });
}(angular));