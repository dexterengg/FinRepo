﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('Info1HeaderCtrl',
    function (
        $scope,
        $rootScope,
        $window,
        $stateParams,
        $state,
        $filter,
        miAppProperties,
        ENV,
        LocaleService,
        miLocale,
        cfpLoadingBar,
        miCarrierContactFactory,
        miComponentRoute,
        $location) {

        $scope.RefreshTelephoneNumber = function () {
            if (miAppProperties.getCarrierTelePhone()) {
                $rootScope.Message = "";
                $rootScope.istelPhoneNumber = true;
                $rootScope.Calltext = $filter('translate')('_Call_');

                var callCenterHourTitle = $filter('translate')('_CallCenterHourTitle_');
                miAppProperties.setCallCenterHourTitle(callCenterHourTitle);
                $rootScope.CallCenterHourTitle = miAppProperties.getCallCenterHourTitle();
                if (miAppProperties.getCarrierTelePhone().primaryContactNumber && miAppProperties.getCarrierTelePhone().secondaryContactNumber) {
                    $rootScope.telPhoneNumber = miAppProperties.getCarrierTelePhone().secondaryContactNumber;
                    $rootScope.DialPhoneNumber = miAppProperties.getCarrierTelePhone().primaryContactNumber;
                    $rootScope.Calltext += " " + $rootScope.telPhoneNumber;                  
                }
                else if (!miAppProperties.getCarrierTelePhone().primaryContactNumber && !miAppProperties.getCarrierTelePhone().secondaryContactNumber)
                {
                    $scope.setNotConfiguredMsg();
                }
                else {
                    $rootScope.telPhoneNumber = !miAppProperties.getCarrierTelePhone().primaryContactNumber ? miAppProperties.getCarrierTelePhone().secondaryContactNumber : miAppProperties.getCarrierTelePhone().primaryContactNumber;
                    $rootScope.DialPhoneNumber = $rootScope.telPhoneNumber;
                    $rootScope.Calltext += " " + $rootScope.telPhoneNumber;                 
                }
            }
            else {
                $scope.setNotConfiguredMsg();
            }
        }
        $scope.setNotConfiguredMsg = function () {

            $rootScope.Message = $filter('translate')('_CallingNumberNotConfigured_');
            $rootScope.istelPhoneNumber = false;
        }

        $scope.RefreshTelephoneNumber();
        $scope.myOptions = miAppProperties.getlanguagelist();
        if (miLocale.getLocaleCode()) {
            $scope.myValue = miLocale.getLocaleCode();
        }
        else {
            if (($stateParams.lan != undefined) && !($stateParams.lan in ENV.LOCALES))
                $scope.myValue = ENV.DEFAULT_LOCALE;
            else
                $scope.myValue = $stateParams.lan === "" ? ENV.DEFAULT_LOCALE : $stateParams.lan;
        }
        $rootScope.getLanguageSpecificCallCentereHours = function () {
            var LanguageFlag = false;
            var DefaultLanguageHours = "";
            var callCenterHours = [];           
            var callCenterHourQueryString = miAppProperties.getCallCenterHoursDTO();
            var callCenterHourArray = callCenterHourQueryString.split(ENV.CALL_CENTER_LANGUAGE_SEPARATOR);
            $scope.selectedLanguage = miLocale.getLocaleCode();
            for (var index = 0; index < callCenterHourArray.length; index++) {
                var LanguageWithHourArray = callCenterHourArray[index].split(ENV.CALL_CENTER_LANGUAGE_HOUR_SEPARATOR);
                if (angular.equals(LanguageWithHourArray[0].trim(),ENV.DEFAULT_LOCALE)) {
                    DefaultLanguageHours = LanguageWithHourArray[1];
                }
               else if (angular.equals(LanguageWithHourArray[0].trim(),$scope.selectedLanguage)) {
                    callCenterHourQueryString = LanguageWithHourArray[1];
                    LanguageFlag = true;
                }

            }
            if (!LanguageFlag) {
                if (DefaultLanguageHours) {
                    callCenterHourQueryString = DefaultLanguageHours;
                }
                else {
                    callCenterHourQueryString = "";
                    }              

            }

            //getting the call center hours separator character.
            var callCenterHourSeparator = ENV.CALL_CENTER_HOUR_SEPARATOR;
            //getting the call center title.
            var callCenterHourTitle = $filter('translate')('_CallCenterHourTitle_');
            if (callCenterHourQueryString != undefined && callCenterHourQueryString != "") {
                callCenterHours = callCenterHourQueryString.split(callCenterHourSeparator);
                miAppProperties.setCallCenterHourTitle(callCenterHourTitle);
                miAppProperties.setCallCenterHours(callCenterHours);
                miAppProperties.setDisplayCallCenterHours(callCenterHours.length > 0);
            }
            else {               
                miAppProperties.setDisplayCallCenterHours(false);
            }
            //getting the call center title
            $rootScope.CallCenterHourTitle = miAppProperties.getCallCenterHourTitle();
            //getting the call center hours
            $rootScope.CallCenterHours = miAppProperties.getCallCenterHours();
            //Display Call Center Hours
            $rootScope.DisplayCallCenterHours = miAppProperties.getDisplayCallCenterHours();
        }

        $scope.changeLanguage = function (locale) {
            miAppProperties.setCarrierTelePhone(false);
            cfpLoadingBar.completeCallPopup();
            cfpLoadingBar.start();
            miLocale.setLocaleCode(locale);
            $rootScope.getLanguageSpecificCallCentereHours();
            LocaleService.setLocaleByDisplayName(locale);
            miCarrierContactFactory.getCarrierTelephoneNumber(miAppProperties.getorgcode(), miLocale.getLocaleCode())
                                              .then(function (carriercontactresponse) {
                                                  cfpLoadingBar.complete();
                                                  if (carriercontactresponse.route) {
                                                      $state.go(miComponentRoute.getComponentroute(carriercontactresponse.route));
                                                  }
                                                  else {
                                                      if (carriercontactresponse.status === 200) {
                                                          miAppProperties.setCarrierTelePhone(carriercontactresponse.data);
                                                      }
                                                      $scope.RefreshTelephoneNumber();
                                                  }
                                              });
            $rootScope.identificationHelpDoc = "/src/themes/" +$rootScope.companyCode + "/helpfiles/index-" +miLocale.getLocaleCode() + ".html";
            $rootScope.CheckHelpDoc();
        }



        $scope.isVisible = false;
        $rootScope.callInsuranceCarrier = function () {
            if ($scope.isVisible) {
                cfpLoadingBar.completeCallPopup();
                $scope.isVisible = false;
                return;
            }
            if (!$scope.isVisible) {
                cfpLoadingBar.startCallPopup();
                $scope.isVisible = true;
            }
        }

        $rootScope.call = function () {
            window.open('tel:' + $rootScope.DialPhoneNumber, '_self');
        }

     
        //getting the call center title
        $rootScope.CallCenterHourTitle = miAppProperties.getCallCenterHourTitle();
        //getting the call center hours
        $rootScope.CallCenterHours = miAppProperties.getCallCenterHours();
        //Display Call Center Hours
        $rootScope.DisplayCallCenterHours = miAppProperties.getDisplayCallCenterHours();

    });

}(angular));