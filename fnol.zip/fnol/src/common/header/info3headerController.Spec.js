﻿describe('MFNOL AngularJS Controller (info3header Controller)', function () {
    var languageList = [
        {
            text: "Français (Canada)",
            value: "fr-CA"
        },
        {
            text: "English (UK)",
            value: "en-GB"
        },
        {
            text: "English (US)",
            value: "en-US"
        },
        {
            text: "Français (France)",
            value: "fr-FR"
        },
        {
            text: "Deutsch (Deutschland)",
            value: "de-DE"
        },
        {
            text: "Italiano (Italia)",
            value: "it-IT"
        },
        {
            text: "Español (España)",
            value: "es-ES"
        }
    ];

    var myValue = "en-US";
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: 123,
        stageType: "fake-Stage",
        stageDesc: "fake-stageDesc",
        pageName: "fake-pageName",
        UserIdentificationdata: "UserIdentificationdata",
        totalNumOfStages: 6,
        stageUiOrder: 2,
        contextid: 123,
        coStageId: 123,
        statuscode: 400,
        flagStage: true,
        StageOrder: 6
    };
    angular.module('mock.infoheaderdata', [])
		.factory('miAppProperties', function ($q) {
		    var constant = {};
		    constant.gettheme = function () {
		        return expectedDetail.theme;
		    };
		    constant.getorgcode = function () {
		        return expectedDetail.orgcode;
		    };
		    constant.getanimationclass = function () {
		        return expectedDetail.animationclass;
		    };
		    constant.getlanguage = function () {
		        return expectedDetail.language;
		    };
		    constant.getDocID = function () {
		        return expectedDetail.DocID;
		    };
		    constant.getstageType = function () {
		        return expectedDetail.stageType;
		    };
		    constant.getstageDesc = function () {
		        return expectedDetail.stageDesc;
		    };
		    constant.getpageName = function () {
		        return expectedDetail.pageName;
		    };
		    constant.setisConfirmed = function () {
		        return expectedDetail.isConfirmed;
		    };
		    constant.setDocID = function (DocID) {
		        return expectedDetail.DocID;
		    };
		    constant.getUserIdentificationdata = function () {
		        return expectedDetail.UserIdentificationdata;
		    };
		    constant.gettotalNumOfStages = function () {
		        return expectedDetail.totalNumOfStages;
		    };
		    constant.getstageUiOrder = function () {
		        return expectedDetail.stageUiOrder;
		    };
		    constant.getcontextid = function () {
		        return expectedDetail.contextid;
		    };
		    constant.getcoStageId = function () {
		        return expectedDetail.coStageId;
		    };
		    constant.setstatuscode = function (statuscode) {
		        expectedDetail.statuscode = statuscode;
		    };
		    constant.setflagStage = function (flagStage) {
		        expectedDetail.flagStage = flagStage;
		    };
		    constant.getStageOrder = function () {
		        return expectedDetail.StageOrder;
		    };
		    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
		    constant.fetch = function () {
		        var mockUser = "M2";
		        return $q.when(mockUser);
		    };
		    // other stubbed methods
		    return constant;
		})

    describe('info3headerController Test', function () {
        var LocaleService, locales, stateparams, miLocale, miStageFactory;

        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.infoheaderdata'));

        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $stateparams = $injector.get('$stateParams');
                $state = $injector.get('$state');
                LocaleService = $injector.get('LocaleService');
                miLocale = $injector.get('miLocale');
                miStageFactory = $injector.get('miStageFactory');
                $controller = $injector.get('$controller');
            });
        });

        it('ensure back function called', inject(function () {
            $controller('Info3HeaderCtrl', { $scope: $scope, $state: $state });
            $scope.back();
        }));

        it('ensure updateStage called with error', inject(function () {
            $controller('Info3HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.skip();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
        }));

        it('ensure updateStage called with success', inject(function () {
            $controller('Info3HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.skip();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));

        it('ensure updateStage called with error when contextid is null', inject(function () {
            $controller('Info3HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale, miStageFactory: miStageFactory });
            expectedDetail.contextid = false;
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.skip();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));

    });
});