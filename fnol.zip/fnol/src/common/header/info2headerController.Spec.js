﻿describe('MFNOL AngularJS Controller (info2header Controller)', function () {

    var info2headerexpectedDetail = {
        orgcode: "M2",
        stageUiOrder: 2,
        contextid: 123,
        coStageId: 123,
        statuscode: 400,
        flagStage: true,
        StageOrder:6
    };
    angular.module('mock.info2headerdata', [])
		.factory('miAppProperties', function ($q) {
		    var constant = {};
		    constant.getorgcode = function () {
		        return info2headerexpectedDetail.orgcode;
		    };
			
		    constant.getcontextid = function () {
		        return info2headerexpectedDetail.contextid;
		    };
		    constant.getcoStageId = function () {
		        return info2headerexpectedDetail.coStageId;
		    };
		    constant.setstatuscode = function (statuscode) {
		        info2headerexpectedDetail.statuscode = statuscode;
		    };
		    constant.setflagStage = function (flagStage) {
		        info2headerexpectedDetail.flagStage = flagStage;
		    };
		    constant.getStageOrder = function () {
		        return info2headerexpectedDetail.StageOrder;
		    };
		    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
		    constant.fetch = function () {
		        var mockUser = "M2";
		        return $q.when(mockUser);
		    };
		    // other stubbed methods
		    return constant;
		})

    describe('info2headerController_back()_Test', function () {
        var LocaleService, locales, stateparams, miLocale, miStageFactory;

        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.info2headerdata'));

        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $stateparams = $injector.get('$stateParams');
                $state = $injector.get('$state');
                LocaleService = $injector.get('LocaleService');
                miLocale = $injector.get('miLocale');
                miStageFactory = $injector.get('miStageFactory');
                $controller = $injector.get('$controller');
            });
        });
        //spec to track that spy created on miStageFactory.getPreviousStage was called
        it('ensure getPreviousStage called click on back button ', inject(function () {
            $controller('Info2HeaderCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "CHOICE_SELECTION" });
            });
            spyOn($state, 'go');
            $scope.back();
            expect(miStageFactory.getPreviousStage).toHaveBeenCalled();
        }));
        it('ensure getPreviousStage called when failed with Error Page', inject(function () {
            $controller('Info2HeaderCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.back();
            expect(miStageFactory.getPreviousStage).toHaveBeenCalled();
        }));
    });
    describe('info2headerController_skip()_Test', function () {
        var LocaleService, locales, stateparams, miLocale, miStageFactory;
        beforeEach(module('mi.mfnol.web'));
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.info2headerdata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $stateparams = $injector.get('$stateParams');
                $state = $injector.get('$state');
                LocaleService = $injector.get('LocaleService');
                miLocale = $injector.get('miLocale');
                miStageFactory = $injector.get('miStageFactory');
                $controller = $injector.get('$controller');
            });
        });
        it('ensure updateStage called with error', inject(function () {
            $controller('Info2HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.skip();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
        }));

        it('ensure updateStage called with success', inject(function () {
            $controller('Info2HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.skip();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));

        it('ensure updateStage called with error when contextid is null', inject(function () {
            $controller('Info2HeaderCtrl', { $scope: $scope, $state: $state, miLocale: miLocale, miStageFactory: miStageFactory });
            info2headerexpectedDetail.contextid = false;
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.skip();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));

    });
});