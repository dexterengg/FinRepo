﻿describe('MFNOL AngularJS Controller (Time Question Controller)', function () {
    var $httpBackend, $scope;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        questionDetailsList: [],
        isSupportable: false,
        isEditablefalse: false,
        isEditabletrue: true,
        backbuttoncss: "clickable_Back_Btn",
        IsStageStatusChanged: true,
        contextid: false,
        coStageId: 123,
        docID: 0
    };
    var currentQuestion = { "answerList": [{ "qustnnreQustnId": 0, "answerDisplayText": "2015-10-10T12:00:00-05:00", "lowRangeValue": 0, "highRangeValue": 0, "answerDisplayOrder": 0, "answerItemID": 0, "answered": true }], "answrControlType": "TIME_QUESTION", "qustnnreQustnId": 100000119179, "companyCd": null, "qustnnreId": 0, "qustnText": "What was the time when collision occurred?", "qustnFormattedText": "false", "editable": true, "qustnPlainText": null }
    // Mocked Service
    angular.module('mock.timedata', [])
		.factory('miAppProperties', function ($q) {
		    var constant = {};
		    constant.gettheme = function () {
		        return expectedDetail.theme;// "M2";
		    };
		   constant.getanimationclass = function () {
		        return expectedDetail.animationclass;
		    };
		    constant.gettotalNumOfStages = function () {
		        return expectedDetail.totalNumOfStages;
		    };
		    constant.getstageUiOrder = function () {
		        return expectedDetail.stageUiOrder;
		    };
		    constant.setstatuscode = function (statuscode) {
		    };
		    constant.getstatuscode = function () {
		        return "fake-StatusCode";
		    };
		    constant.getCurrentQuestion = function () {
		        return currentQuestion;
		    };
		    constant.getstageName = function () {
		        return "IDENTIFICATION";
		    };
		    constant.insertUserIdentificationdata = function (Id, Question, Answer) {
		        var QuesAnsDetail = { "Id": Id, "Question": Question, "Answer": Answer };
		        expectedDetail.UserIdentificationdata.push(QuesAnsDetail);
		    };
		    constant.insertQuestionDetails = function (questionnaireQuestionId, answerText) {
		        var questionDetails = {
		            "qustnnrQustnId": questionnaireQuestionId,
		            "answer": answerText
		        };
		        expectedDetail.questionDetailsList.push(questionDetails);
		    };
		    constant.getBackButtonCss = function () {
		        return expectedDetail.backbuttoncss;
		    };
		    constant.IsStageStatusChanged = function () {
		        return expectedDetail.IsStageStatusChanged
		    };
		    constant.setStageStatus = function (stageStatus) {
		        expectedDetail.stageStatus = stageStatus;
		    }
		    constant.getStageStatus = function () {
		        return expectedDetail.stageStatus;
		    };
		    constant.getcontextid = function () {
		        return expectedDetail.contextid;
		    };
		    constant.getcoStageId = function () {
		        return expectedDetail.coStageId;
		    };
		    constant.getDocID = function () {
		        return expectedDetail.docID;
		    };
		    constant.setVersionMismatchStatus = function () { }
		    constant.getVersionMismatchStatus = function () {
		        return false;
		    }
		    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
		    constant.fetch = function () {
		        var mockUser = "M2";
		        return $q.when(mockUser);
		    };

		    // other stubbed methods

		    return constant;
		});
    beforeEach(module('mi.mfnol.web'));
    describe('TimeQuestion_Controller_Testforcurrenttheme', function () {
        //  beforeEach(module('mi.mfnol.web'));
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.timedata'));
        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            $scope = $rootScope.$new();
            $controller = _$controller_;
            $controller = $controller('TimeQuestionCtrl', {
                $scope: $scope,
                miAppProperties: _miAppProperties_
            });
        }));
        it('erensure current theme is not null', function () {
            expect($scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect($scope.currtheme).toBe(expectedDetail.theme);
        });
        it('time Question Controll  ensure animation class is not null', function () {
            expect($scope.pageClass).not.toBe(null);
        });
        it('ensure animation class is page-main', function () {
            expect($scope.pageClass).toBe(expectedDetail.animationclass);
        });
        it('ensure time question is not null', function () {
            expect($scope.questionText).not.toBe(null);
        });
        it('verify the question text', function () {
            expect($scope.questionText).toBe("What was the time when collision occurred?");
        });
        it('ensure back button css is clickable', function () {
            expect($scope.Back_Btn_Class).toBe(expectedDetail.backbuttoncss);
        });
        it('ensure questionnaire version is false', function () {
            expect($scope.isVersionMismatch).toBe(false);
        });
    });
    
    describe('TimeQuestion_Controller_miUiStagesProgressbar_Service_Test', function () {
        beforeEach(module('mock.timedata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });
        //spec to track that spy created on miUiStagesProgressbar.changeUiStage was called
        it('should call miUiStagesProgressbar changeUiStage when called', inject(function () {
            $controller('TimeQuestionCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            expect(miUiStagesProgressbar.changeUiStage).toHaveBeenCalled();
        }));

    });

    describe('TimeQuestion_Controller_isSupportable()_isEditable()_function_Test', function () {
        beforeEach(module('mock.timedata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });
        it('should return false when called isSupportable()', inject(function () {
            $controller('TimeQuestionCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            $scope.isSupportable();
            expect(expectedDetail.isSupportable).toBe(false);
        }));
        it('should return false when called isEditable()', inject(function () {
            $controller('TimeQuestionCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            $scope.isEditable();
            expect(expectedDetail.isEditablefalse).toBe(false);
        }));
    });

    describe('TimeQuestion_Controller_isEditable()_valueChange()_textValueChange()_function_Test', function () {
        var currentQuestion1 = { "answerList": [{ "qustnnreQustnId": 0, "answerDisplayText": "2015-10-10T12:00:00-05:00", "lowRangeValue": 0, "highRangeValue": 0, "answerDisplayOrder": 0, "answerItemID": 0, "answered": true }], "answrControlType": "TIME_QUESTION", "qustnnreQustnId": 100000119179, "companyCd": null, "qustnnreId": 0, "qustnText": "What was the time when collision occurred?", "qustnFormattedText": "false", "editable": false, "qustnPlainText": null }
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                //miAppProperties = $injector.get('miAppProperties');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });
        it('should return true when called isEditable()', inject(function (miAppProperties) {
            miAppProperties.setCurrentQuestion(currentQuestion1);
            $controller('TimeQuestionCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            $scope.isEditable();
            expect(expectedDetail.isEditabletrue).toBe(true);
        }));
        it('ensure valueChange() method called', inject(function (miAppProperties) {
            miAppProperties.setCurrentQuestion(currentQuestion1);
            $controller('TimeQuestionCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            $scope.valueChange("fake-value");
            expect($scope.value).toBe("fake-value");
        }));

        it('ensure textvalueChange() method called', inject(function (miAppProperties) {
            miAppProperties.setCurrentQuestion(currentQuestion1);
            $controller('TimeQuestionCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            $scope.textvalueChange("fake-value");
            expect($scope.textvalue).toBe("fake-value");
        }));

        it('ensure the time value when enter valid time', inject(function (miAppProperties) {
            miAppProperties.setCurrentQuestion(currentQuestion1);
            $controller('TimeQuestionCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            expect($scope.textvalue).not.toBe(null);
        }));
      });
    

    describe('TimeQuestion_Controller_trustAsHtml()_Test', function () {

        var miAppFactory, miValidation;

        beforeEach(module('mock.timedata'));

        beforeEach(function () {

            inject(function ($injector) {

                $scope = $injector.get('$rootScope').$new();

                $state = $injector.get('$state');

                $filter = $injector.get('$filter');

                $controller = $injector.get('$controller');

                $sce = $injector.get('$sce');

                miAppFactory = $injector.get('miAppFactory');
                miValidation = $injector.get('miValidation');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');

                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
                spyOn(miValidation, 'validateDateandTime').and.returnValue('InValid');

            });

        });

        //spec to track that spy created on miUiStagesProgressbar.changeUiStage was called

        it('should call sce trustAsHtml', inject(function () {

            $controller('TimeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce });

            spyOn($sce, 'trustAsHtml').and.callThrough();

            $scope.getHtml('<h1>Test</h1>');
            $scope.next();
            expect($sce.trustAsHtml).toHaveBeenCalled();

        }));

    });

    describe('TimeQuestion_Controller_For_Next()_function', function () {
        beforeEach(module('mi.mfnol.web'));
        //var miAppFactory;
        beforeEach(module('mock.timedata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miAppFactory = $injector.get('miAppFactory');
                miStageFactory = $injector.get('miStageFactory');
                miAppProperties = $injector.get('miAppProperties');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');

            });
        });
        //spec to track that spy created on $sce.trustAsHtml and miStageFactory.updateStage was called

        it('should call sce trustAsHtml', inject(function () {
            $controller('TimeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce });
            spyOn($sce, 'trustAsHtml').and.callThrough();
            $scope.getHtml('<h1>Test</h1>');
            expect($sce.trustAsHtml).toHaveBeenCalled();
        }));
        it('should call timeValidate function with valid uam on next click', inject(function () {
            $controller('TimeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.value = "fake-value";
            $scope.next();
            expect(miStageFactory.updateStage).not.toHaveBeenCalled();

        }));
        it('should call timeValidate function with Invalid uam on next click', inject(function () {
            $controller('TimeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.next();
            expect(miStageFactory.updateStage).toHaveBeenCalled();

        }));
        it('should call miStageFactory updateStage with error page', inject(function () {
            $controller('TimeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.next(currentQuestion.answerList[0], true);
            expect(miStageFactory.updateStage).toHaveBeenCalled();

        }));
        it('should call miStageFactory updateStage with success', inject(function () {
            $controller('TimeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miAppFactory, 'getRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.next(currentQuestion.answerList[0], true);
            expect(miAppProperties.getStageStatus()).toBe("REOPEN");

        }));
        it('should call miStageFactory updateStage and miAppFactory getRoute with success', inject(function () {
            $controller('TimeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            $state.current.name = "shell.landing-Question.time-Question";
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            spyOn(miAppFactory, 'getRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "TIME_QUESTION" });
            });
            spyOn($state, 'go');
            $scope.next(currentQuestion.answerList[0], true);
            expect(miUiStagesProgressbar.changeUiStage).toHaveBeenCalled();


        }));
    });


    describe('TimeQuestion_Controller_Next()_Test', function () {
        var miAppFactory, miValidation, miAppProperties;
        //beforeEach(module('mock.timedata'));
        var currentQuestion1 = { "answerList": [{ "qustnnreQustnId": 0, "answerDisplayText": "2015-10-10T12:00:00-05:00", "lowRangeValue": 0, "highRangeValue": 0, "answerDisplayOrder": 0, "answerItemID": 0, "answered": true }], "answrControlType": "TIME_QUESTION", "qustnnreQustnId": 100000119179, "companyCd": null, "qustnnreId": 0, "qustnText": "What was the time when collision occurred?", "qustnFormattedText": "false", "editable": true, "qustnPlainText": null };
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                miAppFactory = $injector.get('miAppFactory');
                miAppProperties = $injector.get('miAppProperties');
                miValidation = $injector.get('miValidation');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
                spyOn(miValidation, 'validateDateandTime').and.returnValue('Valid');
               
            });
        });
       it('ensure that insertQuestionDetails() have been called', inject(function (miAppProperties) {
            miAppProperties.setCurrentQuestion(currentQuestion1);
            miAppProperties.setstageName("IDENTIFICATION");
            //$state.current.name = "shell.landing-Question.time-Question";
            $controller('TimeQuestionCtrl', { '$scope': $scope, miAppFactory: miAppFactory });
            spyOn(miAppProperties, 'insertQuestionDetails').and.returnValue("fake-result");
            spyOn(miAppFactory, 'getRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: " " });
            });
            spyOn($state, 'go');
            $scope.next();
            expect(miAppProperties.insertQuestionDetails).toHaveBeenCalled();
        }));
    });

    describe('Time Question Controller_Test_For_Back_Functionality', function () {
        beforeEach(module('mi.mfnol.web'));
        var miAppFactory;
        beforeEach(module('mock.timedata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miAppFactory = $injector.get('miAppFactory');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });
        //spec to track that spy created on miUiStagesProgressbar.changeUiStage was called
        it('should call miAppFactory getPreviousRoute with choiceselection questionType', inject(function () {
            $controller('TimeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            $state.current.name = "shell.landing-Question.choiceselection-Question";
            spyOn(miAppFactory, 'getPreviousRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "CHOICE_SELECTION" });
            });

            $scope.back();
            expect(miAppFactory.getPreviousRoute).toHaveBeenCalled();


        }));
        it('should call miAppFactory getPreviousRoute with range questionType', inject(function () {
            $controller('TimeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            $state.current.name = "shell.landing-Question.choiceselection-Question";
            spyOn(miAppFactory, 'getPreviousRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "RANGE_VALUE" });
            });
            spyOn($state, 'go');
            $scope.back();
            expect(miAppFactory.getPreviousRoute).toHaveBeenCalled();


        }));
        it('should call miAppFactory getPreviousRoute return backbutton CSS', inject(function () {
            $controller('TimeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });
            spyOn(miAppFactory, 'getPreviousRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn($state, 'go');
            $scope.back();
            expect(miAppFactory.getPreviousRoute).toHaveBeenCalled();
        }));
    });

    describe('Time Question Controller_Test_For_Back_Functionality', function () {
        var currentQuestion1 = { "answerList": [{ "qustnnreQustnId": 0, "answerDisplayText": "", "lowRangeValue": 0, "highRangeValue": 0, "answerDisplayOrder": 0, "answerItemID": 0, "answered": true }], "answrControlType": "TIME_QUESTION", "qustnnreQustnId": 100000119179, "companyCd": null, "qustnnreId": 0, "qustnText": "What was the time when collision occurred?", "qustnFormattedText": "false", "editable": true, "qustnPlainText": null }
        beforeEach(module('mi.mfnol.web'));
        var miAppFactory;
        // beforeEach(module('mock.datedata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miAppFactory = $injector.get('miAppFactory');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });
        //spec to track that spy created on miUiStagesProgressbar.changeUiStage was called
        it('should call miAppFactory getPreviousRoute With  Null Answer', inject(function (miAppProperties) {
            miAppProperties.setCurrentQuestion(currentQuestion1);
            miAppProperties.setstageName("IDENTIFICATION");
            $controller('TimeQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar });

            $state.current.name = "shell.landing-Question.time-Question";
            spyOn(miAppFactory, 'getPreviousRoute').and.callFake(function () {
                return $.Deferred().resolve({ route: "TIME_QUESTION" });
            });
            spyOn($state, 'go');
            $scope.back();
            expect(miAppFactory.getPreviousRoute).toHaveBeenCalled();


        }));
    });
         
   });