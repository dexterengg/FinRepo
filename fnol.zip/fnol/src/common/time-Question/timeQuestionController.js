﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('TimeQuestionCtrl',
    function (
        $scope,
        $http,
        $state,
        $sce,
        $window,
        miAppProperties,
        cfpLoadingBar,
        ENV,
        miComponentRoute,
        miQues,
        miValidation,
        miUiStagesProgressbar,
        miAppFactory,
        miStageFactory,
        miLocale,
        $interval,
        $filter) {
        //$scope.Back_Btn_Class = "clickable_Back_Btn";
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        var currentQuestion = miAppProperties.getCurrentQuestion();
        $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
        var answertext = currentQuestion.answerList[0].answerDisplayText;
        $scope.placeholder = ENV.TIME_FORMAT;
        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();

        var isDatetimeControl = Modernizr.inputtypes.time;

        $scope.isSupportable = function () {
            return isDatetimeControl;
        }
        $scope.isEditable = function () {
            var edit = currentQuestion.editable;
            if (edit)
                return false;
            else
                return true;
        }
        $scope.valueChange = function (val) {
            $scope.value = val;
            angular.element('#uamtime').text("");
            angular.element('#uamtime').removeClass('mi-uam-block--alert');
        }
        $scope.textvalueChange = function (val) {
            $scope.textvalue = val;
            angular.element('#uamtime').text("");
            angular.element('#uamtime').removeClass('mi-uam-block--alert');
        }
        if (answertext) {
            answertext = answertext.toUpperCase();
            if (new Date(answertext) === ENV.INVALID_DATE) {
                answertext = ENV.DEFAULT_DATE + answertext;
            }
            if (isDatetimeControl) {
                $scope.value = new Date(answertext);
            }
            else {
                $scope.textvalue = miValidation.getCustomDateTime(new Date(answertext), ENV.TIME_CONSTANT);
            }
        }
        else {
            if (isDatetimeControl) {
                $scope.value = "";
            }
            else {
                $scope.textvalue = "";
            }
        }
        $scope.getHtml = function (html) {

            return $sce.trustAsHtml(html);
        };
        //validate Time field on onblur/next button click
        $scope.timeValidate = function ()
        {
            var cntrl = angular.element('#uamtime');
          
            var uam = miValidation.validateDateandTime(isDatetimeControl ? $scope.value : $scope.textvalue, ENV.TIME_CONSTANT, !(isDatetimeControl));
            if (uam == "Valid") {
                cntrl.text("");
                cntrl.removeClass('mi-uam-block--alert');
            }
            else {
                cntrl.text(uam);
                cntrl.addClass('mi-uam-block--alert');
                cfpLoadingBar.complete();
                return false;
            };

        }
        $scope.next = function () {
            cfpLoadingBar.start();

            //set isVersionMismatch to false so that version mismatch message will not show on next question
            miAppProperties.setVersionMismatchStatus(false);

            if ($scope.timeValidate() === false) {
                return false;
            }
            if (isDatetimeControl) {

                answertext = new Date($scope.value).toISOString();
            }
            else {
                answertext = new Date("01/01/1970 " + $scope.textvalue.toString().trim()).toISOString();
            }
            
            //Calling function to insert question details
            miAppProperties.insertQuestionDetails(currentQuestion.qustnnreQustnId, answertext);

            ga('send', 'event', 'Answer', 'Time question', answertext);

            //Calling function to check whether we user has given same answer or not
            var isStatusChanged = miAppProperties.IsStageStatusChanged(currentQuestion, answertext);

            //If status changed then we need to first update the stage with state "REOPEN"
            //Otherwise continue with existing call
            if (isStatusChanged) {
                miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_REOPEN)
                    .then(function (updatestageresponse) {
                        if (updatestageresponse.route) {
                            cfpLoadingBar.complete();
                            $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                        }
                        else {
                            miAppProperties.setStageStatus(ENV.CLAIMSTATUS_REOPEN);
                            $scope.getRoute();
                        }
                    })
            }
            else {
                $scope.getRoute();
            }   //End of checking status changed condition            
        }


        $scope.getRoute = function () {
            miAppFactory.getRoute()
                 .then(function (routeresponse) {
                     if (routeresponse.route) {
                         if ($state.current.name === miComponentRoute.getComponentroute(routeresponse.route)) {
                             $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

                             //Code to check whether version mismatch is true or not
                             //It is the scenario if the script type is first question and user has changed questionnaire from WCAdmin
                             //In this case question will show with error message
                             $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();

                             cfpLoadingBar.complete();
                             $scope.samepagecss = "page-inner-slideOutUp";
                             miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
                             //$scope.Back_Btn_Class = "clickable_Back_Btn";
                             var intervalCanceller = $interval(function () {
                                 $scope.samepagecss = "";
                                 currentQuestion = miAppProperties.getCurrentQuestion();
                                 $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
                                 answertext = currentQuestion.answerList[0].answerDisplayText;

                                 if (answertext) {
                                     if (new Date(answertext) === ENV.INVALID_DATE) {
                                         answertext = ENV.DEFAULT_DATE + answertext;
                                     }
                                     if (isDatetimeControl) {
                                         $scope.value = new Date(answertext);
                                     }
                                     else {
                                         $scope.textvalue = miValidation.getCustomDateTime(new Date(answertext), ENV.TIME_CONSTANT);
                                    }
                                 }
                                 else {
                                     if (isDatetimeControl) {
                                         $scope.value = "";
                                    }
                                else {
                                            $scope.textvalue = "";
                                }
                                 }
                                 $interval.cancel(intervalCanceller);
                             }, 1000);
                        }
                        else {
                            cfpLoadingBar.complete();
                            $state.go(miComponentRoute.getComponentroute(routeresponse.route));
                        }
                    }
            });
        }

        $scope.back = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Back');
            cfpLoadingBar.start();

            //set isVersionMismatch to false so that version mismatch message will not show on next question
            miAppProperties.setVersionMismatchStatus(false);

            miAppFactory.getPreviousRoute(currentQuestion.qustnnreQustnId)
            .then(function (routeresponse) {
                if (routeresponse.route) {
                    if ($state.current.name === miComponentRoute.getComponentroute(routeresponse.route)) {
                        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

                        //Code to check whether version mismatch is true or not
                        //It is the scenario if the script type is first question and user has changed questionnaire from WCAdmin
                        //In this case question will show with error message
                        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();

                        cfpLoadingBar.complete();
                        $scope.samepagecss = "page-inner-slideOutUp";
                        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
                        var intervalCanceller = $interval(function () {
                            $scope.samepagecss = "";
                            currentQuestion = miAppProperties.getCurrentQuestion();
                            $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
                            answertext = currentQuestion.answerList[0].answerDisplayText;                        
                            if (answertext) {
                                if (new Date(answertext) === ENV.INVALID_DATE) {
                                    answertext = ENV.DEFAULT_DATE + answertext;
                                }
                                if (isDatetimeControl) {
                                    $scope.value = new Date(answertext);
                                }
                                else {
                                    $scope.textvalue = miValidation.getCustomDateTime(new Date(answertext), ENV.TIME_CONSTANT);
                                }
                            }
                            else {
                                if (isDatetimeControl) {
                                    $scope.value = "";
                                }
                                else {
                                    $scope.textvalue = "";
                                }
                            }
                            $interval.cancel(intervalCanceller);
                        }, 1000);
                    }
                    else {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(routeresponse.route));
                    }
                }

                else {
                    cfpLoadingBar.complete();
                    $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
                }
            });

        }
        
    });
}(angular));
