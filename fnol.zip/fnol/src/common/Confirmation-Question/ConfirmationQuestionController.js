﻿
(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('ConfirmationQuestionCtrl',
    function (
        $rootScope,
        $scope,
        $state,
        $sce,
        $filter,
        miAppProperties,
        ENV,
        miLocale,
        miComponentRoute,
        cfpLoadingBar,
        miUiStagesProgressbar,
        miCMSFactory,
        miStageFactory,
        miAppFactory) {

        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        $scope.answerText = miAppProperties.getQuestionnairesQuestionDetails();
        $scope.isQuestionnaireSummmary = false;
        if (miAppProperties.getpageName() === ENV.QUESTIONNAIRE_SUMMARY_CONSTANT) {
            $scope.displayQuestion = miAppProperties.getdisplayQuestionFlag();
            $scope.isQuestionnaireSummmary = true;
        }
        else {
            $scope.displayQuestion = true;
        }

        $scope.answerText = miAppProperties.getQuestionnairesQuestionDetails();
        $scope.questionText = $filter('translate')('_ConfirmationHeading_');
        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

        $scope.getHtml = function (html) {
            return $sce.trustAsHtml(html);
        };

        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());

        $scope.Confirm = function () {
            ga('send', 'event', 'Decision', 'Button click', 'Confirm');
            cfpLoadingBar.start();
            if (miAppProperties.getpageName() != ENV.QUESTIONNAIRE_SUMMARY_CONSTANT) {
                miAppProperties.setisConfirmed(true);

                miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                .then(function (nextstageresponse) {

                    if (nextstageresponse.route) {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                    }

                });
            }
            else {
                miAppProperties.setDocID(false);
                miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
               .then(function (response) {
                   if (response.route) {
                        cfpLoadingBar.complete();
                       $state.go(miComponentRoute.getComponentroute(response.route));
                   }
                   else {
                       miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                        .then(function (nextstageresponse) {
                            if (nextstageresponse.route) {
                                cfpLoadingBar.complete();
                                $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                            }
                        });
                   }
               });

            }
        }

        $scope.Edit = function () {
            ga('send', 'event', 'Decision', 'Button click', 'Edit');
            cfpLoadingBar.start();
            //Condition to check the page name is Identification Confirmation Page(CP1)/Questionnaire Summary Page
            // if (miAppProperties.getpageName() != ENV.QUESTIONNAIRE_SUMMARY_CONSTANT) {
            if (miAppProperties.getQuestionnaireSummaryPage() != ENV.QUESTIONNAIRE_SUMMARY_CONSTANT) {
                miAppProperties.ClearUserIdentificationdata();
                miAppProperties.clearQuestionDetails();
                miAppProperties.setredirectionToken(false);
                miAppProperties.setcontextid(false);
                miAppProperties.setisConfirmed(false);
                miAppProperties.setStageOrder(1);
                miAppProperties.setDocID(0);;
                $rootScope.stages = 0;
                miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                          .then(function (nextstageresponse) {
                                                              cfpLoadingBar.complete();
                                                              if (nextstageresponse.route) {
                                                                  $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                              }
                                                          });
            }
            else {
                //get first question of the first questionniare
                miStageFactory.getFirstQuestionnaire(miAppProperties.getorgcode(), miAppProperties.getcontextid(), ENV.APP_VERSION, miLocale.getLocaleCode())
                                                     .then(function (nextstageresponse) {
                                                         cfpLoadingBar.complete();
                                                         if (nextstageresponse.route) {
                                                             $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                         }
                                                     });

            }
        }


        $scope.back = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Back');
            cfpLoadingBar.start();
            miStageFactory.getPreviousStage(miAppProperties.getcontextid(), miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                        .then(function (previousresult) {
                            if (previousresult.route) {
                                cfpLoadingBar.complete();
                                $state.go(miComponentRoute.getComponentroute(previousresult.route));
                            }
                            else {
                                //hide the back buttion by click on back button when previous stage is integration type
                                cfpLoadingBar.complete();
                                $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

                        }
                        });

        }
    });
}(angular));