﻿describe('MFNOL AngularJS Controller (Confirmation Question Controller)', function () {

    var $httpBackend, $scope, $controller;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        statuscode: "statuscode",
        DocID: 123,
        isConfirmed: true,
        totalNumOfStages: 6,
        stageUiOrder: 2,
        stageOrder: 4,
        contextid: false,
        systemDocId: 0,
        backbuttoncss: "clickable_Back_Btn",
        UserIdentificationdatalength: 0,
        pageName: "fakePage",
        coStageId: "fakeCoStageId"
    };
    var UserIdentificationdata = "UserIdentificationdata";
    // Mocked Service
    angular.module('mock.confirmationdata', [])
	.factory('miAppProperties', function ($q) {
	    var constant = {};
	    constant.gettheme = function () {
	        return expectedDetail.theme;
	    };
	    constant.getorgcode = function () {
	        return expectedDetail.orgcode;
	    };
	    constant.getanimationclass = function () {
	        return expectedDetail.animationclass;
	    };
	    constant.getQuestionnairesQuestionDetails = function () {
	        return UserIdentificationdata;
	    };
	    constant.gettotalNumOfStages = function () {
	        return expectedDetail.totalNumOfStages;
	    };
	    constant.getstageUiOrder = function () {
	        return expectedDetail.stageUiOrder;
	    };
	    constant.setisConfirmed = function () {
	        return expectedDetail.isConfirmed;
	    }
	    constant.setstatuscode = function (statuscode) {
	        expectedDetail.statuscode = statuscode;
	    };
	    constant.getStageOrder = function () {
	        return expectedDetail.stageOrder;
	    };
	    constant.clearQuestionDetails = function () {
	    };
	    constant.setredirectionToken = function (token) {
	    };
	    constant.setcontextid = function (contextid) {
	    };
	    constant.getcontextid = function () {
	        return expectedDetail.contextid;
	    }
	    constant.setStageOrder = function (stageorder) {
	    };
	    constant.setsystemDocId = function (docid) {
	    };
	    constant.ClearUserIdentificationdata = function () {
	        return expectedDetail.UserIdentificationdatalength;
	    }
	    constant.getBackButtonCss = function () {
	        return expectedDetail.backbuttoncss;
	    };
	    constant.setDocID = function (DocID) {
	        return expectedDetail.DocID;
	    };
	    constant.getpageName = function () {
	        return expectedDetail.pageName;
	    }

	    constant.setpageName = function (pageName) {
	        expectedDetail.pageName = pageName;
	    }
	    constant.getcoStageId = function () {
	        return expectedDetail.coStageId;
	    }

	    constant.setcoStageId = function (coStageId) {
	        expectedDetail.coStageId = coStageId;
	    }

	    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
	    constant.fetch = function () {
	        var mockUser = "M2";
	        return $q.when(mockUser);
	    };
	    // other stubbed methods
	    return constant;
	})

    describe('ConfirmationQuestion_Controller_Test_for_currentTheme', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.confirmationdata'));

        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('ConfirmationQuestionCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));
        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });

        it('ensure default page class name', function () {
            expect(scope.pageClass).toBe('page-main');
        });
        it('ensure back button css is clickable', function () {
            expect(scope.Back_Btn_Class).toBe(expectedDetail.backbuttoncss);
        });
    });
    describe('ConfirmationQuestionController_Confirm()_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.confirmationdata'));
        var sce, miStageFactory, miUiStagesProgressbar, miAppProperties;
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miAppProperties = $injector.get('miAppProperties');
                miStageFactory = $injector.get('miStageFactory');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();

            });
        });
        //spec to track that spy created on miUiStagesProgressbar.changeUiStage was called
        it('should call miUiStagesProgressbar changeUiStage', inject(function () {
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce, miUiStagesProgressbar: miUiStagesProgressbar });
            expect(miUiStagesProgressbar.changeUiStage).toHaveBeenCalled();
        }));
        it('should call sce trustAsHtml', inject(function () {
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce });
            spyOn($sce, 'trustAsHtml').and.callThrough();
            $scope.getHtml('<h1>Test</h1>');
            expect($sce.trustAsHtml).toHaveBeenCalled();
        }));
        it('ensure getNextStage called with success', inject(function () {
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "Vehicle Summary Page" });
            });
            spyOn($state, 'go');
            $scope.Confirm();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));
        it('ensure getNextStage called with error', inject(function () {
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.Confirm();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));

        it('ensure getNextStage called with when ENV.QUESTIONNAIRE_SUMMARY_CONSTANT=Questionnaire Confirmation', inject(function () {
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory, miAppProperties: miAppProperties });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "fakeRoute" });
            });
            miAppProperties.setpageName('Questionnaire Confirmation');
            spyOn($state, 'go');
            $scope.Confirm();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
        }));

        it('ensure getNextStage called with when ENV.QUESTIONNAIRE_SUMMARY_CONSTANT!=Questionnaire Confirmation', inject(function () {
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory, miAppProperties: miAppProperties });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "fakeRoute" });
            });
            miAppProperties.setpageName('Questionnaire Confirmation1');
            spyOn($state, 'go');
            $scope.Confirm();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));
    });
    describe('ConfirmationQuestionController_Edit()_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.confirmationdata'));
        var sce, miStageFactory, miUiStagesProgressbar, miAppProperties;
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miStageFactory = $injector.get('miStageFactory');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                miAppProperties = $injector.get('miAppProperties');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();

            });
        });
        //spec to track that spy created on miStageFactory.getNextStage was called
        it('ensure getNextStage called when success with Identification Page', inject(function () {
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "Identification Page" });
            });
            spyOn($state, 'go');
            $scope.Edit();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));
        it('ensure getNextStage called when failed with Error Page', inject(function () {
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.Edit();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));
        it('ensure getNextStage called with when ENV.QUESTIONNAIRE_SUMMARY_CONSTANT=Questionnaire Confirmation', inject(function () {
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory, miAppProperties: miAppProperties });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "fakeRoute" });
            });
            miAppProperties.setpageName('Questionnaire Confirmation');
            spyOn($state, 'go');
            $scope.Edit();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));
        it('ensure getNextStage called with when ENV.QUESTIONNAIRE_SUMMARY_CONSTANT!=Questionnaire Confirmation', inject(function () {
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory, miAppProperties: miAppProperties });
            spyOn(miStageFactory, 'getFirstQuestionnaire').and.callFake(function () {
                return $.Deferred().resolve({ route: "fakeRoute" });
            });
            miAppProperties.setpageName('Questionnaire Confirmation1');
            spyOn($state, 'go');
            $scope.Edit();
            expect(miStageFactory.getFirstQuestionnaire).toHaveBeenCalled();
        }));
    });


    describe('ConfirmationQuestionController_QuestionTypes_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.confirmationdata'));

        var sce, miCMSFactory, miStageFactory, miUiStagesProgressbar, miAppProperties
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miCMSFactory = $injector.get('miCMSFactory');
                miStageFactory = $injector.get('miStageFactory');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                miAppProperties = $injector.get('miAppProperties');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();

            });
        });

        it('verify the questiontype should be date type', function () {
            UserIdentificationdata = [{ "Type": "DATE_QUESTION", "Answer": "10/10/2015" }]
            spyOn(miAppProperties, 'getQuestionnairesQuestionDetails').and.returnValue(UserIdentificationdata);
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miCMSFactory: miCMSFactory, $sce: $sce, miStageFactory: miStageFactory, miAppProperties: miAppProperties });

            expect($scope.answerText[0].Answer).toBe("10/10/2015");

        });
        it('verify the questiontype should be DateTime type', function () {
            UserIdentificationdata = [{ "Type": "DATETIME_QUESTION", "Answer": "10/10/2015 10:30:00 PM" }]
            spyOn(miAppProperties, 'getQuestionnairesQuestionDetails').and.returnValue(UserIdentificationdata);
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miCMSFactory: miCMSFactory, $sce: $sce, miStageFactory: miStageFactory, miAppProperties: miAppProperties });
            expect($scope.answerText[0].Answer).toBe("10/10/2015 10:30:00 PM");

        });
        it('verify the questiontype should be Time type', function () {
            UserIdentificationdata = [{ "Type": "TIME_QUESTION", "Answer": "10:30:00 PM" }]
            spyOn(miAppProperties, 'getQuestionnairesQuestionDetails').and.returnValue(UserIdentificationdata);
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miCMSFactory: miCMSFactory, $sce: $sce, miStageFactory: miStageFactory, miAppProperties: miAppProperties });
            expect($scope.answerText[0].Answer).toBe("10:30:00 PM");

        });

    });

    describe('ConfirmationQuestionController_back()_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.confirmationdata'));
        var sce, miStageFactory, miUiStagesProgressbar
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miStageFactory = $injector.get('miStageFactory');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();

            });
        });
        //spec to track that spy created on miStageFactory.getNextStage was called
        it('ensure getPreviousStage called when success with Identification Page', inject(function () {
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "CHOICE_SELECTION" });
            });
            spyOn($state, 'go');
            $scope.back();
            expect(miStageFactory.getPreviousStage).toHaveBeenCalled();
        }));
        it('ensure getPreviousStage called when failed with Error Page', inject(function () {
            $controller('ConfirmationQuestionCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.back();
            expect(miStageFactory.getPreviousStage).toHaveBeenCalled();
        }));
    });
});