﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('resourceCtrl',
    function (
        $filter,
        $scope,
        $rootScope,
        $state,
        ENV,
        miAppProperties,
        miLocale,
        cfpLoadingBar,
        miComponentRoute,
        miMoiProperties,
        miValidation,
        miResourceProperties,
        miResourceDataFactory,
        miUpdateStageService,
        miStageFactory,
        miAssignmentUpdateFactory,
        miAppointmentService,
        miUiStagesProgressbar,
        miMoiFactory,
        miAppointmentsSlotFactory,
        miWorkAssignmentFactory,
        miGetMoiListFactory) {
        $rootScope.canLoad = true;
        $scope.isRecordFound = true;
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        $scope.placeholder = $filter('translate')('_CITYSTATEZIP_');
        $scope.moiType = miMoiProperties.getmoiType();
        $rootScope.currentResourceData = miAppProperties.getResourceDataList();

        $scope.maxNumberStar = 5;
        $scope.requestSent = false;

        //getting orgcode 
        //It will work in case of back.  By this it will highlight the selected resource
        $scope.moiOrgId = miAppProperties.assignmentDTO.getMoiOrgID();

        var resourceGroup = miMoiProperties.getResourceGroup();
        if ($rootScope.currentResourceData) {
            if (resourceGroup === ENV.MOIGROUPTYPE) {
                //it is selected resource data which we shows as selected in case of back.
                $scope.selectedResourceData = $filter('filter')($rootScope.currentResourceData, { WORKGRP_ID: $scope.moiOrgId })[0];
            }
            else {
                //it is selected resource data which we shows as selected in case of back.
                $scope.selectedResourceData = $filter('filter')($rootScope.currentResourceData, { ORG_ID: $scope.moiOrgId })[0];
            }
        }

        //if (!$scope.selectedResourceData) {
        if ($rootScope.currentResourceData.length === 0) {
            $scope.selectedResourceData = $rootScope.SelectedResourc;

        }
        if (miMoiProperties.getresourcePostalCode()) {
            $scope.searchtext = miMoiProperties.getresourcePostalCode();
        }


        //Code to set and get the user define postal code for searching resources
        //It will help if assignment having postal code and user is searching resource with different postal code
        //Then in case of back it will retain the postal code entered by user
        if (miMoiProperties.getUserDefinedResourcePostalCode() == "")
        {
            $scope.searchtext = "";
        }
        else if (!miMoiProperties.getUserDefinedResourcePostalCode()) {
            //Set the search text value if appointment is for appraiser and assignmetn has zip code exist
            if (miAppProperties.getappointmentType() != ENV.APPOINTMENTTYPE_ADJUSTER) {
                var assignmentresult = miAppProperties.getAssignmentData();
                var zipCode = assignmentresult.data.moiDetailsFilterDTO ? assignmentresult.data.moiDetailsFilterDTO.zipCode : ENV.NULL_VALUE
                if (zipCode)
                    $scope.searchtext = zipCode;
                else {
                    $scope.searchtext = "";
                    miMoiProperties.setUserDefinedResourcePostalCode("");
                }
            }
            else {
                $scope.searchtext = "";
            }
        }
        else {
            $scope.searchtext = miMoiProperties.getUserDefinedResourcePostalCode();
        }
        //End of code to set and get user define postal code for searching resources

        var span = 0;
        var index = 0;
        var UIResourceModel = {};
        UIResourceModel.Data = [];
        UIResourceModel.VisibleIndex = -1;
        UIResourceModel.Span = ENV.PAGESIZE
        $scope.UIResourceModel = UIResourceModel;

        if (miAppProperties.getappointmentType() === ENV.APPOINTMENTTYPE_ADJUSTER) {
            if ($scope.selectedResourceData)
                $scope.RESOURCELOOKUPHEADER = $filter('translate')('_ADJUSTERLOCATIONHEADERSELECTED_');
            else
                $scope.RESOURCELOOKUPHEADER = $filter('translate')('_ADJUSTERLOCATIONHEADER_');
        }
        else {
            if ($scope.selectedResourceData)
                $scope.RESOURCELOOKUPHEADER = $filter('translate')('_APPRAISERLOCATIONHEADERSELECTED_');
            else
                $scope.RESOURCELOOKUPHEADER = $filter('translate')('_RESOURCELOOKUPHEADER' + miMoiProperties.getmoiType() + '_');
        }

        //if (miAppProperties.getappointmentType() === ENV.APPOINTMENTTYPE_ESTIMATOR) {
        $scope.RESOURCELOOKUPONSINGLEMOIDIMESSAGE = $filter('translate')('_RESOURCELOOKUPONSINGLEMOIDIMESSAGE_');
        $scope.RESOURCELOOKUPONSINGLEMOISHOPMESSAGE = $filter('translate')('_RESOURCELOOKUPONSINGLEMOISHOPMESSAGE_');
        //}
        $scope.getArray = function (number) {
            var arrayOfStar = []
            for (var count = 0; count < number; count++) {
                arrayOfStar.push(count);
            }
            return arrayOfStar;
        }

        ////
        $scope.appendNextTenResources = function (resourcedata) {
            if (resourcedata) {
                if (resourcedata.length - index > UIResourceModel.Span) {
                    span = UIResourceModel.Span;
                }
                else {
                    span = resourcedata.length - index;
                    $scope.enableShowMore = false;
                }

                var displayStartIndex = UIResourceModel.VisibleIndex + 1;
                for (index = displayStartIndex; index < displayStartIndex + span; index++) {
                    UIResourceModel.Data.push(resourcedata[index]);
                }
                UIResourceModel.VisibleIndex = index - 1;
            }
        }

        $scope.callResourceLookUp = function (GroupResource) {
            cfpLoadingBar.start();
            var resourchSearchCriteria = miResourceProperties.getResourceSearchCriteria();
            resourchSearchCriteria.ResourceId = null;
            miResourceDataFactory.GetResourcesOrGroup(resourchSearchCriteria, GroupResource)
            .then(function (resourcesresponse) {
                cfpLoadingBar.complete();
                if (resourcesresponse.route) {
                    $state.go(miComponentRoute.getComponentroute(resourcesresponse.route));
                } else {
                    $rootScope.currentResourceData = resourcesresponse.data;
                    miAppProperties.setResourceDataList(resourcesresponse.data);
                    $scope.appendNextTenResources($rootScope.currentResourceData);
                    $scope.UIResourceModel = UIResourceModel;
                    $scope.ShowNoRecordLabel();
                }
            })
        }

        $rootScope.showMore = function () {
            ga('send', 'event', 'Utility', 'Button click', 'Show more resources');
            $scope.appendNextTenResources($rootScope.currentResourceData);
        }

        $scope.Search = function () {
            ga('send', 'event', 'Utility', 'Button click', 'Search');
            var cntrl = angular.element('#uamValidate');
            if (!$scope.searchtext) {
                miResourceProperties.setPostalCode(null);
                miResourceProperties.setTerritoryType(null);
                miResourceProperties.setRadius(null);
                miMoiProperties.setresourcePostalCode(null);
                cntrl.text("");
                cntrl.removeClass('mi-uam-block--alert');                
                miMoiProperties.setUserDefinedResourcePostalCode("");
            }
            else {

                var uam = miValidation.validatePostal($scope.searchtext);
                if (uam == "Valid") {
                    cntrl.text("");
                    cntrl.removeClass('mi-uam-block--alert');
                }
                else {
                    cntrl.text(uam);
                    cntrl.addClass('mi-uam-block--alert');
                    return false;
                };

                miResourceProperties.setPostalCode($scope.searchtext);
                miResourceProperties.setTerritoryType(ENV.RADIUS_DESC);
                miResourceProperties.setRadius(ENV.RADIUS);
                miMoiProperties.setresourcePostalCode($scope.searchtext);
                miMoiProperties.setUserDefinedResourcePostalCode($scope.searchtext);
            }
            index = 0;
            UIResourceModel.VisibleIndex = -1;
            UIResourceModel.Data = [];
            $rootScope.currentResourceData = null;
            if (miAppProperties.getappointmentType() === ENV.APPOINTMENTTYPE_ADJUSTER) {
                $scope.callResourceLookUp(ENV.MOIGROUPTYPE);
            }
            else {
                if (miResourceProperties.getResourceType()) //this is for bodyshop
                {
                    $scope.callResourceLookUp(ENV.MOIRESOURCETYPE);
                }
                if (miResourceProperties.getGroupType()) //this is for service center
                {
                    $scope.callResourceLookUp(ENV.MOIGROUPTYPE);
                }
            }

        }

        $scope.ShowNoRecordLabel = function () {
            if ($scope.currentResourceData) {
                if ($scope.currentResourceData.length === 0)
                    $scope.isRecordFound = false;
                else
                    $scope.isRecordFound = true;
            }
            else
                $scope.isRecordFound = false;
        }
        $scope.appendNextTenResources($rootScope.currentResourceData);
        $scope.ShowNoRecordLabel();

        $scope.validatePostal = function () {
            var cntrl = angular.element('#uamValidate');
            cntrl.text("");
            cntrl.removeClass('mi-uam-block--alert');
            
            if ($scope.searchtext) {
                var uam = miValidation.validatePostal($scope.searchtext);
                if (uam == "Valid") {
                    //$scope.Search();
                }
                else {
                    cntrl.text(uam);
                    cntrl.addClass('mi-uam-block--alert');
                };
            }
        }

        $scope.updateAssignment = function ($event, resourceData) {
            ga('send', 'event', 'Functional', 'Div click', 'Selected resource');
            if (!$scope.requestSent) {
                $scope.requestSent = true;
                $scope.activeItem = resourceData;
                $rootScope.SelectedResourc = resourceData;
                cfpLoadingBar.start();
                //Check schedule appointment flow in case of adjuster
                if (miAppProperties.getappointmentType() === ENV.APPOINTMENTTYPE_ADJUSTER) {

                    // set appropriate resource id for work group id 
                    miAppProperties.assignmentDTO.setMoiOrgID(resourceData.WORKGRP_ID);
                    var assignmentresult = miAppProperties.getAssignmentData();               

                    var getResourceParameter = {
                        data: {
                            moiType: miMoiProperties.getmoiType(), resourceCode: resourceData.ResourceCode
                        }
                    };

                    //Retrieves resource specific information
                    miWorkAssignmentFactory.getResourceDetails(getResourceParameter)
                                              .then(function (resourceresult) {
                                                  if (resourceresult.route) {
                                                  cfpLoadingBar.complete();
                                                      $state.go(miComponentRoute.getComponentroute(resourceresult.route));
                                                  }
                                                  else {
                                                      var startDate = $filter('date')($filter('date')(new Date(), ENV.ISO_DATETIME_FORMAT), ENV.ISO_DATETIME_FORMAT, miAppProperties.getResourceData().UtcOffset.replace(':', '')) +miAppProperties.getResourceData().UtcOffset;
                                                      //call search appoitntment in case of apointment type as adjuster
                                                      miAppointmentsSlotFactory.getAppointments(miAppProperties.getorgcode(), miLocale.getLocaleCode(), resourceData.ResourceCode, startDate, miAppProperties.getappointmentType(), miAppProperties.getcontextid())
                                                      .then(function (result) {
                                                          cfpLoadingBar.complete();
                                                          if (result.route) {
                                                              //Route to Error page 
                                                              $state.go(miComponentRoute.getComponentroute(result.route));
                                                          }
                                                          else {
                                                              //Route to schedule Appointment page 
                                                              $state.go(miComponentRoute.getComponentroute(ENV.APPOINTMENT_CONSTANT));
                                                          }
                                                      });
                                                  }

                                              });
                }
                else {

                    miAppProperties.assignmentDTO.setMethodOfInspection(miMoiProperties.getmoiType());
                    // set appropriate resource id for diffrent MOIs
                    if (miAppProperties.assignmentDTO.methodOfInspection === ENV.MOITYPE_DI || miAppProperties.assignmentDTO.methodOfInspection === ENV.MOITYPE_SC) {
                        miAppProperties.assignmentDTO.setMoiOrgID(resourceData.WORKGRP_ID);
                    }
                    else {
                        miAppProperties.assignmentDTO.setMoiOrgID(resourceData.ORG_ID);
                    }
                    var assignmentData = miAppProperties.getAssignmentData();
                    miAssignmentUpdateFactory.UpdateAssignment(miAppProperties.assignmentDTO, miAppProperties.getcontextid(), miAppProperties.getorgcode(), assignmentData.data.assignmentDocId, miLocale.getLocaleCode())
                .then(function (updateassignmentresponse) {
                    if (updateassignmentresponse.route) {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(updateassignmentresponse.route));
                    }
                    else {
                        miMoiFactory.moiPageDecision(ENV.MOI_PAGE_CONSTANT)
                                             .then(function (moipageresponse) {
                                                 if (moipageresponse.route) {
                                                     cfpLoadingBar.complete();
                                                     $state.go(miComponentRoute.getComponentroute(moipageresponse.route));
                                                 }
                                                 else {
                                                     miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                                                        .then(function (updatestageresponse) {
                                                            if (updatestageresponse.route) {
                                                                cfpLoadingBar.complete();
                                                                $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                                                            }
                                                            else {
                                                                miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                                   .then(function (nextstageresponse) {
                                                                       if (nextstageresponse.route) {
                                                                           cfpLoadingBar.complete();
                                                                           $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                                       }
                                                                   })
                                                            }
                                                        });

                                                 }
                                             });

                    }
                });
                }
            }
        }

        $scope.back = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Back');
            cfpLoadingBar.start();

            if (miAppProperties.getappointmentType() === ENV.APPOINTMENTTYPE_ADJUSTER) {
                cfpLoadingBar.complete();
                $state.go(miComponentRoute.getComponentroute(ENV.ADJUSTER_APPOINTMENT_INFO_CONSTANT));
            }
            else {
                $scope.moidetails = miMoiProperties.getMoiModelArray();
                if ($scope.moidetails.length > 0) {
                    cfpLoadingBar.complete();
                    $state.go(miComponentRoute.getComponentroute(ENV.MOI_PAGE_CONSTANT));
                }
                else {
                    miGetMoiListFactory.GetMoiList()
                                .then(function (moiresult) {
                                    cfpLoadingBar.complete();
                                    if (moiresult.route) {
                                        $state.go(miComponentRoute.getComponentroute(moiresult.route));
                                    }
                                });
                }
            }
        }
    });
}(angular));