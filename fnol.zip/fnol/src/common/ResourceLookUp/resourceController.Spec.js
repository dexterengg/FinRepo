﻿describe('MFNOL AngularJS Controller (Resource Controller)', function () {

    var $httpBackend, $scope, ctrl, _miResourceProperties_;
    var miResourceData, $state, $controller, $filter, $q, miResourceDataFactory, $state;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: "",
        isSupportable: false,
        isEditablefalse: false,
        isEditabletrue: true,
        ResourceData: 'fakeData',
        AssignmentType: "Estimator",
        resourceGroup: "resourceGroup"
    };

    var searchCriteria = {
        CoCode: "M2"

    };
    var response =
    {

    };

    // Mocked Service
    angular.module('mock.resourcedata', [])
		.factory('miAppProperties', function ($q) {
		    var constant = {};
		    constant.assignmentDTO = {};

		    constant.getappointmentType = function () {
		        return expectedDetail.AssignmentType;
		    };

		    constant.gettheme = function () {
		        return expectedDetail.theme;// "M2";
		    };
		    constant.getorgcode = function () {
		        return expectedDetail.orgcode;
		    };
		    constant.getanimationclass = function () {
		        return expectedDetail.animationclass;
		    };
		    constant.getlanguage = function () {
		        return expectedDetail.language;
		    };
		    constant.getDocID = function () {
		        return expectedDetail.DocID;
		    };
		    constant.gettotalNumOfStages = function () {
		        return expectedDetail.totalNumOfStages;
		    };
		    constant.getstageUiOrder = function () {
		        return expectedDetail.stageUiOrder;
		    };
		    constant.getResourceData = function () {
		        return expectedDetail.ResourceData;
		    };

		    constant.setappointmentType = function (appointmentType) {
		        expectedDetail.AssignmentType = appointmentType;
		    };
		    constant.getResourceDataList = function () {
		        return expectedDetail.ResourceData;
		    };

		    constant.setstatuscode = function (statuscode) {
		    };
		    constant.setAssignmentData = function (AssignmentData) { };
		    constant.assignmentDTO.setMethodOfInspection = function (methodOfInspection) { };
		    constant.assignmentDTO.setMoiOrgID = function (moiOrgID) { };
		    constant.assignmentDTO.getMoiOrgID = function () { return "fake-MoiOrgI" };
		    constant.getstatuscode = function () {
		        return "fake-StatusCode";
		    };
		    constant.getCurrentQuestion = function () {
		        return currentQuestion;
		    };
		    constant.setResourceGroup = function (resourceGroup) {
		        expectedDetail.resourceGroup = resourceGroup;
		    };
		    constant.getResourceGroup = function () {
		        return expectedDetail.resourceGroup;
		    }
		    constant.getstageName = function () {
		        return "IDENTIFICATION";
		    };
		    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
		    constant.fetch = function () {
		        var mockUser = "M2";
		        return $q.when(mockUser);
		    };

		    // other stubbed methods

		    return constant;
		});
    angular.module('mock.resourcedata', [])
		.factory('miMoiProperties', function ($q) {
		    var constant = {};
		    
		    constant.setResourceGroup = function (resourceGroup) {
		        expectedDetail.resourceGroup = resourceGroup;
		    };
		    constant.getResourceGroup = function () {
		        return expectedDetail.resourceGroup;
		    }
		   
		    // other stubbed methods

		    return constant;
		});
    describe('ResourceController Test for currenttheme', function () {

        beforeEach(module('mi.mfnol.web'));
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.resourcedata'));

        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            $scope = $rootScope.$new();
            $controller = _$controller_;
            $controller = $controller('resourceCtrl', {
                $scope: $scope,
                miAppProperties: _miAppProperties_
            });

        }));

        it('erensure current theme is not null', function () {
            expect($scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect($scope.currtheme).toBe(expectedDetail.theme);
        });
        it('time Question Controll  ensure animation class is not null', function () {
            expect($scope.pageClass).not.toBe(null);
        });
        it('ensure animation class is page-main', function () {
            expect($scope.pageClass).toBe(expectedDetail.animationclass);
        });
    });

    describe('Resourcecontroller_miUiStagesProgressbar_Service_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.resourcedata'));
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                miMoiProperties = $injector.get('miMoiProperties');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });
        //spec to track that spy created on miUiStagesProgressbar.changeUiStage was called
        it('should call miUiStagesProgressbar changeUiStage when called', inject(function () {
            $controller('resourceCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            expect(miUiStagesProgressbar.changeUiStage).toHaveBeenCalled();
        }));
        it('verify the moiType should not be null', inject(function (miMoiProperties) {
            miMoiProperties.setmoiType("NSDO");
            $controller('resourceCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            expect($scope.moiType).toBe("NSDO");
        }));
        it('verify the resourcedata should not be null', inject(function (miMoiProperties) {
            $controller('resourceCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            expect($rootScope.currentResourceData).toBe("fakeData");
        }));
    });
    describe('Resource_Controller_getArray()_function_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.resourcedata'));
        var miValidation; var testResponse = {
            route: '', data:
                   {
                       "ResourceName": "gtes",
                       "ResourceType": "",
                       "WORKGRP_ID": "403876",
                       "ResourceCode": "TEST1211",
                       "ADDRESS": "Addr1:9970 Carroll Canyon Road, Addr2:, City:San Diego, state:CA, Zipcode:92131",
                       "CONTACT": null,
                       "Street1": "9970 Carroll Canyon Road",
                       "Street2": "",
                       "City": "San Diego",
                       "StateProvince": "CA",
                       "STATE_NAME": "California",
                       "PostalCode": "92131",
                       "GEOX": "32.89321370",
                       "GEOY": "-117.06763980",
                       "Country": "US",
                       "Phone": "",
                       "Fax": "",
                       "Email": "",
                       "TERRITORY_DEFINITION": "RADIUS",
                       "TERRITORY": "",
                       "EXPERTISE": "Auto, CAT",
                       "DistanceNum": "",
                       "LAST_PROFILE_UPDATED": null,
                       "CAT_FLAG": "Y",
                       "DISPATCH_CENTER_ID": null,
                       "DISPATCH_CENTER_NAME": null,
                       "DISPATCH_CENTER_ORG_CD": null,
                       "CompanyCode": null,
                       "REPAIR_CNT": "",
                       "APPRAISAL_CNT": "",
                       "VALID_INSPECTION_PRIMARY_ADDR": "Y",
                       "Address1": "9970 Carroll Canyon Road<br/>San Diego, CA - California, United States 92131<br/>",
                       "ContactCompilation": "",
                       "TERITORYCOMPILATION": " ",
                       "ALL_EXPERTISE": "Auto,CAT"
                   }
        }
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                miValidation = $injector.get('miValidation');
                miResourceProperties = $injector.get('miResourceProperties');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });

        it('verify getArrary() have been called', inject(function () {
            $controller('resourceCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            $scope.getArray(5);
            expect($scope.getArray).not.toBe(null);
        }));
        it('verify appendNextTenResources() have been called', inject(function () {
            $controller('resourceCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            $scope.appendNextTenResources(testResponse);
            expect($scope.appendNextTenResources).not.toBe(null);
        }));
        it('verify appendNextTenResources() have been called without response data', inject(function () {
            $controller('resourceCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            $scope.appendNextTenResources("fake-resources-data");
            expect($scope.appendNextTenResources).not.toBe(null);
        }));
        it('verify Search() have been called with empty searchText', inject(function () {
            $controller('resourceCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            $scope.searchtext = "";
            miResourceProperties.setResourceType("NSDO");
            miResourceProperties.setGroupType("SCDI");
            $scope.Search();
            expect($rootScope.currentResourceData).toBe(null);
        }));
        it('verify Search() have been called with fake searchText', inject(function () {
            $controller('resourceCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            $scope.searchtext = "fake-searchText";
            $scope.Search();
            expect($rootScope.currentResourceData).not.toBe(null);
        }));

        it('verify Search() have been called with valid uam', inject(function () {
            $controller('resourceCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            $scope.searchtext = "fake-searchText";
            spyOn(miValidation, 'validatePostal').and.returnValue('Valid');
            $scope.Search();
        }));
        it('verify validatePostal() have been called', inject(function () {
            $controller('resourceCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            $scope.searchtext = "fake-searchText";
            $scope.validatePostal();
            expect($rootScope.currentResourceData).not.toBe(null);
        }));

    });
    describe('Resourcecontroller_callResourceLookUp()_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.resourcedata'));
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miResourceDataFactory = $injector.get('miResourceDataFactory');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                miMoiProperties = $injector.get('miMoiProperties');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();

            });
        });

        it('ensure that GetResourcesOrGroup() have been called without error', inject(function () {
            $controller('resourceCtrl', { '$scope': $scope, miResourceDataFactory: miResourceDataFactory });
            spyOn(miResourceDataFactory, 'GetResourcesOrGroup').and.callFake(function () {
                return $.Deferred().resolve({ route: 'fake-Route' });
            });
            $scope.callResourceLookUp("fake-data");
            expect(miResourceDataFactory.GetResourcesOrGroup).toHaveBeenCalled();
        }));

        it('ensure that GetResourcesOrGroup() have been called with error', inject(function () {
            $controller('resourceCtrl', { '$scope': $scope, miResourceDataFactory: miResourceDataFactory });
            spyOn(miResourceDataFactory, 'GetResourcesOrGroup').and.callFake(function () {
                return $.Deferred().resolve({ route: '' });
            });
            $scope.callResourceLookUp("fake-data");
            expect(miResourceDataFactory.GetResourcesOrGroup).toHaveBeenCalled();
        }));

        it('ensure that showMore() have been called', inject(function () {
            $controller('resourceCtrl', { '$scope': $scope, '$rootScope': $rootScope, miResourceDataFactory: miResourceDataFactory });
            spyOn($scope, 'appendNextTenResources').and.callThrough();
            $rootScope.showMore();
            expect($scope.appendNextTenResources).toHaveBeenCalled();
        }));
    });
    describe('Resourcecontroller_updateAssignment()_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        //  beforeEach(module('mock.resourcedata'));
        var testResponse = {
            route: '', data:
                   [{
                       "ResourceName": "gtes",
                       "ResourceType": "",
                       "WORKGRP_ID": "403876",
                       "ORG_ID": "40876",
                       "ResourceCode": "TEST1211",
                       "ADDRESS": "Addr1:9970 Carroll Canyon Road, Addr2:, City:San Diego, state:CA, Zipcode:92131",
                       "CONTACT": null,
                       "Street1": "9970 Carroll Canyon Road",
                       "Street2": "",
                       "City": "San Diego",
                       "StateProvince": "CA",
                       "STATE_NAME": "California",
                       "PostalCode": "92131",
                       "GEOX": "32.89321370",
                       "GEOY": "-117.06763980",
                       "Country": "US",
                       "Phone": "",
                       "Fax": "",
                       "Email": "",
                       "TERRITORY_DEFINITION": "RADIUS",
                       "TERRITORY": "",
                       "EXPERTISE": "Auto, CAT",
                       "DistanceNum": "",
                       "LAST_PROFILE_UPDATED": null,
                       "CAT_FLAG": "Y",
                       "DISPATCH_CENTER_ID": null,
                       "DISPATCH_CENTER_NAME": null,
                       "DISPATCH_CENTER_ORG_CD": null,
                       "CompanyCode": null,
                       "REPAIR_CNT": "",
                       "APPRAISAL_CNT": "",
                       "VALID_INSPECTION_PRIMARY_ADDR": "Y",
                       "Address1": "9970 Carroll Canyon Road<br/>San Diego, CA - California, United States 92131<br/>",
                       "ContactCompilation": "",
                       "TERITORYCOMPILATION": " ",
                       "ALL_EXPERTISE": "Auto,CAT",
                       "assignmentDocId": 34
                   },
                   {
                       "ResourceName": "gtes",
                       "ResourceType": "",
                       "WORKGRP_ID": "403876",
                       "ORG_ID": "40876",
                       "ResourceCode": "TEST1211",
                       "ADDRESS": "Addr1:9970 Carroll Canyon Road, Addr2:, City:San Diego, state:CA, Zipcode:92131",
                       "CONTACT": null,
                       "Street1": "9970 Carroll Canyon Road",
                       "Street2": "",
                       "City": "San Diego",
                       "StateProvince": "CA",
                       "STATE_NAME": "California",
                       "PostalCode": "92131",
                       "GEOX": "32.89321370",
                       "GEOY": "-117.06763980",
                       "Country": "US",
                       "Phone": "",
                       "Fax": "",
                       "Email": "",
                       "TERRITORY_DEFINITION": "RADIUS",
                       "TERRITORY": "",
                       "EXPERTISE": "Auto, CAT",
                       "DistanceNum": "",
                       "LAST_PROFILE_UPDATED": null,
                       "CAT_FLAG": "Y",
                       "DISPATCH_CENTER_ID": null,
                       "DISPATCH_CENTER_NAME": null,
                       "DISPATCH_CENTER_ORG_CD": null,
                       "CompanyCode": null,
                       "REPAIR_CNT": "",
                       "APPRAISAL_CNT": "",
                       "VALID_INSPECTION_PRIMARY_ADDR": "Y",
                       "Address1": "9970 Carroll Canyon Road<br/>San Diego, CA - California, United States 92131<br/>",
                       "ContactCompilation": "",
                       "TERITORYCOMPILATION": " ",
                       "ALL_EXPERTISE": "Auto,CAT",
                       "assignmentDocId": 34
                   }]
        };

        //resourceData = {""};

        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miMoiFactory = $injector.get('miMoiFactory');

                miWorkAssignmentFactory = $injector.get('miWorkAssignmentFactory');
                miAppointmentsSlotFactory = $injector.get('miAppointmentsSlotFactory');
                miAppointmentsSlotFactory.getAppointments
                miAssignmentUpdateFactory = $injector.get('miAssignmentUpdateFactory');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                miAppProperties = $injector.get('miAppProperties');
                miMoiProperties = $injector.get('miMoiProperties');
                miStageFactory = $injector.get('miStageFactory');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();

            });
        });
        it('ensure that updateAssignment() have been called ', inject(function () {
            //$state.current.name = "shell.landing-Question.time-Question";
            miMoiProperties.setmoiType("NSDO");
            miAppProperties.setAssignmentData(testResponse);
            miAppProperties.setResourceDataList(testResponse.data);
            $controller('resourceCtrl', { '$scope': $scope, miAssignmentUpdateFactory: miAssignmentUpdateFactory });
            $scope.requestSent = false;
            spyOn(miAssignmentUpdateFactory, 'UpdateAssignment').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.updateAssignment("fake-data", testResponse.data);

            expect(miAssignmentUpdateFactory.UpdateAssignment).toHaveBeenCalled();
        }));
        it('ensure that moiPageDecision() have been called ', inject(function () {
            //$state.current.name = "shell.landing-Question.time-Question";
            miMoiProperties.setmoiType("SCDI");
            miAppProperties.setResourceDataList(testResponse.data);
            miAppProperties.setAssignmentData(testResponse);
            $controller('resourceCtrl', { '$scope': $scope, miAssignmentUpdateFactory: miAssignmentUpdateFactory, miMoiFactory: miMoiFactory });
            $scope.requestSent = false;
            spyOn(miAssignmentUpdateFactory, 'UpdateAssignment').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miMoiFactory, 'moiPageDecision').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.updateAssignment("fake-data", testResponse.data);

            expect(miMoiFactory.moiPageDecision).toHaveBeenCalled();
        }));
        it('ensure that updateStage have been called ', inject(function () {
            //$state.current.name = "shell.landing-Question.time-Question";
            miMoiProperties.setmoiType("SCDI");
            miAppProperties.setResourceDataList(testResponse.data);
            miAppProperties.setAssignmentData(testResponse);
            $controller('resourceCtrl', { '$scope': $scope, miAssignmentUpdateFactory: miAssignmentUpdateFactory, miMoiFactory: miMoiFactory });
            $scope.requestSent = false;
            spyOn(miAssignmentUpdateFactory, 'UpdateAssignment').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miMoiFactory, 'moiPageDecision').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.updateAssignment("fake-data", testResponse.data);

            expect(miStageFactory.updateStage).toHaveBeenCalled();
        }));

        it('ensure that ShowNoRecordLabel() have been called', inject(function () {
            miMoiProperties.setmoiType("NSDO");
            miAppProperties.setAssignmentData(testResponse);
            miAppProperties.setResourceDataList(testResponse.data);
            $controller('resourceCtrl', { '$scope': $scope, miResourceDataFactory: miResourceDataFactory });
            $scope.currentResourceData = [];
            $scope.ShowNoRecordLabel();
            expect($scope.isRecordFound).toBe(false);
        }));

        it('ensure that miWorkAssignmentFactory() have been called ', inject(function () {
            miMoiProperties.setmoiType("NSDO");
            miAppProperties.setResourceDataList(testResponse.data);
            miAppProperties.setAssignmentData(testResponse);
            miAppProperties.setappointmentType("ADJUSTER");
            $controller('resourceCtrl', { '$scope': $scope, miWorkAssignmentFactory: miWorkAssignmentFactory });
            $scope.requestSent = false;
            spyOn(miWorkAssignmentFactory, 'getResourceDetails').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.updateAssignment("fake-data", testResponse.data);

            expect(miWorkAssignmentFactory.getResourceDetails).toHaveBeenCalled();
        }));

        it('ensure that getAppointments() have been called ', inject(function () {
            //$state.current.name = "shell.landing-Question.time-Question";
            miMoiProperties.setmoiType("NSDO");
            miAppProperties.setResourceDataList(testResponse.data);
            miAppProperties.setAssignmentData(testResponse);
            miAppProperties.setappointmentType("ADJUSTER");
            $controller('resourceCtrl', { '$scope': $scope, miWorkAssignmentFactory: miWorkAssignmentFactory, miAppointmentsSlotFactory: miAppointmentsSlotFactory });
            $scope.requestSent = false;
            spyOn(miWorkAssignmentFactory, 'getResourceDetails').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miAppointmentsSlotFactory, 'getAppointments').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.updateAssignment("fake-data", testResponse.data);

            expect(miAppointmentsSlotFactory.getAppointments).toHaveBeenCalled();
        }));
    });




});