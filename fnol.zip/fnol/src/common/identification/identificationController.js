﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('IdentificationCtrl',
    function (
        $rootScope,
        $scope,
        $state,
        $httpParamSerializer,
        $filter,
        $window,
        Idle,
        miAppProperties,
        cfpLoadingBar,
        ENV,
        miComponentRoute,
        miValidation,
        miLocale,
        miAppFactory,
        miStageFactory) {
        $scope.identificationvars = [];
        $rootScope.infoheader = false;
        $scope.$parent.mainclass = "mi-shell__content mobile-content mobile-content1";
        $scope.$parent.spaceclass = "mobile-card";
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        $scope.customSettings = [];
        miAppProperties.setislandingpage(false);
        $scope.customSettings = miAppProperties.getIdentificationfields().carrierConfigurationResponse.carrierConfiguration.loginfield.group;
        $rootScope.appBodyTheme = "";
        $scope.placeholder = ENV.DATE_FORMAT;
        miAppProperties.ClearUserIdentificationdata();
        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

        var isDatetimeControl = Modernizr.inputtypes.date;
        $scope.isSupportable = function () {
            return isDatetimeControl;
        }
        if ($scope.customSettings.length > 0) {
            var QueWithType = [];
            var fieldValue;
            for (var i = 0; i < $scope.customSettings.length; i++) {

                if ($scope.customSettings[i].field.length > 1) {
                    var orque = [];
                    var orque_placehoder = [];
                    for (var j = 0; j < $scope.customSettings[i].field.length; j++) {
                        orque.push($scope.customSettings[i].field[j].name);
                        orque_placehoder.push($scope.customSettings[i].field[j].ex);
                        var a = { "id": $scope.customSettings[i].field[j].id, "indx": i, "type": $scope.customSettings[i].field[0].type };
                        $scope.identificationvars.push(a);
                    }

                    //Code to get the value against key(if exist) and set it into variable.
                    //It will show the entered value in text box when user will revisit to this page within session.
                    fieldValue = miAppProperties.getUserIdentificationLoginKeyDetails($scope.customSettings[i].field[0].id);

                    var que1 = { id: $scope.customSettings[i].field[0].id, name: orque.join(" or "), type: $scope.customSettings[i].field[0].type, placeholder: $filter('translate')('_Example_') + orque_placehoder.join("" + $filter('translate')('_OR_') + ""), val: fieldValue };
                    QueWithType.push(que1);
                }
                else {
                    //Checking whether field type is date or not
                    //IF date type then we need to store value as date
                    //Otherwise as a normal string
                    if ($scope.customSettings[i].field.type === ENV.DATEOFLOSS_CONSTANT) {

                        if (miAppProperties.getUserIdentificationLoginKeyDetails($scope.customSettings[i].field.id)) {
                            var strDateOfLoss = miAppProperties.getUserIdentificationLoginKeyDetails($scope.customSettings[i].field.id);
                            //replace unicode characters from strDateOfLoss.
                            //It was creating problem in I.E.
                            fieldValue = new Date(strDateOfLoss.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, ''))
                        }

                        if ((!isDatetimeControl) && fieldValue)// incase of date control not supported and date should have value
                            fieldValue = miValidation.getCustomDateTime(fieldValue, $scope.customSettings[i].field.type);

                    }
                    else {
                        fieldValue = miAppProperties.getUserIdentificationLoginKeyDetails($scope.customSettings[i].field.id);
                    }

                    var que1 = { id: $scope.customSettings[i].field.id, name: $scope.customSettings[i].field.name, type: $scope.customSettings[i].field.type, placeholder: $filter('translate')('_Example_') + $scope.customSettings[i].field.ex, val: fieldValue };
                    var a = { "id": $scope.customSettings[i].field.id, "type": $scope.customSettings[i].field.type, "indx": i };
                    $scope.identificationvars.push(a);
                    QueWithType.push(que1);
                }
                //code to clear the stored value.
                fieldValue = "";
            }
            $scope.questionText = $filter('translate')('_IdentificationQues_');
            $scope.answerText = QueWithType;
        }
        //Validation function to validate control 
        $scope.validate = function (key, type) {
            var uam = "";
            var cntrl = angular.element('#' + key);
            cntrl.text("");
            cntrl.removeClass('mi-uam-block--alert');
            var val;
            if (cntrl[0]) {
                val = cntrl.siblings().eq(0).val().trim();
                if (angular.equals(type,ENV.DATEOFLOSS_CONSTANT)) {
                    // if custom validation required
                    if (val == null || angular.equals(val.trim(), "")) {
                        uam = miValidation.validateDateandTime(isDatetimeControl ? new Date(val) : val, ENV.DATE_CONSTANT, !(isDatetimeControl));
                    }
                    else {
                        uam = miValidation.validateDateandTime(isDatetimeControl ? $filter('date')(new Date(val).toISOString(), ENV.DATE_FORMAT) : val, ENV.DATE_CONSTANT, !(isDatetimeControl));
                    }                   
                    if (angular.equals(uam,"Valid")) {
                        cntrl.text("");
                        cntrl.removeClass('mi-uam-block--alert');                       
                        val =new Date(cntrl.siblings().eq(0).val()).toISOString();                       
                        return val;
                    }
                    else {
                        cntrl.text(uam);
                        cntrl.addClass('mi-uam-block--alert');
                        cfpLoadingBar.complete();
                        return false;
                    };
                }
                else {
                    uam = miValidation.validate(val);
                    if (angular.equals(uam,"Valid")) {
                        cntrl.text("");
                        cntrl.removeClass('mi-uam-block--alert');
                        return val;
                    }
                    else {
                        cntrl.text(uam);
                        cntrl.addClass('mi-uam-block--alert');
                        cfpLoadingBar.complete();
                        return false;
                    };
                }
            }
        }

        $scope.gotonext = function (event) {
            if (event.which == 13 || event.keyCode == 13) {
                //code to execute here
                $scope.next();
                return false;
            }
            return true;
        }

        $scope.next = function () {
            ga('send', 'event', 'Navigation', 'Button click', 'Filled policy details and next');
            cfpLoadingBar.start();
            var uam = "";
            var objQueryParams = {};
            $rootScope.identificationkeyvaluepairs = "";
            var identificationDetail = "";
            var index = 0;
            var 
            //checking form validation according to is required
            index = 0;
            for(var identificationIndex = 0; identificationIndex < $scope.identificationvars.length; identificationIndex++) {
                var value = $scope.validate($scope.identificationvars[identificationIndex]["id"], $scope.identificationvars[identificationIndex]["type"]);
                if (angular.equals(value,false)) {
                    return false;
                }
                $rootScope.identificationkeyvaluepairs = $rootScope.identificationkeyvaluepairs + '"' +$scope.identificationvars[identificationIndex]["id"]+ '":"' +value + '",';
                objQueryParams[$scope.identificationvars[identificationIndex]["id"]]= value;
            };
            //end of validation

            //Loop to set all control values to useridentification data list to use it on vehicle summary page
            for (var i = 0; i < $scope.identificationvars.length; i++) {
                var key = $scope.identificationvars[i]["id"];
                var cntrl = angular.element('#' + key);
                var val;
                if (cntrl[0]) {
                    //checking whether control is date type or not
                    //If yes then we are converting it into user's locale string.
                    //After that storing it into userIdentificationdata array to show it on Identification Confirmation page
                    if ($scope.identificationvars[i]["type"] === ENV.DATEOFLOSS_CONSTANT)
                        val = new Date(new Date(cntrl.siblings().eq(0).val()).toISOString()).toLocaleDateString();
                    else
                        val = cntrl.siblings().eq(0).val();

                    miAppProperties.insertUserIdentificationdata(QueWithType[index]["id"], QueWithType[index]["name"], val);

                    //Calling function to set the value of corresponding key into DTO.
                    //It will be in use, when user will revisit to this page in edit mode from confirmation pages.
                    miAppProperties.setUserIdentificationLoginKeyDetails(key, val);

                    index++;
                }
            }

            var queryParam = $httpParamSerializer(objQueryParams);

            miAppFactory.identify(queryParam, miLocale.getLocaleCode())
            .then(function (identificationresponse) {
                if (identificationresponse.route) {
                    cfpLoadingBar.complete();
                    $state.go(miComponentRoute.getComponentroute(identificationresponse.route));
                }
                else {
                    Idle.watch();
                    miAppProperties.setcontextid(identificationresponse.data.contextId);
                    miAppProperties.setflagStage(true);
                    if (identificationresponse.data.status === ENV.CLAIMSTATUS_INPROGRESS) {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(ENV.EXISTINGCLAIM_CONSTANT));
                    }
                    else {
                        miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                          .then(function (nextstageresponse) {
                              cfpLoadingBar.complete();
                              if (nextstageresponse.route) {
                                  $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                              }
                          });
                    }
                }
            });

        }

        $scope.back = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Back');
            cfpLoadingBar.start();
            miStageFactory.getPreviousStage(miAppProperties.getcontextid(), miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                        .then(function (previousresult) {
                            if (previousresult.route) {
                                cfpLoadingBar.complete();
                                $state.go(miComponentRoute.getComponentroute(previousresult.route));
                            }
                            else {
                                cfpLoadingBar.complete();
                                $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
                            }
                        });

        }
    });
}(angular));