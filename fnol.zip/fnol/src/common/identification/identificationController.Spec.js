﻿/// <reference path="../../../tests/jasmine/jasmine.js" />
describe('identificationController', function () {
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: "",
        totalNumOfStages: 6,
        stageUiOrder: 2,
        statuscode: "statuscode",
        stageName: "IDENTIFICATION",
        spaceclass: '',
        identificationHelpDoc: 'https://www-dev.mymitchell.com/tchs/helpfiles/WCmFNOL/MPI/1033/index.htm',
        identificationvars: [],
        mainclass: 'mi-shell__content mobile-content mobile-content1',
        spaceclass: 'mobile-card',
        currtheme: '',
        pageClass: '',
        customSettings: [],
        islandingpage: false,
        Identificationfields: {
            "carrierConfigurationResponse": {
                "carrierConfiguration": {
                    "loginfield": {
                        "xmlns": "http://www.mitchell.com/schemas/fnol/FnolIdFields"
            , "group": [{ "field": { "id": "policyOrLicPlateNum", "ex": "ABC-123", "name": "Licence Plate or Policy Number", "type": "textbox" } }, { "field": { "id": "driverLicenseNum", "ex": 123456789, "name": "DD/REF", "type": "textbox" } }, { "field": { "id": "dateOfLoss", "ex": new Date().getDate(), "name": "Date of Loss", "type": "date" } }]
                        , "culture": "en-US"
                    }
                }
            }
        },
        backbuttoncss: "clickable_Back_Btn",
        isSupportable: false,
        contextid: "fake-contextid"
    };

    angular.module('mock.Identificationdata', [])
   .factory('miAppProperties', function ($q) {
       var constant = {};
       var constant = {};
       constant.gettheme = function () {
           return expectedDetail.theme;
       };
       constant.getorgcode = function () {
           return expectedDetail.orgcode;
       };
       constant.getanimationclass = function () {
           return expectedDetail.animationclass;
       };
       constant.gettotalNumOfStages = function () {
           return expectedDetail.totalNumOfStages;
       };
       constant.getstageUiOrder = function () {
           return expectedDetail.stageUiOrder;
       };

       constant.setstatuscode = function (statuscode) {
           expectedDetail.statuscode = statuscode;
       };
       constant.setislandingpage = function () {
           //expectedDetail.islandingPage = islandingPage;
       };
       constant.setsessionexpired = function () { };
       constant.setcontextid = function () { };
       constant.getcontextid = function () {
           return expectedDetail.contextid;
       };
       constant.setflagStage = function () { };
       constant.getStageOrder = function () { };
       constant.getstageName = function () {
           return expectedDetail.stageName;
       };
       constant.getislandingpage = function () {
           return expectedDetail.islandingpage;
       };
       constant.getIdentificationfields = function () {
           return expectedDetail.Identificationfields;
       };
       constant.ClearUserIdentificationdata = function () {

       };
       constant.getBackButtonCss = function () {
           return expectedDetail.backbuttoncss;
       };
       constant.insertUserIdentificationdata = function (id, name, value) { };
       constant.getUserIdentificationLoginKeyDetails = function (key) {
           return "fakedata";
       };
       constant.setUserIdentificationLoginKeyDetails = function (key, value) {
       };
       // example stub method that returns a promise, e.g. if original method returned $http.get(...)
       constant.fetch = function () {
           var mockUser = "M2";
           return $q.when(mockUser);
       };

       // other stubbed methods

       return constant;
   })
    angular.module('mock.IdentificationdataforSupportable', [])
   .factory('miAppProperties', function ($q) {
       var constant = {};
       var constant = {};
       constant.gettheme = function () {
           return expectedDetail.theme;
       };
       constant.getorgcode = function () {
           return expectedDetail.orgcode;
       };
       constant.getanimationclass = function () {
           return expectedDetail.animationclass;
       };
       constant.gettotalNumOfStages = function () {
           return expectedDetail.totalNumOfStages;
       };
       constant.getstageUiOrder = function () {
           return expectedDetail.stageUiOrder;
       };

       constant.setstatuscode = function (statuscode) {
           expectedDetail.statuscode = statuscode;
       };
       constant.setislandingpage = function () {
           //expectedDetail.islandingPage = islandingPage;
       };
       constant.setsessionexpired = function () { }
       constant.getstageName = function () {
           return expectedDetail.stageName;
       };
       constant.getislandingpage = function () {
           return expectedDetail.islandingpage;
       };
       constant.getIdentificationfields = function () {
           return expectedDetail.Identificationfields;
       };
       constant.ClearUserIdentificationdata = function () {

       };
       constant.getBackButtonCss = function () {
           return expectedDetail.backbuttoncss;
       };
       constant.getUserIdentificationLoginKeyDetails = function (key) {
           return "fakedata";
       };
       // example stub method that returns a promise, e.g. if original method returned $http.get(...)
       constant.fetch = function () {
           var mockUser = "M2";
           return $q.when(mockUser);
       };

       // other stubbed methods

       return constant;
   })
    describe('IdentificationController_Test_Mainclass', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.Identificationdata'));
        var controller, miQuestionService, scope;
        beforeEach(inject(function () {
            inject(function ($injector, $controller, _miAppProperties_) {
                scope = $injector.get('$rootScope').$new();
                miQuestionService = $injector.get('miQues');
                controller = $controller('IdentificationCtrl', {
                    $scope: scope,
                    miQues: miQuestionService,
                    dataShare: _miAppProperties_
                });
            });
        }));

        it('ensure mainclass url is not null', function () {
            expect(scope.mainclass).not.toBe(null);
        });

        it('ensure mainclass is  "mi-shell__content mobile-content mobile-content1"', function () {
            expect(scope.mainclass).toBe(expectedDetail.mainclass);
        });
        it('ensure spaceclass is  "mobile-card"', function () {
            expect(scope.spaceclass).toBe(expectedDetail.spaceclass);
        });

    });
    describe('Identification Controller_Test_Theme', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.Identificationdata'));
        var controller, miQuestionService, scope;
        beforeEach(inject(function () {
            inject(function ($injector, $controller, _miAppProperties_) {
                scope = $injector.get('$rootScope').$new();
                miQuestionService = $injector.get('miQues');
                controller = $controller('IdentificationCtrl', {
                    $scope: scope,
                    miQues: miQuestionService,
                    dataShare: _miAppProperties_
                });
            });
        }));

        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })

        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });
        it('ensure animation class is page-main', function () {
            expect(scope.pageClass).toBe(expectedDetail.animationclass);
        });
        it('ensure back button css is clickable', function () {
            expect(scope.Back_Btn_Class).toBe(expectedDetail.backbuttoncss);
        });
    });
    describe('Identification Controller', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.IdentificationdataforSupportable'));

        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('IdentificationCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));
        it('should return false when called isSupportable()', inject(function () {
            scope.isSupportable();
            expect(expectedDetail.isSupportable).toBe(false);
        }));
    });
    describe('identificationController_Test_CustomSettings', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.Identificationdata'));
        var controller, miQuestionService, scope;
        beforeEach(inject(function () {
            inject(function ($injector, $controller, _miAppProperties_) {
                scope = $injector.get('$rootScope').$new();
                miQuestionService = $injector.get('miQues');
                controller = $controller('IdentificationCtrl', {
                    $scope: scope,
                    miQues: miQuestionService,
                    dataShare: _miAppProperties_
                });
            });
        }));

        it('ensure CustomSettings is not null', function () {
            expect(scope.identificationHelpDoc).not.toBe(null);
        });
    });
    describe('identificationController_Test_Next Method', function () {
        var $controller, $q, dataShare, miService, miLocale;
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.Identificationdata'));
        var controller, miQuestionService, scope;
        beforeEach(inject(function () {
            inject(function ($injector, $controller, _miAppProperties_) {
                scope = $injector.get('$rootScope').$new();
                miQuestionService = $injector.get('miQues');
                $httpBackend = $injector.get('$httpBackend');
                controller = $controller('IdentificationCtrl', {
                    $scope: scope,
                    miQues: miQuestionService,
                    dataShare: _miAppProperties_
                });
            });
        }));

        var queryParam = "driverLicenseNum=123&licensePlate=123&policyNum=123";
        var requestheader = { headers: { 'Authorization': 'bearer v1/wPeUWJuaiMeXvKXW1QumM4qYE73nCkHgIlcAfubkVgVfUMsyeiTIjPJm4p1Dm6CA9Odqr0TSVf0pPv3V7HbXtRdnRQIRRbUa0Y7ni-aAoAUfFzmr2mkEhU__9kjoKSjU1JU03Ktrh1xABUPXSClLfMWVMJ5xL4SOCSGzC2lkSXDY7oY1lJk5J98ie9gNfZDZPVVwHTNtfv13bu32UDanN2EWQWKOB0xRA6FyFbUYNeVr2MoEhVu_kY_gpTJtgTrnzoY5R5SJOEtJ3C6WSYJ_icA_UIzWkHNl6tZInRjZUm16dDg5DywdVVjsRPH7ynaCBol7Cnt72FLQDbD0WMIHkAK6HF1Il0D5FK-bNtqsvzduipQMl55hdzbo74f415PZ6CX_A7P2B_Hyesiub5Mh3wzHRH_7sloTOlR9Sgzv7xmuL2ux8VWUporzO3akJHehx-rid6j4SYQgr6WIi-jZwl_dru8eapAlDyT2egO51-a31KjYV0F7NQvNuhpa_MXLGj9NJZEaYrzK-3klJ8mriqNFI7WHqfC12S1_gRSiYZI' } };

        it('should demonstrate using expect in sequence', inject(function ($http) {
            $httpBackend.expect('GET', 'https://services-dev.mymitchell.com/FNOLWebService/api/fnol/' + "?" + queryParam).respond(200);
            //expect($httpBackend.flush).not.toThrow();
        }));

    });
    describe('IdentificationController Controller_Test_For_gotonext()', function () {
        beforeEach(module('mi.mfnol.web'));
        //var miAppFactory;
        beforeEach(module('mock.Identificationdata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');

                miAppFactory = $injector.get('miAppFactory');
            });
        });
        it('should call gotonext', inject(function () {
            $controller('IdentificationCtrl', { $scope: $scope, $state: $state, miAppFactory: miAppFactory });

            $scope.gotonext('');
            //expect($scope.questionText).not.toBe(null);

        }));
    });

    describe('Identification Controller_next()_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        //var miAppFactory;
        beforeEach(module('mock.Identificationdata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miLocale = $injector.get('miLocale');
                miAppFactory = $injector.get('miAppFactory');
                miStageFactory = $injector.get('miStageFactory');
                miAppProperties = $injector.get('miAppProperties');
                miValidation = $injector.get('miValidation');
                spyOn(angular, 'element').and.callFake(function () {
                    return {
                        "0": {
                            "accessKey": ""
                        },
                        text: function (d) {
                        },
                        removeClass: function (d) {
                        },
                        siblings: function () {
                            return {
                                eq: function (d) {
                                    return {
                                        val: function () {
                                            return "fakeData";
                                        }
                                    }
                                }
                            }
                        },
                        addClass: function (d) {
                        },
                        "context": {
                        },
                        "length": 1
                    };
                });
                var oldDate = Date;
                spyOn(window, 'Date').and.callFake(function () {
                    return new oldDate();
                });
                spyOn(miAppProperties, 'insertUserIdentificationdata').and.callFake(function (a, b, c) {
                });
                spyOn(miAppProperties, 'setUserIdentificationLoginKeyDetails').and.callFake(function (a, b) {
                });
                spyOn(miValidation, 'validateDateandTime').and.callFake(function (a) {
                    return "Valid";
                });
            });
        });
        it('should call miAppFactory.identify with success', inject(function () {
            miLocale.setLocaleCode('fr-FR');
            $controller('IdentificationCtrl', { $scope: $scope, $state: $state, miAppFactory: miAppFactory });
            spyOn(miAppFactory, 'identify').and.callFake(function () {
                return $.Deferred().resolve({ route: "DATETIME_QUESTION" });
            });
            spyOn($state, 'go')
            $scope.next();
            expect(miAppFactory.identify).toHaveBeenCalled();

        }));

        it('should call miAppFactory.identify with success and CLAIMSTATUS_INPROGRESS', inject(function () {
            miLocale.setLocaleCode('fr-FR');
            $controller('IdentificationCtrl', { $scope: $scope, $state: $state, miAppFactory: miAppFactory });
            spyOn(miAppFactory, 'identify').and.callFake(function () {
                return $.Deferred().resolve({
                    data: { status: "IN_PROGRESS" }
                });
            });
            spyOn($state, 'go')
            $scope.next();
            expect(miAppFactory.identify).toHaveBeenCalled();

        }));
        it('should call miAppFactory.identify with route null', inject(function () {
            miLocale.setLocaleCode('fr-FR');
            $controller('IdentificationCtrl', { $scope: $scope, $state: $state, miAppFactory: miAppFactory });
            spyOn(miAppFactory, 'identify').and.callFake(function () {
                return $.Deferred().resolve({ route: "", data: "status:IN_PROGRESS" });
            });
            spyOn($state, 'go')
            $scope.next();
            expect(miAppFactory.identify).toHaveBeenCalled();

        }));
        it('should call getNextStage when next button click', inject(function () {
            miLocale.setLocaleCode('fr-FR');
            $controller('IdentificationCtrl', { $scope: $scope, $state: $state, miAppFactory: miAppFactory });
            spyOn(miAppFactory, 'identify').and.callFake(function () {
                return $.Deferred().resolve({ route: "", data: "status:IN_PROGRESS" });
            });
            spyOn($state, 'go')
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({
                    route: 400
                });
            });
            $scope.next();
            expect(miAppFactory.identify).toHaveBeenCalled();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));

    });
    describe('Identification Controller_For_Back_Functionality', function () {
        beforeEach(module('mi.mfnol.web'));
        //var miAppFactory;
        beforeEach(module('mock.Identificationdata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miLocale = $injector.get('miLocale');
                miAppFactory = $injector.get('miAppFactory');
                miStageFactory = $injector.get('miStageFactory');
            });
        });

        //spec to track that spy created on miStageFactory.getNextStage was called
        it('ensure getPreviousStage called when success with choice selection question type', inject(function () {
            $controller('IdentificationCtrl', { $scope: $scope, $state: $state, miStageFactory: miStageFactory });
            spyOn(miStageFactory, 'getPreviousStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "CHOICE_SELECTION" });
            });
            spyOn($state, 'go');
            $scope.back();
            expect(miStageFactory.getPreviousStage).toHaveBeenCalled();
        }));
    });
});



