﻿describe('MFNOL AngularJS Controller (Appointment Confirmation Controller)', function () {
    var $httpBackend, $scope;
    var $controller, $q, $state, $filter, miUiStagesProgressbar;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US", 
        DocID: "",
        totalNumOfStages: "5",
        stageUiOrder: "2",
        resource: 'm2dis10',
        ResourceData: [],
        AssignmentData: {
            data: {
                adjusterApptReqFlag: false, assignmentDocId: 100008325203, assignmentType: "ORIGINAL_ESTIMATE", estApptReqFlag: true
            },moiOrgId:1800666, moiType:"SCDI",preferedMOIList:null,resourceCode:"762345"
        },
        appointmentType: "ESTIMATOR",
        contextid: 12324,
        customError:"fake-Error",
        locationId: "fakeId",
        //appointmentType: "fake-appointment",
        startDateTime: "fake-StartDate"
    }                                                                                                                                                                                                                           ;
    // Mocked Service
    angular.module('mock.appointmentdata', [])
    .factory('miAppProperties', function ($q) {
        var constant = {};
        constant.appointmentDTO = {};
        constant.gettheme = function () {
            return expectedDetail.theme;// "M2";
        };
        constant.getResourceData = function () {
            return expectedDetail.ResourceData;
        };
        constant.getAssignmentData = function () {
            return expectedDetail.AssignmentData;
        };
        constant.getappointmentType = function () {
            return expectedDetail.appointmentType;
        };
        constant.setappointmentType = function (appointmentType) {
            expectedDetail.appointmentType = appointmentType;
        };
        constant.getcontextid = function () {
            return expectedDetail.contextid;
        };
        constant.getorgcode = function () {
            return expectedDetail.orgcode;
        };
        constant.getanimationclass = function () {
            return expectedDetail.animationclass;
        };
        constant.getlanguage = function () {
            return expectedDetail.language;
        };
        constant.getDocID = function () {
            return expectedDetail.DocID;
        };
        constant.gettotalNumOfStages = function () {
            return expectedDetail.totalNumOfStages;
        };
        constant.getstageUiOrder = function () {
            return expectedDetail.stageUiOrder;
        };
        constant.setstatuscode = function (statuscode) {
        };
        constant.getstatuscode = function () {
            return "fake-StatusCode";
        };
        constant.setCustomError = function (customError) {
            expectedDetail.customError=customError
        };
        constant.getCustomError = function () {
            return expectedDetail.customError;
        };
        constant.appointmentDTO.setLocationId = function (locationId) {
            expectedDetail.locationId = locationId;
        };
        constant.appointmentDTO.setAppointmentType = function (appointmenttype) {
            expectedDetail.appointmentType = appointmenttype;
        };
        constant.appointmentDTO.setStartDateTime = function (startDateTime) {
            expectedDetail.startDateTime = startDateTime;
        };
        constant.setcoStageId = function (costageId) { }
        constant.getcoStageId=function(){
            return "fake-Id";
        }
        
        // example stub method that returns a promise, e.g. if original method returned $http.get(...)
       
        // other stubbed methods
        return constant;
    });
    
    //beforeEach(module('mi.mfnol.web'));
    describe('appointment Confirmation Controller Test for current theme and page class', function () {
         beforeEach(module('mi.mfnol.web'));
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.appointmentdata'));
        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            $scope = $rootScope.$new();
            $controller = _$controller_;
            $controller = $controller('AppointmentSummaryCtrl', {
                $scope: $scope,
                miAppProperties: _miAppProperties_
            });
        }));
        it('ensure current theme is not null', function () {
            expect($scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect($scope.currtheme).toBe(expectedDetail.theme);
        });
        it('Open Question Controll ensure animation class is not null', function () {
            expect($scope.pageClass).not.toBe(null);
        });
        it('ensure animation class is page-main', function () {
            expect($scope.pageClass).toBe(expectedDetail.animationclass);
        });
    });
    describe('Appointment Confirmation Controller confirm functionality', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.appointmentdata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miBookAppointmentFactory = $injector.get('miBookAppointmentFactory');
                miAppProperties = $injector.get('miAppProperties');
                miStageFactory = $injector.get('miStageFactory');
            });
        });
        it('should call miBookAppointmentFactory.BookAppointment() with Error Page on confirm button', inject(function () {
            $controller('AppointmentSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce });
            spyOn(miBookAppointmentFactory, 'BookAppointment').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.Confirm(true);
            expect(miBookAppointmentFactory.BookAppointment).toHaveBeenCalled();
        }));
        it('should call update stage service with failure response on confirm button when appointmentType is adjuster', inject(function () {
            miAppProperties.setappointmentType("ADJUSTER");
            $controller('AppointmentSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miBookAppointmentFactory: miBookAppointmentFactory });
            $scope.AssignmentData.data.adjusterApptReqFlag = true;

            spyOn(miBookAppointmentFactory, 'BookAppointment').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.Confirm(true);
            expect(miBookAppointmentFactory.BookAppointment).toHaveBeenCalled();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
        }));
        ('should call update stage service with succuess response on confirm button when appointmentType is adjuster', inject(function () {
            miAppProperties.setappointmentType("ADJUSTER");
            $controller('AppointmentSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miBookAppointmentFactory: miBookAppointmentFactory });
            $scope.AssignmentData.data.adjusterApptReqFlag = true;

            spyOn(miBookAppointmentFactory, 'BookAppointment').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn($state, 'go');
            $scope.Confirm(true);
            expect(miBookAppointmentFactory.BookAppointment).toHaveBeenCalled();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
        }));
        it('should call adjuster informatin page on confirm button', inject(function () {
            miAppProperties.setappointmentType("ESTIMATOR");
            $controller('AppointmentSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miBookAppointmentFactory: miBookAppointmentFactory });
            $scope.AssignmentData.data.adjusterApptReqFlag = true;
            spyOn(miBookAppointmentFactory, 'BookAppointment').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn($state, 'go');
            $scope.Confirm(true);
            expect(miBookAppointmentFactory.BookAppointment).toHaveBeenCalled();
            expect($state.go).toHaveBeenCalledWith('shell.landing-Question.AdjusterAppointmentInfo');
        }));
        
    });
    describe('Appointment Confirmation Controller confirm functionality', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.appointmentdata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miBookAppointmentFactory = $injector.get('miBookAppointmentFactory');
                miStageFactory = $injector.get('miStageFactory');
                miAppProperties = $injector.get('miAppProperties');
            });
        });
        it('ensure error description should be display on confirm button', inject(function () {
            $controller('AppointmentSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miBookAppointmentFactory: miBookAppointmentFactory, miStageFactory: miStageFactory });
            $scope.AssignmentData.data.adjusterApptReqFlag = false;
            expectedDetail.customError = "fake-Error"
            spyOn(miBookAppointmentFactory, 'BookAppointment').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn($state, 'go');
            $scope.Confirm(true);
            expect(miBookAppointmentFactory.BookAppointment).toHaveBeenCalled();
            expect($scope.errDesc).toBe("fake-Error");
        }));
        it('should call Error page on confirm button with updatestage failure response', inject(function () {
            $controller('AppointmentSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miBookAppointmentFactory: miBookAppointmentFactory, miAppProperties: miAppProperties, miStageFactory: miStageFactory });
            $scope.AssignmentData.data.adjusterApptReqFlag = false;
            miAppProperties.setCustomError(false);
            spyOn(miBookAppointmentFactory, 'BookAppointment').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn($state, 'go');
            $scope.Confirm(true);
            expect(miBookAppointmentFactory.BookAppointment).toHaveBeenCalled();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
            expect($state.go).toHaveBeenCalledWith('shell.Error');
         }));
        it('should call Claim Summary Page on confirm button with updatestage success response', inject(function () {
            $controller('AppointmentSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miBookAppointmentFactory: miBookAppointmentFactory, miAppProperties: miAppProperties, miStageFactory: miStageFactory });
            $scope.AssignmentData.data.adjusterApptReqFlag = false;
            miAppProperties.setCustomError(false);
            spyOn(miBookAppointmentFactory, 'BookAppointment').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn($state, 'go');
            $scope.Confirm(true);
            expect(miBookAppointmentFactory.BookAppointment).toHaveBeenCalled();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
            //expect($state.go).toHaveBeenCalledWith('shell.landing-Question.ClaimSummary');
        }));
    });
    describe('Appointment Confirmation Controller Edit functionality', function () {
        beforeEach(module('mi.mfnol.web'));
        var miAppFactory;
        beforeEach(module('mock.appointmentdata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');               
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miAppointmentsSlotFactory = $injector.get('miAppointmentsSlotFactory');
            });
        });       
        it('should call sce trustAsHtml', inject(function () {
            $controller('AppointmentSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce });
            spyOn($sce, 'trustAsHtml').and.callThrough();
            $scope.getHtml('<h1>Test</h1>');
            expect($sce.trustAsHtml).toHaveBeenCalled();
        }));
        it('should call miAppointmentsSlotFactory.getAppointments() with success on Edit button', inject(function () {
            $controller('AppointmentSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory});
            spyOn(miAppointmentsSlotFactory, 'getAppointments').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            $scope.Edit();
            expect(miAppointmentsSlotFactory.getAppointments).toHaveBeenCalled();
        }));
        it('should call miAppointmentsSlotFactory getAppointments', inject(function () {
            $controller('AppointmentSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory, miAppointmentsSlotFactory: miAppointmentsSlotFactory });
            spyOn(miAppointmentsSlotFactory, 'getAppointments').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.Edit();
            expect(miAppointmentsSlotFactory.getAppointments).toHaveBeenCalled();
        }));
    });

    describe('Appointment Confirmation Controller back functionality', function () {
        beforeEach(module('mi.mfnol.web'));
        var miAppFactory;
        beforeEach(module('mock.appointmentdata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miAppointmentsSlotFactory = $injector.get('miAppointmentsSlotFactory');
            });
        });
        it('should call miAppointmentsSlotFactory.getAppointments() with success on Edit button', inject(function () {
            $controller('AppointmentSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miAppFactory: miAppFactory });
            spyOn($state, 'go');
            $scope.back();
            expect($state.go).toHaveBeenCalledWith('shell.landing-Question.ScheduleAppointment');
        }));

    });
});
