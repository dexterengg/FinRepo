﻿
(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('AppointmentSummaryCtrl',
    function (
        $rootScope,
        $scope,
        $state,
        $sce,
        $filter,
        miAppProperties,
        ENV,
        miLocale,
        miComponentRoute,
        cfpLoadingBar,
        miUiStagesProgressbar,
        miCMSFactory,
        miStageFactory,
        miAppFactory,
        miAppointmentsSlotFactory,
        miBookAppointmentFactory,
        miMoiProperties) {

        $scope.btnConfirmEnable = true;
        $scope.errCode = false;
        miAppProperties.setCustomError(false);
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();

        $scope.questionText = $filter('translate')('_AppointmentConfirmationHeading_');
        $scope.ResourceData = miAppProperties.getResourceData();
        $scope.AssignmentData = miAppProperties.getAssignmentData();
        if (miAppProperties.getappointmentType() === ENV.APPOINTMENTTYPE_ADJUSTER) {
            miAppProperties.appointmentDTO.setLocationId($scope.ResourceData.WORKGRP_ID);
            miAppProperties.appointmentDTO.setResourceCode($scope.ResourceData.ResourceCode)
        }

        if (miAppProperties.getappointmentType() === ENV.APPOINTMENTTYPE_ESTIMATOR) {
            miAppProperties.appointmentDTO.setLocationId($scope.AssignmentData.data.moiOrgId);
            miAppProperties.appointmentDTO.setResourceCode($scope.AssignmentData.data.resourceCode)
        }

        miAppProperties.appointmentDTO.setAppointmentType(miAppProperties.getappointmentType());
        miAppProperties.appointmentDTO.setStartDateTime($rootScope.appointmentUtcDateString);


        $scope.getHtml = function (html) {
            return $sce.trustAsHtml(html);
        };

        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        if ($rootScope.appointmentDateHeader === $filter('translate')('_Today_') || $rootScope.appointmentDateHeader === $filter('translate')('_Tomorrow_')) {
            $rootScope.appointmentDateHeader = $rootScope.appointmentDateHeader + ", " + $filter('date')(new Date($rootScope.appointmentDate + " " + ENV.DEFAULT_TIME), ENV.FILTER_FULLDATE_FORMAT);
        }
        $scope.appointmentTimezone = miAppProperties.getResourceData().TimeZone;
        $scope.Confirm = function (isclick) {
            ga('send', 'event', 'Decision', 'Button click', 'Confirm');
            if (isclick) {
                cfpLoadingBar.start();
                miBookAppointmentFactory.BookAppointment(miAppProperties.appointmentDTO, miAppProperties.getcontextid(), miAppProperties.getorgcode(), $scope.AssignmentData.data.assignmentDocId ? $scope.AssignmentData.data.assignmentDocId : 0, miLocale.getLocaleCode())
                      .then(function (appointmentesresponse) {                          
                          if (appointmentesresponse.route) {
                              cfpLoadingBar.complete();
                              $state.go(miComponentRoute.getComponentroute(appointmentesresponse.route));
                          }
                              // display the error message when appointment slot is not available which the user want to select and error code=11 comes 
                          else if (appointmentesresponse.data.resStatus != ENV.SUCCESS) {
                              cfpLoadingBar.complete();
                              $scope.questionText = $filter('translate')('_ScheduleAppointmentErrorMessage_');
                              $scope.btnConfirmEnable = false;
                              $scope.errCode = true;
                              if (miAppProperties.getCustomError()) {
                                  $scope.errDesc = miAppProperties.getCustomError();
                              }
                              else {
                                  $scope.errDesc = $filter('translate')('_AppointmentBookingErrorMessage_');
                                }
                             
                          }

                              //route the adjuster info predefined page when adjuster appointment is required
                          else if ($scope.AssignmentData.data.adjusterApptReqFlag) {
                              if (miAppProperties.getappointmentType() === ENV.APPOINTMENTTYPE_ADJUSTER) {
                                  miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                             .then(function (updatestageresponse) {

                                 if (updatestageresponse.route) {
                                     cfpLoadingBar.complete();
                                     $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                                 }
                                 else {
                                     miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                                                   .then(function (nextstageresponse) {
                                                                                       if (nextstageresponse.route) {
                                                                                           cfpLoadingBar.complete();
                                                                                           $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                                                       }
                                                                                   })
                                 }
                             });
                              }

                              if (miAppProperties.getappointmentType() === ENV.APPOINTMENTTYPE_ESTIMATOR) {
                                  cfpLoadingBar.complete();
                                  miMoiProperties.setResourceSkipped(false);
                                  $rootScope.moiSkipped = false;
                                  miMoiProperties.setresourcePostalCode(null);
                                  // $rootScope.setToDefault();
                                  $state.go(miComponentRoute.getComponentroute(ENV.ADJUSTER_APPOINTMENT_INFO_CONSTANT));
                              }

                          }

                              // route the claim summary page when appointment is booked successfully and no adjuster appointment is required.
                          else {
                              miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                              .then(function (updatestageresponse) {
                                  if (updatestageresponse.route) {
                                      cfpLoadingBar.complete();
                                      $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                                  }
                                  else {
                                      miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                            .then(function (nextstageresponse) {
                                                if (nextstageresponse.route) {
                                                    cfpLoadingBar.complete();
                                                    $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                }
                                            })
                                  }
                              });
                          }
                      });
            }
        }

        $scope.Edit = function () {
            ga('send', 'event', 'Decision', 'Button click', 'Edit');
            $rootScope.isAppointmentEdit = true;
            if (miAppProperties.getappointmentType() === ENV.APPOINTMENTTYPE_ESTIMATOR) {
                cfpLoadingBar.start();
                var assignmentResult = miAppProperties.getAssignmentData();               
                var startDate = $filter('date')($filter('date')(new Date(), ENV.ISO_DATETIME_FORMAT), ENV.ISO_DATETIME_FORMAT, miAppProperties.getResourceData().UtcOffset.replace(':', '')) + miAppProperties.getResourceData().UtcOffset;
                //call appointment service
                miAppointmentsSlotFactory.getAppointments(miAppProperties.getorgcode(), miLocale.getLocaleCode(), $scope.ResourceData.ResourceCode, startDate, miAppProperties.getappointmentType(), miAppProperties.getcontextid())
                .then(function (result) {
                    cfpLoadingBar.complete();
                    $rootScope.setToDefault();
                    if (result.route) {
                        //Route to Error page 
                        $state.go(miComponentRoute.getComponentroute(result.route));
                    }
                    else {
                        //Route to schedule Appointment page 
                        $state.go(miComponentRoute.getComponentroute(ENV.APPOINTMENT_CONSTANT));
                    }
                });
            }
            if (miAppProperties.getappointmentType() === ENV.APPOINTMENTTYPE_ADJUSTER) {
                //Route to Resource Controller page 
                $state.go(miComponentRoute.getComponentroute(ENV.RESOURCE_CONSTANT));
            }
        }
        $scope.back = function () {
            $rootScope.isAppointmentEdit = true;
            $state.go(miComponentRoute.getComponentroute(ENV.APPOINTMENT_CONSTANT));
        }

    });
}(angular));