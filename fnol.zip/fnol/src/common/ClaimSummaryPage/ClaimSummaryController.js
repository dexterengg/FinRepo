﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('ClaimSummaryCtrl',
    function (
        $rootScope,
        $scope,
        $state,
        $sce,
        $filter,
        miAppProperties,
        cfpLoadingBar,
        ENV,
        miComponentRoute,
        miQues,
        miUiStagesProgressbar,
        miMoiProperties,
        miLocale,
        miResourceDataFactory,
        miResourceProperties,
        miWorkAssignmentFactory,
        miCMSFactory,
        miAppointmentsSlotFactory) {
        $rootScope.appBodyTheme = "";
        $scope.GetSummaryData = function () {
            $rootScope.ShellTitle = $filter('translate')('_CLAIMSUMMARYHEADER_');
            $scope.currtheme = miAppProperties.gettheme();
            $scope.pageClass = miAppProperties.getanimationclass();          
        }
        $scope.CompleteClaim = function () {
            //mark the context as done.          
            miCMSFactory.deletePolicy(miAppProperties.getcontextid(), ENV.DONECLAIM_STATUS, miLocale.getLocaleCode())
            .then(function (deletepolicyresponse) {
                if (deletepolicyresponse.route) {
                    $state.go(miComponentRoute.getComponentroute(deletepolicyresponse.route));
                }

            })

        }
        var getResourceParameter = {};      
        $scope.claimInfoFound = true;
        $scope.pageReady = false;
        cfpLoadingBar.start();
       
        //Get Assignment Details
        miWorkAssignmentFactory.getWorkAssignmentDetails(miAppProperties.getorgcode(), miAppProperties.getcontextid(), miLocale.getLocaleCode())
        .then(function (assignmentresult) {           
               if (assignmentresult.route) {
                    cfpLoadingBar.complete();
                    $state.go(miComponentRoute.getComponentroute(assignmentresult.route));
                }
               else {                   
                   if (assignmentresult.data.claimNumber) {                     
                        $scope.ClaimSummaryInfo = "<b>" + $filter('translate')('_ClaimSummaryContent_') + "</b>" + "</br></br>" + "<b>" + $filter('translate')('_ClaimNumber_') + "</b>" + "</br>" + assignmentresult.data.claimNumber + "</br></br>";                       
                            //appraiser appointment found
                            if (assignmentresult.data.resourceCode) {
                                getResourceParameter = { data: { moiType: assignmentresult.data.moiType, resourceCode: assignmentresult.data.resourceCode } };
                                //Retrieves resource specific information for appraiser
                                miWorkAssignmentFactory.getResourceDetails(getResourceParameter)
                                                          .then(function (resourceresult) {
                                                              if (resourceresult.route) {
                                                                  cfpLoadingBar.complete();
                                                                  $state.go(miComponentRoute.getComponentroute(resourceresult.route));
                                                              }
                                                              else {                                                            
                                                                  $scope.resourceData = miAppProperties.getResourceData();
                                                                  $scope.ClaimSummaryInfo = $scope.ClaimSummaryInfo + "<b>" + $filter('translate')('_EstimatorAppointment_') + "</b></br>" + $scope.resourceData.ResourceName + "</br>" + $scope.resourceData.Address1;
                                                                  if (assignmentresult.data.estimatorAppt) {
                                                                      $scope.ClaimSummaryInfo = $scope.ClaimSummaryInfo + $filter('date')(assignmentresult.data.estimatorAppt, "fullDate", miAppProperties.getResourceData().UtcOffset.replace(':', '')) + $filter('translate')('_At_') + $filter('date')(assignmentresult.data.estimatorAppt, "shortTime", miAppProperties.getResourceData().UtcOffset.replace(':', '')) + " (" +$scope.resourceData.TimeZone + ")";
                                                                  }
                                                                  if (assignmentresult.data.adjusterAppt) {
                                                                      getResourceParameter = { data: { moiType: ENV.MOITYPE_DI, resourceCode: assignmentresult.data.adjResourceCode } };
                                                                      //Retrieves resource specific information for Adjuster
                                                                      miWorkAssignmentFactory.getResourceDetails(getResourceParameter)
                                                                                                .then(function (adjusterresourceresult) {
                                                                                                    cfpLoadingBar.complete();
                                                                                                    if (resourceresult.route) {
                                                                                                        $state.go(miComponentRoute.getComponentroute(resourceresult.route));
                                                                                                    }
                                                                                                    else {
                                                                                                        $scope.pageReady = true;                                                                                                        
                                                                                                        $scope.GetSummaryData();
                                                                                                        $scope.CompleteClaim();
                                                                                                        $scope.resourceData = miAppProperties.getResourceData();                                                                                                       
                                                                                                        $scope.ClaimSummaryInfo = $scope.ClaimSummaryInfo + "</br></br><b>" + $filter('translate')('_AdjusterAppointment_') + "</b></br>" + $scope.resourceData.ResourceName + "</br>" + $scope.resourceData.Address1 + $filter('date')(assignmentresult.data.adjusterAppt, "fullDate", miAppProperties.getResourceData().UtcOffset.replace(':', '')) + $filter('translate')('_At_') + $filter('date')(assignmentresult.data.adjusterAppt, "shortTime", miAppProperties.getResourceData().UtcOffset.replace(':', '')) + " (" +$scope.resourceData.TimeZone + ")";
                                                                                                    }
                                                                                                })
                                                                  }
                                                                  else {
                                                                      cfpLoadingBar.complete();
                                                                      $scope.pageReady = true;
                                                                      $scope.GetSummaryData();
                                                                      $scope.CompleteClaim();
                                                                  }

                                                              }
                                                          })
                            }
                            else {
                                //appraiser details not  found only adjuster appointment found
                                if (assignmentresult.data.adjusterAppt) {
                                    getResourceParameter = { data: { moiType: ENV.MOITYPE_DI, resourceCode: assignmentresult.data.adjResourceCode } };

                                    //Retrieves resource specific information for Adjuster
                                    miWorkAssignmentFactory.getResourceDetails(getResourceParameter)
                                                              .then(function (adjusterresourceresult) {
                                                                  cfpLoadingBar.complete();
                                                                  if (adjusterresourceresult.route) {
                                                                      $state.go(miComponentRoute.getComponentroute(resourceresult.route));
                                                                  }
                                                                  else {
                                                                      $scope.pageReady = true;
                                                                      $scope.GetSummaryData();
                                                                      $scope.CompleteClaim();                                                                      
                                                                      $scope.resourceData = miAppProperties.getResourceData();                                                                    
                                                                      $scope.ClaimSummaryInfo = $scope.ClaimSummaryInfo + "<b>" + $filter('translate')('_AdjusterAppointment_') + "</b></br>" + $scope.resourceData.ResourceName + "</br>" + $scope.resourceData.Address1 + $filter('date')(assignmentresult.data.adjusterAppt, "fullDate", miAppProperties.getResourceData().UtcOffset.replace(':', '')) + $filter('translate')('_At_') + $filter('date')(assignmentresult.data.adjusterAppt, "shortTime", miAppProperties.getResourceData().UtcOffset.replace(':', '')) + " (" +$scope.resourceData.TimeZone + ")";
                                                                  }

                                                              })
                                }
                                //appraiser appointment not  found and adjuster appointment  not found
                                else {
                                    cfpLoadingBar.complete();
                                    $scope.pageReady = true;
                                    $scope.GetSummaryData();
                                    $scope.CompleteClaim();                                                                      

                                }
                            }                                          
                            $scope.ClaimSummaryHeading = $filter('translate')('_ClaimSummaryHEADING_');
                    }
                        
                    else {
                       // claim not found and  adjuster appointment not found
                        if (!assignmentresult.data.adjusterAppt) {
                            cfpLoadingBar.complete();
                            $scope.claimInfoFound = false;
                            $scope.pageReady = true;
                            $scope.GetSummaryData();
                            $scope.CompleteClaim();
                            $scope.ClaimSummaryHeading = $filter('translate')('_ClaimSummaryHeadingWithNoInfo_');
                        }
                            // claim not found and adjuster appointment  found
                        else {
                            $scope.ClaimSummaryHeading = $filter('translate')('_ClaimSummaryHEADING_');
                            getResourceParameter = { data: { moiType: ENV.MOITYPE_DI, resourceCode: assignmentresult.data.adjResourceCode } };
                            //Retrieves resource specific information for Adjuster
                            miWorkAssignmentFactory.getResourceDetails(getResourceParameter)
                                                      .then(function (adjusterresourceresult) {
                                                          cfpLoadingBar.complete();
                                                          if (adjusterresourceresult.route) {

                                                              $state.go(miComponentRoute.getComponentroute(resourceresult.route));
                                                          }
                                                          else {
                                                              $scope.pageReady = true;
                                                              $scope.GetSummaryData();
                                                              $scope.CompleteClaim();                                                             
                                                              $scope.resourceData = miAppProperties.getResourceData();
                                                              $scope.ClaimSummaryInfo = "<b>" + $filter('translate')('_ClaimSummaryContent_') + "</b>" + "</br></br><b>" + $filter('translate')('_AdjusterAppointment_') + "</br></b>" + $scope.resourceData.ResourceName + "</br>" + $scope.resourceData.Address1 + $filter('date')(assignmentresult.data.adjusterAppt, "fullDate", miAppProperties.getResourceData().UtcOffset.replace(':', '')) + $filter('translate')('_At_') + $filter('date')(assignmentresult.data.adjusterAppt, "shortTime", miAppProperties.getResourceData().UtcOffset.replace(':', '')) + " (" +$scope.resourceData.TimeZone + ")";
                                                          }

                                                      })

                        }
                    }              

                }
            
        })

        $scope.getHtml = function (html) {
            return $sce.trustAsHtml(html);
        };

        $scope.RedirectToWebsite = function () {
            location.href = "FNOLTestPage.aspx";
        }

   


    });
}(angular));
