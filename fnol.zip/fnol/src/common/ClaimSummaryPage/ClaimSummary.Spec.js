﻿describe('ClaimSummary Controller', function () {
    var $httpBackend, $scope;
    var $controller, $q, $state, $filter, miUiStagesProgressbar, miMoiProperties;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: "",
        contextid: "111",
        ResourceData: { "ResourceName": "Nick Win7", "ResourceCode": "M2RCNV2", "ORG_ID": "398992", "CompanyCode": "M2", "TYPE": "NON-STAFF", "ResourceType": "Body Shop", "ADDRESS": "Addr1:6220 Greenwich Dr, Addr2:, City:San Diego, state:CA, Zipcode:92122", "Street1": "6220 Greenwich Dr", "Street2": "", "City": "San Diego", "StateProvince": "CA", "STATE_NAME": "California", "PostalCode": "92122", "GEOX": "32.85152435302730", "GEOY": "-117.183128356934", "Country": "United States", "Phone": "8583688000", "Fax": "", "Email": "nicholas.varela@mitchell.com", "CONTACT": "Phone:8583688000, Fax:, Email:nicholas.varela@mitchell.com", "RATING": "4", "RATING_COMMENT": "", "CAPACITY": "", "FACTOR": "", "DistanceNum": "", "TERRITORY_DEFINITION": "", "TERRITORY": "", "FAVORITE": "", "IN_NET_WORK": "No", "REPAIR_CNT": "", "APPRAISAL_CNT": "11", "Address1": "6220 Greenwich Dr<br/>San Diego, CA - California,  92122<br/>", "ContactCompilation": "Phone : (858) 368-8000<br/>nicholas.varela@mitchell.com<br/>", "Distance": "0", "FAVORITEF": "N", "TERITORYCOMPILATION": " ", "ALL_EXPERTISE": "", "IS_ESTIMATOR": "Yes", "HAS_RC_COMM": "Yes", "TimeZone": "Pacific Standard Time" },
      
       
    };
  
    // Mocked Service
    angular.module('mock.data', [])
	.factory('miAppProperties', function ($q) {
	    var constant = {};
	    constant.setstatuscode = function (statuscode) {
	    };
	    constant.getstatuscode = function () {
	        return "fake-StatusCode";
	    };

	    constant.getResourceData = function () {
	        return expectedDetail.ResourceData;
	    };

	    constant.setstatus = function () {
	        return expectedDetail.contextid;// "M2";
	    };

	    constant.getcontextid = function () {
	        return expectedDetail.contextid;// "M2";
	    };
	    constant.gettheme = function () {
	        return expectedDetail.theme;// "M2";
	    };
	    constant.getorgcode = function () {
	        return expectedDetail.orgcode;
	    };
	    constant.getanimationclass = function () {
	        return expectedDetail.animationclass;
	    };
	    constant.getlanguage = function () {
	        return expectedDetail.language;
	    };
	    constant.getDocID = function () {
	        return expectedDetail.DocID;
	    };	    
	    
	    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
	    constant.fetch = function () {
	        var mockUser = "M2";
	        return $q.when(mockUser);
	    };

	    // other stubbed methods

	    return constant;
	})

        .service('LocaleService', function ($translate, LOCALES, $rootScope, tmhDynamicLocale) {
            return {
                getLocaleDisplayName: function () {
                    return info1headerexpectedDetail.LocaleDisplayName;
                },
                setLocaleByDisplayName: function (localeDisplayName) {

                },
                getLocalesDisplayNames: function () {
                    return false;
                }
            };
        });

    describe('ClaimSummaryData', function () {
        beforeEach(module('mi.mfnol.web'));

        beforeEach(module('mock.data'));
        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            $scope = $rootScope.$new();
            $controller = _$controller_;
            $controller = $controller('ClaimSummaryCtrl', {
                $scope: $scope,
                miAppProperties: _miAppProperties_
            });
        }));
        it('erensure current theme is not null', function () {
            expect($scope.currtheme).not.toBe(null);
        })

        it('Open Question Controll  ensure animation class is not null', function () {
            expect($scope.pageClass).not.toBe(null);
        });
    });

        describe('Claim Summary Controller_Test_function', function () {
            beforeEach(module('mi.mfnol.web'));
            var miLocale;
            beforeEach(module('mock.data'));
            beforeEach(function () {
                inject(function ($injector) {                   
                    $scope = $injector.get('$rootScope').$new();
                    $state = $injector.get('$state');
                    $filter = $injector.get('$filter');
                    $controller = $injector.get('$controller');
                    $sce = $injector.get('$sce');
                    miLocale = $injector.get('miLocale');
                    miAppFactory = $injector.get('miAppFactory');                                     
                    miStageFactory = $injector.get('miStageFactory');                   
                    miWorkAssignmentFactory = $injector.get('miWorkAssignmentFactory');                   
                    spyOn(miWorkAssignmentFactory, 'getWorkAssignmentDetails').and.callFake(function () {
                        return $.Deferred().resolve({ route: 400 });
                    });
                    
                });
            });
            //spec to track that spy created on $sce.trustAsHtml and miStageFactory.updateStage was called
       
            it('should call sce trustAsHtml', inject(function () {                
                $controller('ClaimSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce });
                spyOn($sce, 'trustAsHtml').and.callThrough();
                $scope.getHtml('<h1>Test</h1>');
                expect($sce.trustAsHtml).toHaveBeenCalled();
            }));
            it('should call miWorkAssignmentFactory.getWorkAssignmentDetails() with Error Page', inject(function () {
                miLocale.setLocaleCode('en-US');
                $controller('ClaimSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce,miLocale: miLocale, miWorkAssignmentFactory: miWorkAssignmentFactory });               
                expect(miWorkAssignmentFactory.getWorkAssignmentDetails).toHaveBeenCalled();
            }));

            
        })

        describe('Claim Summary Controller_Test_with_WorkAssignmentDetails_function when claim number found and resource not found adjuster not found', function () {
            beforeEach(module('mi.mfnol.web'));
            var miLocale;
            beforeEach(module('mock.data'));
            beforeEach(function () {
                inject(function ($injector) {                    
                    $scope = $injector.get('$rootScope').$new();
                    $state = $injector.get('$state');
                    $filter = $injector.get('$filter');
                    $controller = $injector.get('$controller');
                    $sce = $injector.get('$sce');
                    miLocale = $injector.get('miLocale');
                    miAppFactory = $injector.get('miAppFactory');
                    miStageFactory = $injector.get('miStageFactory');
                    miWorkAssignmentFactory = $injector.get('miWorkAssignmentFactory');
                    miCMSFactory = $injector.get('miCMSFactory');
                    spyOn(miWorkAssignmentFactory, 'getWorkAssignmentDetails').and.callFake(function () {
                        return $.Deferred().resolve({ route: "", data: { "cmsSelectedResource": false, "moiType": "SCDI", "adjusterAppt": null, "estApptReqFlag": false, "resourceCode": null, "estimatorAppt": "2016-03-29T09:00:00", "adjusterApptReqFlag": false, "adjResourceCode": "DIHT", "preferedMOIList": null, "moiDetailsFilterDTO": null, "assignmentType": "ESTIMATOR", "assignmentDocId": 100008436068, "moiOrgId": 1800666, "claimNumber": 123 } });
                    });
                    spyOn(miCMSFactory, 'deletePolicy').and.callFake(function () {
                        return $.Deferred().resolve({ route: ""});
                    });
                   

                });
            });           

            it('should call miWorkAssignmentFactory.getWorkAssignmentDetails() when claim number found and resource not found adjuster not found', inject(function () {              
                miLocale.setLocaleCode('en-US');               
                $controller('ClaimSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miLocale: miLocale, miWorkAssignmentFactory: miWorkAssignmentFactory });                                            
                expect(miWorkAssignmentFactory.getWorkAssignmentDetails).toHaveBeenCalled();
               expect($scope.ClaimSummaryInfo).toBe('<b>_ClaimSummaryContent_</b></br></br><b>_ClaimNumber_</b></br>123</br></br>');              
            }));
        })

        describe('Claim Summary Controller_Test_with_WorkAssignmentDetails_function when claim number found and resource found adjuster not found', function () {
            beforeEach(module('mi.mfnol.web'));
            var miLocale;
            beforeEach(module('mock.data'));
            beforeEach(function () {
                inject(function ($injector) {
                    $scope = $injector.get('$rootScope').$new();
                    $state = $injector.get('$state');
                    $filter = $injector.get('$filter');
                    $controller = $injector.get('$controller');
                    $sce = $injector.get('$sce');
                    miLocale = $injector.get('miLocale');
                    miAppFactory = $injector.get('miAppFactory');
                    miStageFactory = $injector.get('miStageFactory');
                    miWorkAssignmentFactory = $injector.get('miWorkAssignmentFactory');
                    miCMSFactory = $injector.get('miCMSFactory');
                    spyOn(miWorkAssignmentFactory, 'getWorkAssignmentDetails').and.callFake(function () {
                        return $.Deferred().resolve({ route: "", data: { "cmsSelectedResource": false, "moiType": "SCDI", "adjusterAppt": null, "estApptReqFlag": false, "resourceCode": "12345", "estimatorAppt": "2016-03-29T09:00:00", "adjusterApptReqFlag": false, "adjResourceCode": "DIHT", "preferedMOIList": null, "moiDetailsFilterDTO": null, "assignmentType": "ESTIMATOR", "assignmentDocId": 100008436068, "moiOrgId": 1800666, "claimNumber": 123 } });
                    });
                    spyOn(miCMSFactory, 'deletePolicy').and.callFake(function () {
                        return $.Deferred().resolve({ route: "" });
                    });
                    spyOn(miWorkAssignmentFactory, 'getResourceDetails').and.callFake(function () {
                        return $.Deferred().resolve({ route: "", data: {} });
                    });


                });
            });

            it('should call miWorkAssignmentFactory.getWorkAssignmentDetails() when claim number found and resource found adjuster not found', inject(function () {
                miLocale.setLocaleCode('en-US');
                $controller('ClaimSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miLocale: miLocale, miWorkAssignmentFactory: miWorkAssignmentFactory });
                expect(miWorkAssignmentFactory.getWorkAssignmentDetails).toHaveBeenCalled();
                expect($scope.ClaimSummaryInfo).toBe('<b>_ClaimSummaryContent_</b></br></br><b>_ClaimNumber_</b></br>123</br></br><b>_EstimatorAppointment_</b></br>Nick Win7</br>6220 Greenwich Dr<br/>San Diego, CA - California,  92122<br/>Tuesday, March 29, 2016_At_3:30 AM (Pacific Standard Time)');
            }));
        })

        describe('Claim Summary Controller_Test_with_WorkAssignmentDetails_function when claim number found ,resource found and adjuster found', function () {
            beforeEach(module('mi.mfnol.web'));
            var miLocale;
            beforeEach(module('mock.data'));
            beforeEach(function () {
                inject(function ($injector) {
                    $scope = $injector.get('$rootScope').$new();
                    $state = $injector.get('$state');
                    $filter = $injector.get('$filter');
                    $controller = $injector.get('$controller');
                    $sce = $injector.get('$sce');
                    miLocale = $injector.get('miLocale');
                    miAppFactory = $injector.get('miAppFactory');
                    miStageFactory = $injector.get('miStageFactory');
                    miWorkAssignmentFactory = $injector.get('miWorkAssignmentFactory');
                    miCMSFactory = $injector.get('miCMSFactory');
                    spyOn(miWorkAssignmentFactory, 'getWorkAssignmentDetails').and.callFake(function () {
                        return $.Deferred().resolve({ route: "", data: { "cmsSelectedResource": false, "moiType": "SCDI", "adjusterAppt": "2016-03-29T09:00:00", "estApptReqFlag": false, "resourceCode": "12345", "estimatorAppt": "2016-03-29T09:00:00", "adjusterApptReqFlag": false, "adjResourceCode": "DIHT", "preferedMOIList": null, "moiDetailsFilterDTO": null, "assignmentType": "ESTIMATOR", "assignmentDocId": 100008436068, "moiOrgId": 1800666, "claimNumber": 123 } });
                    });
                    spyOn(miCMSFactory, 'deletePolicy').and.callFake(function () {
                        return $.Deferred().resolve({ route: "" });
                    });
                    spyOn(miWorkAssignmentFactory, 'getResourceDetails').and.callFake(function () {
                        return $.Deferred().resolve({ route: "", data: {} });
                    });


                });
            });

            it('should call miWorkAssignmentFactory.getWorkAssignmentDetails() when claim number found ,resource found and adjuster found', inject(function () {               
                miLocale.setLocaleCode('en-US');
                $controller('ClaimSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miLocale: miLocale, miWorkAssignmentFactory: miWorkAssignmentFactory });
                expect(miWorkAssignmentFactory.getWorkAssignmentDetails).toHaveBeenCalled();
                expect($scope.ClaimSummaryInfo).toBe('<b>_ClaimSummaryContent_</b></br></br><b>_ClaimNumber_</b></br>123</br></br><b>_EstimatorAppointment_</b></br>Nick Win7</br>6220 Greenwich Dr<br/>San Diego, CA - California,  92122<br/>Tuesday, March 29, 2016_At_3:30 AM (Pacific Standard Time)</br></br><b>_AdjusterAppointment_</b></br>Nick Win7</br>6220 Greenwich Dr<br/>San Diego, CA - California,  92122<br/>Tuesday, March 29, 2016_At_3:30 AM (Pacific Standard Time)');
            }));
        })

        describe('Claim Summary Controller_Test_with_WorkAssignmentDetails_function when claim number found ,resource not found and adjuster found', function () {
            beforeEach(module('mi.mfnol.web'));
            var miLocale;
            beforeEach(module('mock.data'));
            beforeEach(function () {
                inject(function ($injector) {
                    $scope = $injector.get('$rootScope').$new();
                    $state = $injector.get('$state');
                    $filter = $injector.get('$filter');
                    $controller = $injector.get('$controller');
                    $sce = $injector.get('$sce');
                    miLocale = $injector.get('miLocale');
                    miAppFactory = $injector.get('miAppFactory');
                    miStageFactory = $injector.get('miStageFactory');
                    miWorkAssignmentFactory = $injector.get('miWorkAssignmentFactory');
                    miCMSFactory = $injector.get('miCMSFactory');
                    spyOn(miWorkAssignmentFactory, 'getWorkAssignmentDetails').and.callFake(function () {
                        return $.Deferred().resolve({ route: "", data: { "cmsSelectedResource": false, "moiType": "SCDI", "adjusterAppt": "2016-03-29T09:00:00", "estApptReqFlag": false, "resourceCode": null, "estimatorAppt": "2016-03-29T09:00:00", "adjusterApptReqFlag": false, "adjResourceCode": "DIHT", "preferedMOIList": null, "moiDetailsFilterDTO": null, "assignmentType": "ESTIMATOR", "assignmentDocId": 100008436068, "moiOrgId": 1800666, "claimNumber": 123 } });
                    });
                    spyOn(miCMSFactory, 'deletePolicy').and.callFake(function () {
                        return $.Deferred().resolve({ route: "" });
                    });
                    spyOn(miWorkAssignmentFactory, 'getResourceDetails').and.callFake(function () {
                        return $.Deferred().resolve({ route: "", data: {} });
                    });


                });
            });

            it('should call miWorkAssignmentFactory.getWorkAssignmentDetails() when claim number found ,resource not found and adjuster found', inject(function () {
                miLocale.setLocaleCode('en-US');
                $controller('ClaimSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miLocale: miLocale, miWorkAssignmentFactory: miWorkAssignmentFactory });
                expect(miWorkAssignmentFactory.getWorkAssignmentDetails).toHaveBeenCalled();
                expect($scope.ClaimSummaryInfo).toBe('<b>_ClaimSummaryContent_</b></br></br><b>_ClaimNumber_</b></br>123</br></br><b>_AdjusterAppointment_</b></br>Nick Win7</br>6220 Greenwich Dr<br/>San Diego, CA - California,  92122<br/>Tuesday, March 29, 2016_At_3:30 AM (Pacific Standard Time)');
            }));
        })

        describe('Claim Summary Controller_Test_with_WorkAssignmentDetails_function when claim not found and adjuster found', function () {
            beforeEach(module('mi.mfnol.web'));
            var miLocale;
            beforeEach(module('mock.data'));
            beforeEach(function () {
                inject(function ($injector) {
                    $scope = $injector.get('$rootScope').$new();
                    $state = $injector.get('$state');
                    $filter = $injector.get('$filter');
                    $controller = $injector.get('$controller');
                    $sce = $injector.get('$sce');
                    miLocale = $injector.get('miLocale');
                    miAppFactory = $injector.get('miAppFactory');
                    miStageFactory = $injector.get('miStageFactory');
                    miWorkAssignmentFactory = $injector.get('miWorkAssignmentFactory');
                    miCMSFactory = $injector.get('miCMSFactory');
                    spyOn(miWorkAssignmentFactory, 'getWorkAssignmentDetails').and.callFake(function () {
                        return $.Deferred().resolve({ route: "", data: { "cmsSelectedResource": false, "moiType": "SCDI", "adjusterAppt": "2016-03-29T09:00:00", "estApptReqFlag": false, "resourceCode": null, "estimatorAppt": "2016-03-29T09:00:00", "adjusterApptReqFlag": false, "adjResourceCode": "DIHT", "preferedMOIList": null, "moiDetailsFilterDTO": null, "assignmentType": "ESTIMATOR", "assignmentDocId": 100008436068, "moiOrgId": 1800666, "claimNumber": null } });
                    });
                    spyOn(miCMSFactory, 'deletePolicy').and.callFake(function () {
                        return $.Deferred().resolve({ route: "" });
                    });
                    spyOn(miWorkAssignmentFactory, 'getResourceDetails').and.callFake(function () {
                        return $.Deferred().resolve({ route: "", data: {} });
                    });


                });
            });

            it('should call miWorkAssignmentFactory.getWorkAssignmentDetails() when claim not found and adjuster found', inject(function () {               
                miLocale.setLocaleCode('en-US');
                $controller('ClaimSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miLocale: miLocale, miWorkAssignmentFactory: miWorkAssignmentFactory });
                expect(miWorkAssignmentFactory.getWorkAssignmentDetails).toHaveBeenCalled();
                expect($scope.ClaimSummaryInfo).toBe('<b>_ClaimSummaryContent_</b></br></br><b>_AdjusterAppointment_</br></b>Nick Win7</br>6220 Greenwich Dr<br/>San Diego, CA - California,  92122<br/>Tuesday, March 29, 2016_At_3:30 AM (Pacific Standard Time)');
            }));
        })

        describe('Claim Summary Controller_Test_with_WorkAssignmentDetails_function when claim not found and no adjuster found', function () {
            beforeEach(module('mi.mfnol.web'));
            var miLocale;
            beforeEach(module('mock.data'));
            beforeEach(function () {
                inject(function ($injector) {
                    $scope = $injector.get('$rootScope').$new();
                    $state = $injector.get('$state');
                    $filter = $injector.get('$filter');
                    $controller = $injector.get('$controller');
                    $sce = $injector.get('$sce');
                    miLocale = $injector.get('miLocale');
                    miAppFactory = $injector.get('miAppFactory');
                    miStageFactory = $injector.get('miStageFactory');
                    miWorkAssignmentFactory = $injector.get('miWorkAssignmentFactory');
                    miCMSFactory = $injector.get('miCMSFactory');
                    spyOn(miWorkAssignmentFactory, 'getWorkAssignmentDetails').and.callFake(function () {
                        return $.Deferred().resolve({ route: "", data: { "cmsSelectedResource": false, "moiType": "SCDI", "adjusterAppt": null, "estApptReqFlag": false, "resourceCode": null, "estimatorAppt": "2016-03-29T09:00:00", "adjusterApptReqFlag": false, "adjResourceCode": "DIHT", "preferedMOIList": null, "moiDetailsFilterDTO": null, "assignmentType": "ESTIMATOR", "assignmentDocId": 100008436068, "moiOrgId": 1800666, "claimNumber": null } });
                    });
                    spyOn(miCMSFactory, 'deletePolicy').and.callFake(function () {
                        return $.Deferred().resolve({ route: "" });
                    });
                    spyOn(miWorkAssignmentFactory, 'getResourceDetails').and.callFake(function () {
                        return $.Deferred().resolve({ route: "", data: {} });
                    });


                });
            });

            it('should call miWorkAssignmentFactory.getWorkAssignmentDetails() when claim not found and no adjuster found', inject(function () {                
                miLocale.setLocaleCode('en-US');
                $controller('ClaimSummaryCtrl', { $scope: $scope, $state: $state, $sce: $sce, miLocale: miLocale, miWorkAssignmentFactory: miWorkAssignmentFactory });
                expect(miWorkAssignmentFactory.getWorkAssignmentDetails).toHaveBeenCalled();
                expect($scope.ClaimSummaryHeading).toBe('_ClaimSummaryHeadingWithNoInfo_');
            }));
        })


});