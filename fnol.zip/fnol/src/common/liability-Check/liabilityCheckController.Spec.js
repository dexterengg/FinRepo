﻿describe('MFNOL AngularJS Controller (LiabilityCheck Controller)', function () {

    var $httpBackend, $scope, $controller, miLocale
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: 123,
        stageType: "fake-Stage",
        stageDesc: "fake-stageDesc",
        pageName: "fake-pageName",
        UserIdentificationdata: "UserIdentificationdata",
        totalNumOfStages: 6,
        stageUiOrder: 2,
        islandingpage: false,
        sessionexpired: true,
        appBodyTheme: "mi-app-body",
        getIdentificationFields: true,
        getorgcode: true,
        getLocaleCode: true,
        getIdentificationFields: true,
        getflagStage: true,
        getcontextid: true,
        getcoStageId: 123,
        statuscode: 400,
        Docidlist: "Docidlist"
    };
    // Mocked Service
    angular.module('mock.LiabilityCheckCtrldata', [])
    .factory('miAppProperties', function ($q) {

        var constant = {};
        constant.gettheme = function () {
            return expectedDetail.theme;
        };
        constant.getorgcode = function () {
            return expectedDetail.orgcode;
        };
        constant.getanimationclass = function () {
            return expectedDetail.animationclass;
        };
        constant.getlanguage = function () {
            return expectedDetail.language;
        };
        constant.getDocID = function () {
            return expectedDetail.DocID;
        };
        constant.getstageType = function () {
            return expectedDetail.stageType;
        };
        constant.getstageDesc = function () {
            return expectedDetail.stageDesc;
        };
        constant.getpageName = function () {
            return expectedDetail.pageName;
        };
        constant.setisConfirmed = function () {
            return expectedDetail.isConfirmed;
        };
        constant.setDocID = function (DocID) {
            return expectedDetail.DocID;
        };
        constant.getUserIdentificationdata = function () {
            return expectedDetail.UserIdentificationdata;
        };
        constant.gettotalNumOfStages = function () {
            return expectedDetail.totalNumOfStages;
        };
        constant.getstageUiOrder = function () {
            return expectedDetail.stageUiOrder;
        };
        constant.setislandingpage = function (islandingpage) {
            expectedDetail.islandingpage = islandingpage;
        };
        constant.getsessionexpired = function () {
            return expectedDetail.sessionexpired;
        };
        constant.getorgcode = function () {
            return expectedDetail.getorgcode;
        };
        constant.getLocaleCode = function () {
            return expectedDetail.getLocaleCode;
        };
        constant.getflagStage = function () {
            return expectedDetail.getflagStage;
        };
        constant.getcontextid = function () {
            return expectedDetail.getcontextid;
        };
        constant.getcoStageId = function () {
            return expectedDetail.getcoStageId;
        };
        constant.setstatuscode = function (statuscode) {
            expectedDetail.statuscode = statuscode;
        };
        constant.getDocidlist = function () {
            return expectedDetail.Docidlist.toString();
        };
        // example stub method that returns a promise, e.g. if original method returned $http.get(...)
        constant.fetch = function () {
            var mockUser = "M2";
            return $q.when(mockUser);
        };
        // other stubbed methods
        return constant;
    })


    describe('LiabilityCheckCtrl_Controller_Test_for_currentTheme', function () {
        beforeEach(module('mi.mfnol.web'));
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.LiabilityCheckCtrldata'));
        var ctrl, scope;
        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('LiabilityCheckCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));

        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });

        it('ensure default page class name', function () {
            expect(scope.pageClass).toBe('page-main');
        });

    });

    describe('LiabilityCheckCtrl_Controller_Test_for', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.LiabilityCheckCtrldata'));
        var sce, miCMSFactory, miStageFactory, miUiStagesProgressbar, miLocale, miQuestionaireFactory
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $controller = $injector.get('$controller');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                miStageFactory = $injector.get('miStageFactory');
                miQuestionaireFactory = $injector.get('miQuestionaireFactory');
                miLocale = $injector.get('miLocale');
                spyOn(miQuestionaireFactory, 'getOutcome').and.callFake(function () {
                    return $.Deferred().resolve({ route: 400 });
                });
                spyOn(miStageFactory, 'createStage').and.callFake(function () {
                    return $.Deferred().resolve({
                        route: 400
                    });
                });
            });
        });

        it('should call getoutcome with error', inject(function () {
            $controller('LiabilityCheckCtrl', {
                $scope: $scope, $state: $state, miStageFactory: miStageFactory, miLocale: miLocale, miQuestionaireFactory: miQuestionaireFactory
            });
            expect(miQuestionaireFactory.getOutcome).toHaveBeenCalled();
            expect(miStageFactory.createStage).toHaveBeenCalled();
        }));
    });



    describe('LiabilityCheckCtrl_Controller_Test_for', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.LiabilityCheckCtrldata'));
        var sce, miCMSFactory, miStageFactory, miUiStagesProgressbar, miLocale, miQuestionaireFactory
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $controller = $injector.get('$controller');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                miStageFactory = $injector.get('miStageFactory');
                miQuestionaireFactory = $injector.get('miQuestionaireFactory');
                miLocale = $injector.get('miLocale');
                spyOn(miQuestionaireFactory, 'getOutcome').and.callFake(function () {
                    return $.Deferred().resolve({ route: 400 });
                });
                spyOn(miStageFactory, 'createStage').and.callFake(function () {
                    return $.Deferred().resolve({
                        route: ""
                    });
                });
            });
        });

        it('should call getoutcome with success', inject(function () {
            $controller('LiabilityCheckCtrl', {
                $scope: $scope, $state: $state, miStageFactory: miStageFactory, miLocale: miLocale, miQuestionaireFactory: miQuestionaireFactory
            });
            expect(miQuestionaireFactory.getOutcome).toHaveBeenCalled();
            expect(miStageFactory.createStage).toHaveBeenCalled();
        }));
    });

});

