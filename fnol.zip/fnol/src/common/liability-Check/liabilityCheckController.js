﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('LiabilityCheckCtrl',
    function (
        $scope,
        $state,
        miAppProperties,
        ENV,
        miLocale,
        miComponentRoute,
        cfpLoadingBar,
        miUiStagesProgressbar,
        miQuestionaireFactory,
        miStageFactory) {

        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        //var docids = miAppProperties.getDocidlist();
        if (miAppProperties.getcontextid()) {
            //cfpLoadingBar.start();
            $scope.accidentScenarioProcessed = true;
            $scope.extendDot = ".";
            miQuestionaireFactory.getOutcome(miAppProperties.getorgcode(), miAppProperties.getcontextid())
            .then(function (outcomeresponse) {
                $scope.calculatingResposiblityProcessed = true;
                $scope.extendDot = "..";
                if (miAppProperties.getStageStatus() === ENV.CLAIMSTATUS_INPROGRESS) {
                    $scope.VerifyOutComeList(outcomeresponse);
                }
                else {
                    miStageFactory.createStage(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                                                   .then(function (createstageresponse) {
                                                       $scope.accidentDetailsProcessed = true;
                                                       $scope.extendDot = "...";
                                                       //cfpLoadingBar.complete();
                                                       if (createstageresponse.route) {
                                                           $state.go(miComponentRoute.getComponentroute(createstageresponse.route));
                                                       }
                                                       else if (outcomeresponse.route) {
                                                           //$state.go(miComponentRoute.getComponentroute(outcomeresponse.route));
                                                           $scope.VerifyOutComeList(outcomeresponse);
                                                       }
                                                   })
                }
            });
        }

        $scope.UpdateAndGetNextStage = function () {
             miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                .then(function (updatestageresponse) {
                    $scope.extendDot = "...";
                    if (updatestageresponse.route) {
                        $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                    }
                    else {
                        miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                             .then(function (nextstageresponse) {
                                 $scope.accidentDetailsProcessed = true;
                                 $scope.extendDot = "....";
                                 if (nextstageresponse.route) {
                                     $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                 }
                                 else {
                                     //condition to check when Assignment decision has no route and display claim summary page.
                                     miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                                      .then(function (updatestageresponse) {
                                          if (updatestageresponse.route) {
                                              $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                                          }
                                          else {
                                              miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                   .then(function (nextstageresponse) {
                                                       if (nextstageresponse.route) {
                                                          $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                       }
                                                   })
                                          }
                                      })
                                 }

                             })
                    }
                })
          }
        $scope.VerifyOutComeList = function (outcomeresponse)
        {
            //Condition to check outcomelist is blank or not if outcomelist is not blank then route the outcome UI 
            //if outcomelist is blank or Outcomes with attributes not display then update and get next stage.
            if (!miAppProperties.getOutcomeDetail().fnolOutComesList.length || !miAppProperties.getDisplayOutCome().length) {
                $scope.UpdateAndGetNextStage();
            }
            else {
                    $state.go(miComponentRoute.getComponentroute(outcomeresponse.route));
            }
        }
    });
}(angular));