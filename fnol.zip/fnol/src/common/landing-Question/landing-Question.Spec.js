﻿describe('MFNOL AngularJS Controller (Landing Question Controller)', function () {
    var $httpBackend, $scope;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: "",
        stageType: "Questionnaire",
        stageDesc: "fake-stageDesc",
        pageName: "fake-pageName",
        UserIdentificationdata: [],
        totalNumOfStages: 6,
        stageUiOrder: 2,
        statuscode: "statuscode",
        stageName: "IDENTIFICATION",
        questionnaireID: 123,
        sessionID: "sessionID",
        islandingpage: true,
        systemDocId: 123,
        contextid: "1213545",
        currentQuestion: { 'qustnnreId': 0, 'companyCd': null, 'qustnnreQustnId': 100000121517, 'editable': true, 'qustnPlainText': null, 'qustnFormattedText': 'PHNwYW4gc3R5bGU9ImZvbnQtc2l6ZTogMTZweDsiPldoYXQgd2FzIHlvdXIgcm9sZSBpbiB0aGUgaW5jaWRlbnQ/PC9zcGFuPg==', 'qustnText': 'What was your role in the incident?', 'answrControlType': 'OPEN_QUESTION', 'answerList': [{ 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130108, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Registered Owner and Driver', 'answerDisplayOrder': 1, 'answered': false }, { 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130109, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Registered Owner', 'answerDisplayOrder': 2, 'answered': false }, { 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130110, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Driver', 'answerDisplayOrder': 3, 'answered': false }, { 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130111, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Neither', 'answerDisplayOrder': 4, 'answered': false }] }
    };
    // Mocked Service
    beforeEach(module('mi.mfnol.environment'));
    beforeEach(module('mi.mfnol.web'));
    angular.module('mock.LandingQuestionCtrldata', [])
	.factory('miAppProperties', function ($q) {
	    var constant = {};
	    constant.gettheme = function () {
	        return expectedDetail.theme;
	    };
	    constant.getorgcode = function () {
	        return expectedDetail.orgcode;
	    };
	    constant.getanimationclass = function () {
	        return expectedDetail.animationclass;
	    };
	    constant.getlanguage = function () {
	        return expectedDetail.language;
	    };
	    constant.getDocID = function () {
	        return expectedDetail.DocID;
	    };
	    constant.getstageType = function () {
	        return expectedDetail.stageType;
	    };
	    constant.getstageDesc = function () {
	        return expectedDetail.stageDesc;
	    };
	    constant.getpageName = function () {
	        return expectedDetail.pageName;
	    };
	    constant.setisConfirmed = function () {
	        return expectedDetail.isConfirmed;
	    };
	    constant.setDocID = function (DocID) {
	        return expectedDetail.DocID;
	    };
	    constant.getUserIdentificationdata = function () {
	        return expectedDetail.UserIdentificationdata;
	    };
	    constant.gettotalNumOfStages = function () {
	        return expectedDetail.totalNumOfStages;
	    };
	    constant.getstageUiOrder = function () {
	        return expectedDetail.stageUiOrder;
	    };
	    constant.getCurrentQuestion = function () {
	        return expectedDetail.currentQuestion;
	    };
	    constant.getcontextid = function () {
	        expectedDetail.contextid;
	    };
	    constant.setcontextid = function (contextid) {
	        expectedDetail.contextid = contextid;
	    };
	    constant.setstatuscode = function (statuscode) {
	        expectedDetail.statuscode = statuscode;
	    };
	    constant.getstatuscode = function () {
	        return expectedDetail.statuscode;
	    };
	    constant.getstageName = function () {
	        return expectedDetail.stageName;
	    };
	    constant.insertUserIdentificationdata = function (Id, Question, Answer) {
	        var QuesAnsDetail = { "Id": Id, "Question": Question, "Answer": Answer };
	        expectedDetail.UserIdentificationdata.push(QuesAnsDetail);
	    };
	    constant.getUserIdentificationdata = function () {
	        return expectedDetail.UserIdentificationdata;
	    };
	    constant.ClearUserIdentificationdata = function () {
	        expectedDetail.UserIdentificationdata.length = 0;
	    };
	    constant.getquestionnaireID = function () {
	        return expectedDetail.questionnaireID;
	    };
	    constant.setSessionID = function (sessionID) {
	        expectedDetail.sessionID = sessionID;
	    };
	    constant.getSessionID = function () {
	        return expectedDetail.sessionID;
	    };
	    constant.setislandingpage = function (islandingpage) {
	        expectedDetail.islandingpage = islandingpage;
	    };
	    constant.getislandingpage = function () {
	        return expectedDetail.islandingpage;
	    };
	    constant.getsystemDocId = function () {
	        return expectedDetail.systemDocId;
	    };

	    constant.setpartialStage = function () {
	        return false;
	    };

	    constant.setIsAnswering = function () {
	        return false;
	    };

	    constant.setStageOrder = function () {
	        return 0;
	    };
	    constant.getStageOrder = function (getStageOrder) {
	    };

	    constant.setmoiType = function () {
	        return false;
	    };

	    constant.getsystemDocId = function () {
	        return expectedDetail.systemDocId;
	    };
	    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
	    constant.fetch = function () {
	        var mockUser = "M2";
	        return $q.when(mockUser);
	    };
	    // other stubbed methods
	    return constant;
	})

    describe('LandingQuestionController_Test_for_currenttheme', function () {
        var ctrl, scope;
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.LandingQuestionCtrldata'));
        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('LandingQuestionCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });
        }));
        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('Open Question Controll  ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });
        it('ensure animation class is page-main', function () {
            expect(scope.pageClass).toBe(expectedDetail.animationclass);
        });

    });

    describe('Landing Question Controller', function () {
        var miAppFactory, miQuestionaireFactory, $rootScope, cfpLoadingBar;
        beforeEach(module('mock.LandingQuestionCtrldata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $rootScope = $injector.get('$rootScope');
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miQuestionaireFactory = $injector.get('miQuestionaireFactory');
                cfpLoadingBar = $injector.get('cfpLoadingBar');
                spyOn(miQuestionaireFactory, 'questionnaireRouteDecision').and.callFake(function () {
                    return $.Deferred().resolve({ route: 400 });
                });
            });
        });

        it('should call miQuestionaireFactory questionnaireRouteDecision with error', inject(function () {
            $controller('LandingQuestionCtrl', { $scope: $scope, $state: $state, miQuestionaireFactory: miQuestionaireFactory });
            expect(miQuestionaireFactory.questionnaireRouteDecision).toHaveBeenCalled();
            expectedDetail.theme = null;
        }));

        it('should not do anything if theme is null', inject(function () {
            $controller('LandingQuestionCtrl', { $scope: $scope, $state: $state, miQuestionaireFactory: miQuestionaireFactory });
        }));

        it('should call open  popup', inject(function () {
            $controller('LandingQuestionCtrl', { $scope: $scope, $state: $state, $rootScope: $rootScope, miQuestionaireFactory: miQuestionaireFactory, cfpLoadingBar: cfpLoadingBar });
            $rootScope.openPopup();
            expect(cfpLoadingBar.openPopupWindow).toHaveBeenCalled();
        }));

        it('should call open popup', inject(function () {
            $controller('LandingQuestionCtrl', { $scope: $scope, $state: $state, $rootScope: $rootScope, miQuestionaireFactory: miQuestionaireFactory, cfpLoadingBar: cfpLoadingBar });
            $rootScope.openPopup();
            expect(cfpLoadingBar.openPopupWindow).toHaveBeenCalled();
        }));
        it('should call close popup', inject(function () {
            $controller('LandingQuestionCtrl', { $scope: $scope, $state: $state, $rootScope: $rootScope, miQuestionaireFactory: miQuestionaireFactory, cfpLoadingBar: cfpLoadingBar });
            $rootScope.closePopup();
            expect(cfpLoadingBar.closePopupWindow).toHaveBeenCalled();
        }));

    });

    describe('Landing Question Controller Discurd Claim function', function () {
        var miAppFactory, miQuestionaireFactory, $rootScope, cfpLoadingBar, miStageFactory;
        beforeEach(module('mock.LandingQuestionCtrldata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $rootScope = $injector.get('$rootScope');
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miQuestionaireFactory = $injector.get('miQuestionaireFactory');
                cfpLoadingBar = $injector.get('cfpLoadingBar');
                miStageFactory = $injector.get('miStageFactory');
            });
        });


        it('should Call miCMSFactory.deletePolicy when discardClaim calls with route is not null ', inject(function () {
            $controller('LandingQuestionCtrl', { $scope: $scope, $state: $state, $rootScope: $rootScope, miQuestionaireFactory: miQuestionaireFactory, cfpLoadingBar: cfpLoadingBar, miCMSFactory: miCMSFactory });
            spyOn(miCMSFactory, 'deletePolicy').and.callFake(function () {
                return $.Deferred().resolve({ route: 'fakeRoute' });
            });
            $rootScope.discardClaim();
            expect(miCMSFactory.deletePolicy).toHaveBeenCalled();
        }));

        it('should Call miCMSFactory.deletePolicy when discardClaim is calles calls with route is null', inject(function () {
            $controller('LandingQuestionCtrl', { $scope: $scope, $state: $state, $rootScope: $rootScope, miQuestionaireFactory: miQuestionaireFactory, cfpLoadingBar: cfpLoadingBar, miCMSFactory: miCMSFactory });
            spyOn(miCMSFactory, 'deletePolicy').and.callFake(function () {
                return $.Deferred().resolve({ route: null });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 'fakeRoute' });
            });
            $rootScope.discardClaim();
            expect(miCMSFactory.deletePolicy).toHaveBeenCalled();
        }));
    });

    describe('LandingQuestionController_Test_for_animation', function () {
        var element, body, root;
        beforeEach(module('ngAnimate', 'ngAnimateMock', 'mi.mfnol.web'));
        beforeEach(inject(function ($animate, $document, $rootElement, $rootScope) {
            // enable animations globally
            $animate.enabled(true);

            // create a node to be animated and inject it into the DOM
            element = angular.element('<div></div>');
            root = $rootElement.append(element)[0];
            body = $document[0].body;
            body.appendChild(root);

            // trigger initial digest
            $rootScope.$digest();
        }));
        afterEach(function () {
            // clean up
            body.removeChild(root);
        });
        it('ensure current animation is working on enter', inject(function ($animate, $$animateJs) {
            // trigger animation
            $$animateJs(element, 'enter', {
                addClass: 'feb-step-main'
            }).start();
            $animate.flush();
        }));

        it('ensure current animation is working on leave', inject(function ($animate, $$animateJs) {
            // trigger animation
            $$animateJs(element, 'leave', {
                addClass: 'feb-step-main'
            }).start();
            $animate.flush();
        }));

        it('ensure current animation is working on move', inject(function ($animate, $$animateJs) {
            // trigger animation
            $$animateJs(element, 'move', {
                addClass: 'feb-step-main'
            }).start();
            $animate.flush();
        }));
    });

});