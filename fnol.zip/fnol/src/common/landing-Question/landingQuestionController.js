﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
        .animation('.feb-step-main', function () {
            return {
                enter: function (element, done) {
                    element.css('display', 'none');
                    $(element).fadeIn(500, function () {
                        done();
                    });
                },
                leave: function (element, done) {
                    $(element).fadeOut(500, function () {
                        done();
                    });
                },
                move: function (element, done) {
                    element.css('display', 'none');
                    $(element).slideDown(500, function () {
                        done();
                    });
                }
            }
        })
    .controller('LandingQuestionCtrl',
    function (
        $scope,
        $state,
        $rootScope,
        miAppProperties,
        ENV,
        miLocale,
        cfpLoadingBar,
        miComponentRoute,
        miQuestionaireFactory,
        uuid2,
        $filter,
        miCMSFactory,
        miStageFactory,
        miMoiProperties) {
        $rootScope.infoheader = false;
        miAppProperties.setSessionID(uuid2.newuuid());
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        $scope.$parent.mainclass = "mi-shell__content mobile-content mobile-content1";
        $scope.$parent.spaceclass = "mobile-card";
        $rootScope.appBodyTheme = "";

        if ($rootScope.initailizeProgressBar === undefined)
            $rootScope.initailizeProgressBar = true;

        miAppProperties.setislandingpage(true);
        if (miAppProperties.getstageType() === ENV.QUESTIONNAIRE_CONSTANT) {
            if (!miAppProperties.gettheme()) {
            }
            else {
                cfpLoadingBar.start();
                miQuestionaireFactory.questionnaireRouteDecision(miAppProperties.getorgcode(), miAppProperties.getDocID(), miAppProperties.getquestionnaireID(), miLocale.getLocaleCode())
                    .then(function (questionnairerouteresponse) {
                        if (questionnairerouteresponse.route) {
                            cfpLoadingBar.complete();
                            $state.go(miComponentRoute.getComponentroute(questionnairerouteresponse.route));
                        }
                        else if(questionnairerouteresponse.status==204)//condition to check when questionnaire does not have any question
                        {
                            if (questionnairerouteresponse.data === "") {
                                if (miAppProperties.getcontextid()) {
                                    miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                                    .then(function (updatestageresponse) {
                                        if (updatestageresponse.route) {
                                            cfpLoadingBar.complete();
                                            $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                                        }
                                        else {
                                            miAppProperties.setflagStage(true);
                                            miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                         .then(function (nextstagedata) {
                                                             cfpLoadingBar.complete();
                                                             $state.go(miComponentRoute.getComponentroute(nextstagedata.route));
                                                         })
                                        }
                                    })
                                }
                                else {
                                    miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                    .then(function (nextstagedata) {
                                        cfpLoadingBar.complete();
                                        $state.go(miComponentRoute.getComponentroute(nextstagedata.route));
                                    })
                                }
                            }

                        }
                        
                    });
            }
        }
        $rootScope.openPopup = function () {
            $rootScope.WarningMessage = $filter('translate')('_RemoveClaimWarningMessage_');
            $rootScope.DiscardButtonLabel = $filter('translate')('_DiscardButtonLabel_');
            $rootScope.CancelButtonLabel = $filter('translate')('_CancelButtonLabel_');
            cfpLoadingBar.openPopupWindow();
        };

        $rootScope.closePopup = function () {
            cfpLoadingBar.closePopupWindow();
        };

        $rootScope.discardClaim = function () {
            ga('send', 'event', 'Decision', 'Hyperlink click', 'Discard existing claim');
            cfpLoadingBar.closePopupWindow();
            cfpLoadingBar.start();
            miCMSFactory.deletePolicy(miAppProperties.getcontextid(),ENV.DISCARDCLAIM_STATUS, miLocale.getLocaleCode())
            .then(function (deletePolicyResponse) {
                if (deletePolicyResponse.route) {
                    cfpLoadingBar.complete();
                    $state.go(miComponentRoute.getComponentroute(deletePolicyResponse.route));
                }
                else {
                    miAppProperties.currentquestionnaireQuestionId = 0;
                    miAppProperties.setcontextid(false);
                    miAppProperties.setpartialStage(false);
                    miAppProperties.setIsAnswering(false);
                    miAppProperties.setStageOrder(0);
                    $rootScope.stages = 0;
                    $rootScope.currentResourceData = [];
                    miMoiProperties.setmoiType(false);
                    miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                        .then(function(nextStageResponse) {
                            if (nextStageResponse.route) {
                                cfpLoadingBar.complete();
                                $state.go(miComponentRoute.getComponentroute(nextStageResponse.route));
                            }
                        });
                }
            });
        };

    });
}(angular));
