﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('AdjusterAppointmentInfoCtrl',
    function (
        $rootScope,
        $scope,
        $state,
        $sce,
        miAppProperties,
        cfpLoadingBar,
        ENV,
        miComponentRoute,
        miUiStagesProgressbar,
        $filter,
        miResourceProperties,
        miResourceDataFactory,
        miMoiProperties) {
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        $scope.questionText = $filter('translate')("_AdjusterAppointmentMessage_");
        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();
        $scope.getHtml = function (html) {
            return $sce.trustAsHtml(html);
        };

        //Setting the value of user defined postal code to null
        //to clear search textbox data if any
        miMoiProperties.setUserDefinedResourcePostalCode(null);

        $scope.next = function () {
            //restet stored appointment slots
            miAppProperties.setAppointmentList([], false);
            miAppProperties.setappointmentType(ENV.APPOINTMENTTYPE_ADJUSTER);           
            miMoiProperties.setmoiType(ENV.MOITYPE_DI);
            miResourceProperties.setDefaultCriteriaForMoi(ENV.MOITYPE_DI);

            //Calling function to clear postal code and other entries to refine resource search
            miAppProperties.setPostalCodeToDefault();
            miResourceProperties.setPostalCode(null);
            miResourceProperties.setTerritoryType(null);
            miResourceProperties.setRadius(null);
            
            miMoiProperties.setResourceSkipped(false);
            $rootScope.moiSkipped = false;
            miMoiProperties.setresourcePostalCode(null);

            if ($rootScope.isAdvancedFilterApplied)
                $rootScope.setToDefault();
            cfpLoadingBar.start();
            //call adjuster locations
            miResourceDataFactory.GetResourcesOrGroup(miResourceProperties.getResourceSearchCriteria(), ENV.MOIGROUPTYPE)
               .then(function (resourcesresponse) {
                   cfpLoadingBar.complete();
                   if (resourcesresponse.route) {
                       $state.go(miComponentRoute.getComponentroute(resourcesresponse.route));
                   } else {                      
                       miAppProperties.setResourceDataList(resourcesresponse.data);
                       $state.go(miComponentRoute.getComponentroute(ENV.RESOURCE_CONSTANT));
                   }
               });

        }
    });
}(angular));

