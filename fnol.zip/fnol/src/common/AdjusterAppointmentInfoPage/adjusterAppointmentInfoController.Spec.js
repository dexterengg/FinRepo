﻿describe('MFNOL AngularJS Controller (Adjuster Appointment Controller)', function () {

    var $httpBackend, $scope, $controller, miAppProperties;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        UserIdentificationdata: [],
        questionDetailsList: [],
        totalNumOfStages: 6,
        stageUiOrder: 2,
        statuscode: "statuscode",
        stageStatus: "",
        stageName: "IDENTIFICATION",
        currentQuestion: { 'qustnnreId': 0, 'companyCd': null, 'qustnnreQustnId': 100000121517, 'editable': true, 'qustnPlainText': null, 'qustnFormattedText': 'PHNwYW4gc3R5bGU9ImZvbnQtc2l6ZTogMTZweDsiPldoYXQgd2FzIHlvdXIgcm9sZSBpbiB0aGUgaW5jaWRlbnQ/PC9zcGFuPg==', 'qustnText': 'What was your role in the incident?', 'answrControlType': 'CHOICE_SELECTION', 'answerList': [{ 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130108, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Registered Owner and Driver', 'answerDisplayOrder': 1, 'answered': false }, { 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130109, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Registered Owner', 'answerDisplayOrder': 2, 'answered': false }, { 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130110, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Driver', 'answerDisplayOrder': 3, 'answered': false }, { 'qustnnreQustnId': 100000121517, 'answerItemID': 100000130111, 'lowRangeValue': 0, 'highRangeValue': 0, 'answerDisplayText': 'Neither', 'answerDisplayOrder': 4, 'answered': false }] },
        backbuttoncss: "clickable_Back_Btn",
        IsStageStatusChanged: true,
        contextid: false,
        coStageId: 123,
        docID: 0,
        resourceGroup: "resourceGroup",
        resourceSkipped: "resourceSkipped",
        resourcePostalCode: "resourcePostalCode"
    };
    // Mocked Service
    angular.module('mock.AdjusterAppointmentData', [])
	.factory('miAppProperties', function ($q) {
	    var constant = {};
	    constant.gettheme = function () {
	        return expectedDetail.theme;
	    };
	    constant.getorgcode = function () {
	        return expectedDetail.orgcode;
	    };
	    constant.getanimationclass = function () {
	        return expectedDetail.animationclass;
	    };
	    constant.gettotalNumOfStages = function () {
	        return expectedDetail.totalNumOfStages;
	    };
	    constant.getstageUiOrder = function () {
	        return expectedDetail.stageUiOrder;
	    };
	    constant.getCurrentQuestion = function () {
	        return expectedDetail.currentQuestion;
	    };
	    constant.setstatuscode = function (statuscode) {
	        expectedDetail.statuscode = statuscode;
	    };
	    constant.getstageName = function () {
	        return expectedDetail.stageName;
	    };
	    constant.getBackButtonCss = function () {
	        return expectedDetail.backbuttoncss;
	    };
	    constant.IsStageStatusChanged = function () {
	        return expectedDetail.IsStageStatusChanged
	    };
	    constant.setStageStatus = function (stageStatus) {
	        expectedDetail.stageStatus = stageStatus;
	    }
	    constant.getStageStatus = function () {
	        return expectedDetail.stageStatus;
	    };
	    constant.getcontextid = function () {
	        return expectedDetail.contextid;
	    };
	    constant.getcoStageId = function () {
	        return expectedDetail.coStageId;
	    };
	    constant.setappointmentType = function (data) {
	        expectedDetail.appointmentData = data;
	    };
	    constant.getResourceData = function () {
	        return expectedDetail.ResourceData;
	    };
	    constant.setResourceData = function (data) { };
	    constant.getappointmentType = function () {
	        return expectedDetail.appointmentData;
	    };
	    constant.getDocID = function () {
	        return expectedDetail.docID;
	    };
	    constant.setVersionMismatchStatus = function () { }
	    constant.getVersionMismatchStatus = function () {
	        return false;
	    };
	    constant.setsessionexpired = function () {
	        return false;
	    }
	    constant.getResourceDataList = function () {
	        return "resourceDataList";
	    };
	    constant.setResourceDataList = function (resourceDataList) {
	        return resourceDataList;
	    }
	    constant.setPostalCodeToDefault = function () { };
	    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
	    constant.fetch = function () {
	        var mockUser = "M2";
	        return $q.when(mockUser);
	    };
	    // other stubbed methods
	    return constant;
	}).factory('miMoiProperties', function () {
	    var constant = {};
	    constant.getmoiType = function () {
	        return expectedDetail.getmoiType
	    };
	    constant.setmoiType = function (data) {
	        expectedDetail.moiType = data;
	    };
	    constant.setResourceGroup = function (resourceGroup) {
	        expectedDetail.resourceGroup = resourceGroup;
	    };
	    constant.getResourceGroup = function () {
	        return expectedDetail.resourceGroup;
	    }
	    constant.setResourceSkipped = function (resourceSkipped) {
	        expectedDetail.resourceSkipped = resourceSkipped;
	    };
	    constant.getResourceSkipped = function () {
	        return expectedDetail.resourceSkipped;
	    };
	    constant.setresourcePostalCode = function (resourcePostalCode) {
	        expectedDetail.resourcePostalCode = resourcePostalCode;
	    };
	    constant.getresourcePostalCode = function () {
	        return expectedDetail.resourcePostalCode;
	    };
	    

	    return constant;
	});

    describe('Unit tests for current theme and page class', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.AdjusterAppointmentData'));

        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('AdjusterAppointmentInfoCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));
        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });

        it('ensure default page class name', function () {
            expect(scope.pageClass).toBe(expectedDetail.animationclass);
        });
        it('ensure questionnaire version is false', function () {
            expect(scope.isVersionMismatch).toBe(false);
        })
    });


    describe('Testing other functions called from the UI', function () {
        var ctrl, $scope, $sce, $filter, miResourceDataFactory, miUiStagesProgressbar, rootScope;
        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.AdjusterAppointmentData'));
        beforeEach(inject(function (_$controller_, $rootScope, $injector, _miAppProperties_) { // inject mocked service
            $scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('AdjusterAppointmentInfoCtrl', {
                $scope: $scope,
                miAppProperties: _miAppProperties_
            });
            $sce = $injector.get('$sce');
            rootScope = $injector.get('$rootScope');
            miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
            $filter = $injector.get('$filter');
            miResourceDataFactory = $injector.get('miResourceDataFactory');
        }));

        it('should call sce trustAsHtml', function () {
            spyOn($sce, 'trustAsHtml');
            $scope.getHtml('<h1>Test</h1>');
            expect($sce.trustAsHtml).toHaveBeenCalled();
        });

        it('should ensure display message is not null', function () {
            expect($scope.questionText).not.toBe(null);
        });

        it('should ensure miUiStagesProgressbar.changeUiStage is called', function () {
            spyOn(miUiStagesProgressbar, 'changeUiStage');
            miUiStagesProgressbar.changeUiStage(7, 5);
            expect(miUiStagesProgressbar.changeUiStage).toHaveBeenCalled();
        });

        it('should ensure $filter(\'translate\')("_AdjusterAppointmentMessage_") is called', function () {
            expect($scope.questionText).toEqual($filter('translate')("_AdjusterAppointmentMessage_"));
        });

        it('should ensure on click next miResourceDataFactory.GetResourcesOrGroup is called when route is null', function () {
            spyOn(miResourceDataFactory, 'GetResourcesOrGroup').and.callFake(function () {
                return $.Deferred().resolve({ route: null });
            });
            $scope.next();
            expect(miResourceDataFactory.GetResourcesOrGroup).toHaveBeenCalled();
        });

        it('should ensure reset search filter date if isAdvancedFilterApplied is true', function () {
            rootScope.isAdvancedFilterApplied = true;
            //spyOn(rootScope, 'setToDefault').and.callFake(function () {
            //});
            expect(rootScope.isAdvancedFilterApplied).toBe(true);
        });
        it('should ensure on click next miResourceDataFactory.GetResourcesOrGroup is called when route is not null', function () {
            spyOn(miResourceDataFactory, 'GetResourcesOrGroup').and.callFake(function () {
                return $.Deferred().resolve({ route: 'fakeRoute' });
            });
            $scope.next();
            expect(miResourceDataFactory.GetResourcesOrGroup).toHaveBeenCalled();
        });
    });

});