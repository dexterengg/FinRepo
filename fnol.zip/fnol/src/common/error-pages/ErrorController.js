﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('ErrorCtrl',
    function (
        $scope,
        $rootScope,
        $filter,
        miAppProperties) {

        $rootScope.infoheader = false;
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = 'page-main';
        $scope.$parent.mainclass = "mi-shell__content mobile-content";
        $rootScope.appBodyTheme = "mi-app-body";

        miAppProperties.setislandingpage(false);
        if (miAppProperties.getCustomError()) {
            $scope.error = miAppProperties.getCustomError();
        }
        else {
            $scope.error = $filter('translate')('_' + miAppProperties.getstatuscode() + '_');
        }
        miAppProperties.ClearUserIdentificationdata();
        miAppProperties.setStageOrder(0);
        $rootScope.ShellTitle = $filter('translate')('_ERRORHEADER_');
        
    });
}(angular));