﻿describe('MFNOL AngularJS Controller (Error Controller)', function () {

    var $httpBackend, $scope, $controller, stageQuestionaireRouteDetails;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: "",
        stageType: "fake-Stage",
        stageDesc: "fake-stageDesc",
        pageName: "fake-pageName",
        UserIdentificationdata: "UserIdentificationdata",
        totalNumOfStages: 6,
        stageUiOrder: 2,
        statuscode: 400,
        islandingpage: false,
        customerror: "customerror",
        UserIdentificationdata: [],
        StageOrder:0,
        currentQuestion: { "qustnnreId": 0, "companyCd": null, "qustnnreQustnId": 100000122487, "editable": true, "qustnPlainText": null, "qustnFormattedText": "", "qustnText": "In this section we will be covering the following", "answrControlType": "SCRIPT_QUESTION", "answerList": [{ "qustnnreQustnId": 0, "answerItemID": 0, "lowRangeValue": 0, "highRangeValue": 0, "answerDisplayText": null, "answerDisplayOrder": 0, "answered": false }] }
    };
    // Mocked Service
    angular.module('mock.errorData', [])
	.factory('miAppProperties', function ($q) {
	    var constant = {};
	    constant.gettheme = function () {
	        return expectedDetail.theme;
	    };
	    constant.getorgcode = function () {
	        return expectedDetail.orgcode;
	    };
	    constant.getanimationclass = function () {
	        return expectedDetail.animationclass;
	    };
	    constant.getlanguage = function () {
	        return expectedDetail.language;
	    };
	    constant.getDocID = function () {
	        return expectedDetail.DocID;
	    };
	    constant.getstageType = function () {
	        return expectedDetail.stageType;
	    };
	    constant.getstageDesc = function () {
	        return expectedDetail.stageDesc;
	    };
	    constant.getpageName = function () {
	        return expectedDetail.pageName;
	    };
	    constant.setisConfirmed = function () {
	        return expectedDetail.isConfirmed;
	    };
	    constant.setDocID = function (DocID) {
	        return expectedDetail.DocID;
	    };
	    constant.getUserIdentificationdata = function () {
	        return expectedDetail.UserIdentificationdata;
	    };
	    constant.gettotalNumOfStages = function () {
	        return expectedDetail.totalNumOfStages;
	    };
	    constant.getstageUiOrder = function () {
	        return expectedDetail.stageUiOrder;
	    };
	    constant.getCurrentQuestion = function () {
	        return expectedDetail.currentQuestion;
	    };
	    constant.setstatuscode = function (statuscode) {
	        expectedDetail.statuscode = statuscode;
	    };
	    constant.getstatuscode = function () {
	        return expectedDetail.statuscode;
	    };
	    constant.setislandingpage = function (islandingpage) {
	        expectedDetail.islandingpage = islandingpage;
	    };
	    constant.getislandingpage = function () {
	        return expectedDetail.islandingpage;
	    };
	    constant.setCustomError = function (customerror) {
	        expectedDetail.customerror = customerror;
	    };
	    constant.getCustomError = function () {
	        return expectedDetail.customerror;
	    };
	    constant.insertUserIdentificationdata = function (Id, Question, Answer) {
	        var QuesAnsDetail = { "Id": Id, "Question": Question, "Answer": Answer };
	        expectedDetail.UserIdentificationdata.push(QuesAnsDetail);
	    };
	    constant.getUserIdentificationdata = function () {
	        return expectedDetail.UserIdentificationdata;
	    };
	    constant.ClearUserIdentificationdata = function () {
	        expectedDetail.UserIdentificationdata.length = 0;
	    };
	    constant.setStageOrder = function (StageOrder) {
	        expectedDetail.StageOrder = StageOrder;
	    };
	    constant.getStageOrder = function () {
	        return expectedDetail.StageOrder;
	    };
	    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
	    constant.fetch = function () {
	        var mockUser = "M2";
	        return $q.when(mockUser);
	    };
	    // other stubbed methods
	    return constant;
	})

    describe('Error_Controller_Test_for_currentTheme', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.errorData'));

        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('ErrorCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));
        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });

        it('ensure default page class name', function () {
            expect(scope.pageClass).toBe(expectedDetail.animationclass);
        });

        it('ensure error is custom when getCustomError has value', function () {
            expect(scope.error).toBe(expectedDetail.customerror);
            expectedDetail.customerror = false;
        });

        it('ensure error is custom when getCustomError has null value', function () {
            expect(scope.error).not.toBe(null);
        });
    });

});