﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('AppointmentCtrl',
    function (
        $filter,
        $scope,
        $rootScope,
        $state,
        $sce,
        ENV,
        miAppProperties,
        miLocale,
        cfpLoadingBar,
        miComponentRoute,
        miAppointmentsSlotFactory,
        miUiStagesProgressbar,
        miValidation,
        miAdvanceSearchFactory,
        miResourceDataFactory,
        miResourceProperties,
        miMoiProperties,
        miConversion) {

        $scope.TimeHintMsg = "";
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        $scope.getHtml = function (html) {
            return $sce.trustAsHtml(html);
        };
        $scope.ResourceData = miAppProperties.getResourceData();
        if (miAppProperties.getAppointmentList().hasData)
            $scope.appointmentData = miAppProperties.getAppointmentList();
        else
            $scope.appointmentData = miAppProperties.getappointmentDetails();
        //variable to check whether resource skipped or not
        $scope.isResourceSkipped = miMoiProperties.getResourceSkipped();

        $scope.populateData = function (appoinmentDataList) {
            $scope.AppointmentDTO = [];
            for (var slotindex = 0; slotindex < appoinmentDataList.length; slotindex++) {
                $scope.AppointmentDTO.push(appoinmentDataList[slotindex]["appointmentSlot"]);
            }
            //sorting of appointments
            $scope.AppointmentDTO = $filter('orderBy')($scope.AppointmentDTO);
        }

        var currentDate = new Date();
        currentDate.setDate(currentDate.getDate() + 1);
        if ($rootScope.searchData == undefined) {
            //Is Advanced Filter applied
            $rootScope.isAdvancedFilterApplied = false;
            $rootScope.searchData = {};
            if (Modernizr.inputtypes.date)
                $rootScope.searchData["dateStart"] = new Date();
            else
                $rootScope.searchData["dateStart"] = $filter("date")(new Date(), ENV.DATE_FORMAT);
        }
        $scope.slotsAvailable = true;
        $scope.dataCustomization = function () {
            $scope.dateonlySlots = [];
            $scope.datetimeSlots = [];
            $scope.uiDateModel = [];
            $scope.dateModel = [];
            $scope.appointmentSlotModel = [];
            $scope.UIModel = {
            };
            $scope.originalAppointmentSlots = [];
            $scope.convertedAppointmentSlots = [];
            for (var index = 0; index < $scope.AppointmentDTO.length; index++) {

                //Conversion to Local timezone
                $scope.originalAppointmentSlots.push($scope.AppointmentDTO[index]);

                $scope.AppointmentDTO[index] = $filter('date')($scope.AppointmentDTO[index], ENV.ISO_DATETIME_FORMAT, miAppProperties.getResourceData().UtcOffset.replace(':', ''));
                $scope.convertedAppointmentSlots.push($scope.AppointmentDTO[index]);
                if ($scope.dateModel.indexOf($filter('date')($scope.AppointmentDTO[index], ENV.FILTER_DATE_FORMAT1)) == -1) {
                    $scope.dateModel.push($filter('date')($scope.AppointmentDTO[index], ENV.FILTER_DATE_FORMAT1));
                }
                $scope.dateSlot = $filter('date')($scope.AppointmentDTO[index], ENV.FILTER_DATE_FORMAT1);
                //UI Date Label
                if ($scope.dateSlot === $filter('date')(new Date(), ENV.FILTER_DATE_FORMAT1, miAppProperties.getResourceData().UtcOffset.replace(':', ''))) {
                    if ($scope.uiDateModel.indexOf($filter('translate')('_Today_')) == -1) {
                        $scope.uiDateModel.push($filter('translate')('_Today_'));
                    }
                }
                else if ($scope.dateSlot === $filter('date')(currentDate, ENV.FILTER_DATE_FORMAT1, miAppProperties.getResourceData().UtcOffset.replace(':', ''))) {
                    if ($scope.uiDateModel.indexOf($filter('translate')('_Tomorrow_')) == -1) {
                        $scope.uiDateModel.push($filter('translate')('_Tomorrow_'));
                    }
                }
                else {
                    if ($scope.uiDateModel.indexOf($filter('date')($scope.AppointmentDTO[index], ENV.FILTER_FULLDATE_FORMAT)) == -1) {
                        $scope.uiDateModel.push($filter('date')($scope.AppointmentDTO[index], ENV.FILTER_FULLDATE_FORMAT));
                    }
                }
                //Filtering of distinct Dates from appointment  response DTO                    
                if ($scope.dateonlySlots.indexOf($scope.dateSlot) == -1) {
                    $scope.dateonlySlots.push($scope.dateSlot);
                }
                $scope.datetimeSlot = $filter('date')($scope.AppointmentDTO[index], ENV.FILTER_DATE_FORMAT3);
                $scope.datetimeSlots.push($scope.datetimeSlot);

            }
        }

        $scope.dataFormatting = function () {
            if (!$rootScope.isAppointmentEdit) {
                $rootScope.appointmentTime = "";
                $rootScope.appointmentDate = "";
            }

            //Filtering of time slots from appointment  response DTO
            for (var dateindex = 0; dateindex < $scope.dateonlySlots.length; dateindex++) {
                $scope.timeonlySlots = [];
                $scope.dateSpecificTimeSlots = $filter('filter')($scope.datetimeSlots, $scope.dateonlySlots[dateindex]);
                for (var timeindex = 0; timeindex < $scope.dateSpecificTimeSlots.length; timeindex++) {
                    $scope.dateSpecificTimeSlots[timeindex].substr(0, $scope.dateSpecificTimeSlots[timeindex].indexOf(' '));
                    if ($scope.timeonlySlots.indexOf($scope.dateSpecificTimeSlots[timeindex].substr($scope.dateSpecificTimeSlots[timeindex].indexOf(' ') + 1)) == -1) {
                        $scope.timeonlySlots.push($scope.dateSpecificTimeSlots[timeindex].substr($scope.dateSpecificTimeSlots[timeindex].indexOf(' ') + 1));
                    }
                }
                $scope.morning_shift_List = $filter('filter')($scope.timeonlySlots, $filter('translate')('_AM_'));
                $scope.afternoon_shift_List = $filter('filter')($scope.timeonlySlots, $filter('translate')('_PM_'));

                //handle is selected flag
                $scope.morning_shift = [];
                $scope.afternoon_shift = [];
                var expandAfternoon = false;
                var expandMorning = false;
                for (var a = 0; a < $scope.morning_shift_List.length; a++) {
                    var morning_slot = {
                    };
                    if ($scope.morning_shift_List[a] === $rootScope.appointmentTime && $scope.dateModel[dateindex] === $rootScope.appointmentDate) {
                        expandMorning = true;
                        morning_slot = {
                            "slotname": $scope.morning_shift_List[a], "isSelected": true
                        }
                        $scope.morning_shift.push(morning_slot);
                    }
                    else {
                        morning_slot = {
                            "slotname": $scope.morning_shift_List[a], "isSelected": false
                        }
                        $scope.morning_shift.push(morning_slot);
                    }
                }

                for (var a = 0; a < $scope.afternoon_shift_List.length; a++) {
                    var afternoon_slot = {
                    };
                    if ($scope.afternoon_shift_List[a] === $rootScope.appointmentTime && $scope.dateModel[dateindex] === $rootScope.appointmentDate) {
                        expandAfternoon = true;
                        afternoon_slot = {
                            "slotname": $scope.afternoon_shift_List[a], "isSelected": true
                        }
                        $scope.afternoon_shift.push(afternoon_slot);
                    }
                    else {
                        afternoon_slot = {
                            "slotname": $scope.afternoon_shift_List[a], "isSelected": false
                        }
                        $scope.afternoon_shift.push(afternoon_slot);
                    }
                }

                $scope.appointmentSlot = {
                    "sectionHeadingText": $scope.uiDateModel[dateindex], "date": $scope.dateModel[dateindex], "contents": [{
                        header: $filter('translate')('_Morning_'), "slots": $scope.morning_shift, "isExpand": expandMorning
                    }, {
                        header: $filter('translate')('_Afternoon_'), "slots": $scope.afternoon_shift, "isExpand": expandAfternoon
                    }]
                };
                $scope.appointmentSlotModel.push($scope.appointmentSlot);
            }
        }

        $scope.setData = function () {
            $scope.UIModel = {
                "sections": $scope.appointmentSlotModel
            };
        }
        $scope.setError = function (appointmentData) {
            if (miAppProperties.getappointmentDetailsStatus() === 200) {
                if (appointmentData.appointmentList.length === 0) {
                    $scope.slotsAvailable = false;
                    if ($rootScope.isAdvancedFilterApplied) {
                        $scope.errDesc = $filter('translate')('_AppointmentListEmptyMessage_');
                    }
                    else {
                        $scope.errDesc = $filter('translate')('_AppointmentDefaultSearchEmptyMessage_');
                    }
                }
                else {
                    $scope.TimeHintMsg = appointmentData.userMsg;
                    $scope.populateData(appointmentData.appointmentList);
                    $scope.dataCustomization();
                    $scope.dataFormatting();
                    $scope.setData();
                }

            }
            if (miAppProperties.getappointmentDetailsStatus() === 406) {

                if (miAppProperties.getCustomError()) {
                    $scope.errDesc = miAppProperties.getCustomError();
                }
                else {
                    $scope.errDesc = $filter('translate')('_AppointmentDefaultSearchEmptyMessage_');
                }
                $scope.errDesc = miAppProperties.getCustomError();
                $scope.slotsAvailable = false;
            }
        }

        $scope.setError($scope.appointmentData);

        $scope.book = function (dateheader, date, time) {
            ga('send', 'event', 'Functional', 'Button click', 'Book appointment');
            $rootScope.appointmentDateHeader = dateheader;
            $rootScope.appointmentDate = date;
            $rootScope.appointmentTime = time;
            var booktime=time.replace($filter('translate')('_AM_'),"AM").replace($filter('translate')('_PM_'),"PM");
            var utcString = $filter('filter')($scope.convertedAppointmentSlots, $filter('date')(new Date(date + " " + booktime), ENV.ISO_DATETIME_FORMAT2));
            var indexBookSlot = $scope.convertedAppointmentSlots.indexOf(utcString[0]);
            $rootScope.appointmentUtcDateString = $scope.originalAppointmentSlots[indexBookSlot];
            $rootScope.isAppointmentEdit = false;
            $state.go(miComponentRoute.getComponentroute(ENV.APPOINTMENTSUMMARY_PAGE_CONSTANT));
        }

        $scope.showMore = function () {
            ga('send', 'event', 'Utility', 'Button click', 'Show more appointments');
            cfpLoadingBar.start();
            var startDate = $filter('date')($filter('date')(new Date(), ENV.ISO_DATETIME_FORMAT), ENV.ISO_DATETIME_FORMAT, miAppProperties.getResourceData().UtcOffset.replace(':', '')) +miAppProperties.getResourceData().UtcOffset;
            var moreApptsStartDateTime=$scope.AppointmentDTO[$scope.AppointmentDTO.length - 1] +miAppProperties.getResourceData().UtcOffset;
            var slots = [];
            var params = { paramName: ENV.SHOW_MORE_PARAMS, paramValue: moreApptsStartDateTime};
            miAppointmentsSlotFactory.getAppointments(miAppProperties.getorgcode(), miLocale.getLocaleCode(), miAppProperties.getResourceData().ResourceCode, startDate, miAppProperties.getappointmentType(), miAppProperties.getcontextid(), params)
            .then(function (result) {
                cfpLoadingBar.complete();
                slots = result.data.appointmentList;
                if (slots.length != 0) {
                    $scope.slotsAvailable = true;
                    angular.forEach(slots, function (obj, index) {
                        var list = $scope.appointmentData.appointmentList;
                        $scope.appointmentData.appointmentList.push(obj);
                    });
                    miAppProperties.setAppointmentList($scope.appointmentData.appointmentList, true);
                    $scope.populateData($scope.appointmentData.appointmentList);
                    $scope.dataCustomization();
                    $scope.dataFormatting();
                    $scope.setData();
                    $scope.showErrDesc = false;
                }
                else {
                    $scope.slotsAvailable = false;
                    $scope.showErrDesc = true;
                    $scope.errDesc = $filter('translate') ('_ShowMoreListEmptyMessage_');
            }
        });
    }

        $scope.openAdvancedSearch = function () {
            ga('send', 'event', 'Utility', 'Button click', 'Open advance search');
            miAdvanceSearchFactory.advancedSearchByDatetime();
            cfpLoadingBar.openAdvancedSearch();
    }   

        //function to search a appointment
        $rootScope.applyAdvancedSearch = function () {
            
            $scope.data = $rootScope.searchFormFields.field;
            $scope.index = 0;
            $scope.uam = "";
            $scope.searchDate = "";
            $scope.timeafter = "";
            $scope.timebefore = "";
            $scope.searchParams =[];
            for (var i = 0; i < $scope.data.length; i++) {
                $scope.key = $scope.data[i]["id"];
                $scope.cntrl = angular.element('#' +$scope.key);
                $scope.cntrl.text("");
                $scope.cntrl.removeClass('mi-uam-block--alert');
        }
            for (var i = 0; i < $scope.data.length; i++) {
                $scope.key = $scope.data[i]["id"];
                $scope.cntrl = angular.element('#' +$scope.key);
                $scope.val = "";
                if ($scope.cntrl[0]) {

                    $scope.val = $scope.cntrl.siblings().eq(0).val();
                    $scope.index++;

                    if ($scope.data[i]["type"] === ENV.SEARCH_PARAM_DATE) {
                        // if custom validation required
                        $scope.uam = miValidation.validateDateandTime($scope.data[i]["isSupportable"] ? $filter('date')(new Date($scope.val).toISOString(), ENV.DATE_FORMAT) : $scope.val, $scope.data[i]["type"], !$scope.data[i]["isSupportable"]);
                        if ($scope.uam == "Valid")
                            $scope.uam = miValidation.isNotPastDate($scope.data[i]["isSupportable"] ? $filter('date')(new Date($scope.val).toISOString(), ENV.DATE_FORMAT) : $scope.val, miAppProperties.getResourceData().UtcOffset.replace(':', ''));
                        if ($scope.uam == "Valid")
                            $scope.uam = miValidation.setMaxSearchYear($scope.data[i]["isSupportable"] ? $filter('date')(new Date($scope.val).toISOString(), ENV.DATE_FORMAT) : $scope.val, ENV.MAX_SEARCH_YEAR);
                        if ($scope.uam == "Valid") {
                            $scope.cntrl.text("");
                            $scope.cntrl.removeClass('mi-uam-block--alert');
                        }
                        else {
                            $scope.cntrl.text($scope.uam);
                            $scope.cntrl.addClass('mi-uam-block--alert');
                            return false;
                    };
                        $scope.searchDate = $scope.cntrl.siblings().eq(0).val();
                        $scope.val = $scope.searchDate;
                    }
                    else if ($scope.data[i]["type"] === ENV.SEARCH_PARAM_TIME) {
                        // if custom validation required
                        //formatted HH:mm:ss.sss to HH:mm
                        $scope.val = $scope.val.split(":").splice(0, 2).join(":");
                        $scope.uam = miValidation.validateDateandTimeAllowEmpty($scope.val, $scope.data[i]["type"], true);
                        if ($scope.uam == "Valid" && $scope.val.length > 0)
                            $scope.uam = miValidation.isNotPastDatetime($scope.searchDate + " " + $scope.val, miAppProperties.getResourceData().UtcOffset.replace(':', ''));
                        if ($scope.uam == "Valid" && $scope.val.length > 0)
                            $scope.val = $scope.searchDate + " " +$scope.val;
                        else if ($scope.uam == "Valid")
                            $scope.val = $scope.searchDate + " " +ENV.DEFAULT_TIME;
                        //Saving timeafter for time comparison
                        if ($scope.key != ENV.TIME_BEFORE_KEY)
                            $scope.timeafter = $scope.val;
                        if ($scope.uam == "Valid" && $scope.timeafter != ""
                            && $scope.key == ENV.TIME_BEFORE_KEY && $scope.val.split(" ")[1] != ENV.DEFAULT_TIME) {
                            $scope.uam = miValidation.compareDatetime(new Date($scope.timeafter), new Date($scope.val));
                            if ($scope.uam == "Valid")
                                $scope.timebefore = $scope.val;
                    }

                        if ($scope.uam == "Valid") {
                            $scope.cntrl.text("");
                            $scope.val = new Date($scope.val);
                            $scope.cntrl.removeClass('mi-uam-block--alert');
                        }
                        else {
                            $scope.cntrl.text($scope.uam);
                            $scope.cntrl.addClass('mi-uam-block--alert');
                            return false;
                    };
                    }
                    else {
                        $scope.uam = miValidation.validate($scope.val);
                        if ($scope.uam == "Valid") {
                            $scope.cntrl.text("");
                            $scope.cntrl.removeClass('mi-uam-block--alert');
                        }
                        else {
                            $scope.cntrl.text($scope.uam);
                            $scope.cntrl.addClass('mi-uam-block--alert');
                            return false;
                    };
                }
            }
                $scope.searchParams.push({
                    "id": $scope.key, "val": $scope.val
            });
        }
            cfpLoadingBar.start();
            cfpLoadingBar.closeAdvancedSearch();
            $scope.locationID = "";
            var utcDatetime = "";
            utcDatetime = $filter('date') ($scope.searchParams[1].val, ENV.ISO_DATETIME_FORMAT);
            var startDate = utcDatetime +miAppProperties.getResourceData().UtcOffset;
            utcDatetime = $filter('date') ($scope.searchParams[2].val, ENV.ISO_DATETIME_FORMAT);
            var endTime = $scope.timebefore != "" ? utcDatetime +miAppProperties.getResourceData().UtcOffset : "";
            var params = { paramName: ENV.END_TIME_PARAMS, paramValue: endTime };
            miAppointmentsSlotFactory.getAppointments(miAppProperties.getorgcode(), miLocale.getLocaleCode(), miAppProperties.getResourceData().ResourceCode, startDate, miAppProperties.getappointmentType(), miAppProperties.getcontextid(), params)
                .then(function (result) {
                    //Dummy service call
                    $scope.appointmentData = result.data;
                    $scope.setError($scope.appointmentData);
                    $rootScope.isAdvancedFilterApplied = true;
                    cfpLoadingBar.complete();
        });
    }

        //function to close the advance search popup.
        $rootScope.advancedSearchClose = function () {
            cfpLoadingBar.closeAdvancedSearch();
    }

        //function to reset advance search.
        $scope.resetAdvancedSearch = function () {
            //getting current date.,           
            var startDate = $filter('date') ($filter('date')(new Date(), ENV.ISO_DATETIME_FORMAT), ENV.ISO_DATETIME_FORMAT, miAppProperties.getResourceData().UtcOffset.replace(':', '')) +miAppProperties.getResourceData().UtcOffset;
            //Starting loading animation.
            cfpLoadingBar.start();
            //restet stored appointment slots
            miAppProperties.setAppointmentList([], false);
            miAppointmentsSlotFactory.getAppointments(miAppProperties.getorgcode(), miLocale.getLocaleCode(), miAppProperties.getResourceData().ResourceCode, startDate, miAppProperties.getappointmentType(), miAppProperties.getcontextid())
                .then(function (result) {
                    $scope.appointmentData = result.data;
                    $scope.setError($scope.appointmentData);
                    $rootScope.isAdvancedFilterApplied = false
                    //Resetting search fields
                    $rootScope.setToDefault();
                    //Closing the loading animation.
                    cfpLoadingBar.complete();
        });
    }

        //function to set default to the advance search
        $rootScope.setToDefault = function () {
            $rootScope.emptySearchData(true);
    }

        $rootScope.emptySearchData = function (setDefaultDate) {
            if (Modernizr.inputtypes.date) {
                $rootScope.searchData["dateStart"] = setDefaultDate ? new Date() : "";
                $rootScope.searchData["timeAfter"] = "";
                $rootScope.searchData["timeBefore"] = "";
            }
            else {
                $rootScope.searchData["dateStart"] = setDefaultDate ? $filter("date")(new Date(), ENV.DATE_FORMAT) : "";
                $rootScope.searchData["timeAfter"] = "";
                $rootScope.searchData["timeBefore"] = "";
        }
    }

        $scope.back = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Back');
            cfpLoadingBar.start();
            $rootScope.setToDefault();
            //restet stored appointment slots
            miAppProperties.setAppointmentList([], false);
            if (miAppProperties.getResourceDataList()) {
                cfpLoadingBar.complete();
                $state.go(miComponentRoute.getComponentroute(ENV.RESOURCE_CONSTANT));
            }
            else {
                //Here no need to check whether we are doing back for appraiser or adjuster
                //Because in forward navigation we are already setting value for moitype and resourceGroup as per estimator/adjuster
                //So we will get correct values which requires to shwo the resources for estimator/adjuster respectively.
                miResourceProperties.setDefaultCriteriaForMoi(miMoiProperties.getmoiType());
                var resourceGroup = miMoiProperties.getResourceGroup();
                var resourchSearchCriteria = miResourceProperties.getResourceSearchCriteria();
                resourchSearchCriteria.ResourceId = null;

                // Resource data            

                miResourceDataFactory.GetResourcesOrGroup(resourchSearchCriteria, resourceGroup)
                    .then(function (resourcesresponse) {
                        cfpLoadingBar.complete();
                        if (resourcesresponse.route) {
                            $state.go(miComponentRoute.getComponentroute(resourcesresponse.route));
                        } else {
                            miAppProperties.setResourceDataList(resourcesresponse.data);
                            $state.go(miComponentRoute.getComponentroute(ENV.RESOURCE_CONSTANT));
                    }
            });
        }
    }
});
}(angular));
