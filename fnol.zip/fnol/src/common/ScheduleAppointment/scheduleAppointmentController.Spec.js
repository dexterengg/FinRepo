﻿describe('MFNOL AngularJS Controller (ScheduleAppointment Controller)', function () {

    var $scope, $controller, $state, $sce, $rootScope, miAdvanceSearchFactory, ENV, miValidation, miAppointmentsSlotFactory, miAppProperties;

    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: "",
        isSupportable: false,
        isEditablefalse: false,
        isEditabletrue: true,
        ResourceData: 'fakeData',
        appointmentData: "fakeData",
        appointmentType: "fake",
        appointmentStatusCode: 200,
        contextId: "111"
    };

    var appointmentData =
    {
        appointmentList: [
            {
                appointmentSlot: "2016-11-13T06:00:00",
                resourceId: "M2DIS10"
            },
            {
                appointmentSlot: "2016-11-14T06:00:00",
                resourceId: "M2DIS10"
            },
            {
                appointmentSlot: "2016-11-14T18:00:00",
                resourceId: "M2DIS10"
            },
            {
                appointmentSlot: "2016-11-14T22:00:00",
                resourceId: "M2DIS10"
            },
            {
                appointmentSlot: "2016-11-15T06:00:00",
                resourceId: "M2DIS10"
            }, {
                appointmentSlot: new Date().toISOString(),
                resourceId: "M2DIS10"

            },
            {
                appointmentSlot: new Date(new Date().setDate(new Date().getDate() + 1)).toISOString(),
                resourceId: "M2DIS10"

            }
        ],
        errInfo: null,
        resDesc: "Request Success",
        resStatus: "SUCCESS",
        userMsg: "These slots may be lost after 5 minutes"
    };

    var appointmentDataEmpty =
    {
        appointmentList: []
    }

    var searchedappointmentData =
   {
       appointmentList: [
           {
               appointmentSlot: "2016-11-13T06:00:00",
               resourceId: "M2DIS10"
           },
           {
               appointmentSlot: "2016-11-14T06:00:00",
               resourceId: "M2DIS10"
           },
           {
               appointmentSlot: "2016-11-14T18:00:00",
               resourceId: "M2DIS10"
           }
       ],
       errInfo: null,
       resDesc: "Request Success",
       resStatus: "SUCCESS",
       userMsg: "These slots may be lost after 5 minutes"
   };

    angular.module('mock.resourcedata', [])
		.factory('miAppProperties', function () {
		    var constant = {};
		    constant.gettheme = function () {
		        return expectedDetail.theme;// "M2";
		    };
		    constant.getanimationclass = function () {
		        return expectedDetail.animationclass;
		    };
		    constant.getResourceData = function () {
		        return expectedDetail.ResourceData;
		    };
		    constant.getappointmentType = function () {
		        return expectedDetail.appointmentData;
		    };
		    constant.gettotalNumOfStages = function () {
		        return expectedDetail.totalNumOfStages;
		    };
		    constant.getstageUiOrder = function () {
		        return expectedDetail.stageUiOrder;
		    };
		    constant.getorgcode = function () {
		        return expectedDetail.orgcode;
		    };
		    constant.getappointmentDetails = function () {
		        return appointmentData;
		    };
		    constant.getcontextid = function () {
		        return expectedDetail.contextId;
		    };
		    constant.getappointmentDetailsStatus = function () {
		        return expectedDetail.appointmentStatusCode;
		    };
		    constant.setappointmentDetailsStatus = function (data) {
		        expectedDetail.appointmentStatusCode = data;
		    };
		    constant.setsessionexpired = function (data) { };
		    constant.setResourceDataList = function (resourceList) { };
		    constant.getResourceDataList = function () {
		        return expectedDetail.ResourceData;
		    };
		    constant.fetch = function () {
		        var mockUser = "M2";
		        return $q.when(mockUser);
		    };
		    return constant;
		});

    angular.module('mock.searchFormFields', [])
    .factory('miAdvanceSearchFactory', function () {
        var factory = {};
        factory.advancedSearchByDatetime = function () {
            $rootScope.searchFormFields = {
                "field": [{
                    "id": "datestart",
                    "placeholder": "",
                    "name": $filter('translate')("_StartingOn_"),
                    "type": "date",
                    "isSupportable": true,
                    "val": "dateStart"
                }, {
                    "id": "timeafter",
                    "placeholder": "",
                    "name": "",
                    "type": "time",
                    "isSupportable": true,
                    "val": "timeAfter"
                }, {
                    "id": "timebefore",
                    "placeholder": "",
                    "name": "",
                    "type": "time",
                    "isSupportable": true,
                    "val": "timeBefore"
                }, {
                    "id": "txtcity",
                    "placeholder": "",
                    "name": "",
                    "type": "text",
                    "isSupportable": true,
                    "val": "mockCity"
                }]
            }
        }
        return factory;
    });

    beforeEach(module('mi.mfnol.web'));
    beforeEach(module('mock.resourcedata'));
    beforeEach(module('mock.searchFormFields'));

    beforeEach(function () {
        inject(function ($injector, _miAdvanceSearchFactory_) {
            $rootScope = $injector.get('$rootScope');
            $scope = $injector.get('$rootScope').$new();
            $controller = $injector.get('$controller');
            $state = $injector.get('$state');
            $sce = $injector.get('$sce');
            $filter = $injector.get('$filter');
            miAppointmentsSlotFactory = $injector.get('miAppointmentsSlotFactory');
            miAppProperties = $injector.get('miAppProperties');
            miAdvanceSearchFactory = _miAdvanceSearchFactory_;
            ENV = $injector.get('ENV');
        });
    });

    describe('Unit tests for current theme and page class', function () {
        beforeEach(function () {
            $scope = {};
            controller = $controller('AppointmentCtrl', { $scope: $scope });
        });

        it('should ensure current theme is not null', function () {
            expect($scope.currtheme).not.toBe(null);
        });
        it('should ensure current theme is M2', function () {
            expect($scope.currtheme).toBe(expectedDetail.theme);
        });
        it('should ensure page class is not null', function () {
            expect($scope.pageClass).not.toBe(null);
        });
        it('should ensure page class is page-main', function () {
            expect($scope.pageClass).toBe(expectedDetail.animationclass);
        });

    });

    describe('Testing other functions called from the UI', function () {
        beforeEach(function () {
            $scope = {};
            controller = $controller('AppointmentCtrl', { $scope: $scope, $state: $state, $sce: $sce });
        });

        it('should call sce trustAsHtml', function () {
            spyOn($sce, 'trustAsHtml');
            $scope.getHtml('<h1>Test</h1>');
            expect($sce.trustAsHtml).toHaveBeenCalled();
        });

        it('should ensure book fuction is called and sets the values correctly', function () {
            spyOn($state, 'go');
            $scope.book("a", "b", "c");
            expect($rootScope.appointmentDateHeader).toBe('a');
            expect($rootScope.appointmentDate).toBe('b');
            expect($rootScope.appointmentTime).toBe('c');
        });

        it('should ensure showMore function is called and executed', function () {
            var oldDate = Date;
            spyOn(window, 'Date').and.callFake(function () {
                return new oldDate();
            });
            $scope.AppointmentDTO = [{
                appointmentSlot: "2016-11-13T06:00:00",
                resourceId: "M2DIS10"
            }, {
                appointmentSlot: "2016-11-14T06:00:00",
            }, {
                appointmentSlot: new Date().toISOString(),

            },
            {
                appointmentSlot: new Date(new Date().setDate(new Date().getDate() + 1)).toISOString(),

            }];
            spyOn(miAppointmentsSlotFactory, 'getAppointments').and.callFake(function () {
                return $.Deferred().resolve({
                    data: appointmentData
                });
            });
            $scope.showMore();
        });

        it('should ensure showMore function is called and executed when AppointmentDTO is null', function () {
            var oldDate = Date;
            spyOn(window, 'Date').and.callFake(function () {
                return new oldDate();
            });
            $scope.AppointmentDTO = [{
                appointmentSlot: ""
            }]
            spyOn(miAppointmentsSlotFactory, 'getAppointments').and.callFake(function () {
                return $.Deferred().resolve({
                    data: appointmentDataEmpty
                });
            });
            $scope.showMore();
        });
    });
    describe('Unit tests for Advancded search', function () {
        var spy = {
        };
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope')
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miAdvanceSearchFactory = $injector.get('miAdvanceSearchFactory');
                miAppointmentsSlotFactory = $injector.get('miAppointmentsSlotFactory');
                spyOn($state, 'go');
                ENV = $injector.get('ENV');
                $controller('AppointmentCtrl', {
                    $scope: $scope, $state: $state
                });
                miValidation = $injector.get('miValidation');
                spy = spyOn(angular, 'element').and.callFake(function () {
                    return {
                        "0": {
                            "accessKey": ""
                        },
                        text: function (d) {
                        },
                        removeClass: function (d) {
                        },
                        siblings: function () {
                            return {
                                eq: function (d) {
                                    return {
                                        val: function () {
                                            return "2016-12-06T04:55:05.907Z";
                                        }
                                    }
                                }
                            }
                        },
                        addClass: function (d) {
                        },
                        "context": {
                        },
                        "length": 1
                    };
                });
                $rootScope.searchFormFields = {
                    "field": [{
                        "id": "datestart",
                        "placeholder": "",
                        "name": $filter('translate')("_StartingOn_"),
                        "type": "date",
                        "isSupportable": true,
                        "val": "dateStart"
                    }, {
                        "id": "timeafter",
                        "placeholder": "",
                        "name": "",
                        "type": "time",
                        "isSupportable": true,
                        "val": "timeAfter"
                    }, {
                        "id": "timebefore",
                        "placeholder": "",
                        "name": "",
                        "type": "time",
                        "isSupportable": true,
                        "val": "timeBefore"
                    },
                    {
                        "id": "txtcity",
                        "placeholder": "",
                        "name": "",
                        "type": "text",
                        "isSupportable": true,
                        "val": "mockCity"
                    }]
                }
                // $rootScope.searchData = undefined;
            });
        });
        afterEach(function () {
            spy.and.callThrough();
        });
        it('should ensure isAdvancedFilterApplied flag is flase initially', function () {
            $scope.openAdvancedSearch();
            $rootScope.advancedSearchClose();
            expect($rootScope.isAdvancedFilterApplied).toBe(false);
        });
        it('should ensure isAdvancedFilterApplied flag is flase initially', function () {
            Modernizr.inputtypes.date = true;
            $scope.openAdvancedSearch();
            expect($rootScope.isAdvancedFilterApplied).toBe(false);
        });
        it('ensure advancedSearchClose() should be call', function () {
            $rootScope.advancedSearchClose();
            expect($rootScope.isAdvancedFilterApplied).toBe(false);
        });
        it('ensure miAppointmentsSlotFactory.getAppointments() should be call on resetAdvanceSearch', function () {
            $rootScope.searchData = {
            };
            spyOn(miAppointmentsSlotFactory, 'getAppointments').and.callFake(function () {
                return $.Deferred().resolve({
                    data: appointmentData
                });
            });
            $scope.resetAdvancedSearch();
            expect($rootScope.isAdvancedFilterApplied).toBe(false);
        });
        it('ensure setToDefault() should be call', function () {
            $rootScope.searchData = {
            };
            $scope.setToDefault();
            expect($rootScope.isAdvancedFilterApplied).toBe(false);
        });
        it('ensure setToDefault() should be call when HTML5 is supported', function () {
            $rootScope.searchData = {
            };
            Modernizr.inputtypes.date = true;
            $scope.setToDefault(true);
            expect($rootScope.isAdvancedFilterApplied).toBe(false);
        });

        it('ensure setToDefault() should be call when HTML5 is not supported', function () {
            $rootScope.searchData = {
            };
            Modernizr.inputtypes.date = false;
            $scope.setToDefault(false);
            expect($rootScope.isAdvancedFilterApplied).toBe(false);
        });

        it('ensure applyAdvancedSearch() should be call', function () {
            $rootScope.applyAdvancedSearch();
            expect($rootScope.isAdvancedFilterApplied).toBe(false);
        });
        it('ensure miValidation.validateDateandTime should call when input type is date', function () {
            spyOn(miValidation, 'validateDateandTime').and.callFake(function () {
                return "Valid"
            });
            $scope.applyAdvancedSearch();
            expect(miValidation.validateDateandTime).toHaveBeenCalled();
        });

        it('ensure miValidation.isNotPastDate should call when miValidation.validateDateandTime is "Valid"', function () {
            spyOn(miValidation, 'validateDateandTime').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'isNotPastDate').and.callFake(function () {
                return "Valid"
            });
            $scope.applyAdvancedSearch();
            expect(miValidation.isNotPastDate).toHaveBeenCalled();
        });

        it('ensure miValidation.setMaxSearchYear should call when miValidation.isNotPastDate is "Valid"', function () {
            spyOn(miValidation, 'validateDateandTime').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'isNotPastDate').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'setMaxSearchYear').and.callFake(function () {
                return "Valid"
            });
            var oldDate = Date;
            spyOn(window, 'Date').and.callFake(function () {
                return new oldDate();
            });
            $scope.applyAdvancedSearch();
            expect(miValidation.setMaxSearchYear).toHaveBeenCalled();
        });

        it('ensure miValidation.setMaxSearchYear should not call when miValidation.validateDateandTime is "Invalid"', function () {
            spyOn(miValidation, 'validateDateandTime').and.callFake(function () {
                return "Invalid"
            });
            spyOn(miValidation, 'setMaxSearchYear').and.callFake(function () {
                return "Invalid"
            });
            $scope.applyAdvancedSearch();
            expect(miValidation.setMaxSearchYear).not.toHaveBeenCalled();
        });

        it('ensure miValidation.validateDateandTimeAllowEmpty should call when input type is time', function () {
            spyOn(miValidation, 'validateDateandTime').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'isNotPastDate').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'setMaxSearchYear').and.callFake(function () {
                return "Valid"
            });
            var oldDate = Date;
            spyOn(window, 'Date').and.callFake(function () {
                return new oldDate();
            });
            spyOn(miValidation, 'validateDateandTimeAllowEmpty').and.callFake(function () {
                return "Valid"
            });
            $scope.applyAdvancedSearch();
            expect(miValidation.validateDateandTimeAllowEmpty).toHaveBeenCalled();
        });

        it('ensure miValidation.validate should call when input type is text is null', function () {
            spyOn(miValidation, 'validateDateandTime').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'isNotPastDate').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'setMaxSearchYear').and.callFake(function () {
                return "Valid"
            });
            var oldDate = Date;
            spyOn(window, 'Date').and.callFake(function () {
                return new oldDate();
            });
            spyOn(miValidation, 'validateDateandTimeAllowEmpty').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'isNotPastDatetime').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'compareDatetime').and.callFake(function () {
                return "Valid"
            });
            $scope.val = "";
            spyOn(miValidation, 'validate').and.callFake(function () {
                return "Invalid"
            });
            $scope.applyAdvancedSearch();
            //expect(miValidation.validate).toHaveBeenCalled();
        });

        it('ensure miValidation.validate should call when input type is text is not null', function () {
            spyOn(miValidation, 'validateDateandTime').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'isNotPastDate').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'setMaxSearchYear').and.callFake(function () {
                return "Valid"
            });
            var oldDate = Date;
            spyOn(window, 'Date').and.callFake(function () {
                return new oldDate();
            });
            spyOn(miValidation, 'validateDateandTimeAllowEmpty').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'isNotPastDatetime').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'compareDatetime').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'validate').and.callFake(function () {
                return "Invalid"
            });
            $scope.applyAdvancedSearch();
            //expect(miValidation.validate).toHaveBeenCalled();
        });

        it('ensure on call of applyAdvancedSearch() miAppointmentsSlotFactory.getAdvancedSearchAppointments should call', function () {
            spyOn(miValidation, 'validateDateandTime').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'isNotPastDate').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'setMaxSearchYear').and.callFake(function () {
                return "Valid"
            });
            var oldDate = Date;
            spyOn(window, 'Date').and.callFake(function () {
                return new oldDate();
            });
            spyOn(miValidation, 'validateDateandTimeAllowEmpty').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'isNotPastDatetime').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'compareDatetime').and.callFake(function () {
                return "Valid"
            });
            spyOn(miValidation, 'validate').and.callFake(function () {
                return "Valid"
            });
            spyOn(miAppointmentsSlotFactory, 'getAdvancedSearchAppointments').and.callFake(function () {
                return $.Deferred().resolve({
                    data: appointmentData
                });
            });
            $rootScope.applyAdvancedSearch();
            expect(miAppointmentsSlotFactory.getAdvancedSearchAppointments).toHaveBeenCalled();
        });
    });

    describe('Schedule Appointment Controller back functionality', function () {
       // beforeEach(module('mi.mfnol.web'));
        var miAppFactory;
        //beforeEach(module('mock.resourcedata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miResourceDataFactory = $injector.get('miResourceDataFactory');
            });
        });
        it('should call resource page on click of back', inject(function () {
            $controller('AppointmentCtrl', { $scope: $scope, $state: $state, $sce: $sce, miResourceDataFactory: miResourceDataFactory });
            spyOn($state, 'go');
            $scope.back();
            expect($state.go).toHaveBeenCalledWith('shell.landing-Question.ResourceLookUp');
        }));
        it('should call GetResourcesOrGroup service with success response', inject(function () {
            $controller('AppointmentCtrl', { $scope: $scope, $state: $state, $sce: $sce, miResourceDataFactory: miResourceDataFactory });
            miAppProperties.setResourceDataList(false);
            spyOn(miResourceDataFactory, 'GetResourcesOrGroup').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn($state, 'go');
            $scope.back();
            expect($state.go).toHaveBeenCalledWith('shell.landing-Question.ResourceLookUp');
        }));

    });

});