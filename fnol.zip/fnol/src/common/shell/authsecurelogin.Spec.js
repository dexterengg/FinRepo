﻿describe('MFNOL AngularJS Controller (authsecurelogin Controller)', function () {

    var $httpBackend, $scope, $controller;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main1",
        language: "en-US",
        DocID: "",
        stageType: "fake-Stage",
        stageDesc: "fake-stageDesc",
        pageName: "fake-pageName",
        islandingpage: false,
        UserIdentificationdata: [],
        PartialStage: true,
        IsAnswering: true,
        stageOrder: 0,
        telephoneNumber:123
    };
    var sce, miCMSFactory, miStageFactory, miUiStagesProgressbar, miAppFactory, miauthFactory, miuserSession
    // Mocked Service
    angular.module('mock.authsecurelogindata', [])
	.factory('miAppProperties', function ($q) {
	    var constant = {};
	    constant.gettheme = function () {
	        return expectedDetail.theme;
	    };
	    constant.getorgcode = function () {
	        return expectedDetail.orgcode;
	    };
	    constant.getanimationclass = function () {
	        return expectedDetail.animationclass;
	    };
	    constant.getlanguage = function () {
	        return expectedDetail.language;
	    };
	    constant.getDocID = function () {
	        return expectedDetail.DocID;
	    };
	    constant.getstageType = function () {
	        return expectedDetail.stageType;
	    };
	    constant.getstageDesc = function () {
	        return expectedDetail.stageDesc;
	    };
	    constant.getpageName = function () {
	        return expectedDetail.pageName;
	    };
	    constant.setisConfirmed = function () {
	        return expectedDetail.isConfirmed;
	    };
	    constant.setDocID = function (DocID) {
	        return expectedDetail.DocID;
	    };
	    constant.setanimationclass = function (animationclass) {
	        expectedDetail.animationclass = animationclass;
	    };
	    constant.getanimationclass = function () {
	        return expectedDetail.animationclass;
	    };
	    constant.setislandingpage = function (islandingpage) {
	        expectedDetail.islandingpage = islandingpage;
	    };
	    constant.getislandingpage = function () {
	        return expectedDetail.islandingpage;
	    };
	    constant.ClearUserIdentificationdata = function () {
	        expectedDetail.UserIdentificationdata.length = 0;
	    };
	    constant.setpartialStage = function (partialStage) {
	        expectedDetail.PartialStage = partialStage;
	    };
	    constant.setIsAnswering = function (isAnswering) {
	        expectedDetail.IsAnswering = isAnswering;
	    };
	    constant.resetAllVarivables = function () { };
	    constant.getStageOrder = function () {
	        return expectedDetail.stageOrder;
	    };
	    constant.setStageOrder = function (stageOrder) {
	        expectedDetail.stageOrder = stageOrder;
	    };
	    constant.setCarrierTelePhone = function (telephoneNumber) {
	        expectedDetail.telephoneNumber = telephoneNumber;
	    };
	    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
	    constant.fetch = function () {
	        var mockUser = "M2";
	        return $q.when(mockUser);
	    };

	    // other stubbed methods
	    return constant;
	});
   
    describe('AuthSecureLogin_Controller_Test_for_currentTheme', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.authsecurelogindata'));

        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            rootScope = $rootScope;
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('AuthSecureLoginCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));

               
        it('ensure animation class is not null', function () {
            //$controller('AuthSecureLoginCtrl', {
            //    $scope: $scope, $state: $state, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar, miauthFactory: miauthFactory
            //});
            expect(rootScope.ShellTitle).toBe("");
        });

        it('ensure default page class name', function () {
            expect(rootScope.appBodyTheme).toBe('mi-app-body');
        })
    });
    
    describe('AuthSecureLogin Controller', function () {
        beforeEach(module('mi.mfnol.web'));
        
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $controller = $injector.get('$controller');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                miAppFactory = $injector.get('miAppFactory');
                miStageFactory = $injector.get('miStageFactory');
                miCarrierContactFactory = $injector.get('miCarrierContactFactory');
                
            });
        });
        beforeEach(function () {
            inject(function ($injector) {
                miauthFactory = $injector.get('miauthFactory');
                miuserSession = $injector.get('miuserSession');
                spyOn(miuserSession, 'getTokens').and.callThrough();
                spyOn(miauthFactory, 'saveRefreshToken').and.callFake(function () {
                    return $.Deferred().resolve({
                        data: "fakedata"
                    });
                });
                spyOn(miauthFactory, 'refreshUser').and.callFake(function () {
                    return $.Deferred().resolve({
                        data: "fakedata"
                    });
                });
                spyOn(miauthFactory, 'isLoggedIn').and.callFake(function () {
                    return $.Deferred().resolve({
                        data: true
                    });
                });
            });
        });
        it('ensure miauthFactory.saveRefreshToken should call', inject(function () {
            spyOn(miAppFactory, 'getLanguageList').and.callThrough();
            $controller('AuthSecureLoginCtrl', {
                $scope: $scope, $state: $state, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar, miauthFactory: miauthFactory
            });
            expect(miauthFactory.saveRefreshToken).toHaveBeenCalled();
        }));
        it('ensure miAppFactory.getLanguageList should call with error page', inject(function () {
            spyOn($state, 'go');
            spyOn(miAppFactory, 'getLanguageList').and.callFake(function () {
                return $.Deferred().resolve({
                    data: true, route: 400
                });
            });
            $controller('AuthSecureLoginCtrl', {
                $scope: $scope, $state: $state, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar, miauthFactory: miauthFactory
            });
            expect(miAppFactory.getLanguageList).toHaveBeenCalled();
        }));
        it('ensure miAppFactory.getLanguageList and miAppFactory.getIdentificationFields should call with error page', inject(function () {
            spyOn($state, 'go');
            spyOn(miAppFactory, 'getLanguageList').and.callFake(function () {
                return $.Deferred().resolve({
                    data: true, route: ""
                });
            });
            spyOn(miAppFactory, 'getIdentificationFields').and.callFake(function () {
                return $.Deferred().resolve({
                    data: true, route: 400
                });
            });
            $controller('AuthSecureLoginCtrl', {
                $scope: $scope, $state: $state, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar, miauthFactory: miauthFactory
            });
            expect(miAppFactory.getLanguageList).toHaveBeenCalled();
            expect(miAppFactory.getIdentificationFields).toHaveBeenCalled();
        }));
        it('ensure miCarrierContactFactory.getCarrierTelephoneNumber should call with error page', inject(function () {
            spyOn($state, 'go');
            spyOn(miAppFactory, 'getLanguageList').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "fake-list", route: ""
                });
            });
            spyOn(miAppFactory, 'getIdentificationFields').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "fake-fields", route: ""
                });
            });
            spyOn(miCarrierContactFactory, 'getCarrierTelephoneNumber').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "fake-number", route: 400
                });
            });
            $controller('AuthSecureLoginCtrl', {
                $scope: $scope, $state: $state, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar, miauthFactory: miauthFactory
            });
            expect(miAppFactory.getLanguageList).toHaveBeenCalled();
            expect(miAppFactory.getIdentificationFields).toHaveBeenCalled();
            expect(miCarrierContactFactory.getCarrierTelephoneNumber).toHaveBeenCalled();
        }));
        it('ensure miStageFactory.getNextStage should call with error page', inject(function () {
            spyOn($state, 'go');
            spyOn(miAppFactory, 'getLanguageList').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "fake-list", route: ""
                });
            });
            spyOn(miAppFactory, 'getIdentificationFields').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "fake-fields", route: ""
                });
            });
            spyOn(miCarrierContactFactory, 'getCarrierTelephoneNumber').and.callFake(function () {
                return $.Deferred().resolve({
                    data: "fake-number", route: "",status:200
                });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $controller('AuthSecureLoginCtrl', {
                $scope: $scope, $state: $state, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar, miauthFactory: miauthFactory
            });
            expect(miAppFactory.getLanguageList).toHaveBeenCalled();
            expect(miAppFactory.getIdentificationFields).toHaveBeenCalled();
            expect(miCarrierContactFactory.getCarrierTelephoneNumber).toHaveBeenCalled();
        }));

    });


    //describe('AuthSecureLogin Controller', function () {
    //    beforeEach(module('mi.mfnol.web'));

    //    beforeEach(function () {
    //        inject(function ($injector) {
    //            $rootScope = $injector.get('$rootScope');
    //            $controller = $injector.get('$controller');
    //            $scope = $injector.get('$rootScope').$new();
    //            $state = $injector.get('$state');
    //            miAppFactory = $injector.get('miAppFactory');
    //            miStageFactory = $injector.get('miStageFactory');
    //            miCarrierContactFactory = $injector.get('miCarrierContactFactory');

    //        });
    //    });
    //    beforeEach(function () {
    //        inject(function ($injector) {
    //            miauthFactory = $injector.get('miauthFactory');
    //            miuserSession = $injector.get('miuserSession');
    //            spyOn(miuserSession, 'getTokens').and.callThrough();
    //            spyOn(miauthFactory, 'isLoggedIn').and.callFake(function () {
    //                return $.Deferred().resolve({
    //                    data: false
    //                });
    //            });
    //            spyOn(miauthFactory, 'saveRefreshToken').and.callFake(function () {
    //                return $.Deferred().resolve({
    //                    data: "fakedata"
    //                });
    //            });
    //            spyOn(miauthFactory, 'refreshUser').and.callFake(function () {
    //                return $.Deferred().resolve({
    //                    data: "fakedata"
    //                });
    //            });
               
                
    //        });
    //    });
    //    it('ensure miauthFactory.isLoggedIn should not be loggedIn', inject(function () {
            
    //        $controller('AuthSecureLoginCtrl', {
    //            $scope: $scope, $state: $state, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar, miauthFactory: miauthFactory
    //        });
    //        expect(miauthFactory.saveRefreshToken).toHaveBeenCalled();
    //    }));
    //    //it('ensure miAppFactory.getLanguageList should call with error page', inject(function () {
    //    //    spyOn($state, 'go');
    //    //    spyOn(miAppFactory, 'getLanguageList').and.callFake(function () {
    //    //        return $.Deferred().resolve({
    //    //            data: true, route: 400
    //    //        });
    //    //    });
    //    //    $controller('AuthSecureLoginCtrl', {
    //    //        $scope: $scope, $state: $state, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar, miauthFactory: miauthFactory
    //    //    });
    //    //    expect(miauthFactory.saveRefreshToken).toHaveBeenCalled();
    //    //}));
       

    //});
});