﻿describe('MFNOL AngularJS Controller (Shell Controller)', function () {
    var expectedDetail = {
        callCenterHour: "fr-FR, Mon-Sat 10:00AM to 5:00PM;Sunday Holiday|en-US,Mon- Fri 08:00-05:00;Sat-Sun Closed "
    }
   var $scope, $state, $controller, $rootScope;    
    angular.module('mock.shelldata', [])
    .factory('miAppProperties', function ($q) {
        var constant = {};
        constant.appointmentDTO = {};
        constant.getCallCenterHoursDTO = function () {
            return expectedDetail.callCenterHour;// "M2";
        };
        constant.setCallCenterHoursDTO=function () {
            
        };

         constant.setDisplayCallCenterHours =function () { 

         };

         constant.setCallCenterHourTitle  = function () {

         };

         constant.setCallCenterHours   = function () {

         };
        
        return constant;
    });
    
    describe('ShellController Test for URL', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.shelldata'));
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');                             
            });
        });

        it('verify  call center hours undefined', inject(function () {
            debugger;
            expectedDetail.callCenterHour = ""
           $controller('ShellCtrl', { $scope: $scope
          });
         

          }));

        it('verify no call center hours', inject(function () {           
            expectedDetail.callCenterHour =""
           $controller('ShellCtrl', { $scope: $scope });                     
           expect($scope.callCenterHourQueryString).toBe("");        
           
        }));

         it('verify no call center hours', inject(function () {           
            expectedDetail.callCenterHour ="fr-FR, Mon-Sat 10:00AM to 5:00PM;Sunday Holiday|en-US,Mon- Fri 08:00-05:00;Sat-Sun Closed "
           $controller('ShellCtrl', { $scope: $scope });                     
           expect($scope.callCenterHourQueryString).toBe("Mon- Fri 08:00-05:00;Sat-Sun Closed ");        
           
        }));

       
    });
  
});