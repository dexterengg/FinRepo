﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('AuthSecureLoginCtrl',
    function (
        $rootScope,
        $scope,
        $http,
        $state,
        $stateParams,
        cfpLoadingBar,
        miAppProperties,
        ENV,
        miComponentRoute,
        miauthFactory,
        miuserSession,
        miLocale,
        miAppFactory,
        miStageFactory,
        $filter,
        miCarrierContactFactory,
        $timeout) {

        $scope.OrgCode = $filter('uppercase')($stateParams.org);
        $rootScope.companyCode = $scope.OrgCode;
        var thm = $filter('uppercase')($scope.OrgCode);
        //if (thm != "M2" && thm != "Z6") {
        //    thm = "DefaultTheme";
        //}
        var fileref = document.createElement("link")
        fileref.setAttribute("rel", "stylesheet")
        fileref.setAttribute("type", "text/css")
        var url = '/src/themes/' + thm + '/css/main.css';

        var fevref = document.createElement("link")
        fevref.setAttribute("rel", "icon")
        fevref.setAttribute("type", "image/x-icon")
        var urlFav = '/src/themes/' + thm + '/img/favicon.png';// rel="icon" type="image/x-icon" />
        // request the resource file
        $http({ method: "GET", url: url, cache: false })
            .success(function () {
                $scope.currtheme = thm;
                miAppProperties.settheme(thm);
                miAppProperties.setorgcode($scope.OrgCode);
                fileref.setAttribute("href", url);
                fevref.setAttribute("href", urlFav);
                if (typeof fileref != "undefined") {
                    document.getElementsByTagName("head")[0].appendChild(fileref);
                    document.getElementsByTagName("head")[0].appendChild(fevref);
                }
            })
            .error(function () {
                thm = "DefaultTheme";
                url = '/src/themes/' + thm + '/css/main.css';
                urlFav = '/src/themes/' + thm + '/img/favicon.ico';
                $scope.currtheme = thm;
                miAppProperties.settheme(thm);
                miAppProperties.setorgcode($scope.OrgCode);
                fileref.setAttribute("href", url);
                fevref.setAttribute("href", urlFav);
                if (typeof fileref != "undefined") {
                    document.getElementsByTagName("head")[0].appendChild(fileref);
                    document.getElementsByTagName("head")[0].appendChild(fevref);
                }
            });

        $rootScope.identificationHelpDoc = "/src/themes/" + $rootScope.companyCode + "/helpfiles/index-" + miLocale.getLocaleCode() + ".html";
        $rootScope.IsHelpDocExist = false;
        $rootScope.CheckHelpDoc = function () {
            $http.get($rootScope.identificationHelpDoc)
           .success(function (data, status, headers) {

               $rootScope.IsHelpDocExist = true;
           })
           .error(function (data, status, header) {

               $rootScope.IsHelpDocExist = false;
           });
        }

        $rootScope.CheckHelpDoc();

        miAppProperties.setanimationclass('page-main');
        miAppProperties.setislandingpage(false);
        miAppProperties.setpartialStage(false);
        miAppProperties.setIsAnswering(false);
        $rootScope.ShellTitle = "";
        $rootScope.appBodyTheme = "";
        $rootScope.appBodyTheme = "mi-app-body";
        $rootScope.infoheader = false;
        $rootScope.intrologo = 'N';
        $rootScope.introtext = 'N';
        $rootScope.introbody = 'N';
        $rootScope.introbutton = 'N';
        localStorage.setItem('container', "");
        miAppProperties.setImageData();
        miAppProperties.ClearUserIdentificationdata();
        cfpLoadingBar.start();
        cfpLoadingBar.completeCallPopup();
        miAppProperties.resetAllVarivables();
        miauthFactory.saveRefreshToken($rootScope.tmpRefreshToken ? $rootScope.tmpRefreshToken : miuserSession.getTokens().refreshToken, $rootScope.clientId ? $rootScope.clientId : miuserSession.getTokens().clientId)
            .then(function (loginstatus) {
                if (miauthFactory.isLoggedIn()) {
                    miauthFactory.refreshUser().then(function (loginstatus) {
                        if (miauthFactory.isLoggedIn()) {
                            miAppFactory.getLanguageList()
                            .then(function (languagelistresponse) {
                                if (languagelistresponse.route) {
                                    cfpLoadingBar.complete();
                                    $state.go(miComponentRoute.getComponentroute(languagelistresponse.route));
                                }
                                else {
                                    miAppFactory.getIdentificationFields(miAppProperties.getorgcode(), miLocale.getLocaleCode())
                                    .then(function (identificationfieldsresponse) {
                                        if (identificationfieldsresponse.route) {

                                            cfpLoadingBar.complete();
                                            $state.go(miComponentRoute.getComponentroute(identificationfieldsresponse.route));
                                        }
                                        else {
                                            if (!miAppProperties.getStageOrder()) {
                                                miAppProperties.setStageOrder(0);
                                            }
                                            miCarrierContactFactory.getCarrierTelephoneNumber(miAppProperties.getorgcode(), miLocale.getLocaleCode())
                                               .then(function (carriercontactresponse) {
                                                   if (carriercontactresponse.route) {
                                                       cfpLoadingBar.complete();
                                                       $state.go(miComponentRoute.getComponentroute(carriercontactresponse.route));
                                                   }
                                                   else {
                                                       if (carriercontactresponse.status === 200) {
                                                           miAppProperties.setCarrierTelePhone(carriercontactresponse.data);
                                                       }
                                                       miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                        .then(function (nextstageresponse) {

                                                            cfpLoadingBar.complete();
                                                            //$window.location.reload();
                                                            if (nextstageresponse.route) {
                                                                //$route.reload();
                                                                $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                            }
                                                        });
                                                   }
                                               });
                                        }
                                    })
                                }
                            });
                        }
                        else {
                            cfpLoadingBar.complete();
                            $state.go(miComponentRoute.getComponentroute(401));
                        }
                    });
                }
                else {
                    cfpLoadingBar.complete();
                    $state.go(miComponentRoute.getComponentroute(401));
                }
            });
    });
}(angular));