﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('ShellCtrl',
    function (
        $scope,
        $state,
        $http,
        $location,
        $rootScope,
        $q,
        ENV,
        miComponentRoute,
        miGetMiEnvironment,
        $filter,
        miAppProperties,
        $stateParams) {
        var LanguageFlag = false;
        var DefaultLanguageHours = "";
        var callCenterHours = [];
        var token = $location.search()['token'];
        $rootScope.tmpRefreshToken = token;
        debugger;
        //Getting call center hours from query string.
        $scope.callCenterHourQueryString = $location.search()['callcenterhours'];
        if ($scope.callCenterHourQueryString != undefined) {
            miAppProperties.setCallCenterHoursDTO($scope.callCenterHourQueryString);
        }                 
        $scope.callCenterHourQueryString = miAppProperties.getCallCenterHoursDTO();
        
        miAppProperties.setCallCenterHoursDTO($scope.callCenterHourQueryString);
        var callCenterHourArray = $scope.callCenterHourQueryString.split(ENV.CALL_CENTER_LANGUAGE_SEPARATOR);
        $scope.selectedLanguage = $stateParams.lan === "" ? ENV.DEFAULT_LOCALE : $stateParams.lan;
       
        for (var index = 0; index < callCenterHourArray.length; index++) {
            var LanguageWithHourArray = callCenterHourArray[index].split(ENV.CALL_CENTER_LANGUAGE_HOUR_SEPARATOR);           
            if (angular.equals(LanguageWithHourArray[0].trim(), ENV.DEFAULT_LOCALE)) {
                DefaultLanguageHours = LanguageWithHourArray[1];

            }
           else if (angular.equals(LanguageWithHourArray[0].trim(),$scope.selectedLanguage)) {
               $scope.callCenterHourQueryString = LanguageWithHourArray[1];
                LanguageFlag = true;                
            }
           
        }
        if (!LanguageFlag) {
            if (DefaultLanguageHours) {
                $scope.callCenterHourQueryString = DefaultLanguageHours;
            }   
            else {
                $scope.callCenterHourQueryString = "";
            }
           
        }
       
        //getting the call center hours separator character.
        var callCenterHourSeparator = ENV.CALL_CENTER_HOUR_SEPARATOR;
        //getting the call center title.
        var callCenterHourTitle = $filter('translate')('_CallCenterHourTitle_');   
        if ($scope.callCenterHourQueryString != undefined && $scope.callCenterHourQueryString != "") {
            callCenterHours = $scope.callCenterHourQueryString.split(callCenterHourSeparator);
            miAppProperties.setCallCenterHourTitle(callCenterHourTitle);
            miAppProperties.setCallCenterHours(callCenterHours);
            miAppProperties.setDisplayCallCenterHours(callCenterHours.length > 0);
        }
        else {
            miAppProperties.setDisplayCallCenterHours(false);
        }

        var clientId = $location.search()['clientId'];
        if (clientId)
            $rootScope.clientId = clientId.toUpperCase();
        $scope.url = window.location.href.split('/')[2];

        miGetMiEnvironment.getMiEnvironment()
        .then(function () {

            if ($scope.currtheme) {
            }
            else {
                $state.go(miComponentRoute.getComponentroute(ENV.SECURELOGIN_CONSTANT));
            }

        });

    });
}(angular));