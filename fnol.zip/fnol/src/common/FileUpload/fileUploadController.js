﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('FileUploadCtrl',
    function (
        $rootScope,
        $scope,
        $state,
        $sce,
        miAppProperties,
        cfpLoadingBar,
        ENV,
        miComponentRoute,
        miQues,
        miValidation,
        miUiStagesProgressbar,
        miAppFactory,
        miStageFactory,
        miLocale,
        $interval,
        $filter,
        miuserSession,
        miLocalStorageCollection) {
       
        $scope.FileTypes = ENV.ALLOWED_FILE_TYPES;
        $scope.FilesMaxSize = ENV.ALLOWED_FILE_SIZE_INBYTES;
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        $scope.Back_Btn_Class = ENV.CLICKABLE_CSS;
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        $scope.questionText = $filter('translate')("_FileUploadMessage_");
        $scope.getHtml = function (html) {
            return $sce.trustAsHtml(html);
        };

        $scope.imageDetail = miAppProperties.getImageData();

        $scope.UploadImage = function (files, ImageId) {
            cfpLoadingBar.complete();
            $scope.fileData = $rootScope.miEnvironment.REPAIR_CENTER_SERVICES_HTTPS_URL + ENV.DocIndexEndpoint + "/fileInfos/";
            $scope.objUploadImageData = $filter('filter')($scope.imageDetail, { ImageId: ImageId })[0];
            if ($scope.objUploadImageData.ImageId) {
                $scope.imageDetail[$scope.objUploadImageData.Id].ImageSrc = $scope.fileData + files[0].thumbnailIds[0] + "/stream?access_token=" + miuserSession.getTokens().accessToken;
                $scope.imageDetail[$scope.objUploadImageData.Id].ShowUploadedImage = true;
                $scope.imageDetail[$scope.objUploadImageData.Id].ShowBlankImage = false;
                $scope.MainImageSrc = $scope.fileData + files[0].id;
                $scope.ThumbName = files[0].thumbnails[0].fileName;
                miLocalStorageCollection.setPhotodata($scope,
                    $scope.objUploadImageData.Id,
                    ENV.IMGUPLOAD_SCREEN,
                    $scope.fileData + files[0].thumbnailIds[0],
                    $scope.MainImageSrc,
                    files[0].dto.fileName,
                    files[0].id,
                    files[0].thumbnailIds[0],
                    ENV.FILE_DESCRIPTION + $scope.objUploadImageData.Id)
            }
            
        }
        //Delete the box photo by clicking on cancel button 
        $scope.DeleteCameraPhotoWithId = function (PhotoCollectionId) {
                if (localStorage.getItem('container')) {
                  var  data = JSON.parse(miLocalStorageCollection.getPhotoCollection());
                  var index = miLocalStorageCollection.getArrayIndex(data, PhotoCollectionId);
                    if (index > -1) {
                        for (var count = 0; count < data.length; count++) {
                            if (data[index][0].id == PhotoCollectionId) {
                                var GarbajCollection = JSON.parse(localStorage.getItem('Garbag')) || [];
                                GarbajCollection.push(data[index][0].fileId);
                                GarbajCollection.push(data[index][0].fileId);
                                localStorage.setItem('Garbag', JSON.stringify(GarbajCollection));
                                data.splice(index, 1);
                                break;
                            }
                        }
                    }
                    localStorage.setItem('container', JSON.stringify(data));
                }
        }
        //Cancel the image and show/hide the images by clicking on cancel icon
        $scope.CancelImage = function (ImageId) {
            $scope.objCancelImageData = $filter('filter')($scope.imageDetail, { ImageId: ImageId })[0];
            if ($scope.objCancelImageData.ImageId) {
                $scope.imageDetail[$scope.objCancelImageData.Id].ShowUploadedImage = false;
                $scope.imageDetail[$scope.objCancelImageData.Id].ShowBlankImage = true;
                $scope.DeleteCameraPhotoWithId($scope.objCancelImageData.Id);
                $scope.imageDetail[$scope.objCancelImageData.Id].ImageSrc = null
            }
        }
        $scope.back = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Back');
            cfpLoadingBar.start();
            miStageFactory.getPreviousStage(miAppProperties.getcontextid(), miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                        .then(function (previousresult) {
                            if (previousresult.route) {
                                cfpLoadingBar.complete();
                                $state.go(miComponentRoute.getComponentroute(previousresult.route));
                            }
                            else {
                                //hide the back buttion by click on back button when previous stage is integration type
                                cfpLoadingBar.complete();
                                $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

                            }
                        });
        }
             
        $scope.next = function () {
            
        }

        //get the uploaded images when user comes to back button
        $scope.getPreviousImages = function () {
            if (localStorage.getItem('container')) {
                $scope.accessToken = "/stream?access_token=" + miuserSession.getTokens().accessToken;
                var data = JSON.parse(miLocalStorageCollection.getPhotoCollection());
                for (var iIndex = 0; iIndex < $scope.imageDetail.length; iIndex++) {
                    var count = miLocalStorageCollection.getArrayIndex(data, iIndex);
                    if (count > -1) {
                        $scope.imageDetail[iIndex].ImageSrc = data[count][0].thumbUrl + $scope.accessToken;
                    }
                }
            }
        }
        $scope.getPreviousImages();

      
    });
}(angular));
