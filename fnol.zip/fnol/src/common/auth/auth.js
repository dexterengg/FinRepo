﻿(function (ng) {
    "use strict";

    ng.module('miOauth', ['ngCookies', 'mi.mfnol.environment']);

}(angular));