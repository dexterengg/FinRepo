﻿(function (ng) {
    "use strict";

    ng.module('miOauth')
    .factory('miauthFactory', [
        'miauthService',
        '$q',
        'miuserSession',
        '$rootScope',
        '$interval',
        'AUTH_EVENTS',
        'ENV',
        '$document',
        function (authService, $q, userSession, $rootScope, $interval, AUTH_EVENTS, ENV, $document) {
            return {

                isLoggedIn: function () {
                    return !!userSession.get().isAuthenticate;
                },
                authenticateUser: function () {
                    var that = this;
                    var deferred = $q.defer();
                    authService.authenticateUser()
                    .then(function (result) {
                        var loginStatus = {};
                        if (result.status === 400) {
                            loginStatus.result = false;
                            if (result.data.error === 'invalid_user') {
                                loginStatus.invalidUser = true;
                            } else {
                                loginStatus.invalidPassword = true;
                            }
                            userSession.destroy();
                        } else if (result.status === 200) {
                            loginStatus.result = true;
                            userSession.createToken(result.data, result.data.userName);
                            that.startTokenRefreshTimer(result.data.expires_in);
                            that.resetUserInactivityTimer();
                        }
                        deferred.resolve(loginStatus);
                    });
                    return deferred.promise;
                },

                getRefreshToken: function () {
                    return userSession.getTokens().refreshToken;
                },

                saveRefreshToken: function (refreshToken,clientId) {
                    var deferred = $q.defer();
                    var that = this;
                    var result = { response: false };
                    if (refreshToken) {
                        userSession.saveToken(refreshToken,clientId)                        
                        $rootScope.tmpRefreshToken = "";
                        result.response = true;
                        that.startTokenRefreshTimer(299);
                        that.resetUserInactivityTimer();
                        deferred.resolve(result);
                    }
                    else {
                         userSession.destroy();
                        deferred.resolve(result);
                    }
                    return deferred.promise;
                },

                refreshUser: function () {
                    var that = this;
                    var deferred = $q.defer();
                    var refreshToken = userSession.getTokens().refreshToken;
                    userSession.accessTokenRefreshing = true;
                    // code added to fix the refresh issue to keep client Id in rootScope
                    $rootScope.clientId = $rootScope.clientId ? $rootScope.clientId : userSession.getTokens().clientId;
                    authService.refreshUser(refreshToken, that.getSecretKey(userSession.getTokens().clientId)).then(
                        function (result) {
                            userSession.setAccessToken(result.access_token);
                            userSession.setRefreshToken(result.refresh_token);
                            userSession.accessTokenRefreshing = false;
                            $rootScope.$broadcast(AUTH_EVENTS.oAuthSuccessful);
                            deferred.resolve(result);

                        }, function (error) {
                            userSession.cancelAccessTokenTimer();
                            userSession.accessTokenRefreshing = false;
                            userSession.destroy();
                            $rootScope.$broadcast(AUTH_EVENTS.oAuthFailed);
                            deferred.resolve(error);
                        });

                    return deferred.promise;
                },
                // get secret id on the basis of client id from  $rootScope.miEnvironment
                getSecretKey: function (clientId) {
                    var clientSecret = "";
                    clientSecret = eval("$rootScope.miEnvironment.OAUTH_" + clientId + "_SECRET");
                    return clientSecret;
                },

                getTokenRefreshStatus: function () {
                    return userSession.accessTokenRefreshing;
                },

                startTokenRefreshTimer: function (timeoutDuration) {
                    var that = this;

                    var createRefreshTimer = function (timerValue) {
                        if (that.isLoggedIn() && timerValue) {

                            var timer = $interval(function () {
                                that.startTokenRefreshTimer.apply(that);
                                $interval.cancel(timer);
                            }, (timerValue - 60) * 1000);

                            userSession.setAccessTokenTimer(timer);
                        }
                    };

                    if (timeoutDuration) {
                        createRefreshTimer(timeoutDuration);
                    }
                    else {
                        this.refreshUser().then(function (result) {
                            createRefreshTimer(result.expires_in);
                        });
                    }
                },

                //To be called if user activity is detected
                resetUserInactivityTimer: function () {
                    var that = this;
                    if (that.isLoggedIn()) {
                        var timer = $interval(function () {
                            that.logout();
                            $rootScope.$broadcast(AUTH_EVENTS.sessionTimeout);
                        }, ENV.USER_INACTIVE_TIMEOUT);

                        userSession.setUserInactivityTimer(timer);
                    }
                },

                //Buffers user activity to reduce the number of $timeout calls
                lastUserActivityTime: new Date(),

                //Check if the user is inactive by keeping track of mouse and keyboard events. Additional events: mousemove DOMMouseScroll mousewheel scroll touchmove
                checkUserActivity: function () {
                    var that = this;
                    $document.find('body').on('keydown mousedown touchstart', function () {
                        var currentTime = new Date();
                        if (currentTime - that.lastUserActivityTime >= 10000) {
                            that.resetUserInactivityTimer();
                            that.lastUserActivityTime = currentTime;
                        }
                    });
                },

                expireSession: function () {
                    userSession.expireSession();
                    return true;
                },

                logout: function () {
                    userSession.destroy();
                    return true;
                }
            };
        }])

    .constant('AUTH_EVENTS', {
        loginSuccess: 'auth-login-success',
        loginFailed: 'auth-login-failed',
        logoutSuccess: 'auth-logout-success',
        sessionTimeout: 'auth-session-timeout',
        notAuthenticated: 'auth-not-authenticated',
        notAuthorized: 'auth-not-authorized',
        oAuthSuccessful: '$OAuthSuccessful',
        oAuthFailed: '$OAuthFailed'
    });

}(angular));