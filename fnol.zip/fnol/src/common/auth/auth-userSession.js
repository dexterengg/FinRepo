﻿(function (ng) {
    'use strict';

    ng.module('miOauth')
    .service('miuserSession', ['$interval', '$rootScope', function ($interval, $rootScope) {

        this.setAccessToken = function (accessToken) {
            localStorage.setItem('accessToken', accessToken);
        };

        this.setRefreshToken = function (refreshToken) {
            localStorage.setItem('refreshToken', refreshToken);
        };

        this.setIsAuthenticate = function (value) {
            localStorage.setItem('isAuthenticate', value);
        };

        this.setUserName = function (userName) {
            localStorage.setItem('userName', userName);
        };

        this.setOrgId = function (orgId) {
            localStorage.setItem('orgId', orgId);
        };

        this.setTokenId = function (tokenId) {
            localStorage.setItem('token', tokenId);
        };

        this.setNewToken = function (newtoken) {
            localStorage.setItem('Newtoken', newtoken);
        };

        this.setClientId = function (clientId) {
            localStorage.setItem('ClientId', clientId);
        };

        

        this.goToState = null;

        this.goToParam = null;

        this.create = function (result, user) {
            this.setUserName(user.userName);
            this.setOrgId(result.orgId);
            this.setTokenId(result.tokenId);
            this.setNewToken(result.tokenId);    //Do we need this?
            this.setIsAuthenticate('true');
        };

        this.get = function () {
            return {
                userName: localStorage.getItem('userName'),
                userId: localStorage.getItem('userId'),
                orgId: localStorage.getItem('orgId'),
                token: localStorage.getItem('token'),
                isAuthenticate: localStorage.getItem('isAuthenticate')
            };
        };

        this.createToken = function (result, userName) {
            this.setIsAuthenticate('true');
            this.setUserName(userName);
            this.setAccessToken(result.access_token);
            this.setRefreshToken(result.refresh_token);
        };

        this.saveToken = function (refresh_token, clientId) {
            this.setIsAuthenticate('true');
            this.setRefreshToken(refresh_token);
            this.setClientId(clientId);
        };

        this.getTokens = function () {

            return {
                userName: localStorage.getItem('userName'),
                accessToken: localStorage.getItem('accessToken'),
                refreshToken: localStorage.getItem('refreshToken'),
                clientId: localStorage.getItem('ClientId')
            };
        };

        this.expireSession = function () {
            this.cancelAccessTokenTimer();
            localStorage.removeItem('token');
        };

        this.destroy = function () {
            this.cancelAccessTokenTimer();
            this.cancelUserInactivityTimer();

            //localStorage.removeItem('userName');
            localStorage.removeItem('accessToken');
            localStorage.removeItem('refreshToken');
            localStorage.removeItem('isAuthenticate');

            this.goToState = null;
            this.goToParam = null;
        };

        this.setAccessTokenTimer = function (timer) {
            this.cancelAccessTokenTimer();
            $rootScope.accessTokenTimer = timer;
        };

        this.cancelAccessTokenTimer = function () {
            $interval.cancel($rootScope.accessTokenTimer);
        };

        this.setUserInactivityTimer = function (timer) {
            this.cancelUserInactivityTimer();
            $rootScope.userInactivityTimer = timer;
        };

        this.cancelUserInactivityTimer = function () {
            $interval.cancel($rootScope.userInactivityTimer);
        };

        this.accessTokenRefreshing = false;
        
        return this;
    }]);
}(angular));