﻿(function (ng) {
    'use strict';

    ng.module('miOauth')
    .service('miauthService', [
    '$http',
    '$q',
    '$rootScope',
    'ENV',
    function ($http, $q, $rootScope, ENV) {

        return {
            //Code not being used
            /*
            authenticateUser: function () {
              
                var deferred = $q.defer();
                var authResult = { data: '', status: '' };

                try {
                    $http({
                        method: ENV.POST,
                        url: $rootScope.miEnvironment.MYMITCHELL_HTTPS_URL + ENV.OAUTH_SERVICE_URL,  //TODO: Temporary url will be replaced after service deployment. Need tp start the OAuth server solution first.
                        data: "grant_type=" + ENV.GRANT_TYPE + "&client_id=" + $rootScope.clientId + "&client_secret=" +ENV.CLIENT_SECRET + "&username=" +ENV.USER_NAME + "&co_cd=" +ENV.ORG_ID + "&password=" +ENV.PASSWORD,
                        headers: { 'Content-Type': ENV.CONTENT_TYPE_X_WWW_FORM_URLENCODED }
                    }).success(function (result, status, headers, config) {
                        authResult.data = result;
                        authResult.status = status;
                        deferred.resolve(authResult);
                    }).error(function (result, status, headers, config) {
                        authResult.data = result;
                        authResult.status = status;
                        deferred.resolve(authResult);
                    });

                } catch (e) {
                    deferred.reject(e);
                }
                return deferred.promise;

            },
            */
            refreshUser: function (refreshToken, secretKey) {
                var deferred = $q.defer();
                $http({
                    method: ENV.POST,
                    url: $rootScope.miEnvironment.MYMITCHELL_HTTPS_URL + ENV.OAUTH_SERVICE_URL, 
                    data: "grant_type=" + ENV.GRANT_TYPE_REFRESHTOKEN + "&client_id=" + $rootScope.clientId + "&client_secret=" + secretKey + "&refresh_token=" + refreshToken,
                    headers: { 'Content-Type': ENV.CONTENT_TYPE_X_WWW_FORM_URLENCODED }
                }).success(function (result) {
                    deferred.resolve(result);
                }).error(function (error) {
                    deferred.reject(error);
                });

                return deferred.promise;
            }
        };
    }]);
}(angular));