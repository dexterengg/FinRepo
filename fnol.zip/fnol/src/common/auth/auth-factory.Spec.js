﻿describe("mioauth.authFactory", function () {
    var sut,
        rootScope,
        mockAuthService,
        mockUserSession,
        isIE,
        browserLanguage,
        q,
        timeout,
        mockRefreshToken,
        auth_events,
        document;

    beforeEach(module('miOauth'));

    beforeEach(function () {
        browserLanguage = 'en-US';
        var setupMocks = function () {

            mockAuthService = {
                authenticate: function () {
                },

                authenticateUser: function () {
                    var deferred = q.defer();
                   
                    deferred.resolve({ status: 200, data: {} });
                    
                    return deferred.promise;
                },
                  refreshUser: function (value) {
                    var deferred = q.defer();
                    if (value === 'invalidToken') {
                        deferred.reject('');
                    }
                    else {
                        deferred.resolve({ status: 200, data: {} });
                    }
                    return deferred.promise;
                  }
            };

            mockUserSession = {
                get: function () {
                    return {
                        userName: 'userName',
                        userId:'userId',
                        orgId: 'orgId',
                        token: 'token',
                        isAuthenticate: 'true'
                    };
                },

                getTokens: function () {
                    return { refreshToken: mockRefreshToken };
                },

                destroy: function () {
                },

                createToken: function () {
                },

                setUserInactivityTimer: function () {
                },

                setAccessToken: function () {
                },

                setRefreshToken: function () {
                },

                cancelAccessTokenTimer: function () {
                },

                setAccessTokenTimer: function () {
                },

                expireSession: function () {
                },

                saveToken: function (valid) { },

                accessTokenRefreshing: false
            };
        };

        var registerMocks = function () {
            module(function ($provide) {
                $provide.value("miauthService", mockAuthService);
                $provide.value("miuserSession", mockUserSession);
            });
        };

        setupMocks();
        registerMocks();
    });

    beforeEach(inject(['$q', 'miauthFactory', '$rootScope', '$timeout', '$document', 'AUTH_EVENTS',
        function ($q, authFactory, $rootScope, $interval, $document, AUTH_EVENTS) {
            isIE = false;
            sut = authFactory;
            rootScope = $rootScope;
            q = $q;
            timeout = $interval;
            document = $document;
            auth_events = AUTH_EVENTS;

            mockRefreshToken = 'refreshToken';
            
            spyOn(mockUserSession, 'get').and.callThrough();
            spyOn(mockUserSession, 'destroy').and.callThrough();
            spyOn(mockUserSession, 'createToken').and.callThrough();
            spyOn(mockUserSession, 'getTokens').and.callThrough();
            spyOn(mockUserSession, 'setAccessToken').and.callThrough();
            spyOn(mockUserSession, 'cancelAccessTokenTimer').and.callThrough();
            spyOn(mockUserSession, 'setRefreshToken').and.callThrough();
            spyOn(mockUserSession, 'setAccessTokenTimer').and.callThrough();
            spyOn(mockUserSession, 'setUserInactivityTimer').and.callThrough();
            spyOn(mockUserSession, 'expireSession').and.callThrough();

            spyOn(mockUserSession, 'saveToken').and.callThrough();


            spyOn(mockAuthService, 'authenticateUser').and.callThrough();
            spyOn(mockAuthService, 'refreshUser').and.callThrough();
           

            spyOn(authFactory, 'startTokenRefreshTimer').and.callThrough();
            spyOn(authFactory, 'refreshUser').and.callThrough();
            //spyOn(authFactory, 'saveRefreshToken').and.callThrough();
            spyOn(authFactory, 'resetUserInactivityTimer').and.callThrough();
            spyOn(authFactory, 'logout').and.callThrough();

            spyOn(rootScope, '$broadcast').and.callThrough();

            mockUserSession.accessTokenRefreshing = false;
        }]));

    it('should have a function named isLoggedIn', function () {
        expect(angular.isFunction(sut.isLoggedIn)).toBe(true);
    });
    it('should have a function named authenticateUser', function () {
        expect(angular.isFunction(sut.authenticateUser)).toBe(true);
    });
    
    it('should have a function named getRefreshToken', function () {
        expect(angular.isFunction(sut.getRefreshToken)).toBe(true);
    });

    it('should have a function named saveRefreshToken', function () {
        expect(angular.isFunction(sut.saveRefreshToken)).toBe(true);
    });

    it('should have a function named refreshUser', function () {
        expect(angular.isFunction(sut.refreshUser)).toBe(true);
    });

    it('should have a function named getTokenRefreshStatus', function () {
        expect(angular.isFunction(sut.getTokenRefreshStatus)).toBe(true);
    });

    it('should have a function named startTokenRefreshTimer', function () {
        expect(angular.isFunction(sut.startTokenRefreshTimer)).toBe(true);
    });

    it('should have a function named checkUserActivity', function () {
        expect(angular.isFunction(sut.checkUserActivity)).toBe(true);
    });

    it('should have a function named expireSession', function () {
        expect(angular.isFunction(sut.expireSession)).toBe(true);
    });

    it('should have a function named logout', function () {
        expect(angular.isFunction(sut.logout)).toBe(true);
    });




    describe('isLoggedIn', function () {
        it('should call userSession get function to check if user is logged in', function () {
            sut.isLoggedIn();
            expect(mockUserSession.get).toHaveBeenCalled();
        });

        it('should return the correct boolean value when called', function () {
            var result = sut.isLoggedIn();
            expect(result).toBeTruthy();
        });
    });
    describe('authenticateUser', function () {
        it('should call authService authenticateUser when called', function () {
            sut.authenticateUser();
            expect(mockAuthService.authenticateUser).toHaveBeenCalled();
        });

        it('should call userSession createToken function if user has been authenticated', function () {
            
        sut.authenticateUser();
        rootScope.$apply();
        expect(mockUserSession.createToken).toHaveBeenCalled();
        expect(sut.startTokenRefreshTimer).toHaveBeenCalled();
        expect(sut.resetUserInactivityTimer).toHaveBeenCalled();
        });
    });

    describe('getRefreshToken', function () {
        it('should call userSession getTokens function retrieve refreshToken', function () {
            sut.getRefreshToken();
            expect(mockUserSession.getTokens).toHaveBeenCalled();
        });

        it('should return refreshToken when called', function () {
            var result = sut.getRefreshToken();
            expect(result).toEqual('refreshToken');
        });
    });

    describe('saveRefreshToken', function () {
        it('should call usersession savetoken when we call saverefreshtoken', function () {
            sut.saveRefreshToken(true);
            expect(mockUserSession.saveToken).toHaveBeenCalled();
        });

        it('should not call method', function () {
            sut.saveRefreshToken();
            expect(mockUserSession.saveToken).not.toHaveBeenCalled();
        });
        
    });

    describe('refreshUser', function () {
        it('should call authService refreshUser when called', function () {
            sut.refreshUser();
            expect(mockAuthService.refreshUser).toHaveBeenCalled();
        });

        it('should set accessTokenRefreshing flag to true when access token refresh is in progress', function () {
            sut.refreshUser();
            expect(mockUserSession.accessTokenRefreshing).toBeTruthy();
        });

        it('should set accessTokenRefreshing flag to false to when the access token refresh is successful', function () {
            sut.refreshUser();
            rootScope.$apply();
            expect(mockUserSession.accessTokenRefreshing).toBeFalsy();
        });

        it('should store accessToken and refreshToken if authService refreshUser is successful', function () {
            sut.refreshUser();
            rootScope.$apply();
            expect(mockUserSession.setAccessToken).toHaveBeenCalled();
            expect(mockUserSession.setRefreshToken).toHaveBeenCalled();
        });

        it('should broadcast oAuthSuccessful when the access token refresh is successful', function () {
            sut.refreshUser();
            rootScope.$apply();

            expect(rootScope.$broadcast).toHaveBeenCalledWith(auth_events.oAuthSuccessful);
        });

        it('should set accessTokenRefreshing flag to false to when the access token refresh is unsuccessful', function () {
            mockRefreshToken = 'invalidToken';
            sut.refreshUser();
            rootScope.$apply();
            expect(mockUserSession.accessTokenRefreshing).toBeFalsy();
        });

        it('should cancel access token timer if authService refreshUser was unsuccessful', function () {
            mockRefreshToken = 'invalidToken';
            sut.refreshUser();
            rootScope.$apply();
            expect(mockUserSession.cancelAccessTokenTimer).toHaveBeenCalled();
        });

        it('should broadcast oAuthFailed when the access token refresh is not successful', function () {
            mockRefreshToken = 'invalidToken';
            sut.refreshUser();
            rootScope.$apply();

            expect(rootScope.$broadcast).toHaveBeenCalledWith(auth_events.oAuthFailed);
        });
    });
    describe('getTokenRefreshStatus', function () {
        it('should return accessTokenRefreshing value from userSession', function () {
            mockUserSession.accessTokenRefreshing = true;
            var result = sut.getTokenRefreshStatus();
            expect(result).toBeTruthy();
        });
    });
    describe('startTokenRefreshTimer', function () {
        it('should call itself when access token is about to expire', function () {
            sut.startTokenRefreshTimer(1000);
            timeout.flush(1000);
            expect(sut.startTokenRefreshTimer).toHaveBeenCalled();
        });

        it('should call refreshUser before setting timeout if no timeout duration is provided', function () {
            sut.startTokenRefreshTimer();
            expect(sut.refreshUser).toHaveBeenCalled();
        });

        it('should set access token timer on userSession after timer has been created', function () {
            sut.startTokenRefreshTimer(1000);
            timeout.flush(1000);
            expect(mockUserSession.setAccessTokenTimer).toHaveBeenCalled();
        });
    });

    describe('resetUserInactivityTimer', function () {
        it('should logout the user if inactive for a period of time', function () {
            sut.resetUserInactivityTimer();
            timeout.flush(1000);
            expect(sut.logout).not.toHaveBeenCalled();
        });

        it('should store the timer on user session after creation', function () {
            sut.resetUserInactivityTimer();
            expect(mockUserSession.setUserInactivityTimer).toHaveBeenCalled();
        });

      
    });
    describe('expireSession', function () {
        it('should call userSession expireSession function when called', function () {
            sut.expireSession();
            expect(mockUserSession.expireSession).toHaveBeenCalled();
        });
    });
    describe('logout', function () {
        it('should call userSession expireSession function when called', function () {
            sut.logout();
            expect(mockUserSession.destroy).toHaveBeenCalled();
        });
    });
});