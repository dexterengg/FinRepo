﻿describe('auth-userSession', function () {
    var sut, rootScope, timeout, isIE;
    var accessTokenValue = 'newAccessToken';
    var refreshTokenValue = 'newRefreshToken';
    var isAuthenticateValue = 'true';
    var userNameValue = 'newUserName';
    var orgIdValue = 'newOrgId';
    var tokenValue = 'tokenValue';
    var newTokenValue = 'newTokenValue';

    beforeEach(module('miOauth'));

    beforeEach(inject(['miuserSession', '$rootScope', '$timeout',
        function (userSession, $rootScope, $timeout) {
            isIE = false;
            sut = userSession;
            rootScope = $rootScope;
            timeout = $timeout;

            localStorage.setItem('accessToken', '');
            localStorage.setItem('refreshToken', '');
            localStorage.setItem('isAuthenticate', false);
            localStorage.setItem('userName', '');
            localStorage.setItem('orgId', '');
            localStorage.setItem('token', '');
            localStorage.setItem('Newtoken', '');

            spyOn(sut, 'cancelAccessTokenTimer').and.callThrough();
            spyOn(sut, 'cancelUserInactivityTimer').and.callThrough();
        }]));

    describe('setAccessToken', function () {
        it('should set access token on localstorage', function () {
            sut.setAccessToken(accessTokenValue);
            expect(localStorage.getItem('accessToken')).toEqual(accessTokenValue);
        });
    });

    describe('setRefreshToken', function () {
        it('should set refresh token on localstorage', function () {
            sut.setRefreshToken(refreshTokenValue);
            expect(localStorage.getItem('refreshToken')).toEqual(refreshTokenValue);
        });
    });

    describe('setIsAuthenticate', function () {
        it('should set isAuthenticate on localstorage', function () {
            sut.setIsAuthenticate(true);
            expect(localStorage.getItem('isAuthenticate')).toEqual(isAuthenticateValue);
        });
    });

    describe('setUserName', function () {
        it('should set username on localstorage', function () {
            sut.setUserName(userNameValue);
            expect(localStorage.getItem('userName')).toEqual(userNameValue);
        });
    });

    describe('setOrgId', function () {
        it('should set orgId on localstorage', function () {
            sut.setOrgId(orgIdValue);
            expect(localStorage.getItem('orgId')).toEqual(orgIdValue);
        });
    });

    describe('setTokenId', function () {
        it('should set tokenId on localstorage', function () {
            sut.setTokenId(tokenValue);
            expect(localStorage.getItem('token')).toEqual(tokenValue);
        });
    });

    describe('setNewToken', function () {
        it('should set new tokenId on localstorage', function () {
            sut.setNewToken(newTokenValue);
            expect(localStorage.getItem('Newtoken')).toEqual(newTokenValue);
        });
    });

    describe('create', function () {
        it('should store user session data on localStorage', function () {
            sut.create({ orgId: orgIdValue, tokenId: tokenValue }, { username: userNameValue });
            expect(localStorage.getItem('orgId')).toEqual(orgIdValue);
            expect(localStorage.getItem('token')).toEqual(tokenValue);
            expect(localStorage.getItem('Newtoken')).toEqual(tokenValue);
            expect(localStorage.getItem('isAuthenticate')).toEqual(isAuthenticateValue);
        });
    });

    describe('get', function () {
        it('should return username, tokenId, token and isAuthenticate values', function () {
            localStorage.setItem('userName', userNameValue);
            localStorage.setItem('orgId', orgIdValue);
            localStorage.setItem('token', tokenValue);
            localStorage.setItem('isAuthenticate', isAuthenticateValue);
            var result = sut.get();
            expect(result.userName).toEqual(userNameValue);
            expect(result.orgId).toEqual(orgIdValue);
            expect(result.token).toEqual(tokenValue);
            expect(result.isAuthenticate).toEqual(isAuthenticateValue);
        });
    });

    describe('createToken', function () {
        it('should set isAuthenticate, userName, accessToken and refreshToken on create', function () {
            sut.createToken({ access_token: accessTokenValue, refresh_token: refreshTokenValue }, userNameValue);
            expect(localStorage.getItem('isAuthenticate')).toEqual(isAuthenticateValue);
            expect(localStorage.getItem('userName')).toEqual(userNameValue);
            expect(localStorage.getItem('accessToken')).toEqual(accessTokenValue);
            expect(localStorage.getItem('refreshToken')).toEqual(refreshTokenValue);
        });
    });

    describe('getTokens', function () {
        it('should get userName, accessToken and refreshToken', function () {
            localStorage.setItem('userName', userNameValue);
            localStorage.setItem('accessToken', accessTokenValue);
            localStorage.setItem('refreshToken', refreshTokenValue);
            var result = sut.getTokens();
            expect(result.accessToken).toEqual(accessTokenValue);
            expect(result.userName).toEqual(userNameValue);
            expect(result.refreshToken).toEqual(refreshTokenValue);
        });
    });

    describe('expireSession', function () {
        it('should cancel access token timer when called', function () {
            sut.expireSession();
            expect(sut.cancelAccessTokenTimer).toHaveBeenCalled();
        });

        it('should remove tokenId from localStorage', function () {
            localStorage.setItem('token', tokenValue);
            sut.expireSession();
            expect(localStorage.getItem('token')).toBe(null);
        });
    });

    describe('destroy', function () {
        it('should cancel access token timer and user inactivity timer when called', function () {
            sut.destroy();
            expect(sut.cancelAccessTokenTimer).toHaveBeenCalled();
            expect(sut.cancelUserInactivityTimer).toHaveBeenCalled();
        });

        it('should remove accessToken, refreshToken and isAuthenticate', function () {
            localStorage.setItem('accessToken', accessTokenValue);
            localStorage.setItem('refreshToken', refreshTokenValue);
            localStorage.setItem('isAuthenticate', true);

            sut.destroy();
            expect(localStorage.getItem('accessToken')).toBe(null);
            expect(localStorage.getItem('refreshToken')).toBe(null);
            expect(localStorage.getItem('isAuthenticate')).toBe(null);
        });
    });

    describe('setAccessTokenTimer', function () {
        it('should store the access token timer on rootScope', function () {
            var timer = timeout(function () { }, 1000);
            sut.setAccessTokenTimer(timer);

            expect(rootScope.accessTokenTimer).not.toBe(null);
            timeout.flush();
        });
    });

    describe('cancelAccessTokenTimer', function () {
        it('should call timeout cancel for access token timer', function () {
            spyOn(timeout, 'cancel').and.callThrough();
            var timer = timeout(function () { }, 1000);
            sut.setAccessTokenTimer(timer);
            sut.cancelAccessTokenTimer();

            expect(timeout.cancel).toHaveBeenCalled();
        });
    });

    describe('setUserInactivityTimer', function () {
        it('should store the user inactivity timer on rootScope', function () {
            var timer = timeout(function () { }, 1000);
            sut.setUserInactivityTimer(timer);

            expect(rootScope.userInactivityTimer).not.toBe(null);
            timeout.flush();
        });
    });

    describe('cancelUserInactivityTimer', function () {
        it('should call timeout cancel for user inactivity timer', function () {
            spyOn(timeout, 'cancel').and.callThrough();
            var timer = timeout(function () { }, 1000);
            sut.setUserInactivityTimer(timer);
            sut.cancelUserInactivityTimer();

            expect(timeout.cancel).toHaveBeenCalled();
        });
    });
});