﻿describe("miauthService", function () {

    var _httpBackend,
        mockEnv,
        _sut;

    var initialRefeshToken = "InitialRefreshToken";
    var username = "username";
    var password = "password";
    var cocode = "cocode";

    var mockResult = {
        access_token: "ExpectedAccessToken",
        refresh_token: "ExpectedRefreshToken"
    };

    mockEnv = {
        grantType: "password",
        grantTypeRefreshToken: "grantTypeRefreshToken",
        clientId: "clientId",
        clientSecret: "clientSecret",
        OAuthServiceUrl: "https://www-dev.mymitchell.com/OAuth2Server/1.0/OAuth/Token",
        passwordResetServer: "passwordResetServer/"
    };

    beforeEach(module("miOauth"));

    beforeEach(module(function ($provide) {
        browserLanguage = 'en-US';
        $provide.constant("ENV", mockEnv);
    }));

    beforeEach(inject([
        "ENV",
        "$httpBackend",
        "miauthService",
        function (ENV, $httpBackend, authService) {
            isIE = false;
            _httpBackend = $httpBackend;
            _sut = authService;
        }
    ]));

    afterEach(function () {
        _httpBackend.verifyNoOutstandingExpectation();
        _httpBackend.verifyNoOutstandingRequest();
    });

    describe("refreshUser", function () {
        it("should return the access and refresh tokens on success", function () {
            _httpBackend.expectPOST(mockEnv.OAuthServiceUrl,
                "grant_type=" + mockEnv.grantTypeRefreshToken +
                "&client_id=" + mockEnv.clientId +
                "&client_secret=" + mockEnv.clientSecret +
                "&refresh_token=" + initialRefeshToken)
                .respond(mockResult);

            var passed = false;

            _sut.refreshUser(initialRefeshToken)
                .then(function (result) {
                    passed = true;
                    expect(result.access_token)
                        .toBe(mockResult.access_token);
                    expect(result.refresh_token)
                        .toBe(mockResult.refresh_token);
                });

            _httpBackend.flush();

            expect(passed).toBe(true);
        });

        it("should return error response on failure", function () {
            _httpBackend.expectPOST(mockEnv.OAuthServiceUrl,
                "grant_type=" + mockEnv.grantTypeRefreshToken +
                "&client_id=" + mockEnv.clientId +
                "&client_secret=" + mockEnv.clientSecret +
                "&refresh_token=" + initialRefeshToken)
                .respond(404, "Error");

            var passed = false;

            _sut.refreshUser(initialRefeshToken)
                .then(null, function (response) {
                    passed = true;
                    expect(response).toBe("Error");
                });

            _httpBackend.flush();

            expect(passed).toBe(true);
        });
    });

    describe("authenticateUser", function () {
        it('should return auth result and status on success', function () {
            _httpBackend.expectPOST(mockEnv.OAuthServiceUrl,
                "grant_type=" + mockEnv.grantType +
                "&client_id=" + mockEnv.clientId +
                "&client_secret=" + mockEnv.clientSecret +
                "&username=" + username +
                "&co_cd=" + cocode +
                "&password=" + password)
                .respond(200, mockResult);

            _sut.authenticateUser().then(function (response) {
                expect(response.data).toEqual(mockResult);
                expect(response.status).toEqual(200);
            });
            _httpBackend.flush();
        });

        it('should return auth result and status on failure', function () {
            _httpBackend.expectPOST(mockEnv.OAuthServiceUrl,
                "grant_type=" + mockEnv.grantType +
                "&client_id=" + mockEnv.clientId +
                "&client_secret=" + mockEnv.clientSecret +
                "&username=" + username +
                "&co_cd=" + cocode +
                "&password=" + password)
                .respond(400, "Error");

            _sut.authenticateUser().then(function (response) {
                expect(response.data).toEqual("Error");
                expect(response.status).toEqual(400);
            });
            _httpBackend.flush();
        });
    });
});