﻿describe('MFNOL AngularJS Controller (Inro2 Controller)', function () {

    var $httpBackend, $scope, $controller, miLocale
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: 123,
        stageType: "fake-Stage",
        stageDesc: "fake-stageDesc",
        pageName: "fake-pageName",
        flagStage:"fake-flagStage",
        UserIdentificationdata: "UserIdentificationdata",
        totalNumOfStages: 6,
        stageUiOrder: 2,
        islandingpage: false,
        sessionexpired: true,
        appBodyTheme: "mi-app-body-info",
        getIdentificationFields: true,
        getorgcode: true,
        getLocaleCode: true,
        getIdentificationFields: true,
        getflagStage: true,
        getcontextid: true,
        getcoStageId: 123,
        statuscode: 400,
        setflagStage: true,
        getStageStatus: "fake-status"
    };
    // Mocked Service
    angular.module('mock.Intro2Ctrldata', [])
          .factory('miAppProperties', function ($q) {
              var constant = {};
              constant.gettheme = function () {
                  return expectedDetail.theme;// "M2";
              };
              constant.getorgcode = function () {
                  return expectedDetail.orgcode;
              };
              constant.getanimationclass = function () {
                  return expectedDetail.animationclass;
              };
              constant.getlanguage = function () {
                  return expectedDetail.language;
              };
              constant.getDocID = function () {
                  return expectedDetail.DocID;
              };
              constant.gettotalNumOfStages = function () {
                  return expectedDetail.totalNumOfStages;
              };
              constant.getstageUiOrder = function () {
                  return expectedDetail.stageUiOrder;
              };
              constant.setstatuscode = function (statuscode) {
              };
              constant.setislandingpage = function (statuscode) {
                  
              };
              constant.setflagStage = function (setflagStage) {
                 expectedDetail.setflagStage = setflagStage;
              };
              constant.setcontextid = function (getcontextid) {
                  expectedDetail.getcontextid = getcontextid;
              };
              
              constant.getcontextid = function () {
                  return expectedDetail.getcontextid
              };
              constant.getcoStageId = function () {
                  return expectedDetail.getcoStageId;
              };
              constant.getflagStage = function () {
                  return expectedDetail.flagStage;
              };
              constant.getstatuscode = function () {
                  return "fake-StatusCode";
              };
              constant.getCurrentQuestion = function () {
                  return currentQuestion;
              };
              constant.getstageName = function () {
                  return "IDENTIFICATION";
              };
              constant.setStageStatus = function (getStageStatus) {
                  expectedDetail.getStageStatus = getStageStatus;
              };
              constant.getStageStatus = function () {
                  return expectedDetail.getStageStatus;
              };
              // example stub method that returns a promise, e.g. if original method returned $http.get(...)
              constant.fetch = function () {
                  var mockUser = "M2";
                  return $q.when(mockUser);
              };

              // other stubbed methods

              return constant;
          });
    describe('landingPage2_Controller_Test_for_currentTheme', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.Intro2Ctrldata'));
        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_, _miLocale_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('Intro2Ctrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_,
                miLocale: _miLocale_
            });

        }));

        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });

        it('ensure default page class name', function () {
            expect(scope.pageClass).toBe('page-main');
        });

        it('ensure appBodyTheme class is not null', function () {
            expect(scope.appBodyTheme).not.toBe(null);
        });

        it('ensure appBodyTheme class is mi-app-body', function () {
            expect(scope.appBodyTheme).toBe(expectedDetail.appBodyTheme);
        });


    });

    describe('landingPage2_Controller_Test_for_CreateStage()', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.Intro2Ctrldata'));
        var sce, miCMSFactory, miStageFactory, miUiStagesProgressbar, miLocale
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                miStageFactory = $injector.get('miStageFactory');
                miLocale = $injector.get('miLocale');
                miAppProperties = $injector.get('miAppProperties');
                spyOn(miStageFactory, 'createStage').and.callFake(function () {
                    return $.Deferred().resolve({
                        route: ""
                    });
                });
            });
        });

        it('ensure miAppProperties setflagStage should be false', inject(function () {
            $controller('Intro2Ctrl', {
                $scope: $scope, $state: $state, miStageFactory: miStageFactory, miLocale: miLocale//, miAppProperties:miAppProperties
            });
            spyOn($state, 'go');
            expect(miAppProperties.getflagStage()).toBe("fake-flagStage");;
        }));
        it('should call createStage with no error', inject(function () {
            miAppProperties.setStageStatus(null);
            $controller('Intro2Ctrl', {
                $scope: $scope, $state: $state, miStageFactory: miStageFactory, miLocale: miLocale//, miAppProperties:miAppProperties
            });
            spyOn($state, 'go');
            expect(miStageFactory.createStage).toHaveBeenCalled();
        }));
    });
    describe('landingPage2_Controller_Test_for_CreateStage()', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.Intro2Ctrldata'));
        var sce, miCMSFactory, miStageFactory, miUiStagesProgressbar, miLocale
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                miStageFactory = $injector.get('miStageFactory');
                miLocale = $injector.get('miLocale');
                miAppProperties = $injector.get('miAppProperties');
                spyOn(miStageFactory, 'createStage').and.callFake(function () {
                    return $.Deferred().resolve({
                        route: 400
                    });
                });
            });
        });
        it('should call createStage with error page', inject(function () {
            miAppProperties.setStageStatus(null);
            $controller('Intro2Ctrl', {
                $scope: $scope, $state: $state, miStageFactory: miStageFactory, miLocale: miLocale//, miAppProperties:miAppProperties
            });
            spyOn($state, 'go');
            expect(miStageFactory.createStage).toHaveBeenCalled();
        }));
    });
    describe('landingPage2_Controller_Test_for_next()', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.Intro2Ctrldata'));
        var sce, miCMSFactory, miStageFactory, miUiStagesProgressbar, miLocale
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
               $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                miStageFactory = $injector.get('miStageFactory');
                miLocale = $injector.get('miLocale');
            });
        });

        it('should call next with intro page', inject(function () {
            $controller('Intro2Ctrl', {
                $scope: $scope, $state: $state, miStageFactory: miStageFactory, miLocale: miLocale
            });
            spyOn($state, 'go');
             $scope.next();
            expect($state.go).toHaveBeenCalledWith('shell.intro3');
           
        }));
    });

    describe('landingPage2_Controller_Test_for_animation', function () {
        var element, body, root;
        beforeEach(module('ngAnimate', 'ngAnimateMock', 'mi.mfnol.web'));
        beforeEach(inject(function ($animate, $document, $rootElement, $rootScope) {
            // enable animations globally
            $animate.enabled(true);

            // create a node to be animated and inject it into the DOM
            element = angular.element('<div></div>');
            root = $rootElement.append(element)[0];
            body = $document[0].body;
            body.appendChild(root);

            // trigger initial digest
            $rootScope.$digest();
        }));
        afterEach(function () {
            // clean up
            body.removeChild(root);
        });
        it('ensure current animation is working on enter', inject(function ($animate, $$animateJs) {
            // trigger animation
            $$animateJs(element, 'enter', {
                addClass: 'feb-step-main-info'
            }).start();
            $animate.flush();
        }));

        it('ensure current animation is working on leave', inject(function ($animate, $$animateJs) {
            // trigger animation
            $$animateJs(element, 'leave', {
                addClass: 'feb-step-main-info'
            }).start();
            $animate.flush();
        }));

        it('ensure current animation is working on move', inject(function ($animate, $$animateJs) {
            // trigger animation
            $$animateJs(element, 'move', {
                addClass: 'feb-step-main-info'
            }).start();
            $animate.flush();
        }));

    });
});

