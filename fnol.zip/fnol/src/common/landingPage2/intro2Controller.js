﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
        .animation('.feb-step-main-info', function () {
            return {
                enter: function (element, done) {
                    element.css('display', 'none');
                    $(element).fadeIn(500, function () {
                        done();
                    });
                },
                leave: function (element, done) {
                    $(element).fadeOut(500, function () {
                        done();
                    });
                },
                move: function (element, done) {
                    element.css('display', 'none');
                    $(element).slideDown(500, function () {
                        done();
                    });
                }
            }
        })
    .controller('Intro2Ctrl',
    function (
        $scope,
        $state,
        $rootScope,
        ENV,
        miAppProperties,
        cfpLoadingBar,
        miComponentRoute,
        miStageFactory,
        miLocale,
        $timeout) {

        $rootScope.infoheader = true;

        $scope.tempstage = ['Pending', 'Hidden', 'Hidden', 'Hidden', 'Hidden', 'Hidden', 'Hidden'];

        $timeout(function () {
            $rootScope.intrologo = 'Y';
        }, 500);

        $timeout(function () {
            $rootScope.introtext = 'Y';
        }, 1000);

        $timeout(function () {
            $rootScope.introbody = 'Y';
        }, 1500);

        $timeout(function () {
            $scope.tempstage = ['Pending', 'Pending', 'Hidden', 'Hidden', 'Hidden', 'Hidden', 'Hidden'];
        }, 1700);

        $timeout(function () {
            $scope.tempstage = ['Pending', 'Pending', 'Pending', 'Hidden', 'Hidden', 'Hidden', 'Hidden'];
        }, 1900);

        $timeout(function () {
            $scope.tempstage = ['Pending', 'Pending', 'Pending', 'Pending', 'Hidden', 'Hidden', 'Hidden'];
        }, 2100);

        $timeout(function () {
            $scope.tempstage = ['Pending', 'Pending', 'Pending', 'Pending', 'Pending', 'Hidden', 'Hidden'];
        }, 2300);

        $timeout(function () {
            $scope.tempstage = ['Pending', 'Pending', 'Pending', 'Pending', 'Pending', 'Pending', 'Hidden'];
        }, 2500);

        $timeout(function () {
            $scope.tempstage = ['Pending', 'Pending', 'Pending', 'Pending', 'Pending', 'Pending', 'Pending'];
        }, 2700);


        $timeout(function () {
            $scope.tempstage = ['Active', 'Pending', 'Pending', 'Pending', 'Pending', 'Pending', 'Pending'];
        }, 2900);


        $timeout(function () {
            $scope.tempstage = ['Complete', 'Active', 'Pending', 'Pending', 'Pending', 'Pending', 'Pending'];
        }, 3100);

        $timeout(function () {
            $rootScope.introbutton = 'Y';
        }, 3300);

        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        $scope.$parent.mainclass = "mi-shell__content mobile-content";
        $scope.$parent.spaceclass = "";
        $rootScope.appBodyTheme = "mi-app-body-info";
        miAppProperties.setislandingpage(false);

        if (miAppProperties.getcontextid() && miAppProperties.getflagStage()) {

            //Condition to check whether stage status is null or not
            //If stage status is null then we need to create it, 
            //otherwise just pass it and show the respective page or question
            if (miAppProperties.getStageStatus() != null) {
                miAppProperties.setflagStage(false);
            }
            else {
                cfpLoadingBar.start();
                miStageFactory.createStage(miAppProperties.getcontextid(), miAppProperties.getDocID(), miAppProperties.getcoStageId(), miLocale.getLocaleCode())
                .then(function (createstageresponse) {
                    cfpLoadingBar.complete();
                    if (createstageresponse.route) {
                        $state.go(miComponentRoute.getComponentroute(createstageresponse.route));
                    }
                    else {
                        miAppProperties.setflagStage(false);
                    }
                });
            }
        }

        $scope.next = function () {
            ga('send', 'event', 'Navigation', 'Button click', 'Next');
            $rootScope.intrologo = 'N';
            $rootScope.introtext = 'N';
            $rootScope.introbody = 'N';
            $rootScope.introbutton = 'N';
            $state.go(miComponentRoute.getComponentroute(ENV.INTRO3_CONSTANT));
        }
    });
}(angular));