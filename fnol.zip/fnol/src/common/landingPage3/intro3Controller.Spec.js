﻿describe('MFNOL AngularJS Controller (Inro3 Controller)', function () {

    var $httpBackend, $scope, $controller;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: 123,
        stageType: "fake-Stage",
        stageDesc: "fake-stageDesc",
        pageName: "fake-pageName",
        UserIdentificationdata: "UserIdentificationdata",
        totalNumOfStages: 6,
        stageUiOrder: 2,
        islandingpage: false,
        sessionexpired: true,
        appBodyTheme: "mi-app-body-info",
        getIdentificationFields: true,
        getorgcode: true,
        getLocaleCode: true,
        getIdentificationFields: true,
        getcontextid: "fake-contextid",
        coStageId: 123,
        statuscode: 400,
        flagStage: true,
        StageOrder: 6
    };

    // Mocked Service
    angular.module('mock.Intro3Controllerdata', [])
        .factory('miAppProperties', function ($q) {

            var constant = {};


            constant.gettheme = function () {
                return expectedDetail.theme;
            };
            constant.getorgcode = function () {
                return expectedDetail.orgcode;
            };
            constant.getanimationclass = function () {
                return expectedDetail.animationclass;
            };
            constant.getlanguage = function () {
                return expectedDetail.language;
            };
            constant.getDocID = function () {
                return expectedDetail.DocID;
            };
            constant.getstageType = function () {
                return expectedDetail.stageType;
            };
            constant.getstageDesc = function () {
                return expectedDetail.stageDesc;
            };
            constant.getpageName = function () {
                return expectedDetail.pageName;
            };
            constant.setisConfirmed = function () {
                return expectedDetail.isConfirmed;
            };
            constant.setDocID = function (DocID) {
                return expectedDetail.DocID;
            };
            constant.getUserIdentificationdata = function () {
                return expectedDetail.UserIdentificationdata;
            };
            constant.gettotalNumOfStages = function () {
                return expectedDetail.totalNumOfStages;
            };
            constant.getstageUiOrder = function () {
                return expectedDetail.stageUiOrder;
            };
            constant.setislandingpage = function (islandingpage) {
                expectedDetail.islandingpage = islandingpage;
            };
            constant.getsessionexpired = function () {
                return expectedDetail.sessionexpired;
            };
            constant.getorgcode = function () {
                return expectedDetail.getorgcode;
            };
            constant.getLocaleCode = function () {
                return expectedDetail.getLocaleCode;
            };
            constant.getcontextid = function () {
                return expectedDetail.getcontextid;
            };
            constant.setcontextid = function (getcontextid) {
                expectedDetail.getcontextid = getcontextid;
            };
            constant.getcoStageId = function () {
                return expectedDetail.coStageId;
            };
            constant.setstatuscode = function (statuscode) {
                expectedDetail.statuscode = statuscode;
            };
            constant.setflagStage = function (flagStage) {
                expectedDetail.flagStage = flagStage;
            };
            constant.getStageOrder = function () {
                return expectedDetail.StageOrder;
            };
            // example stub method that returns a promise, e.g. if original method returned $http.get(...)
            constant.fetch = function () {
                var mockUser = "M2";
                return $q.when(mockUser);
            };
            // other stubbed methods
            return constant;
        })

    describe('landingPage3_Controller_Test_for_currentTheme', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.Intro3Controllerdata'));
        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('Intro3Ctrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));

        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });

        it('ensure default page class name', function () {
            expect(scope.pageClass).toBe('page-main');
        });

        it('ensure appBodyTheme class is not null', function () {
            expect(scope.appBodyTheme).not.toBe(null);
        });

        it('ensure appBodyTheme class is mi-app-body', function () {
            expect(scope.appBodyTheme).toBe(expectedDetail.appBodyTheme);
        });


    });

    describe('landingPage3_Next()_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.Intro3Controllerdata'));
        var sce, miCMSFactory, miStageFactory, miUiStagesProgressbar, miAppProperties, $timeout, $httpBackend
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $controller = $injector.get('$controller');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                miAppProperties = $injector.get('miAppProperties');
                miStageFactory = $injector.get('miStageFactory');
               
            });
        });

        it('should call updateStage with error when miAppProperties getcontextid is not null', inject(function () {
            $controller('Intro3Ctrl', {
                $scope: $scope, $state: $state, miUiStagesProgressbar: miUiStagesProgressbar, miStageFactory: miStageFactory
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({
                    route: 400
                });
            });
            $scope.next();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
        }));

        it('should call updateStage with success when miAppProperties getcontextid is not null', inject(function () {
            $controller('Intro3Ctrl', {
                $scope: $scope, $state: $state, miAppProperties: miAppProperties, miUiStagesProgressbar: miUiStagesProgressbar, miStageFactory: miStageFactory
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({
                    route: ""
                });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({
                    route: 400
                });
            });
            $scope.next();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));
      });
    
    describe('landingPage3_Next()_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.Intro3Controllerdata'));
        var sce, miCMSFactory, miStageFactory, miUiStagesProgressbar, miAppProperties, $timeout, $httpBackend
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $controller = $injector.get('$controller');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                miAppProperties = $injector.get('miAppProperties');
                miStageFactory = $injector.get('miStageFactory');

            });
        });
        it('should call getNextStage with error when miAppProperties getcontextid is null', inject(function (miAppProperties) {
            miAppProperties.setcontextid(false);
            $controller('Intro3Ctrl', {
                $scope: $scope, $state: $state, miUiStagesProgressbar: miUiStagesProgressbar, miStageFactory: miStageFactory
            });


            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({
                    route: 400
                });
            });
            $scope.next();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();

        }));

    });



});

