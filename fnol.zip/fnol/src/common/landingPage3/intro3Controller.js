﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('Intro3Ctrl',
    function (
        $scope,
        $state,
        $rootScope,
        miAppProperties,
        ENV,
        cfpLoadingBar,
        miComponentRoute,
        miLocale,
        miStageFactory,
        $timeout) {

        $rootScope.infoheader = true;

        $scope.tempstage = ['Complete', 'Active', 'Pending', 'Pending', 'Pending', 'Pending', 'Pending'];

        $timeout(function () {
            $rootScope.intrologo = 'Y';
        }, 500);

        $timeout(function () {
            $rootScope.introtext = 'Y';
        }, 700);

        $timeout(function () {
            $rootScope.introbody = 'Y';
        }, 1000);

        $timeout(function () {
            $rootScope.introbutton = 'Y';
        }, 1100);

        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        $scope.$parent.mainclass = "mi-shell__content mobile-content";
        $scope.$parent.spaceclass = "";
        $rootScope.appBodyTheme = "mi-app-body-info";
        miAppProperties.setislandingpage(false);
        $scope.next = function () {
            ga('send', 'event', 'Navigation', 'Button click', 'Lets begin');
            if (miAppProperties.getcontextid()) {
                cfpLoadingBar.start();
                miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                .then(function (updatestageresponse) {
                    if (updatestageresponse.route) {
                        $rootScope.infoheader = true;
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                    }
                    else {
                        miAppProperties.setflagStage(true);
                        miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                       .then(function (nextstageresponse) {
                           $rootScope.infoheader = true;
                           cfpLoadingBar.complete();
                           if (nextstageresponse.route) {
                               $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                           }
                       });
                    }
                });
            }
            else {
                cfpLoadingBar.start();
                miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                          .then(function (nextstageresponse) {
                              $rootScope.infoheader = true;
                              if (nextstageresponse.route) {
                                  $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                              }
                          });
            }
        }
    });
}(angular));