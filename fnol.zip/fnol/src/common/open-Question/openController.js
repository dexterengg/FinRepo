﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('OpenQuestionCtrl',
    function (
        $scope,
        $state,
        $sce,
        miAppProperties,
        cfpLoadingBar,
        ENV,
        miComponentRoute,
        miQues,
        miValidation,
        miUiStagesProgressbar,
        miAppFactory,
        miStageFactory,
        miLocale,
        $interval) {

        //$scope.Back_Btn_Class = "clickable_Back_Btn";       
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        $scope.value = "";
        var currentQuestion = miAppProperties.getCurrentQuestion();
        $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();
         $scope.isEditable = function () {
            var edit = currentQuestion.editable;
            if (edit)
                return false;
            else
                return true;
        }
        if (currentQuestion.answerList[0].answerDisplayText != null) {
            $scope.value = currentQuestion.answerList[0].answerDisplayText;
        }
        $scope.getHtml = function (html) {
            return $sce.trustAsHtml(html);
        };
       //validate open text field on onblur/next button click
        $scope.validateOpenText = function ()
        {
            var cntrl = angular.element('#uamopenquestion');
            var uam = miValidation.validate($scope.value);
            if (uam == "Valid") {
                cntrl.text("");
                cntrl.removeClass('mi-uam-block--alert');
            }
            else {
                cntrl.text(uam);
                cntrl.addClass('mi-uam-block--alert');
                cfpLoadingBar.complete();
                return false;
            };
        }

        $scope.next = function () {
            cfpLoadingBar.start();

            //set isVersionMismatch to false so that version mismatch message will not show on next question
            miAppProperties.setVersionMismatchStatus(false);
            if ($scope.validateOpenText() === false){ return false; }
            var answerText;
            if ($scope.value) {
                answerText = $scope.value.trim();
            }
            else {
                answerText = "";
            }
            
            ga('send', 'event', 'Answer', 'Open question', answerText);

            //Calling function to insert question details
            miAppProperties.insertQuestionDetails(currentQuestion.qustnnreQustnId, answerText);
            
            //Calling function to check whether we user has given same answer or not
            var isStatusChanged = miAppProperties.IsStageStatusChanged(currentQuestion, answerText);

            //Update the answer in question dto
            currentQuestion.answerList[0].answerDisplayText = answerText;

            //If status changed then we need to first update the stage with state "REOPEN"
            //Otherwise continue with existing call
            if (isStatusChanged) {
                miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_REOPEN)
                    .then(function (updatestageresponse) {
                        if (updatestageresponse.route) {
                            cfpLoadingBar.complete();
                            $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                        }
                        else {
                            miAppProperties.setStageStatus(ENV.CLAIMSTATUS_REOPEN);
                            $scope.getRoute();
                        }
                    })
            }
            else {
                $scope.getRoute();
            }
        }   //End of next function

        $scope.getRoute = function () {
            miAppFactory.getRoute()
            .then(function (routeresponse) {
                if (routeresponse.route) {
                    if ($state.current.name === miComponentRoute.getComponentroute(routeresponse.route)) {
                        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

                        //Code to check whether version mismatch is true or not
                        //It is the scenario if the script type is first question and user has changed questionnaire from WCAdmin
                        //In this case question will show with error message
                        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();

                        cfpLoadingBar.complete();
                        //$scope.Back_Btn_Class = "clickable_Back_Btn";
                        $scope.samepagecss = "page-inner-slideOutUp";
                        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
                        var intervalCanceller = $interval(function () {
                            $scope.samepagecss = "";
                            currentQuestion = miAppProperties.getCurrentQuestion();
                            $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
                            $scope.value = "";
                            if (currentQuestion.answerList[0].answerDisplayText != null) {
                                $scope.value = currentQuestion.answerList[0].answerDisplayText;
                            }
                            $interval.cancel(intervalCanceller);
                        }, 1000);
                    }
                    else {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(routeresponse.route));
                    }
                }
            });
        }

        $scope.back = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Back');
            cfpLoadingBar.start();

            //set isVersionMismatch to false so that version mismatch message will not show on next question
            miAppProperties.setVersionMismatchStatus(false);

            var cntrl = angular.element('#uamopenquestion');
            cntrl.text("");
            cntrl.removeClass('mi-uam-block--alert');
            miAppFactory.getPreviousRoute(currentQuestion.qustnnreQustnId)
            .then(function (routeresponse) {
                if (routeresponse.route) {
                    if ($state.current.name === miComponentRoute.getComponentroute(routeresponse.route)) {
                        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

                        //Code to check whether version mismatch is true or not
                        //It is the scenario if the script type is first question and user has changed questionnaire from WCAdmin
                        //In this case question will show with error message
                        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();

                        cfpLoadingBar.complete();
                        $scope.samepagecss = "page-inner-slideOutUp";
                        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
                        var intervalCanceller = $interval(function () {
                            $scope.samepagecss = "";
                            currentQuestion = miAppProperties.getCurrentQuestion();
                            $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
                            $scope.value = "";
                            if (currentQuestion.answerList[0].answerDisplayText != null) {
                                $scope.value = currentQuestion.answerList[0].answerDisplayText;
                            }
                            $interval.cancel(intervalCanceller);
                        }, 1000);
                    }
                    else {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(routeresponse.route));
                    }
                }
                else {
                    cfpLoadingBar.complete();
                    $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
                }
            });

        }
    });
}(angular));
