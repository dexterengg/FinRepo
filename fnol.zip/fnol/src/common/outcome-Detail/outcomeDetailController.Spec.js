﻿describe('MFNOL AngularJS Controller (Outcome Details Controller)', function () {
    var $httpBackend, $scope;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: "",
        stageType: "Questionnaire",
        stageDesc: "fake-stageDesc",
        pageName: "fake-pageName",
        UserIdentificationdata: [],
        totalNumOfStages: 6,
        stageUiOrder: 2,
        statuscode: "statuscode",
        stageName: "IDENTIFICATION",
        questionnaireID: 123,
        sessionID: "sessionID",
        islandingpage: true,
        systemDocId: 123,
        contextid: 125,
        coStageId: 256,
        getStageOrder: 5,
       outcomeDetails: { "fnolOutComesList": [{ "indicator": null, "score": 0.0, "userMessage": "This is generic message.", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "", "displayOutcome": null, "userAction": null }, { "indicator": "PASS", "score": 30.0, "userMessage": "Fraud Range Fall in Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "Fraud", "displayOutcome": "Y", "userAction": "Next" }, { "indicator": "PASS", "score": 30.0, "userMessage": "Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005487, "rangeName": "Fraud 3451", "evltnOutcome": "Coverage", "displayOutcome": "N", "userAction": null }, { "indicator": "PASS", "score": 30.0, "userMessage": "Liability of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000008487, "rangeName": "Liability 3451", "evltnOutcome": "Liability", "displayOutcome": "Y", "userAction": "ACCEPT/DECLINE" }] },
        fnolOutComesList: [{ "indicator": null, "score": 0.0, "userMessage": "This is generic message.", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "", "displayOutcome": null, "userAction": null }, { "indicator": "PASS", "score": 30.0, "userMessage": "Fraud Range Fall in Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "Fraud", "displayOutcome": "Y", "userAction": "Next" }, { "indicator": "PASS", "score": 30.0, "userMessage": "Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005487, "rangeName": "Fraud 3451", "evltnOutcome": "Coverage", "displayOutcome": "N", "userAction": null }, { "indicator": "PASS", "score": 30.0, "userMessage": "Liability of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000008487, "rangeName": "Liability 3451", "evltnOutcome": "Liability", "displayOutcome": "Y", "userAction": "ACCEPT/DECLINE" }] 

    };
    // Mocked Service
    angular.module('mock.OutcomeDetailCtrldata', [])
	.factory('miAppProperties', function ($q) {
	    var constant = {};
	    constant.gettheme = function () {
	        return expectedDetail.theme;
	    };
	    constant.getorgcode = function () {
	        return expectedDetail.orgcode;
	    };
	    constant.getanimationclass = function () {
	        return expectedDetail.animationclass;
	    };
	    constant.getlanguage = function () {
	        return expectedDetail.language;
	    };
	    constant.getDocID = function () {
	        return expectedDetail.DocID;
	    };
	    constant.getstageType = function () {
	        return expectedDetail.stageType;
	    };
	    constant.getstageDesc = function () {
	        return expectedDetail.stageDesc;
	    };
	    constant.getpageName = function () {
	        return expectedDetail.pageName;
	    };
	    constant.setisConfirmed = function () {
	        return expectedDetail.isConfirmed;
	    };
	    constant.setDocID = function (DocID) {
	        return expectedDetail.DocID;
	    };
	    constant.getUserIdentificationdata = function () {
	        return expectedDetail.UserIdentificationdata;
	    };
	    constant.gettotalNumOfStages = function () {
	        return expectedDetail.totalNumOfStages;
	    };
	    constant.getstageUiOrder = function () {
	        return expectedDetail.stageUiOrder;
	    };
	    constant.getCurrentQuestion = function () {
	        return expectedDetail.currentQuestion;
	    };
	    constant.setstatuscode = function (statuscode) {
	        expectedDetail.statuscode = statuscode;
	    };
	    constant.getstatuscode = function () {
	        return expectedDetail.statuscode;
	    };
	    constant.getstageName = function () {
	        return expectedDetail.stageName;
	    };
	    constant.insertUserIdentificationdata = function (Id, Question, Answer) {
	        var QuesAnsDetail = { "Id": Id, "Question": Question, "Answer": Answer };
	        expectedDetail.UserIdentificationdata.push(QuesAnsDetail);
	    };
	    constant.getUserIdentificationdata = function () {
	        return expectedDetail.UserIdentificationdata;
	    };
	    constant.ClearUserIdentificationdata = function () {
	        expectedDetail.UserIdentificationdata.length = 0;
	    };
	    constant.getquestionnaireID = function () {
	        return expectedDetail.questionnaireID;
	    };
	    constant.setSessionID = function (sessionID) {
	        expectedDetail.sessionID = sessionID;
	    };
	    constant.getSessionID = function () {
	        return expectedDetail.sessionID;
	    };
	    constant.setislandingpage = function (islandingpage) {
	        expectedDetail.islandingpage = islandingpage;
	    };
	    constant.getislandingpage = function () {
	        return expectedDetail.islandingpage;
	    };
	    constant.getsystemDocId = function () {
	        return expectedDetail.systemDocId;
	    };
	    constant.getOutcomeDetail = function () {
	        return expectedDetail.outcomeDetails;
	    };
	    constant.evltnConfigId = [];
	    constant.setConfigIdlist = function (evltnConfigId) {
	        this.evltnConfigId.push(evltnConfigId);
	    };
	    constant.getConfigIdlist = function () {
	        return this.evltnConfigId;
	    };

	    constant.getcontextid = function () {
	        return expectedDetail.contextid;
	    };
	    constant.getcoStageId = function () {
	        return expectedDetail.coStageId;
	    };
	    constant.getStageOrder = function () {
	        return expectedDetail.getStageOrder;
	    };
	    constant.getDisplayOutCome = function () {
	        return expectedDetail.fnolOutComesList;
	    };
	    constant.setDisplayOutCome = function (fnolOutComesList) {
	        expectedDetail.fnolOutComesList = fnolOutComesList;
	    };
	    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
	    constant.fetch = function () {
	        var mockUser = "M2";
	        return $q.when(mockUser);
	    };
	    // other stubbed methods
	    return constant;
	})

    .factory('miUiStagesProgressbar', function ($q) {
        var constant = {};
        constant.changeUiStage = function (noOfUiStages, currentUiStage) {
            return;
        };
        return constant;
    })

    describe('OutcomeDetailController_Test_for_currenttheme', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.environment'));
        beforeEach(module('mi.mfnol.web'));
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.OutcomeDetailCtrldata'));
        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_, _miUiStagesProgressbar_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('OutcomeDetailCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_,
                miUiStagesProgressbar: _miUiStagesProgressbar_
            });
        }));
        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('Open Question Controll  ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });
        it('ensure animation class is page-main', function () {
            expect(scope.pageClass).toBe(expectedDetail.animationclass);
        });

        it('ensure final outcome list which has count list equals to count of display Y outcome or null and outcome name', function () {
            expect(scope.outcomeDetails.fnolOutComesList.length).toBe(4);
        });

        it('ensure final outcome list which has null as outcome name ', function () {
             expect(scope.outcomeDetails.fnolOutComesList[0].evltnOutcome).toBe("");
        });

        it('ensure final outcome list which has display Y ', function () {
            for (var iIndex = 1; iIndex < scope.outcomeDetails.fnolOutComesList.length; iIndex++)
            {
                scope.outcomeDetails.fnolOutComesList[iIndex].displayOutcome = scope.outcomeDetails.fnolOutComesList[iIndex].displayOutcome
            }
            expect(scope.outcomeDetails.fnolOutComesList[iIndex-1].displayOutcome).toBe("Y");
        });
        it('ensure subHeading should be blank', function () {
            expect(scope.subHeading).toBe("");
        });
        it('ensure answer Text contains usermessage at index 0', function () {
            expect(scope.answerText).toBe("This is generic message.");
        });
        it('ensure isNextShow is Next', function () {
            expect(scope.isNextShow).toBe(true);
        });
        it('ensure outcome name is Fraud', function () {
            expect(scope.outcomeDetails.fnolOutComesList[1].evltnOutcome).toBe("Fraud");
        });
        it('ensure answer Text is Fraud Range Fall in Range of 0 to 40', function () {
            expect(scope.outcomeDetails.fnolOutComesList[1].userMessage).toBe("Fraud Range Fall in Range of 0 to 40");
        });
        it('ensure isNextShow is Next', function () {
            expect(scope.outcomeDetails.fnolOutComesList[1].userAction).toBe("Next");
        });
       
    });
    describe('Outcome Details Controller for Next with more than 1 outcomes ', function () {
        var miStageFactory, scope, ctrl;
        beforeEach(module('mi.mfnol.environment'));
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.OutcomeDetailCtrldata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miStageFactory = $injector.get('miStageFactory');
                miAppProperties = $injector.get('miAppProperties');
                spyOn($state, 'go');
            });
        });
        it('ensure isNextShow has a boolean value false at index of 0 of outcomedetails ', function () {
            expectedDetail.fnolOutComesList[0].userAction = "ACCEPT/DECLINE";
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            expect($scope.isNextShow).toBe(false);
        });
        it('ensure isNextShow has a boolean value true at index of 0 of outcomedetails ', function () {
            expectedDetail.fnolOutComesList[0].userAction = "Next";
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            expect($scope.isNextShow).toBe(true);
        });
    });

    describe('Outcome Details Controller for Next with more than 1 outcomes ', function () {
        var miStageFactory, scope, ctrl;
        beforeEach(module('mi.mfnol.environment'));
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.OutcomeDetailCtrldata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miStageFactory = $injector.get('miStageFactory');
                miAppProperties = $injector.get('miAppProperties');
                miQuestionaireFactory = $injector.get('miQuestionaireFactory');
                spyOn($state, 'go');
            });
        });


        it('ensure outcome name is Coverage', function () {
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            $scope.next();
            $scope.next();
            expect($scope.subHeading).toBe("Coverage");
        });
        it('ensure outcome name is Fraud', function () {
            expectedDetail.fnolOutComesList[1].userAction = "ACCEPT/DECLINE";
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            $scope.next();
            expect($scope.subHeading).toBe("Fraud");
        });
        it('ensure miQuestionaireFactory.postOutcome service called when updataAndNextStage function called', function () {
            expectedDetail.fnolOutComesList = [{ "indicator": null, "score": 0.0, "userMessage": "This is generic message.", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "", "displayOutcome": null, "userAction": null, "evltnOutcomeCategory": "Liability" }];
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            spyOn(miQuestionaireFactory, 'postOutcome').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.next();
            expect(miQuestionaireFactory.postOutcome).toHaveBeenCalled();
        });
        it('ensure miStageFactory.updateStage service called with error when UpdateAndGetNextStage function called', function () {
            expectedDetail.fnolOutComesList = [{ "indicator": null, "score": 0.0, "userMessage": "This is generic message.", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "", "displayOutcome": null, "userAction": null, "evltnOutcomeCategory": "Liability" }];
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            spyOn(miQuestionaireFactory, 'postOutcome').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "400" });
            });
            $scope.next();
            expect(miQuestionaireFactory.postOutcome).toHaveBeenCalled();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
        });
        it('ensure miStageFactory.getNextStage service called with error when UpdateAndGetNextStage function called', function () {
            expectedDetail.fnolOutComesList = [{ "indicator": null, "score": 0.0, "userMessage": "This is generic message.", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "", "displayOutcome": null, "userAction": null, "evltnOutcomeCategory": "Liability" }];
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            spyOn(miQuestionaireFactory, 'postOutcome').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "400" });
            });
            $scope.next();
            expect(miQuestionaireFactory.postOutcome).toHaveBeenCalled();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        });
        it('ensure miStageFactory.getNextStage service called with success when UpdateAndGetNextStage function called', function () {
            expectedDetail.fnolOutComesList = [{ "indicator": null, "score": 0.0, "userMessage": "This is generic message.", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "", "displayOutcome": null, "userAction": null, "evltnOutcomeCategory": "Liability" }];
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            spyOn(miQuestionaireFactory, 'postOutcome').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            $scope.next();
            expect(miQuestionaireFactory.postOutcome).toHaveBeenCalled();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        });
        it('ensure miStageFactory.updateStage service called with error when no outcome category', function () {
            expectedDetail.fnolOutComesList = [{ "indicator": null, "score": 0.0, "userMessage": "This is generic message.", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "", "displayOutcome": null, "userAction": null }];
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "400" });
            });
            $scope.next();
            expect(miStageFactory.updateStage).toHaveBeenCalled();
            
        });
    });

    describe('Outcome Details Controller for Back', function () {
        var miStageFactory, changeUiStage;
        beforeEach(module('mi.mfnol.environment'));
        beforeEach(module('mi.mfnol.web'));
        beforeEach(module('mock.OutcomeDetailCtrldata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miStageFactory = $injector.get('miStageFactory');
                miAppProperties = $injector.get('miAppProperties');
                spyOn($state, 'go');
            });
        });

        it('ensure back button css should be clickable', inject(function () {
            expectedDetail.fnolOutComesList = [{ "indicator": null, "score": 0.0, "userMessage": "This is generic message.", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "", "displayOutcome": null, "userAction": null }, { "indicator": "PASS", "score": 30.0, "userMessage": "Fraud Range Fall in Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "Fraud", "displayOutcome": "Y", "userAction": "Next" }, { "indicator": "PASS", "score": 30.0, "userMessage": "Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005487, "rangeName": "Fraud 3451", "evltnOutcome": "Coverage", "displayOutcome": "N", "userAction": null }, { "indicator": "PASS", "score": 30.0, "userMessage": "Liability of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000008487, "rangeName": "Liability 3451", "evltnOutcome": "Liability", "displayOutcome": "Y", "userAction": "ACCEPT/DECLINE" }]
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            $scope.index = 3;
            $scope.back();
            expect($scope.Back_Btn_Class).toBe("clickable_Back_Btn");
        }));
        it('ensure isNextShow should have boolean value false on click of back', inject(function () {
            expectedDetail.fnolOutComesList = [{ "indicator": null, "score": 0.0, "userMessage": "This is generic message.", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "", "displayOutcome": null, "userAction": null }, { "indicator": "PASS", "score": 30.0, "userMessage": "Fraud Range Fall in Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "Fraud", "displayOutcome": "Y", "userAction": "Next" }, { "indicator": "PASS", "score": 30.0, "userMessage": "Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005487, "rangeName": "Fraud 3451", "evltnOutcome": "Coverage", "displayOutcome": "N", "userAction": "ACCEPT/DECLINE" }, { "indicator": "PASS", "score": 30.0, "userMessage": "Liability of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000008487, "rangeName": "Liability 3451", "evltnOutcome": "Liability", "displayOutcome": "Y", "userAction": "ACCEPT/DECLINE" }]
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            $scope.index = 3;
            $scope.back();
            expect($scope.isNextShow).toBe(false);
        }));
        it('ensure isNextShow should have boolean value true on click of back', inject(function () {
            expectedDetail.fnolOutComesList = [{ "indicator": null, "score": 0.0, "userMessage": "This is generic message.", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "", "displayOutcome": null, "userAction": null }, { "indicator": "PASS", "score": 30.0, "userMessage": "Fraud Range Fall in Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "Fraud", "displayOutcome": "Y", "userAction": "Next" }, { "indicator": "PASS", "score": 30.0, "userMessage": "Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005487, "rangeName": "Fraud 3451", "evltnOutcome": "Coverage", "displayOutcome": "N", "userAction": "Next" }, { "indicator": "PASS", "score": 30.0, "userMessage": "Liability of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000008487, "rangeName": "Liability 3451", "evltnOutcome": "Liability", "displayOutcome": "Y", "userAction": "ACCEPT/DECLINE" }]
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            $scope.index = 3;
            $scope.back();
            expect($scope.isNextShow).toBe(true);
        }));
        it('ensure back button css should be nonclickable', inject(function () {
            expectedDetail.fnolOutComesList = [{ "indicator": null, "score": 0.0, "userMessage": "This is generic message.", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "", "displayOutcome": null, "userAction": null }, { "indicator": "PASS", "score": 30.0, "userMessage": "Fraud Range Fall in Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "Fraud", "displayOutcome": "Y", "userAction": "Next" }, { "indicator": "PASS", "score": 30.0, "userMessage": "Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005487, "rangeName": "Fraud 3451", "evltnOutcome": "Coverage", "displayOutcome": "N", "userAction": "Next" }, { "indicator": "PASS", "score": 30.0, "userMessage": "Liability of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000008487, "rangeName": "Liability 3451", "evltnOutcome": "Liability", "displayOutcome": "Y", "userAction": "ACCEPT/DECLINE" }]
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            $scope.index = 1;
            $scope.back();
            expect($scope.Back_Btn_Class).toBe("nonclickable_Back_Btn");
        }));
        it('ensure back button css should be nonclickable when click on back button ', inject(function () {
            expectedDetail.fnolOutComesList = [{ "indicator": null, "score": 0.0, "userMessage": "This is generic message.", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "", "displayOutcome": null, "userAction": null }, { "indicator": "PASS", "score": 30.0, "userMessage": "Fraud Range Fall in Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005486, "rangeName": "Fraud 1", "evltnOutcome": "Fraud", "displayOutcome": "Y", "userAction": "Next" }, { "indicator": "PASS", "score": 30.0, "userMessage": "Range of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000005487, "rangeName": "Fraud 3451", "evltnOutcome": "Coverage", "displayOutcome": "N", "userAction": "Next" }, { "indicator": "PASS", "score": 30.0, "userMessage": "Liability of 0 to 40", "scoreType": "POINTS", "evltnConfigId": 100000008487, "rangeName": "Liability 3451", "evltnOutcome": "Liability", "displayOutcome": "Y", "userAction": "ACCEPT/DECLINE" }]
            miAppProperties.setDisplayOutCome(expectedDetail.fnolOutComesList);
            $controller('OutcomeDetailCtrl', { $scope: $scope, $state: $state });
            $scope.index =0;
            $scope.back();
            expect($scope.Back_Btn_Class).toBe("nonclickable_Back_Btn");
        }));
    });
});