﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('OutcomeDetailCtrl',
    function (
        $scope,
        $state,
        miAppProperties,
        ENV,
        miUiStagesProgressbar,
        miStageFactory,
        miLocale,
        cfpLoadingBar,
        miComponentRoute,
        miQuestionaireFactory) {
        $scope.Back_Btn_Class = "nonclickable_Back_Btn";
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        $scope.index = 0;
       
        $scope.outcomeDetails = miAppProperties.getOutcomeDetail();

        $scope.outcomeDetails.fnolOutComesList = miAppProperties.getDisplayOutCome();
       
        $scope.subHeading = miAppProperties.getDisplayOutCome()[$scope.index].evltnOutcome;
        $scope.answerText = miAppProperties.getDisplayOutCome()[$scope.index].userMessage;


        //$scope.outcomeTitle = $scope.answer[$scope.index].rangeName == ENV.UNKNOWN ? "" : $scope.answer[$scope.index].rangeName;
        if (miAppProperties.getDisplayOutCome()[$scope.index].userAction) {
            var sUserAction = miAppProperties.getDisplayOutCome()[$scope.index].userAction.toString().toUpperCase();
            if ((sUserAction === "ACCEPT/DECLINE") 
                || (sUserAction === "ACCEPT")
                || (sUserAction === "DECLINE"))
                $scope.isNextShow = false;
            else
                $scope.isNextShow = true;
        }
        else
            $scope.isNextShow = true;

        if (miAppProperties.getDisplayOutCome()[$scope.index].evltnConfigId)//if ($scope.answer[$scope.index].evltnConfigId)
            miAppProperties.setConfigIdlist(miAppProperties.getDisplayOutCome()[$scope.index].evltnConfigId);
        $scope.next = function (userAction) {
            ga('send', 'event', 'Navigation', 'Button click', 'Next');
            $scope.outcomeDetails.fnolOutComesList[$scope.index].userAction = userAction;
            $scope.index++;
            if ($scope.index < miAppProperties.getDisplayOutCome().length) {
                $scope.subHeading = miAppProperties.getDisplayOutCome()[$scope.index].evltnOutcome;
                $scope.answerText = miAppProperties.getDisplayOutCome()[$scope.index].userMessage;
                $scope.Back_Btn_Class = "clickable_Back_Btn";
                //$scope.outcomeTitle = $scope.answer[$scope.index].rangeName == ENV.UNKNOWN ? "" : $scope.answer[$scope.index].rangeName;
                if (miAppProperties.getDisplayOutCome()[$scope.index].userAction) {
                    var sUserAction = miAppProperties.getDisplayOutCome()[$scope.index].userAction.toString().toUpperCase();
                    if ((sUserAction === "ACCEPT/DECLINE")
                        || (sUserAction === "ACCEPT")
                        || (sUserAction === "DECLINE"))
                        $scope.isNextShow = false;
                    else
                        $scope.isNextShow = true;
                }
                else
                    $scope.isNextShow = true;
                if (miAppProperties.getDisplayOutCome()[$scope.index].evltnConfigId)
                    miAppProperties.setConfigIdlist(miAppProperties.getDisplayOutCome()[$scope.index].evltnConfigId);
            }
            else {
                upadateAndNextStage();
            }
        }

        $scope.back = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Back');
            $scope.index--;
            if ($scope.index >= 0) {
                $scope.subHeading = miAppProperties.getDisplayOutCome()[$scope.index].evltnOutcome;
                $scope.answerText = miAppProperties.getDisplayOutCome()[$scope.index].userMessage;
                $scope.Back_Btn_Class = "clickable_Back_Btn";
                //$scope.outcomeTitle = $scope.answer[$scope.index].rangeName == ENV.UNKNOWN ? "" : $scope.answer[$scope.index].rangeName;

                if (miAppProperties.getDisplayOutCome()[$scope.index].userAction) {
                    var sUserAction=miAppProperties.getDisplayOutCome()[$scope.index].userAction.toString().toUpperCase();
                    if ((sUserAction === "ACCEPT/DECLINE")
                        || (sUserAction === "ACCEPT")
                        || (sUserAction === "DECLINE"))
                        $scope.isNextShow = false;
                    else
                        $scope.isNextShow = true;
                }
                else
                    $scope.isNextShow = true;
                if (miAppProperties.getDisplayOutCome()[$scope.index].evltnConfigId)
                    miAppProperties.setConfigIdlist(miAppProperties.getDisplayOutCome()[$scope.index].evltnConfigId);

                if ($scope.index == 0) {
                    $scope.Back_Btn_Class = "nonclickable_Back_Btn";
                }
            }
            else {
                //upadateAndNextStage();
                $scope.Back_Btn_Class = "nonclickable_Back_Btn";
            }
        }
        function upadateAndNextStage() {
            cfpLoadingBar.start();
            $scope.outcomeDetails.fnolOutComesList = $scope.outcomeDetails.fnolOutComesList.filter(function (item) { return item.evltnOutcomeCategory != null });
            if ($scope.outcomeDetails.fnolOutComesList.length) {//condition to check when only generic messages come and no outcomes then acknowledgement service should not be call
             miQuestionaireFactory.postOutcome(miAppProperties.getorgcode(), miAppProperties.getcontextid(), $scope.outcomeDetails)
            .then(function (postOutcomeResponse) {
                if (postOutcomeResponse.route) {
                    cfpLoadingBar.complete();
                    $state.go(miComponentRoute.getComponentroute(postOutcomeResponse.route));
                }
                else {
                    $scope.UpdateAndGetNextStage();
                }

            });
            }
            else {
                $scope.UpdateAndGetNextStage();
            }

            
        }

        $scope.UpdateAndGetNextStage = function () {
              miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                    .then(function (updatestageresponse) {
                        if (updatestageresponse.route) {
                            cfpLoadingBar.complete();
                            $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                        }
                        else {
                            miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                 .then(function (nextstageresponse) {
                                     if (nextstageresponse.route) {
                                         cfpLoadingBar.complete();
                                         $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                     }
                                     else {
                                         //condition to check when Assignment decision has no route and display claim summary page.
                                         miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                                          .then(function (updatestageresponse) {
                                              if (updatestageresponse.route) {
                                                  cfpLoadingBar.complete();
                                                  $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                                              }
                                              else {
                                                  miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                       .then(function (nextstageresponse) {
                                                           if (nextstageresponse.route) {
                                                               cfpLoadingBar.complete();
                                                               $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                           }
                                                       })
                                              }
                                          })
                                     }

                                 })
                        }
                    })
       
        }

    });
}(angular));