﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('ExistingClaimPageCtrl',
    function (
        $rootScope,
        $scope,
        $state,
        miAppProperties,
        ENV,
        cfpLoadingBar,
        miComponentRoute,
        miLocale,
        miStageFactory,
        miCMSFactory) {

        $scope.pageClass = 'page-main';
        $scope.$parent.mainclass = "mi-shell__content mobile-content";
        $scope.$parent.spaceclass = "";
        $rootScope.appBodyTheme = "mi-app-body";
        miAppProperties.setanimationclass('page-main');
        $scope.currtheme = miAppProperties.gettheme();
        miAppProperties.setislandingpage(false);
        miAppProperties.ClearUserIdentificationdata();
        $scope.Continue = function () {
            ga('send', 'event', 'Decision', 'Button click', 'Continue with old claim');
            cfpLoadingBar.start();
            miAppProperties.setpartialStage(true);
            miAppProperties.setIsAnswering(true);
            miStageFactory.getNextPartialStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getcontextid(), miLocale.getLocaleCode())
            .then(function (partialstageresponse) {

                miCMSFactory.getVehicalDetails(miAppProperties.getcontextid(), miLocale.getLocaleCode())
                   .then(function (vehicaldetails) {
                       cfpLoadingBar.complete();
                       if (vehicaldetails.route) {
                           $state.go(miComponentRoute.getComponentroute(vehicaldetails.route));
                       }
                       else {
                           miAppProperties.setVehicalDetails(vehicaldetails.data);
                           miAppProperties.setvehicalDetailsStatus(99);
                           if (partialstageresponse.route) {
                               $state.go(miComponentRoute.getComponentroute(partialstageresponse.route));
                           }
                           // code to handle scenario of assignment update from workcenter
                           else if (partialstageresponse.data.pageName === ENV.MOI_PAGE_CONSTANT) {
                               miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                                        .then(function (updatestageresponse) {
                                            if (updatestageresponse.route) {
                                                cfpLoadingBar.complete();
                                                $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                                            }
                                            else {
                                                miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                     .then(function (nextstageresponse) {
                                                         if (nextstageresponse.route) {
                                                             cfpLoadingBar.complete();
                                                             $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                         }
                                                     })
                                            }
                                        })
                           }

                       }
                   });
            });
        }
        $scope.Discard = function () {
            ga('send', 'event', 'Decision', 'Button click', 'Discard and start new claim');
            cfpLoadingBar.start();
            
            miCMSFactory.deletePolicy(miAppProperties.getcontextid(),ENV.DISCARDCLAIM_STATUS, miLocale.getLocaleCode())
            .then(function (deletepolicyresponse) {
                if (deletepolicyresponse.route) {
                    cfpLoadingBar.complete();
                    $state.go(miComponentRoute.getComponentroute(deletepolicyresponse.route));
                }
                else {
                    cfpLoadingBar.complete();
                    miAppProperties.setcontextid(false);
                    miAppProperties.setpartialStage(false);
                    miAppProperties.setIsAnswering(false);
                    miAppProperties.setStageOrder(1);
                    miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                       .then(function (nextstageresponse) {
                                                           cfpLoadingBar.complete();
                                                           if (nextstageresponse.route) {
                                                               $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                           }
                                                       });
                }
            });
        }

    });
}(angular));