﻿describe('MFNOL AngularJS Controller (ExistingClaimPage Controller)', function () {

    var $httpBackend, $scope, $controller;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: "",
        stageType: "fake-Stage",
        stageDesc: "fake-stageDesc",
        pageName: "fake-pageName",
        islandingpage: false,
        UserIdentificationdata: [],
        PartialStage: true,
        IsAnswering:true
    };
    // Mocked Service
    angular.module('mock.existingClaimData', [])
	.factory('miAppProperties', function ($q) {
	    var constant = {};
	    constant.gettheme = function () {
	        return expectedDetail.theme;
	    };
	    constant.setanimationclass = function (animationclass) {
	        expectedDetail.animationclass = animationclass;
	    };
	    constant.setislandingpage = function (islandingpage) {
	        expectedDetail.islandingpage = islandingpage;
	    };
	    constant.ClearUserIdentificationdata = function () {
	        expectedDetail.UserIdentificationdata.length = 0;
	    };
	    constant.setpartialStage = function (partialStage) {
	        expectedDetail.PartialStage = partialStage;
	    };
	    constant.setIsAnswering = function (isAnswering) {
	        expectedDetail.IsAnswering = isAnswering;
	    }
	    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
	    constant.fetch = function () {
	        var mockUser = "M2";
	        return $q.when(mockUser);
	    };

	    // other stubbed methods
	    return constant;
	})

    describe('ExistingClaimPage_Controller_Test_for_currentTheme', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.existingClaimData'));

        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('ExistingClaimPageCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));
        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });

        it('ensure default page class name', function () {
            expect(scope.pageClass).toBe('page-main');
        })
    });

    describe('ConfirmationQuestionController_Continue()_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        var miCMSFactory, miStageFactory
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                miCMSFactory = $injector.get('miCMSFactory');
                miStageFactory = $injector.get('miStageFactory');
                spyOn($state, 'go');
            });
        });
        it('should call getNextPartialStage and getVehicalDetails with error on Continue click', function () {
            $controller('ExistingClaimPageCtrl', { $scope: $scope, $state: $state, miCMSFactory: miCMSFactory, miStageFactory: miStageFactory });

            spyOn(miStageFactory, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn(miCMSFactory, 'getVehicalDetails').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });

            $scope.Continue();
            expect(miStageFactory.getNextPartialStage).toHaveBeenCalled();
            expect(miCMSFactory.getVehicalDetails).toHaveBeenCalled();
        });

        it('should call getNextPartialStage and getVehicalDetails with success on Continue click', function () {
            $controller('ExistingClaimPageCtrl', { $scope: $scope, $state: $state, miCMSFactory: miCMSFactory, miStageFactory: miStageFactory });

            spyOn(miStageFactory, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "", data: "" });
            });
            spyOn(miCMSFactory, 'getVehicalDetails').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });

            $scope.Continue();
            expect(miStageFactory.getNextPartialStage).toHaveBeenCalled();
            expect(miCMSFactory.getVehicalDetails).toHaveBeenCalled();
        });

       it('should call getNextPartialStage', function () {
            $controller('ExistingClaimPageCtrl', { $scope: $scope, $state: $state, miCMSFactory: miCMSFactory, miStageFactory: miStageFactory });

            spyOn(miStageFactory, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            spyOn(miCMSFactory, 'getVehicalDetails').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });

            $scope.Continue();
            expect(miStageFactory.getNextPartialStage).toHaveBeenCalled();
            expect(miCMSFactory.getVehicalDetails).toHaveBeenCalled();
        });


        it('should call updateStage with error landing page', function () {
            $controller('ExistingClaimPageCtrl', { $scope: $scope, $state: $state, miCMSFactory: miCMSFactory, miStageFactory: miStageFactory });

            spyOn(miStageFactory, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "", data: {"pageName":"Post FNOL"} });
            });
            spyOn(miCMSFactory, 'getVehicalDetails').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.Continue();
            expect(miStageFactory.getNextPartialStage).toHaveBeenCalled();
            expect(miCMSFactory.getVehicalDetails).toHaveBeenCalled();
            expect($state.go).toHaveBeenCalledWith('shell.Error');
        });

        it('should call getNextStage with error landing page', function () {
            $controller('ExistingClaimPageCtrl', { $scope: $scope, $state: $state, miCMSFactory: miCMSFactory, miStageFactory: miStageFactory });

            spyOn(miStageFactory, 'getNextPartialStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "", data: { "pageName": "Post FNOL" } });
            });
            spyOn(miCMSFactory, 'getVehicalDetails').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'updateStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.Continue();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
           expect($state.go).toHaveBeenCalledWith('shell.Error');
        });
    });


    describe('ConfirmationQuestionController_Discard()_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        var miCMSFactory, miStageFactory
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                miCMSFactory = $injector.get('miCMSFactory');
                miStageFactory = $injector.get('miStageFactory');
                spyOn($state, 'go');
            });
        });
        it('should call deletePolicy with error on Discard click', function () {
            $controller('ExistingClaimPageCtrl', { $scope: $scope, $state: $state, miCMSFactory: miCMSFactory, miStageFactory: miStageFactory });

            spyOn(miCMSFactory, 'deletePolicy').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.Discard();
            expect(miCMSFactory.deletePolicy).toHaveBeenCalled();

        });

        it('should call deletePolicy with success on Discard click', function () {
            $controller('ExistingClaimPageCtrl', { $scope: $scope, $state: $state, miCMSFactory: miCMSFactory, miStageFactory: miStageFactory });
            spyOn(miCMSFactory, 'deletePolicy').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            $scope.Discard();
            expect(miCMSFactory.deletePolicy).toHaveBeenCalled();

        });
        it('should call deletePolicy with success on Discard click', function () {
            $controller('ExistingClaimPageCtrl', { $scope: $scope, $state: $state, miCMSFactory: miCMSFactory, miStageFactory: miStageFactory });
            spyOn(miCMSFactory, 'deletePolicy').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            $scope.Discard();
            expect(miCMSFactory.deletePolicy).toHaveBeenCalled();

        });
        it('should call getNextStage and deletePolicy with success on Discard click', function () {
            $controller('ExistingClaimPageCtrl', { $scope: $scope, $state: $state, miCMSFactory: miCMSFactory, miStageFactory: miStageFactory });
            spyOn(miCMSFactory, 'deletePolicy').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({ route: "CHOICE_SELECTION" });
            });
            $scope.Discard();
            expect(miCMSFactory.deletePolicy).toHaveBeenCalled();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
            expect($state.go).toHaveBeenCalledWith('shell.landing-Question.choiceselection-Question');

        });

       
       
    });
});