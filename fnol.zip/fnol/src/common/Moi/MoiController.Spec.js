﻿describe('MFNOL AngularJS Controller (Moi Controller)', function () {
    var $httpBackend, $scope;
    var $controller, $q, $state, $filter, miUiStagesProgressbar, miMoiProperties;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: "",
        totalNumOfStages: "5",
        stageUiOrder: "2"
    };
    // Mocked Service
    angular.module('mock.moidata', [])
    .factory('miAppProperties', function ($q) {
        var constant = {};
        constant.gettheme = function () {
            return expectedDetail.theme;// "M2";
        };
        constant.getorgcode = function () {
            return expectedDetail.orgcode;
        };
        constant.getanimationclass = function () {
            return expectedDetail.animationclass;
        };
        constant.getlanguage = function () {
            return expectedDetail.language;
        };
        constant.getDocID = function () {
            return expectedDetail.DocID;
        };
        constant.gettotalNumOfStages = function () {
            return expectedDetail.totalNumOfStages;
        };
        constant.getstageUiOrder = function () {
            return expectedDetail.stageUiOrder;
        };
        constant.setstatuscode = function (statuscode) {
        };
        constant.setResourceData = function (statuscode) {
        };
        constant.getstatuscode = function () {
            return "fake-StatusCode";
        };
        constant.setResourceDataList = function (resourceList) { };
        constant.getResourceDataList = function () {
            return "fake-resourcedatalist";
        };

        // example stub method that returns a promise, e.g. if original method returned $http.get(...)
        constant.fetch = function () {
            var mockUser = "M2";
            return $q.when(mockUser);
        };
        // other stubbed methods
        return constant;
    });
    //.factory('miResourceProperties', function ($q) {
    // var resourceSearchCriteria = {};
    // resourceSearchCriteria.getResourceSearchCriteria = function () {
    // return {
    // CoCode: "fake-CoCode",
    // ResourceType: "fake-resourceType",
    // ResourceSubType: "fake-subType",
    // GroupType: "fake-groupType",
    // ClaimID: "facke-claimId",
    // ApplCode: "fake-appleCode",
    // Name: "fake-Name"
    // }
    // }
    // // example stub method that returns a promise, e.g. if original method returned $http.get(...)
    // resourceSearchCriteria.fetch = function () {
    // var mockUser = "M2";
    // return $q.when(mockUser);
    // };
    // // other stubbed methods
    // return resourceSearchCriteria;
    //});
    beforeEach(module('mi.mfnol.web'));
    describe('moiControllerTestforcurrenttheme', function () {
        // beforeEach(module('mi.mfnol.web'));
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.moidata'));
        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            $scope = $rootScope.$new();
            $controller = _$controller_;
            $controller = $controller('MoiSelectionCtrl', {
                $scope: $scope,
                miAppProperties: _miAppProperties_
            });
        }));
        it('erensure current theme is not null', function () {
            expect($scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect($scope.currtheme).toBe(expectedDetail.theme);
        });
        it('Open Question Controll ensure animation class is not null', function () {
            expect($scope.pageClass).not.toBe(null);
        });
        it('ensure animation class is page-main', function () {
            expect($scope.pageClass).toBe(expectedDetail.animationclass);
        });
    });
    describe('MoiController_miMoiProperties_getMoiModelArray()_Test', function () {
        var moiselection_mock_data = [
        {
            "MoiID": 1891,
            "MoiType": "SCDI",
            "MoiDisplayText": "",
            "MoiAliasName": "",
            "SearchRadius": 0,
            "PriorityOrder": 1,
            "StateScripting": "No",
            "PreStateScriptingText": "",
            "PostStateScriptingText": "",
            "CarrierEnabled": true,
            "UserEnabled": true,
            "MeetConditions": true,
            "RecommendedMOI": "No",
            "ScriptState": "",
            "DispatchCntrID": "",
            "TerritorySearchFlag": "Y",
            "RadiusSearchFlag": "",
            "SearchType": "",
            "SelfServedEnable": false
        },
        {
            "MoiID": 1895,
            "MoiType": "NSDO",
            "MoiDisplayText": "DRP Body Shop",
            "MoiAliasName": "DRP Body Shop",
            "SearchRadius": 0,
            "PriorityOrder": 2,
            "StateScripting": "No",
            "PreStateScriptingText": "",
            "PostStateScriptingText": "",
            "CarrierEnabled": true,
            "UserEnabled": true,
            "MeetConditions": true,
            "RecommendedMOI": "No",
            "ScriptState": "",
            "DispatchCntrID": "",
            "TerritorySearchFlag": "",
            "RadiusSearchFlag": "",
            "SearchType": "",
            "SelfServedEnable": true
        }];
        beforeEach(module('mock.moidata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                $q = $injector.get('$q');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                miMoiProperties = $injector.get('miMoiProperties');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });
        it('verify the miMoiProperties.getMoiModelArray()', inject(function () {
            miMoiProperties.saveModelsArray(moiselection_mock_data);
            $controller('MoiSelectionCtrl', { $scope: $scope });
            expect($scope.moidetails).toBe(moiselection_mock_data);
        }));
    });
    describe('MoiController_miUiStagesProgressbar_Service_Test', function () {
        beforeEach(module('mock.moidata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });
        //spec to track that spy created on miUiStagesProgressbar.changeUiStage was called
        it('should call miUiStagesProgressbar changeUiStage when called', inject(function () {
            $controller('MoiSelectionCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            expect(miUiStagesProgressbar.changeUiStage).toHaveBeenCalled();
        }));
    });


    describe('MoiController_next()_Test', function () {
        beforeEach(module('mock.moidata'));
        var miResourceProperties, miResourceDataFactory;
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miResourceProperties = $injector.get('miResourceProperties');
                miMoiProperties = $injector.get('miMoiProperties');
                miResourceDataFactory = $injector.get('miResourceDataFactory');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
                spyOn($state, 'go');
            });
        });
        //spec to track that spy created on miUiStagesProgressbar.changeUiStage was called
        it('should call miUiStagesProgressbar changeUiStage when called', inject(function () {
            $controller('MoiSelectionCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            expect(miUiStagesProgressbar.changeUiStage).toHaveBeenCalled();
        }));

        it('verify the user is redirected to error page screen when user get error', inject(function () {
            $controller('MoiSelectionCtrl', { '$scope': $scope, miResourceDataFactory: miResourceDataFactory });
            spyOn(miResourceDataFactory, 'GetResourcesOrGroup').and.callFake(function () {
                return $.Deferred().resolve({ route: 400 });
            });
            $scope.next('NSDO', 'Resource', 'non-staff', 'BS');
            expect($state.go).toHaveBeenCalledWith('shell.Error');
        }));
        it('verify the user is redirected to resource page when user get sucess', inject(function () {
            $controller('MoiSelectionCtrl', { '$scope': $scope, miResourceDataFactory: miResourceDataFactory });
            spyOn(miResourceDataFactory, 'GetResourcesOrGroup').and.callFake(function () {
                return $.Deferred().resolve({ route: "" });
            });
            $scope.next('NSDO', 'Resource', 'non-staff', 'BS');
            expect($state.go).toHaveBeenCalledWith('shell.landing-Question.ResourceLookUp');
        }));
        it('verify the user is redirected to claim summary page when user get pbe moi', inject(function () {
            $controller('MoiSelectionCtrl', { '$scope': $scope, miResourceDataFactory: miResourceDataFactory });
            $scope.next('PBE', 'Resource', 'non-staff', 'BS');
            expect($state.go).toHaveBeenCalledWith('shell.landing-Question.ClaimSummary');
        }));
    });
});
