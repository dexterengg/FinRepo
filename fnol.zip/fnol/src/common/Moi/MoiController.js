﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('MoiSelectionCtrl',
    function (
        $scope,
        $state,
        $sce,
        $filter,
        miAppProperties,
        cfpLoadingBar,
        ENV,
        miComponentRoute,
        miQues,
        miUiStagesProgressbar,
        miMoiProperties,
        miLocale,
        miResourceDataFactory,
        miResourceProperties,
        miStageFactory) {

        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());

        //getting moiName 
        //It will work in case of back.  By this it will highlight the selected moi
        $scope.moiName = miMoiProperties.getmoiType();

        $scope.MoiHeading = $filter('translate')('_MOIHEADING_');
        // Scope variable to display verbiage for MOI
        $scope.NSDO_Moi_Heading = $filter('translate')('_SHOPMOI_');
        $scope.NSDO_Moi_Content = $filter('translate')('_SHOPCONTENT_');
        $scope.NSDO_Moi_Button = $filter('translate')('_SHOPMOIBUTTON_');

        $scope.DI_Moi_Heading = $filter('translate')('_DRIVEINMOI_');
        $scope.DI_Moi_Content = $filter('translate')('_DRIVEINCONTENT_');
        $scope.DI_Moi_Button = $filter('translate')('_DRIVEINMOIBUTTON_');

        $scope.SCDI_Moi_Heading = $filter('translate')('_SERVICECENTERMOI_');
        $scope.SCDI_Moi_Content = $filter('translate')('_SERVICECENTERCONTENT_');
        $scope.SCDI_Moi_Button = $filter('translate')('_SERVICECENTERMOIBUTTON_');

        $scope.FI_Moi_Heading = $filter('translate')('_FIMOI_');
        $scope.FI_Moi_Content = $filter('translate')('_FICONTENT_');
        $scope.FI_Moi_Button = $filter('translate')('_FIMOIBUTTON_');

        $scope.PBE_Moi_Heading = $filter('translate')('_PBEMOI_');
        $scope.PBE_Moi_Content = $filter('translate')('_PBECONTENT_');
        $scope.PBE_Moi_Button = $filter('translate')('_PBEMOIBUTTON_');

        $scope.moidetails = miMoiProperties.getMoiModelArray();

        $scope.next = function (moitype, resouceGroup, resourceGroupType, resourceSubType) {
            ga('send', 'event', 'Navigation', 'Button click', 'Next');
            
            //Setting both resource type and group type to null
            //Later in below function "setDefaultCriteriaForMoi" we are setting correct value for required field.
            //It will useful in case of back and change moi type
            //Otherwise both value will set and resource search will effect
            miResourceProperties.setResourceType(null);
            miResourceProperties.setGroupType(null);

            //Calling function to clear postal code and other entries to refine resource search
            miAppProperties.setPostalCodeToDefault();
            
            if (moitype === "PBE") {
                cfpLoadingBar.start();
                //update postfnol stage as complete
                miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                              .then(function (updatestageresponse) {
                                  cfpLoadingBar.complete();
                                  if (updatestageresponse.route) {                                     
                                      $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                                  }
                                  else {
                                      //Get next stage call
                                      miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                                                  .then(function (nextstageresponse) {
                                                                                      if (nextstageresponse.route) {
                                                                                          cfpLoadingBar.complete();
                                                                                          $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                                                      }
                                                                                  })
                                  }
                              })
            }
            else {
                miMoiProperties.setmoiType(moitype);
                // Resource data            

                miResourceProperties.setDefaultCriteriaForMoi(moitype);
                cfpLoadingBar.start();
                miResourceDataFactory.GetResourcesOrGroup(miResourceProperties.getResourceSearchCriteria(), resouceGroup)
                   .then(function (resourcesresponse) {
                       cfpLoadingBar.complete();
                       if (resourcesresponse.route) {
                           $state.go(miComponentRoute.getComponentroute(resourcesresponse.route));
                       } else {
                           miAppProperties.setResourceDataList(resourcesresponse.data);
                           $state.go(miComponentRoute.getComponentroute(ENV.RESOURCE_CONSTANT));
                       }
                   });

            }


            


        }
    });
}(angular));
