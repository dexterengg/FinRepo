﻿describe('Complex type', function () {
   
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        UserIdentificationdata: [],
        questionDetailsList: [],
        totalNumOfStages: 6,
        stageUiOrder: 2,
        statuscode: "statuscode",
        stageStatus: "",
        stageName: "IDENTIFICATION",
        currentQuestion: {"companyCd":"M2","qustnnreQustnId":100000126681,"qustnnreId":100000009518,"answerList":[{"qustnnreQustnId":100000126681,"answered":false,"answerDisplayText":"test","answerItemID":100000141010,"additionalAnswerInfo":null,"lowRangeValue":0,"highRangeValue":0,"answerDisplayOrder":1,"customText":null},{"qustnnreQustnId":100000126681,"answered":false,"answerDisplayText":"test 1","answerItemID":100000141011,"additionalAnswerInfo":null,"lowRangeValue":0,"highRangeValue":0,"answerDisplayOrder":2,"customText":null}],"saveRequired":false,"userSelectdSystmQustnAns":false,"firstQuestion":false,"complexQuestionTemplate":"{\"field\":[{\"expression\":\"\",\"label\":\"First Name or Company Name\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":1,\"validationmsg\":\"Value should not be empty.\",\"id\":\"FIRST_NAME\",\"watermark\":\"Ex. Jane or ABC Company\",\"maxlength\":100,\"order\":1,\"isRequired\":true,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"Last Name\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":2,\"validationmsg\":\"\",\"id\":\"LAST_NAME\",\"watermark\":\"\",\"maxlength\":100,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"Date of Birth\",\"parentid\":\"\",\"type\":\"Date\",\"row\":3,\"validationmsg\":\"\",\"id\":\"DOB\",\"watermark\":\"\",\"maxlength\":10,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"Address\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":4,\"validationmsg\":\"\",\"id\":\"ADDRESS1\",\"watermark\":\"Ex. 123 Portage Ave\",\"maxlength\":500,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":5,\"validationmsg\":\"\",\"id\":\"ADDRESS2\",\"watermark\":\"\",\"maxlength\":500,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"City Or Town\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":6,\"validationmsg\":\"\",\"id\":\"CITY_OR_TOWN\",\"watermark\":\"Ex. Winnipeg\",\"maxlength\":256,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"State/Province\",\"parentid\":\"\",\"type\":\"DropDown\",\"row\":7,\"validationmsg\":\"\",\"id\":\"STATE_PROVINCE\",\"watermark\":\"\",\"maxlength\":100,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"//ResourceLookupRESTWS//api//territory//states\"},{\"expression\":\"[ABCEGHJKLMNPRSTVXY]\\\\\\\\d[ABCEGHJ-NPRSTV-Z][ ]?\\\\\\\\d[ABCEGHJ-NPRSTV-Z]\\\\\\\\d\",\"label\":\"Zip/Postal Code\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":8,\"validationmsg\":\"Please enter valid Postal Code\",\"id\":\"ZIP\",\"watermark\":\"Ex. R3N 0K3\",\"maxlength\":10,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"(^((\\\\\\\\+\\\\\\\\d{1,5}-)|(\\\\\\\\+\\\\\\\\d{1,5}-\\\\\\\\d{1,5}-)){1}([a-zA-Z0-9]){3,9}$)|(^\\\\\\\\d{10}$|^\\\\\\\\(\\\\\\\\d{3}\\\\\\\\)\\\\\\\\s{0,1}\\\\\\\\d{3}\\\\\\\\-\\\\\\\\d{4}$|^\\\\\\\\d{3}\\\\\\\\-\\\\\\\\d{3}\\\\\\\\-\\\\\\\\d{4}$|^\\\\\\\\d{3}\\\\\\\\-\\\\\\\\d{7}$)\",\"label\":\"Phone Number\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":9,\"validationmsg\":\"Please enter in 999-999-9999 or international format.\",\"id\":\"PHONE\",\"watermark\":\"\",\"maxlength\":20,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"^([a-zA-Z0-9_\\\\\\\\-\\\\\\\\.]+)@([a-zA-Z0-9_\\\\\\\\-\\\\\\\\.]+)\\\\\\\\.([a-zA-Z]{2,5})$\",\"label\":\"Email\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":10,\"validationmsg\":\"Email not valid.\",\"id\":\"EMAIL\",\"watermark\":\"\",\"maxlength\":100,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"Is there anything else you want to tell us?\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":11,\"validationmsg\":\"\",\"id\":\"ADD_INFO\",\"watermark\":\"\",\"maxlength\":500,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"}],\"parentQuestionText\":\"\",\"parentQuestionType\":\"CHOICE_SELECTION\",\"culture\":\"en-US\"}","customTextFlag":"CUSTOM_TEXT","qustnnrVrsnChng":false,"levelNum":2,"sequenceNo":2,"parentQuestionId":100000126415,"qustnText":"test display statement custom party","answrControlType":"PARTY_TYPE","qustnFormattedText":"false","editable":true,"qustnPlainText":null,"systemQuestion":false},
        backbuttoncss: "clickable_Back_Btn",
        IsStageStatusChanged: true,
        contextid: false,
        coStageId: 123,
        docID: 0,
        placeholder: "MM/dd/yyyy",
        questionText:"abc"
    };
    angular.module('mock.complexTypeQuestionData', [])
	.factory('miAppProperties', function ($q) {
	    var constant = {};
	    constant.gettheme = function () {
	        return expectedDetail.theme;
	    };
	    constant.getorgcode = function () {
	        return expectedDetail.orgcode;
	    };
	    constant.getanimationclass = function () {
	        return expectedDetail.animationclass;
	    };
	    constant.gettotalNumOfStages = function () {
	        return expectedDetail.totalNumOfStages;
	    };
	    constant.getstageUiOrder = function () {
	        return expectedDetail.stageUiOrder;
	    };
	    constant.getCurrentQuestion = function () {
	        return expectedDetail.currentQuestion;
	    };

	    constant.setstatuscode = function (statuscode) {
	        expectedDetail.statuscode = statuscode;
	    };
	    constant.getstageName = function () {
	        return expectedDetail.stageName;
	    };

	    constant.getBackButtonCss = function () {
	        return expectedDetail.backbuttoncss;
	    };
	    constant.IsStageStatusChanged = function () {
	        return expectedDetail.IsStageStatusChanged
	    };
	    constant.setStageStatus = function (stageStatus) {
	        expectedDetail.stageStatus = stageStatus;
	    }
	    constant.getStageStatus = function () {
	        return expectedDetail.stageStatus;
	    };
	    constant.getcontextid = function () {
	        return expectedDetail.contextid;
	    };
	    constant.getcoStageId = function () {
	        return expectedDetail.coStageId;
	    };
	    constant.getDocID = function () {
	        return expectedDetail.docID;
	    };
	    constant.setVersionMismatchStatus = function () { }
	    constant.getVersionMismatchStatus = function () {
	        return false;
	    }
	    return constant;
	})

    .factory('miQues', function () {
        var constant = {};
        constant.getQues = function (formatedQues, plainQues) {
            return expectedDetail.questionText;
        }
        return constant;

    });
   
    describe('ComplexType_Controller_Test_for_currentTheme', function () {
        beforeEach(module('mi.mfnol.web'));
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.complexTypeQuestionData'));
        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service           
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('ComplexQuestionCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));

        it('ensure current theme is not null', function () {
            
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });

        it('ensure default page class name', function () {
            expect(scope.pageClass).toBe(expectedDetail.animationclass);
        });
        it('ensure Current Question', function () {
            expect(scope.questionText).toBe(expectedDetail.questionText);
        });
      

    });


    describe('ComplexType Question Controller_PageLoad_Test_function', function () {
        beforeEach(module('mi.mfnol.web'));
        //var miAppFactory;
        beforeEach(module('mock.complexTypeQuestionData'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miAppFactory = $injector.get('miAppFactory');
                miStageFactory = $injector.get('miStageFactory');
                miAppProperties = $injector.get('miAppProperties');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');

            });
        });
        //spec to track that spy created on $sce.trustAsHtml and miStageFactory.updateStage was called

        it('should call sce trustAsHtml', inject(function () {
            $controller('ComplexQuestionCtrl', { $scope: $scope, $state: $state, $sce: $sce });
            spyOn($sce, 'trustAsHtml').and.callThrough();
            $scope.getHtml('<h1>Test</h1>');
            expect($sce.trustAsHtml).toHaveBeenCalled();
        }));

        it('check parentQuestionType is choice selection', function () {
            expect(scope.primaryType).toBe('CS');
        });
        it('check parentQuestionType is Range selection', function () {
            expectedDetail.currentQuestion = { "companyCd": "M2", "qustnnreQustnId": 100000126681, "qustnnreId": 100000009518, "answerList": [{ "qustnnreQustnId": 100000126681, "answered": false, "answerDisplayText": "test", "answerItemID": 100000141010, "additionalAnswerInfo": null, "lowRangeValue": 0, "highRangeValue": 0, "answerDisplayOrder": 1, "customText": null }, { "qustnnreQustnId": 100000126681, "answered": false, "answerDisplayText": "test 1", "answerItemID": 100000141011, "additionalAnswerInfo": null, "lowRangeValue": 0, "highRangeValue": 0, "answerDisplayOrder": 2, "customText": null }], "saveRequired": false, "userSelectdSystmQustnAns": false, "firstQuestion": false, "complexQuestionTemplate": "{\"field\":[{\"expression\":\"\",\"label\":\"First Name or Company Name\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":1,\"validationmsg\":\"Value should not be empty.\",\"id\":\"FIRST_NAME\",\"watermark\":\"Ex. Jane or ABC Company\",\"maxlength\":100,\"order\":1,\"isRequired\":true,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"Last Name\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":2,\"validationmsg\":\"\",\"id\":\"LAST_NAME\",\"watermark\":\"\",\"maxlength\":100,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"Date of Birth\",\"parentid\":\"\",\"type\":\"Date\",\"row\":3,\"validationmsg\":\"\",\"id\":\"DOB\",\"watermark\":\"\",\"maxlength\":10,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"Address\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":4,\"validationmsg\":\"\",\"id\":\"ADDRESS1\",\"watermark\":\"Ex. 123 Portage Ave\",\"maxlength\":500,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":5,\"validationmsg\":\"\",\"id\":\"ADDRESS2\",\"watermark\":\"\",\"maxlength\":500,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"City Or Town\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":6,\"validationmsg\":\"\",\"id\":\"CITY_OR_TOWN\",\"watermark\":\"Ex. Winnipeg\",\"maxlength\":256,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"State/Province\",\"parentid\":\"\",\"type\":\"DropDown\",\"row\":7,\"validationmsg\":\"\",\"id\":\"STATE_PROVINCE\",\"watermark\":\"\",\"maxlength\":100,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"//ResourceLookupRESTWS//api//territory//states\"},{\"expression\":\"[ABCEGHJKLMNPRSTVXY]\\\\\\\\d[ABCEGHJ-NPRSTV-Z][ ]?\\\\\\\\d[ABCEGHJ-NPRSTV-Z]\\\\\\\\d\",\"label\":\"Zip/Postal Code\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":8,\"validationmsg\":\"Please enter valid Postal Code\",\"id\":\"ZIP\",\"watermark\":\"Ex. R3N 0K3\",\"maxlength\":10,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"(^((\\\\\\\\+\\\\\\\\d{1,5}-)|(\\\\\\\\+\\\\\\\\d{1,5}-\\\\\\\\d{1,5}-)){1}([a-zA-Z0-9]){3,9}$)|(^\\\\\\\\d{10}$|^\\\\\\\\(\\\\\\\\d{3}\\\\\\\\)\\\\\\\\s{0,1}\\\\\\\\d{3}\\\\\\\\-\\\\\\\\d{4}$|^\\\\\\\\d{3}\\\\\\\\-\\\\\\\\d{3}\\\\\\\\-\\\\\\\\d{4}$|^\\\\\\\\d{3}\\\\\\\\-\\\\\\\\d{7}$)\",\"label\":\"Phone Number\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":9,\"validationmsg\":\"Please enter in 999-999-9999 or international format.\",\"id\":\"PHONE\",\"watermark\":\"\",\"maxlength\":20,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"^([a-zA-Z0-9_\\\\\\\\-\\\\\\\\.]+)@([a-zA-Z0-9_\\\\\\\\-\\\\\\\\.]+)\\\\\\\\.([a-zA-Z]{2,5})$\",\"label\":\"Email\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":10,\"validationmsg\":\"Email not valid.\",\"id\":\"EMAIL\",\"watermark\":\"\",\"maxlength\":100,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"Is there anything else you want to tell us?\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":11,\"validationmsg\":\"\",\"id\":\"ADD_INFO\",\"watermark\":\"\",\"maxlength\":500,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"}],\"parentQuestionText\":\"\",\"parentQuestionType\":\"RANGE_VALUE\",\"culture\":\"en-US\"}", "customTextFlag": "CUSTOM_TEXT", "qustnnrVrsnChng": false, "levelNum": 2, "sequenceNo": 2, "parentQuestionId": 100000126415, "qustnText": "test display statement custom party", "answrControlType": "PARTY_TYPE", "qustnFormattedText": "false", "editable": true, "qustnPlainText": null, "systemQuestion": false },
              $controller('ComplexQuestionCtrl', { $scope: $scope});
            expect($scope.primaryType).toBe('RV');
        });
        it('check parentQuestionType is Yes-No', function () {           
            expectedDetail.currentQuestion = { "companyCd": "M2", "qustnnreQustnId": 100000126681, "qustnnreId": 100000009518, "answerList": [{ "qustnnreQustnId": 100000126681, "answered": false, "answerDisplayText": "test", "answerItemID": 100000141010, "additionalAnswerInfo": null, "lowRangeValue": 0, "highRangeValue": 0, "answerDisplayOrder": 1, "customText": null }, { "qustnnreQustnId": 100000126681, "answered": false, "answerDisplayText": "test 1", "answerItemID": 100000141011, "additionalAnswerInfo": null, "lowRangeValue": 0, "highRangeValue": 0, "answerDisplayOrder": 2, "customText": null }], "saveRequired": false, "userSelectdSystmQustnAns": false, "firstQuestion": false, "complexQuestionTemplate": "{\"field\":[{\"expression\":\"\",\"label\":\"First Name or Company Name\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":1,\"validationmsg\":\"Value should not be empty.\",\"id\":\"FIRST_NAME\",\"watermark\":\"Ex. Jane or ABC Company\",\"maxlength\":100,\"order\":1,\"isRequired\":true,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"Last Name\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":2,\"validationmsg\":\"\",\"id\":\"LAST_NAME\",\"watermark\":\"\",\"maxlength\":100,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"Date of Birth\",\"parentid\":\"\",\"type\":\"Date\",\"row\":3,\"validationmsg\":\"\",\"id\":\"DOB\",\"watermark\":\"\",\"maxlength\":10,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"Address\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":4,\"validationmsg\":\"\",\"id\":\"ADDRESS1\",\"watermark\":\"Ex. 123 Portage Ave\",\"maxlength\":500,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":5,\"validationmsg\":\"\",\"id\":\"ADDRESS2\",\"watermark\":\"\",\"maxlength\":500,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"City Or Town\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":6,\"validationmsg\":\"\",\"id\":\"CITY_OR_TOWN\",\"watermark\":\"Ex. Winnipeg\",\"maxlength\":256,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"State/Province\",\"parentid\":\"\",\"type\":\"DropDown\",\"row\":7,\"validationmsg\":\"\",\"id\":\"STATE_PROVINCE\",\"watermark\":\"\",\"maxlength\":100,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"//ResourceLookupRESTWS//api//territory//states\"},{\"expression\":\"[ABCEGHJKLMNPRSTVXY]\\\\\\\\d[ABCEGHJ-NPRSTV-Z][ ]?\\\\\\\\d[ABCEGHJ-NPRSTV-Z]\\\\\\\\d\",\"label\":\"Zip/Postal Code\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":8,\"validationmsg\":\"Please enter valid Postal Code\",\"id\":\"ZIP\",\"watermark\":\"Ex. R3N 0K3\",\"maxlength\":10,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"(^((\\\\\\\\+\\\\\\\\d{1,5}-)|(\\\\\\\\+\\\\\\\\d{1,5}-\\\\\\\\d{1,5}-)){1}([a-zA-Z0-9]){3,9}$)|(^\\\\\\\\d{10}$|^\\\\\\\\(\\\\\\\\d{3}\\\\\\\\)\\\\\\\\s{0,1}\\\\\\\\d{3}\\\\\\\\-\\\\\\\\d{4}$|^\\\\\\\\d{3}\\\\\\\\-\\\\\\\\d{3}\\\\\\\\-\\\\\\\\d{4}$|^\\\\\\\\d{3}\\\\\\\\-\\\\\\\\d{7}$)\",\"label\":\"Phone Number\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":9,\"validationmsg\":\"Please enter in 999-999-9999 or international format.\",\"id\":\"PHONE\",\"watermark\":\"\",\"maxlength\":20,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"^([a-zA-Z0-9_\\\\\\\\-\\\\\\\\.]+)@([a-zA-Z0-9_\\\\\\\\-\\\\\\\\.]+)\\\\\\\\.([a-zA-Z]{2,5})$\",\"label\":\"Email\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":10,\"validationmsg\":\"Email not valid.\",\"id\":\"EMAIL\",\"watermark\":\"\",\"maxlength\":100,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"},{\"expression\":\"\",\"label\":\"Is there anything else you want to tell us?\",\"parentid\":\"\",\"type\":\"TextBox\",\"row\":11,\"validationmsg\":\"\",\"id\":\"ADD_INFO\",\"watermark\":\"\",\"maxlength\":500,\"order\":1,\"isRequired\":false,\"action\":\"\",\"value\":\"\",\"datasource\":\"\"}],\"parentQuestionText\":\"\",\"parentQuestionType\":\"YES_NO_VALUE\",\"culture\":\"en-US\"}", "customTextFlag": "CUSTOM_TEXT", "qustnnrVrsnChng": false, "levelNum": 2, "sequenceNo": 2, "parentQuestionId": 100000126415, "qustnText": "test display statement custom party", "answrControlType": "PARTY_TYPE", "qustnFormattedText": "false", "editable": true, "qustnPlainText": null, "systemQuestion": false };
             
              $controller('ComplexQuestionCtrl', { $scope: $scope });
            expect($scope.primaryType).toBe('YN');
        });

        it('check additionalAnswerInfo', function () {
           
            expect(scope.additionalAnswerInfo).not.toBe(null);
        });

        it('should call getComplexFieldData', inject(function () {           
            spyOn(miAppFactory, 'getComplexFieldData').and.callFake(function () {
                return $.Deferred().resolve({ data: [] });
            });
            $controller('ComplexQuestionCtrl', { $scope: $scope,  miAppFactory: miAppFactory });           
            
            expect(miAppFactory.getComplexFieldData).toHaveBeenCalled();



        }));
       
    });

});