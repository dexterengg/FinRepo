﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('ComplexQuestionCtrl',
    function ($scope,
         $filter,
         $q,
         $interval,
         $state,
         miUiStagesProgressbar,
         $sce,
         miQues,
         ENV,
         miLocale,
         cfpLoadingBar,
         miValidation,
         miAppFactory,
         miComponentRoute,
         miStageFactory,
        miAppProperties) {

        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        $scope.placeholder = ENV.DATE_FORMAT;
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        var isDatetimeControl = Modernizr.inputtypes.date;
        $scope.isSupportable = function () {
            return isDatetimeControl;
        }

        var currentQuestion = miAppProperties.getCurrentQuestion();
        $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
        $scope.getHtml = function (html) {
            return $sce.trustAsHtml(html);
        };
        $scope.isEditable = currentQuestion.editable;
        $scope.answerText = currentQuestion.answerList;
        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();
        $scope.complexJsonForUI = [];
        $scope.tempAdditionalAnswerInfo = [];
        $scope.additionalAnswerInfo = [];
        $scope.complexAnswerList = [];

        // method to bind complex question fields
        $scope.bindComplexData = function (id, url) {
            var deferred = $q.defer();
            var options = [];
            if (url) {
                miAppFactory.getComplexFieldData(url)
                .then(function (result) {
                    result.data.forEach(function (item, index) {
                        if (id == "COUNTRY")
                            options.push({ 'text': item.CountryName, 'value': item.CountryShortName })
                        else
                            options.push({ 'text': item.StateName, 'value': item.StateName })
                    })
                    $.each($scope.complexJsonForUI, function (index, object) {
                        if (object.id == id) {
                            object.ddlData = options;
                        }
                    });
                    deferred.resolve(options);
                }, function (result) {
                    deferred.resolve(options);
                })
            }
            return deferred.promise;
        };

        // page load method for complex type question
        $scope.pageLoad = function () {
            var complexQuestionData = currentQuestion.complexQuestionTemplate;
            var complexJson = JSON.parse(complexQuestionData);
            $scope.primaryType = "OP";
            // assign temp primary type for Answer options
            if (complexJson.parentQuestionType === ENV.CHOICE_CONSTANT)
                $scope.primaryType = "CS";
            else if (complexJson.parentQuestionType === ENV.RANGE_CONSTANT)
                $scope.primaryType = "RV";
            else if (complexJson.parentQuestionType === ENV.YES_NO_CONSTANT)
                $scope.primaryType = "YN";
            // update answer json data to pre-polulate
            if (currentQuestion.answerList.length > 0) {
                for (var i = 0; i < currentQuestion.answerList.length; i++) {
                    if (currentQuestion.answerList[i].additionalAnswerInfo) {
                        $scope.additionalAnswerInfo = JSON.parse(currentQuestion.answerList[i].additionalAnswerInfo);
                        $scope.tempAdditionalAnswerInfo = $scope.additionalAnswerInfo;
                        break;
                    }
                }
            }

            // logic to paint UI for complex data
            if (complexJson.field.length > 0) {
                var fieldValue;
                $scope.complexJsonForUI = complexJson.field;
                for (var i = 0; i < complexJson.field.length; i++) {
                    if (complexJson.field[i].type === "DropDown") {
                        // bind drop down data with thier respective sources
                        $scope.bindComplexData(complexJson.field[i].id, complexJson.field[i].datasource);
                    }
                    // populate value in scope variable to pre-populate fields
                    $.each($scope.additionalAnswerInfo, function (index, object) {
                        if (object.Id == $scope.complexJsonForUI[i].id) {
                            $scope.complexJsonForUI[i].value = object.Value;
                            // if date field then get that format
                            if ($scope.complexJsonForUI[i].type === "Date") {
                                if (isDatetimeControl) {
                                    $scope.complexJsonForUI[i].value = object.Value != "" ? new Date(object.Value) : "";
                                }
                                else {
                                    object.Value = object.Value.replace(/[^A-Za-z 0-9 \.,\?""!@#\$%\^&\*\(\)-_=\+;:<>\/\\\|\}\{\[\]`~]*/g, '');
                                    $scope.complexJsonForUI[i].value = object.Value != "" ? miValidation.getCustomDateTime(new Date(object.Value), ENV.DATE_CONSTANT) : "";
                                }
                            }
                        }
                    });
                }
            }
        };

        // calling page load
        $scope.pageLoad();
        $scope.validate = function (key, type, expression, validationMsg, isRequired) {
            var uam, cntrl, val, inputValue;
            uam = "Valid";
            cntrl = angular.element('#' +key);
            cntrl.text("");

            cntrl.removeClass('mi-uam-block--alert');
            type = type.toLowerCase();

            if (cntrl[0]) {
                if (angular.equals(type, ENV.CONTROL_TYPE_DROPDOWN)) {
                    var options = $scope.complexJsonForUI.filter(function(item) {
                        return (angular.equals(item.type.toLowerCase(), ENV.CONTROL_TYPE_DROPDOWN) && angular.equals(item.id, key))
                    });
                    val = options[0].value;
                }
                else
                    val = cntrl.siblings().eq(0).val().trim();
                if (angular.equals(type, ENV.DATEOFLOSS_CONSTANT) && angular.equals(val.trim(), "")) {
                    cntrl.siblings().eq(0).val('');
                }
                // validate fields
                if (isRequired)
                    uam = miValidation.isRequiredValidation(val, validationMsg);
                if (!angular.equals(expression, "") && !angular.equals(val.trim(), ""))
                    uam = miValidation.regexValidation(val, expression, validationMsg);
                if (angular.equals(type, ENV.DATEOFLOSS_CONSTANT) && !angular.equals(val.trim(), "")) {                   
                    uam = miValidation.uam = miValidation.validateDateandTime(isDatetimeControl ?$filter('date')(new Date(cntrl.siblings().eq(0).val()).toISOString(), ENV.DATE_FORMAT): val, type, !(isDatetimeControl));
                    if (angular.equals(uam, "Valid")) {
                        val = new Date(new Date(cntrl.siblings().eq(0).val()).toISOString()).toLocaleDateString();
                    }
                }
                if (angular.equals(uam,"Valid")) {
                    cntrl.text("");
                    cntrl.removeClass('mi-uam-block--alert');
                    return val;
                }
                else {
                    cntrl.text(uam);
                    cntrl.addClass('mi-uam-block--alert');
                    cfpLoadingBar.complete();
                    return false;
                };
            }
        }
        // insert complex answer name, value json 

        $scope.insertAdditionalAnswerInfo = function (Id, Value, Type, Label) {
            var answerInfo = {
                "Id": Id, "Value": Value, "Type": Type, "Label": Label
                };
            this.additionalAnswerInfo.push(answerInfo);
        };
        // get complex answer name, value json
        $scope.getAdditionalAnswerInfo = function () {
            return this.additionalAnswerInfo;
        };
        // reset complex answer name, value json
        $scope.resetAdditionalAnswerInfo = function () {
            this.additionalAnswerInfo =[];
        };

        // reset complex answer name, value json
        $scope.resetTempAdditionalAnswerInfo = function () {
            this.tempAdditionalAnswerInfo =[];
        };

        // reset complex answer to save
        $scope.resetComplexAnswerListData = function () {
            this.complexAnswerList =[];
        };


        // insert complex answer to save
        $scope.insertComplexAnswerListData = function (complexAnswerTxt, additionalAnswerInfo) {
            var stringAdditionalAnswerInfo = JSON.stringify(additionalAnswerInfo);
            var complexAnswerInfo = {
                "complexAnswerTxt": complexAnswerTxt, "additionalAnswerInfo": stringAdditionalAnswerInfo
                };
            this.complexAnswerList.push(complexAnswerInfo);
        };

        $scope.getComplexAnswerListData = function () {
            return this.complexAnswerList;
        };

        $scope.bindChild = function (id, data) {
            $.each($scope.complexJsonForUI, function (index, object) {
                if(object.parentid == id) {
                    $scope.bindComplexData(object.id, object.datasource);
                    return false;
                }
            })
        };

        $scope.changeOption = function (id, data) {
            $scope.bindChild(id, data);

        };


        $scope.getRoute = function () {
            miAppFactory.getRoute()
                .then(function(routeresponse) {
                    if(routeresponse.route) {
                        if ($state.current.name === miComponentRoute.getComponentroute(routeresponse.route)) {
                            $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

                            //Code to check whether version mismatch is true or not
                            //It is the scenario if the script type is first question and user has changed questionnaire from WCAdmin
                            //In this case question will show with error message
                            $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();

                            cfpLoadingBar.complete();
                            $scope.samepagecss = "page-inner-slideOutUp";
                            miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
                            var intervalCanceller = $interval(function() {
                                //$scope.Back_Btn_Class = "clickable_Back_Btn";
                                $scope.samepagecss = "";
                                currentQuestion = miAppProperties.getCurrentQuestion();
                                $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
                                $scope.answerText = currentQuestion.answerList;
                                $scope.isEditable = currentQuestion.editable;
                                $scope.resetAdditionalAnswerInfo();
                                $scope.resetTempAdditionalAnswerInfo();
                                $scope.resetComplexAnswerListData();
                                $scope.pageLoad();
                                $interval.cancel(intervalCanceller);
                            }, 1000);
                        }
                        else {

                            cfpLoadingBar.complete();
                            $state.go(miComponentRoute.getComponentroute(routeresponse.route));
                        }
                    }
                });
        };
        $scope.next = function (ans, stat) {
            cfpLoadingBar.start();

            //set isVersionMismatch to false so that version mismatch message will not show on next question
            miAppProperties.setVersionMismatchStatus(false);

            // reset all variables 
            $scope.resetAdditionalAnswerInfo();
            $scope.resetComplexAnswerListData();
            //checking form validation according to is required and regex 
            for (var complexJsonIndex = 0; complexJsonIndex < $scope.complexJsonForUI.length; complexJsonIndex++) {
                var value = $scope.validate($scope.complexJsonForUI[complexJsonIndex]["id"], $scope.complexJsonForUI[complexJsonIndex]["type"], $scope.complexJsonForUI[complexJsonIndex]["expression"], $scope.complexJsonForUI[complexJsonIndex]["validationmsg"], $scope.complexJsonForUI[complexJsonIndex]["isRequired"]);
                if (value === false) {
                    return false
                }
                $scope.insertAdditionalAnswerInfo($scope.complexJsonForUI[complexJsonIndex]["id"], value, $scope.complexJsonForUI[complexJsonIndex]["type"], $scope.complexJsonForUI[complexJsonIndex]["label"]);
            };
                // prepare answer json to save
            //If action button other than choice selection  
            $scope.insertComplexAnswerListData(ans ? ans.answerDisplayText: ENV.SCRIPT_DEFAULT_VALUE, $scope.getAdditionalAnswerInfo());

            //Calling function to insert question details
            miAppProperties.insertQuestionDetails(currentQuestion.qustnnreQustnId, null, $scope.getComplexAnswerListData());

            //Calling function to check whether we user has given same answer or not
            var isStatusChanged = miAppProperties.IsStageStatusChanged(currentQuestion, ans, $scope.tempAdditionalAnswerInfo, $scope.additionalAnswerInfo);



            //If status changed then we need to first update the stage with state "REOPEN"
            //Otherwise continue with existing call
            if (isStatusChanged) {
                miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_REOPEN)
                   .then(function (updatestageresponse) {
                       if(updatestageresponse.route) {
                           cfpLoadingBar.complete();
                           $state.go(miComponentRoute.getComponentroute(updatestageresponse.route));
                           }
                           else {
                           miAppProperties.setStageStatus(ENV.CLAIMSTATUS_REOPEN);
                           $scope.getRoute();
                           }
                   })
                           }
                       else {
                $scope.getRoute();
                }

                };
        $scope.back = function () {
            ga('send', 'event', 'Navigation', 'Hyperlink click', 'Back');
            cfpLoadingBar.start();

                //set isVersionMismatch to false so that version mismatch message will not show on next question
            miAppProperties.setVersionMismatchStatus(false);

            miAppFactory.getPreviousRoute(currentQuestion.qustnnreQustnId)
            .then(function (routeresponse) {
                if (routeresponse.route) {
                    if($state.current.name === miComponentRoute.getComponentroute(routeresponse.route)) {
                        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

                        //Code to check whether version mismatch is true or not
                        //It is the scenario if the script type is first question and user has changed questionnaire from WCAdmin
                        //In this case question will show with error message
                        $scope.isVersionMismatch = miAppProperties.getVersionMismatchStatus();

                        cfpLoadingBar.complete();
                        $scope.samepagecss = "page-inner-slideOutUp";
                        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
                        var intervalCanceller = $interval(function () {
                            $scope.samepagecss = "";
                            currentQuestion = miAppProperties.getCurrentQuestion();
                            $scope.questionText = miQues.getQues(currentQuestion.qustnFormattedText, currentQuestion.qustnText);
                            $scope.answerText = currentQuestion.answerList;
                            $scope.isEditable = currentQuestion.editable;
                            $scope.resetAdditionalAnswerInfo();
                            $scope.resetComplexAnswerListData();
                            $scope.pageLoad();
                            $interval.cancel(intervalCanceller);
                        }, 1000);
                            }
                            else {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(routeresponse.route));
                        }
                        }

                else {
                    $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
                    cfpLoadingBar.complete();
                    }
            });

            }
                    });
                    }(angular));

