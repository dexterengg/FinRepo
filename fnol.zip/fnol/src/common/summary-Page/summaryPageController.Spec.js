﻿describe('MFNOL AngularJS Controller (Confirmation Question Controller)', function () {

    var $httpBackend, $scope, $controller, stageQuestionaireRouteDetails;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: "",
        stageType: "fake-Stage",
        stageDesc: "fake-stageDesc",
        pageName: "fake-pageName"
    };
    // Mocked Service
    angular.module('mock.confirmationdata', [])
	.factory('miAppProperties', function ($q) {
	    var constant = {};
	    constant.gettheme = function () {
	        return expectedDetail.theme;
	    };
	    constant.getorgcode = function () {
	        return expectedDetail.orgcode;
	    };
	    constant.getanimationclass = function () {
	        return expectedDetail.animationclass;
	    };
	    constant.getlanguage = function () {
	        return expectedDetail.language;
	    };
	    constant.getDocID = function () {
	        return expectedDetail.DocID;
	    };
	    constant.getstageType = function () {
	        return expectedDetail.stageType;
	    };
	    constant.getstageDesc = function () {
	        return expectedDetail.stageDesc;
	    };
	    constant.getpageName = function () {
	        return expectedDetail.pageName;
	    };
	    constant.setisConfirmed = function () {
	        return expectedDetail.isConfirmed;
	    };
	    constant.setDocID = function (DocID) {
	        return expectedDetail.DocID;
	    };


	    // example stub method that returns a promise, e.g. if original method returned $http.get(...)
	    constant.fetch = function () {
	        var mockUser = "M2";
	        return $q.when(mockUser);
	    };
	    // other stubbed methods
	    return constant;
	})

    describe('ConfirmationQuestion_Controller_Test_for_currentTheme', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));

        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.confirmationdata'));

        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('SummaryPageCtrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));
        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });

        it('ensure default page class name', function () {
            expect(scope.pageClass).toBe('page-main');
        })
    });

    describe('ChoiceSelectionQuestion_miUiStagesProgressbar_Service_Test', function () {
        beforeEach(module('mock.moidata'));
        beforeEach(function () {
            inject(function ($injector) {
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $filter = $injector.get('$filter');
                $controller = $injector.get('$controller');
                miUiStagesProgressbar = $injector.get('miUiStagesProgressbar');
                spyOn(miUiStagesProgressbar, 'changeUiStage').and.callThrough();
            });
        });
        //spec to track that spy created on miUiStagesProgressbar.changeUiStage was called
        it('should call miUiStagesProgressbar changeUiStage when called', inject(function () {
            $controller('SummaryPageCtrl', { $scope: $scope, miUiStagesProgressbar: miUiStagesProgressbar });
            expect(miUiStagesProgressbar.changeUiStage).toHaveBeenCalled();
        }));
    });

    describe('ConfirmationQuestionController_Confirm()_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        var sce, miCMSFactory
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                $controller = $injector.get('$controller');
                $sce = $injector.get('$sce');
                miCMSFactory = $injector.get('miCMSFactory');

            });
        });
        it('should call miService partialPolicyVerfication when called', function () {
            $controller('SummaryPageCtrl', { $scope: $scope });

            spyOn($sce, 'trustAsHtml').and.callThrough();
            $scope.getHtml('<h1>Test</h1>');
            expect(sce.trustAsHtml).toHaveBeenCalled();

            //expect(miservice.policyVerfication).toHaveBeenCalled();
        });

    });


    //describe('ConfirmationQuestionController_Edit()_Test', function () {
    //    beforeEach(module('mi.mfnol.web'));
    //    beforeEach(function () {
    //        inject(function ($injector) {
    //            $rootScope = $injector.get('$rootScope');
    //            $scope = $injector.get('$rootScope').$new();
    //            $state = $injector.get('$state');
    //            $controller = $injector.get('$controller');

    //        });
    //    });
    //    it('ensure context id should be false', inject(function (miAppProperties) {
    //        $controller('ConfirmationQuestionController', { $scope: $scope });
    //        spyOn($state, 'go');
    //        $scope.Edit();
    //        expect(miAppProperties.getcontextid()).toBe(false);
    //    }));
    //    it('ensure stage order should be 1', inject(function (miAppProperties) {
    //        $controller('ConfirmationQuestionController', { $scope: $scope });
    //        spyOn($state, 'go');
    //        $scope.Edit();
    //        expect(miAppProperties.getStageOrder()).toBe(1);
    //    }));
    //    it('ensure that user move to login page', inject(function (miAppProperties) {
    //        $controller('ConfirmationQuestionController', { $scope: $scope });
    //        spyOn($state, 'go');
    //        $scope.Edit();
    //        expect($state.go).toHaveBeenCalledWith('shell.securelogin');
    //    }));
    //});

});