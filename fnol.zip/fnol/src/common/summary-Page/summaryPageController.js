﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('SummaryPageCtrl',
    function (
        $rootScope,
        $scope,
        $state,
        $sce,
        $filter,
        miAppProperties,
        ENV,
        miComponentRoute,
        cfpLoadingBar,
        miLocale,
        miUiStagesProgressbar,
        miStageFactory,
        miCMSFactory) {

        $scope.btnEditEnable = true;
        $scope.btnConfirmEnable = true;
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = miAppProperties.getanimationclass();
        miUiStagesProgressbar.changeUiStage(miAppProperties.gettotalNumOfStages(), miAppProperties.getstageUiOrder());
        $scope.errCode = false;
        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();
        $scope.getHtml = function (html) {
            return $sce.trustAsHtml(html);
        };
        if (miAppProperties.getVehicalDetails()) {

            if (miAppProperties.getvehicalDetailsStatus() === 200) {
                if (miAppProperties.getVehicalDetails().vehicleDetails) {
                    //Condition to check whether user is receiving success message or not
                    //If yes then we need to show success message
                    //Otherwise we need to show our custom message
                    if (miAppProperties.getVehicalDetails().resDesc != null && miAppProperties.getVehicalDetails().resDesc != "")
                        $scope.questionText = miAppProperties.getVehicalDetails().resDesc;
                    else
                        $scope.questionText = $filter('translate')('_SUMMARYHEADING_');
                    $scope.answerText = miAppProperties.getVehicalDetails().vehicleDetails;
                }
                else {
                    $scope.questionText = $filter('translate')('_SUMMARYPAGEERROR_');
                    $scope.answerText = [];
                    $scope.btnConfirmEnable = false;
                }
            }
            else if (miAppProperties.getvehicalDetailsStatus() === 406) {
                if (miAppProperties.getVehicalDetails().errCode === 10) {
                    $scope.questionText = miAppProperties.getVehicalDetails().errDesc;
                    $scope.answerText = [];
                    $scope.errCode = true;
                    $scope.btnEditEnable = false;
                    $scope.btnConfirmEnable = false;
                }
                else if (miAppProperties.getVehicalDetails().errCode === 11) {
                    $scope.questionText = miAppProperties.getVehicalDetails().errDesc;
                    $scope.answerText = [];
                    $scope.errCode = true;
                    $scope.btnConfirmEnable = false;
                }
            }
            else if (miAppProperties.getvehicalDetailsStatus() === 99) {
                if (miAppProperties.getVehicalDetails()) {
                    $scope.questionText = $filter('translate')('_SUMMARYHEADING_');
                    $scope.answerText = miAppProperties.getVehicalDetails();
                }
                else {
                    $scope.questionText = $filter('translate')('_SUMMARYPAGEERROR_');
                    $scope.answerText = [];
                    $scope.btnConfirmEnable = false;
                }
            }
        }
        $scope.Confirm = function (isclick) {
            ga('send', 'event', 'Decision', 'Button click', 'Confirm');
            if (isclick) {
                cfpLoadingBar.start();
                miAppProperties.setisConfirmed(true);
                miAppProperties.setDocID(false);
                //update stage call
                miStageFactory.updateStage(miAppProperties.getcontextid(), miAppProperties.getcoStageId(), miLocale.getLocaleCode(), ENV.CLAIMSTATUS_COMPLETE)
                .then(function (response) {
                    if (response.route) {
                        cfpLoadingBar.complete();
                        $state.go(miComponentRoute.getComponentroute(response.route));
                    }
                    else {
                        miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                        .then(function (nextstageresponse) {
                            cfpLoadingBar.complete();
                            
                            if (nextstageresponse.route) {
                                $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                            }
                        });
                    }
                });
            }
        }
        $scope.Edit = function (isclick) {
            ga('send', 'event', 'Decision', 'Button click', 'Edit');
            if (isclick)
            {
                cfpLoadingBar.start();
                miAppProperties.ClearUserIdentificationdata();                
                miAppProperties.setredirectionToken(false);
                miAppProperties.setcontextid(false);
                miAppProperties.setisConfirmed(false);
                miAppProperties.setStageOrder(1);
                miAppProperties.setDocID(0);
                $rootScope.stages = 0;
                
                miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                    .then(function (nextstageresponse) {
                                                        cfpLoadingBar.complete();
                                                        if (nextstageresponse.route) {
                                                            $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                        }
                                                    });
            }
        }
    });
}(angular));