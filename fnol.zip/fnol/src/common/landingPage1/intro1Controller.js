﻿(function (ng) {
    'use strict';
    ng.module('mi.mfnol.web')
    .controller('Intro1Ctrl',
    function (
        $scope,
        $state,
        $stateParams,
        $rootScope,
        miAppProperties,
        ENV,
        cfpLoadingBar,
        miComponentRoute,
        Idle,
        miLocale,
        miAppFactory,
        miStageFactory) {

        Idle.unwatch();
        $scope.OrgCode = $stateParams.org;
        $scope.currtheme = miAppProperties.gettheme();
        $scope.pageClass = 'page-main';
        $scope.$parent.mainclass = "mi-shell__content mobile-content";
        $scope.$parent.spaceclass = "";
        $rootScope.appBodyTheme = "mi-app-body";
        $scope.session = function () {
            return miAppProperties.getsessionexpired();
        }
        $scope.Back_Btn_Class = miAppProperties.getBackButtonCss();

        miAppProperties.setislandingpage(false);
        $scope.next = function () {
            ga('send', 'event', 'Navigation', 'Button click', 'Lets get started.');
            cfpLoadingBar.start();
            miAppProperties.setsessionexpired(false);
            miAppProperties.ClearUserIdentificationLoginKeyDetails();
            miAppFactory.getIdentificationFields(miAppProperties.getorgcode(), miLocale.getLocaleCode())
                                        .then(function (identificationfieldsresponse) {
                                            if (identificationfieldsresponse.route) {
                                                cfpLoadingBar.complete();
                                                $state.go(miComponentRoute.getComponentroute(identificationfieldsresponse.route));
                                            }
                                            else {
                                                miStageFactory.getNextStage(miAppProperties.getorgcode(), ENV.APP_VERSION, miAppProperties.getStageOrder(), miLocale.getLocaleCode())
                                                .then(function (nextstageresponse) {
                                                    cfpLoadingBar.complete();
                                                    if (nextstageresponse.route) {
                                                        $state.go(miComponentRoute.getComponentroute(nextstageresponse.route));
                                                    }
                                                });
                                            }
                                        });
                                 
                            }
    });
}(angular));