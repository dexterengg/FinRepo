﻿describe('MFNOL AngularJS Controller (Inro1 Controller)', function () {

    var $httpBackend, $scope, $controller;
    var expectedDetail = {
        theme: "M2",
        orgcode: "M2",
        animationclass: "page-main",
        language: "en-US",
        DocID: 123,
        stageType: "fake-Stage",
        stageDesc: "fake-stageDesc",
        pageName: "fake-pageName",
        UserIdentificationdata: "UserIdentificationdata",
        totalNumOfStages: 6,
        stageUiOrder: 2,
        islandingpage: false,
        sessionexpired: true,
        appBodyTheme: "mi-app-body",
        getIdentificationFields: true,
        getorgcode: true,
        getLocaleCode: true,
        getIdentificationFields: true,
        backbuttoncss: "clickable_Back_Btn",
    };
    // Mocked Service
    angular.module('mock.confirmationdata1', [])
        .factory('miAppProperties', function ($q) {

            var constant = {};
            constant.gettheme = function () {
                return expectedDetail.theme;
            };
            constant.getorgcode = function () {
                return expectedDetail.orgcode;
            };
            constant.getanimationclass = function () {
                return expectedDetail.animationclass;
            };
            constant.getlanguage = function () {
                return expectedDetail.language;
            };
            constant.getDocID = function () {
                return expectedDetail.DocID;
            };
            constant.getstageType = function () {
                return expectedDetail.stageType;
            };
            constant.getstageDesc = function () {
                return expectedDetail.stageDesc;
            };
            constant.getpageName = function () {
                return expectedDetail.pageName;
            };
            constant.setisConfirmed = function () {
                return expectedDetail.isConfirmed;
            };
            constant.setDocID = function (DocID) {
                return expectedDetail.DocID;
            };
            constant.getUserIdentificationdata = function () {
                return expectedDetail.UserIdentificationdata;
            };
            constant.gettotalNumOfStages = function () {
                return expectedDetail.totalNumOfStages;
            };
            constant.getstageUiOrder = function () {
                return expectedDetail.stageUiOrder;
            };
            constant.setislandingpage = function (islandingpage) {
                expectedDetail.islandingpage = islandingpage;
            };
            constant.getsessionexpired = function () {
                return expectedDetail.sessionexpired;
            };
            constant.getorgcode = function () {
                return expectedDetail.getorgcode;
            };
            constant.getLocaleCode = function () {
                return expectedDetail.getLocaleCode;
            };
            constant.getBackButtonCss = function () {
		        return expectedDetail.backbuttoncss;
		        };
            // example stub method that returns a promise, e.g. if original method returned $http.get(...)
            constant.fetch = function () {
                var mockUser = "M2";
                return $q.when(mockUser);
            };
            // other stubbed methods
            return constant;
        })

    describe('landingPage1_Controller_Test_for_currentTheme', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.confirmationdata1'));
        beforeEach(inject(function (_$controller_, $rootScope, _miAppProperties_) { // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('Intro1Ctrl', {
                $scope: scope,
                miAppProperties: _miAppProperties_
            });

        }));

        it('ensure current theme is not null', function () {
            expect(scope.currtheme).not.toBe(null);
        })
        it('ensure current theme is M2', function () {
            expect(scope.currtheme).toBe(expectedDetail.theme);
        });
        it('ensure animation class is not null', function () {
            expect(scope.pageClass).not.toBe(null);
        });

        it('ensure default page class name', function () {
            expect(scope.pageClass).toBe('page-main');
        });

        it('ensure appBodyTheme class is not null', function () {
            expect(scope.appBodyTheme).not.toBe(null);
        });

        it('ensure appBodyTheme class is mi-app-body', function () {
            expect(scope.appBodyTheme).toBe(expectedDetail.appBodyTheme);
        });
        it('ensure back button css is clickable', function () {
            expect(scope.Back_Btn_Class).toBe(expectedDetail.backbuttoncss);
            });

    });
    describe('landingPage1_Controller_Test_for_OrgCode', function () {
        var ctrl, scope;
        beforeEach(module('mi.mfnol.web'));
        // include previous module containing mocked service which will override actual service, because it's declared later
        beforeEach(module('mock.confirmationdata1'));
        beforeEach(inject(function (_$controller_, $rootScope, _miAppFactory_) {
            // inject mocked service
            scope = $rootScope.$new();
            $controller = _$controller_;
            ctrl = $controller('Intro1Ctrl', {
                $scope: scope,
                miAppFactory: _miAppFactory_
            });
        }));
        it('ensure current OrgCode is not null', function () {
            expect(scope.OrgCode).not.toBe(null);
        });
        it('ensure current theme is M2', function () {
            expect(scope.OrgCode).toBe(expectedDetail.OrgCode);
        });
    });




    describe('landingPage1_session()_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        var sce, miCMSFactory, miStageFactory, miUiStagesProgressbar
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $controller = $injector.get('$controller');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
            });
        });


        it('should session ', function () {
            $controller('Intro1Ctrl', { $scope: $scope, $state: $state });
            $scope.session();
            expect(expectedDetail.sessionexpired).toBe(true);
        });

    });



    describe('landingPage1_Next()_Funtion_Test', function () {
        beforeEach(module('mi.mfnol.web'));
        var sce, miCMSFactory, miStageFactory, miUiStagesProgressbar, miAppFactory
        beforeEach(function () {
            inject(function ($injector) {
                $rootScope = $injector.get('$rootScope');
                $controller = $injector.get('$controller');
                $scope = $injector.get('$rootScope').$new();
                $state = $injector.get('$state');
                miAppFactory = $injector.get('miAppFactory');
                miStageFactory = $injector.get('miStageFactory');
            });
        });

        it('should call miAppFactory getIdentificationFields with error', inject(function () {
            $controller('Intro1Ctrl', {
                $scope: $scope, $state: $state, miAppFactory: miAppFactory, miUiStagesProgressbar: miUiStagesProgressbar
            });
            spyOn(miAppFactory, 'getIdentificationFields').and.callFake(function () {
                return $.Deferred().resolve({
                    route: 400
                });
            });
            $scope.next();
            expect(miAppFactory.getIdentificationFields).toHaveBeenCalled();
        }));


        it('should call miAppFactory getIdentificationFields with success', inject(function () {
            $controller('Intro1Ctrl', {
                $scope: $scope, $state: $state, miAppFactory: miAppFactory, miStageFactory: miStageFactory, miUiStagesProgressbar: miUiStagesProgressbar
            });
            spyOn(miAppFactory, 'getIdentificationFields').and.callFake(function () {
                return $.Deferred().resolve({
                    route: ""
                });
            });
            spyOn(miStageFactory, 'getNextStage').and.callFake(function () {
                return $.Deferred().resolve({
                    route: 400
                });
            });
            $scope.next();
            expect(miAppFactory.getIdentificationFields).toHaveBeenCalled();
            expect(miStageFactory.getNextStage).toHaveBeenCalled();
        }));
    });



});
